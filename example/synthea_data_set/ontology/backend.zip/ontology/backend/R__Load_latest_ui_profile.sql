--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: context; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.context (id, system, code, version, display) FROM stdin;
1	fdpg.mii.synthea	AllergyIntolerance	1.0.0	AllergyIntolerance
2	fdpg.mii.synthea	Procedure	1.0.0	Prozedur
3	fdpg.mii.synthea	Patient	1.0.0	Patient
4	fdpg.mii.synthea	Diagnose	1.0.0	Diagnose
5	fdpg.mii.synthea	Laboruntersuchung	1.0.0	Laboruntersuchung
6	fdpg.mii.cds	Patient	1.0.0	Patient
7	fdpg.mii.synthea	Medikamentenverabreichung	1.0.0	Verabreichung von Medikamenten
\.


--
-- Data for Name: mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapping (id, name, type, content) FROM stdin;
\.


--
-- Data for Name: termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.termcode (id, system, code, version, display) FROM stdin;
1	http://snomed.info/sct	359672006	http://snomed.info/sct/900000000000207008/version/20230430	Median sternotomy (procedure)
2	http://loinc.org	6273-7		Walnut IgE Ab [Units/volume] in Serum
3	http://www.nlm.nih.gov/research/umls/rxnorm	691028	0.0.1	calcium gluconate / niacinamide / phenobarbital
4	http://www.nlm.nih.gov/research/umls/rxnorm	1365660	0.0.1	24 HR oxcarbazepine 150 MG Extended Release Oral Tablet [Oxtellar]
5	http://snomed.info/sct	385798007	http://snomed.info/sct/900000000000207008/version/20230430	Radiation therapy care (regime/therapy)
6	http://www.nlm.nih.gov/research/umls/rxnorm	830847	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Cardizem]
7	http://www.nlm.nih.gov/research/umls/rxnorm	1670353	0.0.1	5 ML phenytoin sodium 50 MG/ML Injection
8	http://snomed.info/sct	111287006	http://snomed.info/sct/900000000000207008/version/20230430	Tricuspid valve regurgitation (disorder)
9	http://www.nlm.nih.gov/research/umls/rxnorm	996740	0.0.1	Memantine hydrochloride 2 MG/ML Oral Solution
10	http://snomed.info/sct	762998009	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using New York Heart Association Classification (procedure)
11	http://www.nlm.nih.gov/research/umls/rxnorm	1361402	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Backaid IPF]
12	http://snomed.info/sct	36955009	http://snomed.info/sct/900000000000207008/version/20230430	Loss of taste (finding)
13	http://www.nlm.nih.gov/research/umls/rxnorm	1872085	0.0.1	aspirin 500 MG / citric acid 1000 MG / sodium bicarbonate 1985 MG Granules for Oral Solution
14	http://www.nlm.nih.gov/research/umls/rxnorm	1719286	0.0.1	10 ML Furosemide 10 MG/ML Injection
15	http://www.nlm.nih.gov/research/umls/rxnorm	831296	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Tiazac]
16	http://www.nlm.nih.gov/research/umls/rxnorm	860182	0.0.1	rimabotulinumtoxinB 5000 UNT/ML [Myobloc]
17	http://www.nlm.nih.gov/research/umls/rxnorm	317150	0.0.1	ritonavir 100 MG Oral Capsule
18	http://www.nlm.nih.gov/research/umls/rxnorm	686419	0.0.1	erythromycin ethylsuccinate 80 MG/ML [EryPed]
19	http://loinc.org	10480-2		Estrogen+Progesterone receptor Ag [Presence] in Tissue by Immune stain
20	http://www.nlm.nih.gov/research/umls/rxnorm	797541	0.0.1	isopropyl alcohol
21	http://www.nlm.nih.gov/research/umls/rxnorm	669119	0.0.1	aspirin / diphenhydramine
22	http://www.nlm.nih.gov/research/umls/rxnorm	2286257	0.0.1	dexamethasone 20 MG [Hemady]
23	http://www.nlm.nih.gov/research/umls/rxnorm	310798	0.0.1	Hydrochlorothiazide 25 MG Oral Tablet
24	http://www.nlm.nih.gov/research/umls/rxnorm	686402	0.0.1	erythromycin ethylsuccinate 40 MG/ML Oral Suspension [EryPed]
25	http://www.nlm.nih.gov/research/umls/rxnorm	323964	0.0.1	rifampin 600 MG
26	http://snomed.info/sct	390791001	http://snomed.info/sct/900000000000207008/version/20230430	Referral for echocardiography (procedure)
27	http://www.nlm.nih.gov/research/umls/rxnorm	312962	0.0.1	simvastatin 5 MG Oral Tablet
28	http://www.nlm.nih.gov/research/umls/rxnorm	897625	0.0.1	verapamil hydrochloride 240 MG [Verelan]
29	http://www.nlm.nih.gov/research/umls/rxnorm	9384	0.0.1	rifampin
30	http://www.nlm.nih.gov/research/umls/rxnorm	598008	0.0.1	erythromycin 250 MG Oral Capsule
31	http://www.nlm.nih.gov/research/umls/rxnorm	106876	0.0.1	isoniazid / rifampin
32	http://www.nlm.nih.gov/research/umls/rxnorm	1988329	0.0.1	diltiazem hydrochloride 420 MG [Tiadylt]
33	http://snomed.info/sct	86964003	http://snomed.info/sct/900000000000207008/version/20230430	Sweat Test
34	http://www.nlm.nih.gov/research/umls/rxnorm	2119714	0.0.1	5 ML hyaluronidase-oysk 2000 UNT/ML / trastuzumab 120 MG/ML Injection
35	http://snomed.info/sct	119481000119105	http://snomed.info/sct/900000000000207008/version/20230430	History of aortic valve repair (situation)
36	http://snomed.info/sct	713197008	http://snomed.info/sct/900000000000207008/version/20230430	Recurrent rectal polyp
37	http://www.nlm.nih.gov/research/umls/rxnorm	2639748	0.0.1	hydrocortisone 10 MG/ML / ketoconazole 1.5 MG/ML Otic Solution [Malacetic]
38	http://www.nlm.nih.gov/research/umls/rxnorm	690790	0.0.1	aminophylline / ephedrine / phenobarbital / potassium iodide
39	http://snomed.info/sct	252482003	http://snomed.info/sct/900000000000207008/version/20230430	Stair-climbing test (procedure)
40	http://www.nlm.nih.gov/research/umls/rxnorm	994226	0.0.1	aspirin 325 MG / carisoprodol 200 MG / codeine phosphate 16 MG Oral Tablet
41	http://www.nlm.nih.gov/research/umls/rxnorm	1486452	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet) / 7 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Wymzya Fe 28 Day]
42	http://www.nlm.nih.gov/research/umls/rxnorm	309682	0.0.1	dexamethasone 0.001 MG/MG / tobramycin 0.003 MG/MG Ophthalmic Ointment
43	http://loinc.org	84215-3		Mental health Telehealth Note
44	http://www.nlm.nih.gov/research/umls/rxnorm	198089	0.0.1	phenobarbital 60 MG Oral Tablet
45	http://snomed.info/sct	10383002	http://snomed.info/sct/900000000000207008/version/20230430	Counseling for termination of pregnancy
46	http://www.nlm.nih.gov/research/umls/rxnorm	204892	0.0.1	clonazePAM 0.25 MG Oral Tablet
47	http://www.nlm.nih.gov/research/umls/rxnorm	567075	0.0.1	erythromycin 0.02 MG/MG [Erygel]
48	http://snomed.info/sct	735029006	http://snomed.info/sct/900000000000207008/version/20230430	Shellfish (substance)
49	http://loinc.org	55277-8		HIV status
50	http://snomed.info/sct	418824004	http://snomed.info/sct/900000000000207008/version/20230430	Off-pump coronary artery bypass (procedure)
51	http://www.nlm.nih.gov/research/umls/rxnorm	831322	0.0.1	diltiazem hydrochloride 300 MG [Tiazac]
52	http://www.nlm.nih.gov/research/umls/rxnorm	904664	0.0.1	{30 (aspirin 325 MG Oral Tablet) / 30 (pravastatin sodium 80 MG Oral Tablet) } Pack
53	http://www.nlm.nih.gov/research/umls/rxnorm	1791240	0.0.1	diltiazem hydrochloride 100 MG Injection
54	http://www.nlm.nih.gov/research/umls/rxnorm	855936	0.0.1	phenytoin sodium 25 MG Oral Capsule
55	http://snomed.info/sct	198992004	http://snomed.info/sct/900000000000207008/version/20230430	Antepartum eclampsia
56	http://www.nlm.nih.gov/research/umls/rxnorm	830882	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Tablet
57	http://www.nlm.nih.gov/research/umls/rxnorm	432638	0.0.1	acetaminophen 250 MG / aspirin 250 MG Oral Tablet
58	http://snomed.info/sct	418891003	http://snomed.info/sct/900000000000207008/version/20230430	Computed tomography of chest and abdomen
59	http://www.nlm.nih.gov/research/umls/rxnorm	749795	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [St. Joseph Aspirin]
60	http://snomed.info/sct	410011004	http://snomed.info/sct/900000000000207008/version/20230430	Administration of anesthesia AND/OR sedation (procedure)
61	http://www.nlm.nih.gov/research/umls/rxnorm	1536148	0.0.1	120 ACTUAT mometasone furoate 0.2 MG/ACTUAT Metered Dose Inhaler [Asmanex]
62	http://www.nlm.nih.gov/research/umls/rxnorm	567511	0.0.1	isoniazid 50 MG / pyrazinamide 300 MG / rifampin 120 MG [Rifater]
63	http://www.nlm.nih.gov/research/umls/rxnorm	198480	0.0.1	aspirin 500 MG / caffeine 32 MG Oral Tablet
64	http://www.nlm.nih.gov/research/umls/rxnorm	1720314	0.0.1	erythromycin lactobionate 500 MG [Erythrocin]
65	http://www.nlm.nih.gov/research/umls/rxnorm	1095224	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet) / 7 (ferrous fumarate 75 MG Chewable Tablet) } Pack
66	http://www.nlm.nih.gov/research/umls/rxnorm	566956	0.0.1	erythromycin 500 MG [Ery-Tab]
67	http://www.nlm.nih.gov/research/umls/rxnorm	831285	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Dilt]
68	http://snomed.info/sct	169553002	http://snomed.info/sct/900000000000207008/version/20230430	Insertion of subcutaneous contraceptive (procedure)
69	http://www.nlm.nih.gov/research/umls/rxnorm	1251326	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG [Femhrt]
70	http://www.nlm.nih.gov/research/umls/rxnorm	748879	0.0.1	Levora 0.15/30 28 Day Pack
71	http://www.nlm.nih.gov/research/umls/rxnorm	1722680	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Blisovi 24 Fe 1/20 28 Day]
72	http://snomed.info/sct	224299000	http://snomed.info/sct/900000000000207008/version/20230430	Received higher education (finding)
73	http://www.nlm.nih.gov/research/umls/rxnorm	994537	0.0.1	aspirin 770 MG / caffeine 60 MG / orphenadrine citrate 50 MG Oral Tablet [Norgesic]
74	http://www.nlm.nih.gov/research/umls/rxnorm	1001476	0.0.1	aspirin 325 MG Delayed Release Oral Tablet [Ecpirin]
75	http://www.nlm.nih.gov/research/umls/rxnorm	1189780	0.0.1	aspirin 81 MG [Ecotrin]
76	http://www.nlm.nih.gov/research/umls/rxnorm	2626485	0.0.1	pentobarbital sodium 390 MG/ML / phenytoin sodium 50 MG/ML Injectable Solution [Euthaphen]
77	http://www.nlm.nih.gov/research/umls/rxnorm	312363	0.0.1	phenobarbital 32 MG Oral Tablet
78	http://www.nlm.nih.gov/research/umls/rxnorm	1358776	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack
79	http://snomed.info/sct	305351004	http://snomed.info/sct/900000000000207008/version/20230430	Admission to intensive care unit (procedure)
80	http://www.nlm.nih.gov/research/umls/rxnorm	892159	0.0.1	aspirin 3900 MG
81	http://loinc.org	72514-3		Pain severity - 0-10 verbal numeric rating [Score] - Reported
82	http://www.nlm.nih.gov/research/umls/rxnorm	1870230	0.0.1	NDA020800 0.3 ML Epinephrine 1 MG/ML Auto-Injector
83	http://www.nlm.nih.gov/research/umls/rxnorm	329547	0.0.1	aspirin 228 MG
84	http://www.nlm.nih.gov/research/umls/rxnorm	211891	0.0.1	aspirin 500 MG Oral Tablet [Norwich Aspirin]
85	http://www.nlm.nih.gov/research/umls/rxnorm	214254	0.0.1	aspirin / meprobamate
86	http://snomed.info/sct	225297008	http://snomed.info/sct/900000000000207008/version/20230430	Care planning and problem solving actions (procedure)
87	http://www.nlm.nih.gov/research/umls/rxnorm	898346	0.0.1	amlodipine 10 MG / benazepril hydrochloride 40 MG Oral Capsule
88	http://www.nlm.nih.gov/research/umls/rxnorm	197577	0.0.1	dexamethasone 0.5 MG Oral Tablet
89	http://www.nlm.nih.gov/research/umls/rxnorm	866508	0.0.1	5 ML metoprolol tartrate 1 MG/ML Injection
90	http://snomed.info/sct	180030006	http://snomed.info/sct/900000000000207008/version/20230430	Amputation of left foot
91	http://snomed.info/sct	171126009	http://snomed.info/sct/900000000000207008/version/20230430	Tuberculosis screening (procedure)
92	http://www.nlm.nih.gov/research/umls/rxnorm	1091632	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Tablet [Matzim]
93	http://www.nlm.nih.gov/research/umls/rxnorm	890957	0.0.1	erythromycin 0.0053 MG/ML Topical Solution [Maracyn]
94	http://www.nlm.nih.gov/research/umls/rxnorm	2556800	0.0.1	estradiol 1 MG / norethindrone acetate 0.5 MG / relugolix 40 MG Oral Tablet [Myfembree]
95	http://snomed.info/sct	301882004	http://snomed.info/sct/900000000000207008/version/20230430	Placement of aortic cross clamp (procedure)
96	http://www.nlm.nih.gov/research/umls/rxnorm	207436	0.0.1	rifampin 600 MG Injection [Rifadin]
97	http://snomed.info/sct	80394007	http://snomed.info/sct/900000000000207008/version/20230430	Hyperglycemia (disorder)
98	http://snomed.info/sct	44301001	http://snomed.info/sct/900000000000207008/version/20230430	Suicide
99	http://www.nlm.nih.gov/research/umls/rxnorm	2106644	0.0.1	itraconazole 65 MG [Tolsura]
100	http://www.nlm.nih.gov/research/umls/rxnorm	238100	0.0.1	Lorazepam 2 MG/ML Injectable Solution
101	http://www.nlm.nih.gov/research/umls/rxnorm	861356	0.0.1	0.8 ML fondaparinux sodium 12.5 MG/ML Prefilled Syringe
102	http://snomed.info/sct	93761005	http://snomed.info/sct/900000000000207008/version/20230430	Primary malignant neoplasm of colon
103	http://snomed.info/sct	5880005	http://snomed.info/sct/900000000000207008/version/20230430	Physical examination procedure (procedure)
104	http://www.nlm.nih.gov/research/umls/rxnorm	898340	0.0.1	verapamil hydrochloride 180 MG Oral Capsule
105	http://loinc.org	44667-4		Site of distant metastasis in Breast tumor
106	http://www.nlm.nih.gov/research/umls/rxnorm	891134	0.0.1	aspirin 15600 MG Oral Tablet
107	http://www.nlm.nih.gov/research/umls/rxnorm	999999	0.0.1	Lenzilumab 200 MG IV
108	http://www.nlm.nih.gov/research/umls/rxnorm	31565	0.0.1	nefazodone
109	http://www.nlm.nih.gov/research/umls/rxnorm	2588848	0.0.1	levoketoconazole 150 MG Oral Tablet
110	http://www.nlm.nih.gov/research/umls/rxnorm	849859	0.0.1	diltiazem malate 240 MG
111	http://www.nlm.nih.gov/research/umls/rxnorm	2371768	0.0.1	{28 (elagolix 300 MG / estradiol 1 MG / norethindrone 0.5 MG Oral Capsule) / 28 (elagolix 300 MG Oral Capsule) } Pack [Oriahnn 28 Day Kit]
112	http://loinc.org	6206-7		Peanut IgE Ab [Units/volume] in Serum
113	http://www.nlm.nih.gov/research/umls/rxnorm	1808217	0.0.1	100 ML Propofol 10 MG/ML Injection
114	http://snomed.info/sct	66931009	http://snomed.info/sct/900000000000207008/version/20230430	Hypercalcemia (disorder)
115	http://snomed.info/sct	221360009	http://snomed.info/sct/900000000000207008/version/20230430	Spasticity (finding)
116	http://www.nlm.nih.gov/research/umls/rxnorm	316385	0.0.1	norethindrone 0.35 MG
117	http://www.nlm.nih.gov/research/umls/rxnorm	205532	0.0.1	Pulmozyme (Dornase Alfa)
118	http://snomed.info/sct	12719002	http://snomed.info/sct/900000000000207008/version/20230430	Platelet transfusion (procedure)
119	http://www.nlm.nih.gov/research/umls/rxnorm	898367	0.0.1	benazepril hydrochloride 20 MG / hydrochlorothiazide 12.5 MG Oral Tablet
120	http://www.nlm.nih.gov/research/umls/rxnorm	566954	0.0.1	erythromycin 333 MG [Ery-Tab]
121	http://www.nlm.nih.gov/research/umls/rxnorm	3443	0.0.1	diltiazem
122	http://snomed.info/sct	368581000119106	http://snomed.info/sct/900000000000207008/version/20230430	Neuropathy due to type 2 diabetes mellitus (disorder)
123	http://snomed.info/sct	105531004	http://snomed.info/sct/900000000000207008/version/20230430	Housing unsatisfactory (finding)
124	http://www.nlm.nih.gov/research/umls/rxnorm	749785	0.0.1	Ortho Tri-Cyclen 28 Day Pack
125	http://snomed.info/sct	127013003	http://snomed.info/sct/900000000000207008/version/20230430	Disorder of kidney due to diabetes mellitus (disorder)
126	http://www.nlm.nih.gov/research/umls/rxnorm	1926946	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Aurovela Fe 1/20 28 Day]
127	http://www.nlm.nih.gov/research/umls/rxnorm	1424021	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo [Vital-Ketodine]
128	http://snomed.info/sct	392247006	http://snomed.info/sct/900000000000207008/version/20230430	Insertion of catheter into artery (procedure)
129	http://www.nlm.nih.gov/research/umls/rxnorm	1550536	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Tarina Fe 1/20 28 Day]
130	http://www.nlm.nih.gov/research/umls/rxnorm	308182	0.0.1	Amoxicillin 250 MG Oral Capsule
131	http://snomed.info/sct	67879005	http://snomed.info/sct/900000000000207008/version/20230430	History and physical examination, limited (procedure)
132	http://www.nlm.nih.gov/research/umls/rxnorm	574308	0.0.1	aspirin 325 MG [Bufferin]
133	http://snomed.info/sct	39898005	http://snomed.info/sct/900000000000207008/version/20230430	Sleep disorder (disorder)
134	http://www.nlm.nih.gov/research/umls/rxnorm	1422896	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Jencycla 28 Day]
135	http://www.nlm.nih.gov/research/umls/rxnorm	216525	0.0.1	dexamethasone / neomycin / polymyxin B
136	http://www.nlm.nih.gov/research/umls/rxnorm	335993	0.0.1	aspirin 210 MG
137	http://snomed.info/sct	239873007	http://snomed.info/sct/900000000000207008/version/20230430	Osteoarthritis of knee
138	http://snomed.info/sct	58150001	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of clavicle
139	http://www.nlm.nih.gov/research/umls/rxnorm	330392	0.0.1	oxcarbazepine 300 MG
140	http://www.nlm.nih.gov/research/umls/rxnorm	1009121	0.0.1	calcium carbonate / phenytoin
141	http://snomed.info/sct	39621005	http://snomed.info/sct/900000000000207008/version/20230430	Disorder of gallbladder (disorder)
142	http://www.nlm.nih.gov/research/umls/rxnorm	855871	0.0.1	phenytoin sodium 30 MG Extended Release Oral Capsule [Dilantin]
143	http://www.nlm.nih.gov/research/umls/rxnorm	1092683	0.0.1	chloroxylenol 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo [Pharmaseb]
144	http://www.nlm.nih.gov/research/umls/rxnorm	857121	0.0.1	aspirin 500 MG / hydrocodone bitartrate 5 MG Oral Tablet
145	http://snomed.info/sct	34043003	http://snomed.info/sct/900000000000207008/version/20230430	Dental consultation and report (procedure)
146	http://www.nlm.nih.gov/research/umls/rxnorm	1536680	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1916 MG Effervescent Oral Tablet [Alka-Seltzer]
147	http://www.nlm.nih.gov/research/umls/rxnorm	1009150	0.0.1	dexamethasone / sodium phosphate
148	http://www.nlm.nih.gov/research/umls/rxnorm	689512	0.0.1	aspirin / caffeine / dihydrocodeine
149	http://www.nlm.nih.gov/research/umls/rxnorm	309692	0.0.1	dexamethasone 1 MG/ML Ophthalmic Suspension
150	http://www.nlm.nih.gov/research/umls/rxnorm	897617	0.0.1	verapamil hydrochloride 180 MG
151	http://www.nlm.nih.gov/research/umls/rxnorm	830796	0.0.1	diltiazem hydrochloride 360 MG [Cardizem]
152	http://snomed.info/sct	90226004	http://snomed.info/sct/900000000000207008/version/20230430	Cytopathology procedure, preparation of smear, genital source (procedure)
153	http://www.nlm.nih.gov/research/umls/rxnorm	1359130	0.0.1	ethinyl estradiol 0.03 MG / norethindrone acetate 1 MG Oral Tablet
154	http://www.nlm.nih.gov/research/umls/rxnorm	1537336	0.0.1	chlorhexidine gluconate 10 MG/ML / ketoconazole 2.5 MG/ML Topical Spray
155	http://www.nlm.nih.gov/research/umls/rxnorm	198014	0.0.1	Naproxen 500 MG Oral Tablet
156	http://www.nlm.nih.gov/research/umls/rxnorm	1363309	0.0.1	Chlorpheniramine Maleate 4 MG Oral Tablet
157	http://www.nlm.nih.gov/research/umls/rxnorm	1291868	0.0.1	aspirin 325 MG / diphenhydramine citrate 38 MG Oral Tablet
158	http://www.nlm.nih.gov/research/umls/rxnorm	1098669	0.0.1	nefazodone hydrochloride 200 MG
159	http://www.nlm.nih.gov/research/umls/rxnorm	317461	0.0.1	phenobarbital 32 MG
160	http://www.nlm.nih.gov/research/umls/rxnorm	1365844	0.0.1	24 HR oxcarbazepine 600 MG Extended Release Oral Tablet
161	http://www.nlm.nih.gov/research/umls/rxnorm	197579	0.0.1	dexamethasone 1 MG Oral Tablet
162	http://snomed.info/sct	232717009	http://snomed.info/sct/900000000000207008/version/20230430	Coronary artery bypass grafting (procedure)
163	http://www.nlm.nih.gov/research/umls/rxnorm	1998481	0.0.1	{49 (dexamethasone 1.5 MG Oral Tablet) } Pack [TaperDex 12 Day Taper]
164	http://www.nlm.nih.gov/research/umls/rxnorm	833164	0.0.1	itraconazole 100 MG Oral Capsule [Sporanox]
165	http://snomed.info/sct	95417003	http://snomed.info/sct/900000000000207008/version/20230430	Primary fibromyalgia syndrome
166	http://www.nlm.nih.gov/research/umls/rxnorm	1046923	0.0.1	atropine sulfate 0.00388 MG/ML / hyoscyamine sulfate 0.0207 MG/ML / phenobarbital 3.24 MG/ML / scopolamine hydrobromide 0.0013 MG/ML [Donnatal]
167	http://www.nlm.nih.gov/research/umls/rxnorm	214251	0.0.1	aspirin / carisoprodol
168	http://www.nlm.nih.gov/research/umls/rxnorm	597455	0.0.1	clarithromycin 1000 MG Extended Release Oral Tablet
169	http://www.nlm.nih.gov/research/umls/rxnorm	330393	0.0.1	oxcarbazepine 600 MG
170	http://www.nlm.nih.gov/research/umls/rxnorm	210864	0.0.1	acetaminophen 115 MG / aspirin 210 MG / caffeine 16 MG / salicylamide 65 MG Oral Tablet [Saleto]
171	http://www.nlm.nih.gov/research/umls/rxnorm	37882	0.0.1	difebarbamate / febarbamate / phenobarbital
172	http://loinc.org	85337-4		Estrogen receptor Ag [Presence] in Breast cancer specimen by Immune stain
173	http://www.nlm.nih.gov/research/umls/rxnorm	308417	0.0.1	aspirin 975 MG Delayed Release Oral Tablet
174	http://snomed.info/sct	306185001	http://snomed.info/sct/900000000000207008/version/20230430	Referral to cardiac surgery service (procedure)
175	http://www.nlm.nih.gov/research/umls/rxnorm	2001499	0.0.1	Vitamin B12 5 MG/ML Injectable Solution
176	http://www.nlm.nih.gov/research/umls/rxnorm	483438	0.0.1	pregabalin 100 MG Oral Capsule
177	http://www.nlm.nih.gov/research/umls/rxnorm	1007240	0.0.1	acetiamine / aspirin
178	http://www.nlm.nih.gov/research/umls/rxnorm	859088	0.0.1	NDA020983 200 ACTUAT albuterol 0.09 MG/ACTUAT Metered Dose Inhaler [Ventolin]
179	http://www.nlm.nih.gov/research/umls/rxnorm	855670	0.0.1	phenytoin sodium 100 MG
180	http://snomed.info/sct	763302001	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using Alcohol Use Disorders Identification Test - Consumption (procedure)
181	http://snomed.info/sct	177765008	http://snomed.info/sct/900000000000207008/version/20230430	Opening of chest (procedure)
182	http://www.nlm.nih.gov/research/umls/rxnorm	1087756	0.0.1	dexamethasone 2 MG/ML [Dexasone]
183	http://snomed.info/sct	448813005	http://snomed.info/sct/900000000000207008/version/20230430	Sepsis caused by Pseudomonas (disorder)
184	http://www.nlm.nih.gov/research/umls/rxnorm	336345	0.0.1	phenobarbital 40 MG
185	http://snomed.info/sct	387713003	http://snomed.info/sct/900000000000207008/version/20230430	Surgical procedure (procedure)
186	http://snomed.info/sct	195662009	http://snomed.info/sct/900000000000207008/version/20230430	Acute viral pharyngitis (disorder)
187	http://www.nlm.nih.gov/research/umls/rxnorm	1652673	0.0.1	Doxycycline Monohydrate 50 MG Oral Tablet
188	http://www.nlm.nih.gov/research/umls/rxnorm	819659	0.0.1	aspirin / papain
189	http://loinc.org	7258-7		Cow milk IgE Ab [Units/volume] in Serum
190	http://www.nlm.nih.gov/research/umls/rxnorm	1046815	0.0.1	atropine sulfate 0.0194 MG / hyoscyamine sulfate 0.1037 MG / phenobarbital 16.2 MG / scopolamine hydrobromide 0.0065 MG Oral Tablet
191	http://www.nlm.nih.gov/research/umls/rxnorm	2106648	0.0.1	itraconazole 65 MG Oral Capsule [Tolsura]
192	http://www.nlm.nih.gov/research/umls/rxnorm	20489	0.0.1	cefpodoxime
193	http://snomed.info/sct	236974004	http://snomed.info/sct/900000000000207008/version/20230430	Instrumental delivery
194	http://www.nlm.nih.gov/research/umls/rxnorm	904458	0.0.1	pravastatin sodium 10 MG Oral Tablet
195	http://www.nlm.nih.gov/research/umls/rxnorm	1665060	0.0.1	cefazolin 2000 MG Injection
196	http://www.nlm.nih.gov/research/umls/rxnorm	10612	0.0.1	tinidazole
197	http://www.nlm.nih.gov/research/umls/rxnorm	572210	0.0.1	aspirin 325 MG [Norwich Aspirin]
198	http://snomed.info/sct	278365007	http://snomed.info/sct/900000000000207008/version/20230430	Anticoagulant-induced bleeding (disorder)
199	http://www.nlm.nih.gov/research/umls/rxnorm	1665057	0.0.1	2 ML verapamil hydrochloride 2.5 MG/ML Injection
200	http://www.nlm.nih.gov/research/umls/rxnorm	1811631	0.0.1	aspirin 81 MG / omeprazole 40 MG Delayed Release Oral Tablet
201	http://www.nlm.nih.gov/research/umls/rxnorm	1811916	0.0.1	aspirin 325 MG / omeprazole 40 MG Delayed Release Oral Tablet [Yosprala]
202	http://www.nlm.nih.gov/research/umls/rxnorm	1729516	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Blisovi 21 Fe 1.5/30 28 Day Pack]
203	http://www.nlm.nih.gov/research/umls/rxnorm	329729	0.0.1	erythromycin 15 MG/ML
204	http://snomed.info/sct	90407005	http://snomed.info/sct/900000000000207008/version/20230430	Evaluation of psychiatric state of patient
205	http://www.nlm.nih.gov/research/umls/rxnorm	315433	0.0.1	aspirin 975 MG
206	http://www.nlm.nih.gov/research/umls/rxnorm	573988	0.0.1	modafinil 100 MG [Provigil]
207	http://snomed.info/sct	65588006	http://snomed.info/sct/900000000000207008/version/20230430	Premature birth of newborn
208	http://snomed.info/sct	252160004	http://snomed.info/sct/900000000000207008/version/20230430	Standard pregnancy test
209	http://www.nlm.nih.gov/research/umls/rxnorm	897705	0.0.1	verapamil hydrochloride 2.5 MG/ML
210	http://snomed.info/sct	287191006	http://snomed.info/sct/900000000000207008/version/20230430	Suicide - suffocation
211	http://www.nlm.nih.gov/research/umls/rxnorm	211817	0.0.1	carbamazepine 200 MG Oral Tablet [Epitol]
212	http://snomed.info/sct	229064008	http://snomed.info/sct/900000000000207008/version/20230430	Movement therapy (regime/therapy)
213	http://www.nlm.nih.gov/research/umls/rxnorm	2103182	0.0.1	1 ML Vasopressin (USP) 20 UNT/ML Injection
214	http://www.nlm.nih.gov/research/umls/rxnorm	1790099	0.0.1	10 ML Doxorubicin Hydrochloride 2 MG/ML Injection
215	http://www.nlm.nih.gov/research/umls/rxnorm	1534809	0.0.1	168 HR Ethinyl Estradiol 0.00146 MG/HR / norelgestromin 0.00625 MG/HR Transdermal System
216	http://snomed.info/sct	56018004	http://snomed.info/sct/900000000000207008/version/20230430	Wheezing (finding)
217	http://snomed.info/sct	428251008	http://snomed.info/sct/900000000000207008/version/20230430	History of appendectomy
218	http://www.nlm.nih.gov/research/umls/rxnorm	476556	0.0.1	emtricitabine 200 MG / tenofovir disoproxil fumarate 300 MG Oral Tablet
219	http://www.nlm.nih.gov/research/umls/rxnorm	728550	0.0.1	ketoconazole 20 MG/ML Topical Foam
220	http://www.nlm.nih.gov/research/umls/rxnorm	857005	0.0.1	Acetaminophen 325 MG / HYDROcodone Bitartrate 7.5 MG Oral Tablet
221	http://snomed.info/sct	698819004	http://snomed.info/sct/900000000000207008/version/20230430	Postoperative sepsis (disorder)
222	http://www.nlm.nih.gov/research/umls/rxnorm	898723	0.0.1	benazepril hydrochloride 5 MG Oral Tablet
223	http://snomed.info/sct	25064002	http://snomed.info/sct/900000000000207008/version/20230430	Headache (finding)
224	http://www.nlm.nih.gov/research/umls/rxnorm	897783	0.0.1	24 HR trandolapril 2 MG / verapamil hydrochloride 180 MG Extended Release Oral Tablet
225	http://loinc.org	59408-5		Oxygen saturation in Arterial blood by Pulse oximetry
226	http://www.nlm.nih.gov/research/umls/rxnorm	1009388	0.0.1	dexamethasone 1 MG/ML / neomycin 3.2 MG/ML / thiabendazole 40 MG/ML Topical Solution
227	http://www.nlm.nih.gov/research/umls/rxnorm	1250909	0.0.1	aspirin 500 MG / diphenhydramine citrate 38.3 MG Oral Tablet [Bayer Aspirin PM Reformulated Nov 2011]
228	http://www.nlm.nih.gov/research/umls/rxnorm	198466	0.0.1	aspirin 325 MG Oral Capsule
229	http://www.nlm.nih.gov/research/umls/rxnorm	1313886	0.0.1	phenytoin 50 MG [Dilantin]
230	http://www.nlm.nih.gov/research/umls/rxnorm	214551	0.0.1	estradiol / norethindrone
231	http://snomed.info/sct	68566005	http://snomed.info/sct/900000000000207008/version/20230430	Urinary tract infectious disease (disorder)
232	http://snomed.info/sct	431182000	http://snomed.info/sct/900000000000207008/version/20230430	Placing subject in prone position (procedure)
233	http://www.nlm.nih.gov/research/umls/rxnorm	897781	0.0.1	24 HR trandolapril 1 MG / verapamil hydrochloride 240 MG Extended Release Oral Tablet
234	http://www.nlm.nih.gov/research/umls/rxnorm	833194	0.0.1	diltiazem hydrochloride 5 MG/ML
235	http://www.nlm.nih.gov/research/umls/rxnorm	1361226	0.0.1	heparin sodium, porcine 1000 UNT/ML Injectable Solution
236	http://www.nlm.nih.gov/research/umls/rxnorm	751875	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Necon 0.5/35 28 Day]
237	http://www.nlm.nih.gov/research/umls/rxnorm	2642137	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Etyqa 1/0.5 28 Day]
238	http://snomed.info/sct	444260001	http://snomed.info/sct/900000000000207008/version/20230430	20 Gene mutation test
239	http://www.nlm.nih.gov/research/umls/rxnorm	318272	0.0.1	aspirin 81 MG Chewable Tablet
240	http://www.nlm.nih.gov/research/umls/rxnorm	573012	0.0.1	benzoyl peroxide 0.05 MG/MG / erythromycin 0.03 MG/MG [Benzamycin]
241	http://www.nlm.nih.gov/research/umls/rxnorm	1007483	0.0.1	dexamethasone / hypromellose
242	http://www.nlm.nih.gov/research/umls/rxnorm	1737466	0.0.1	100 ML tirofiban 0.05 MG/ML Injection
243	http://www.nlm.nih.gov/research/umls/rxnorm	849867	0.0.1	diltiazem hydrochloride 100 MG
244	http://www.nlm.nih.gov/research/umls/rxnorm	866307	0.0.1	12 HR carbamazepine 400 MG Extended Release Oral Tablet [Tegretol]
245	http://www.nlm.nih.gov/research/umls/rxnorm	569462	0.0.1	dexamethasone 1 MG/ML / tobramycin 3 MG/ML [Tobradex]
246	http://www.nlm.nih.gov/research/umls/rxnorm	208821	0.0.1	dexamethasone 0.001 MG/MG / tobramycin 0.003 MG/MG Ophthalmic Ointment [Tobradex]
247	http://www.nlm.nih.gov/research/umls/rxnorm	863606	0.0.1	erythromycin ethylsuccinate 400 MG Oral Tablet [E.E.S.]
248	http://www.nlm.nih.gov/research/umls/rxnorm	211310	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG Oral Capsule [Fiorinal]
249	http://snomed.info/sct	68496003	http://snomed.info/sct/900000000000207008/version/20230430	Polyp of colon
250	http://www.nlm.nih.gov/research/umls/rxnorm	1092398	0.0.1	aspirin 500 MG / diphenhydramine hydrochloride 25 MG Oral Tablet
251	http://www.nlm.nih.gov/research/umls/rxnorm	2563430	0.0.1	aspirin 81 MG [Vazalore]
252	http://snomed.info/sct	234466008	http://snomed.info/sct/900000000000207008/version/20230430	Acquired coagulation disorder (disorder)
253	http://snomed.info/sct	307731004	http://snomed.info/sct/900000000000207008/version/20230430	Injury of tendon of the rotator cuff of shoulder
254	http://www.nlm.nih.gov/research/umls/rxnorm	993770	0.0.1	Acetaminophen 300 MG / Codeine Phosphate 15 MG Oral Tablet
255	http://www.nlm.nih.gov/research/umls/rxnorm	897585	0.0.1	verapamil hydrochloride 100 MG [Verelan]
256	http://www.nlm.nih.gov/research/umls/rxnorm	617312	0.0.1	atorvastatin 10 MG Oral Tablet
257	http://snomed.info/sct	274804006	http://snomed.info/sct/900000000000207008/version/20230430	Evaluation of uterine fundal height
258	http://snomed.info/sct	395142003	http://snomed.info/sct/900000000000207008/version/20230430	Allergy screening test
259	http://www.nlm.nih.gov/research/umls/rxnorm	689529	0.0.1	aspirin / ethoheptazine / meprobamate
260	http://www.nlm.nih.gov/research/umls/rxnorm	2371763	0.0.1	elagolix / estradiol / norethindrone
261	http://www.nlm.nih.gov/research/umls/rxnorm	1251324	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG [Femhrt]
262	http://snomed.info/sct	31676001	http://snomed.info/sct/900000000000207008/version/20230430	Human immunodeficiency virus antigen test
263	http://snomed.info/sct	410401003	http://snomed.info/sct/900000000000207008/version/20230430	Nursing care/supplementary surveillance (regime/therapy)
264	http://www.nlm.nih.gov/research/umls/rxnorm	751616	0.0.1	nebivolol 10 MG Oral Tablet [Bystolic]
265	http://www.nlm.nih.gov/research/umls/rxnorm	1665227	0.0.1	20 ML Ciprofloxacin 10 MG/ML Injection
266	http://snomed.info/sct	363406005	http://snomed.info/sct/900000000000207008/version/20230430	 Malignant neoplasm of colon (disorder)
267	http://loinc.org	29463-7		Body weight
268	http://www.nlm.nih.gov/research/umls/rxnorm	1008877	0.0.1	aspirin / chlorpheniramine / pseudoephedrine
269	http://snomed.info/sct	1871000124103	http://snomed.info/sct/900000000000207008/version/20230430	Transition from acute care to home-health care (finding)
270	http://www.nlm.nih.gov/research/umls/rxnorm	313212	0.0.1	tenecteplase 50 MG Injection
271	http://www.nlm.nih.gov/research/umls/rxnorm	4337	0.0.1	fentanyl
272	http://snomed.info/sct	699253003	http://snomed.info/sct/900000000000207008/version/20230430	Surgical manipulation of joint of knee (procedure)
273	http://www.nlm.nih.gov/research/umls/rxnorm	572163	0.0.1	aspirin 81 MG [St. Joseph Aspirin]
274	http://www.nlm.nih.gov/research/umls/rxnorm	724442	0.0.1	aspirin 81 MG [Anacin Aspirin Regimen]
275	http://www.nlm.nih.gov/research/umls/rxnorm	583139	0.0.1	carbamazepine 200 MG [Equetro]
276	http://snomed.info/sct	67841000119103	http://snomed.info/sct/900000000000207008/version/20230430	Primary small cell malignant neoplasm of lung, TNM stage 4 (disorder)
277	http://www.nlm.nih.gov/research/umls/rxnorm	856460	0.0.1	24 HR propranolol hydrochloride 120 MG Extended Release Oral Capsule
278	http://snomed.info/sct	53827007	http://snomed.info/sct/900000000000207008/version/20230430	Excessive salivation (disorder)
279	http://www.nlm.nih.gov/research/umls/rxnorm	1815	0.0.1	bupivacaine
280	http://snomed.info/sct	431857002	http://snomed.info/sct/900000000000207008/version/20230430	Chronic kidney disease stage 4 (disorder)
281	http://snomed.info/sct	34095006	http://snomed.info/sct/900000000000207008/version/20230430	Dehydration (disorder)
282	http://www.nlm.nih.gov/research/umls/rxnorm	214259	0.0.1	aspirin / pseudoephedrine
283	http://www.nlm.nih.gov/research/umls/rxnorm	1293661	0.0.1	aspirin 81 MG [Aspir-Low]
284	http://snomed.info/sct	233553003	http://snomed.info/sct/900000000000207008/version/20230430	Vascular cannula removal (procedure)
285	http://www.nlm.nih.gov/research/umls/rxnorm	2663929	0.0.1	chlorhexidine gluconate 20 MG/ML / hydrocortisone 5 MG/ML / ketoconazole 10 MG/ML Topical Spray
286	http://www.nlm.nih.gov/research/umls/rxnorm	1297962	0.0.1	ketoconazole 1 MG/ML [T8 Keto Flush]
287	http://snomed.info/sct	399208008	http://snomed.info/sct/900000000000207008/version/20230430	Plain chest X-ray (procedure)
288	http://www.nlm.nih.gov/research/umls/rxnorm	245134	0.0.1	72 HR Fentanyl 0.025 MG/HR Transdermal System
289	http://www.nlm.nih.gov/research/umls/rxnorm	831193	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Tiazac]
290	http://loinc.org	32465-7		Physical findings of Prostate
291	http://www.nlm.nih.gov/research/umls/rxnorm	897630	0.0.1	24 HR verapamil hydrochloride 360 MG Extended Release Oral Capsule
292	http://www.nlm.nih.gov/research/umls/rxnorm	830876	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Tablet [Cardizem]
293	http://www.nlm.nih.gov/research/umls/rxnorm	1536835	0.0.1	aspirin 500 MG / citric acid 1000 MG / sodium bicarbonate 1985 MG Effervescent Oral Tablet [Alka-Seltzer]
294	http://snomed.info/sct	303653007	http://snomed.info/sct/900000000000207008/version/20230430	Computed tomography of head (procedure)
295	http://snomed.info/sct	66857006	http://snomed.info/sct/900000000000207008/version/20230430	Hemoptysis (finding)
296	http://snomed.info/sct	91861009	http://snomed.info/sct/900000000000207008/version/20230430	Acute myeloid leukemia, disease (disorder)
297	http://www.nlm.nih.gov/research/umls/rxnorm	1247397	0.0.1	aspirin 1000 MG / caffeine 65 MG Oral Powder [BC Arthritis]
298	http://www.nlm.nih.gov/research/umls/rxnorm	197558	0.0.1	dapsone 25 MG Oral Tablet
299	http://snomed.info/sct	165829005	http://snomed.info/sct/900000000000207008/version/20230430	Gonorrhea infection titer test (procedure)
300	http://www.nlm.nih.gov/research/umls/rxnorm	199164	0.0.1	phenobarbital 97.2 MG Oral Tablet
301	http://www.nlm.nih.gov/research/umls/rxnorm	1000404	0.0.1	norethindrone acetate 5 MG
302	http://snomed.info/sct	32911000	http://snomed.info/sct/900000000000207008/version/20230430	Homeless (finding)
303	http://snomed.info/sct	315639002	http://snomed.info/sct/900000000000207008/version/20230430	Initial patient assessment (procedure)
304	http://www.nlm.nih.gov/research/umls/rxnorm	831241	0.0.1	diltiazem hydrochloride 180 MG [Cartia]
305	http://www.nlm.nih.gov/research/umls/rxnorm	1739883	0.0.1	atropine sulfate 0.0194 MG / hyoscyamine sulfate 0.1037 MG / phenobarbital 16.2 MG / scopolamine hydrobromide 0.0065 MG [Phenohytro]
306	http://www.nlm.nih.gov/research/umls/rxnorm	1100451	0.0.1	pentobarbital sodium 390 MG/ML / phenytoin sodium 50 MG/ML [Euthasol]
307	http://www.nlm.nih.gov/research/umls/rxnorm	977836	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Heather 28 Day]
308	http://www.nlm.nih.gov/research/umls/rxnorm	1092207	0.0.1	ketoconazole 3 MG/ML
309	http://www.nlm.nih.gov/research/umls/rxnorm	348506	0.0.1	itraconazole 10 MG/ML Oral Solution
310	http://www.nlm.nih.gov/research/umls/rxnorm	250838	0.0.1	estradiol 2 MG / norethindrone 0.7 MG Oral Tablet
311	http://www.nlm.nih.gov/research/umls/rxnorm	1000405	0.0.1	norethindrone acetate 5 MG Oral Tablet
312	http://snomed.info/sct	183450002	http://snomed.info/sct/900000000000207008/version/20230430	Admission to burn unit
313	http://www.nlm.nih.gov/research/umls/rxnorm	312362	0.0.1	phenobarbital 30 MG Oral Tablet
314	http://snomed.info/sct	71493000	http://snomed.info/sct/900000000000207008/version/20230430	Transfusion of packed red blood cells (procedure)
315	http://snomed.info/sct	15724005	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of vertebral column without spinal cord injury
316	http://www.nlm.nih.gov/research/umls/rxnorm	2003249	0.0.1	lamivudine 300 MG / tenofovir disoproxil fumarate 300 MG Oral Tablet
317	http://www.nlm.nih.gov/research/umls/rxnorm	214507	0.0.1	diltiazem / enalapril
318	http://www.nlm.nih.gov/research/umls/rxnorm	3264	0.0.1	dexamethasone
319	http://www.nlm.nih.gov/research/umls/rxnorm	897722	0.0.1	verapamil hydrochloride 40 MG Oral Tablet
320	http://www.nlm.nih.gov/research/umls/rxnorm	317298	0.0.1	aspirin 162 MG
321	http://www.nlm.nih.gov/research/umls/rxnorm	901437	0.0.1	verapamil hydrochloride 160 MG
322	http://snomed.info/sct	229069003	http://snomed.info/sct/900000000000207008/version/20230430	Posture training (procedure)
323	http://www.nlm.nih.gov/research/umls/rxnorm	317463	0.0.1	phenobarbital 60 MG
324	http://www.nlm.nih.gov/research/umls/rxnorm	702318	0.0.1	aspirin 500 MG / caffeine 32.5 MG [Bayer Back and Body Pain]
325	http://www.nlm.nih.gov/research/umls/rxnorm	831309	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Cartia]
326	http://www.nlm.nih.gov/research/umls/rxnorm	897844	0.0.1	24 HR trandolapril 2 MG / verapamil hydrochloride 240 MG Extended Release Oral Tablet
327	http://www.nlm.nih.gov/research/umls/rxnorm	206212	0.0.1	erythromycin 0.02 MG/MG Topical Gel [Erygel]
328	http://www.nlm.nih.gov/research/umls/rxnorm	903884	0.0.1	fluvoxamine maleate 100 MG Oral Tablet
329	http://snomed.info/sct	171207006	http://snomed.info/sct/900000000000207008/version/20230430	Depression screening
330	http://www.nlm.nih.gov/research/umls/rxnorm	392531	0.0.1	erythromycin / zinc acetate
331	http://www.nlm.nih.gov/research/umls/rxnorm	197650	0.0.1	erythromycin 500 MG Oral Tablet
332	http://www.nlm.nih.gov/research/umls/rxnorm	831215	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Dilt]
333	http://www.nlm.nih.gov/research/umls/rxnorm	1735006	0.0.1	10 ML Fentanyl 0.05 MG/ML Injection
334	http://www.nlm.nih.gov/research/umls/rxnorm	315875	0.0.1	erythromycin 25 MG/ML
335	http://snomed.info/sct	386394001	http://snomed.info/sct/900000000000207008/version/20230430	Pregnancy termination care
336	http://www.nlm.nih.gov/research/umls/rxnorm	749859	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Ortho-Novum 1/35 28 Day]
337	http://www.nlm.nih.gov/research/umls/rxnorm	18867	0.0.1	benazepril
338	http://snomed.info/sct	275833003	http://snomed.info/sct/900000000000207008/version/20230430	AFP test - antenatal
339	http://www.nlm.nih.gov/research/umls/rxnorm	2532527	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Pad [Mal-A-Ket Wipes]
340	http://snomed.info/sct	128188000	http://snomed.info/sct/900000000000207008/version/20230430	Cerebral palsy (disorder)
341	http://www.nlm.nih.gov/research/umls/rxnorm	197378	0.0.1	Astemizole 10 MG Oral Tablet
342	http://www.nlm.nih.gov/research/umls/rxnorm	1869595	0.0.1	{27 (dexamethasone 1.5 MG Oral Tablet) } Pack
343	http://snomed.info/sct	297279009	http://snomed.info/sct/900000000000207008/version/20230430	Steroid therapy (procedure)
344	http://www.nlm.nih.gov/research/umls/rxnorm	866419	0.0.1	24 HR metoprolol succinate 200 MG Extended Release Oral Tablet
345	http://www.nlm.nih.gov/research/umls/rxnorm	433718	0.0.1	ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet
346	http://snomed.info/sct	29240004	http://snomed.info/sct/900000000000207008/version/20230430	Autopsy examination
347	http://www.nlm.nih.gov/research/umls/rxnorm	993452	0.0.1	1 ML denosumab 60 MG/ML Prefilled Syringe
348	http://www.nlm.nih.gov/research/umls/rxnorm	749852	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack
349	http://www.nlm.nih.gov/research/umls/rxnorm	1811912	0.0.1	aspirin 325 MG / omeprazole 40 MG [Yosprala]
350	http://snomed.info/sct	74400008	http://snomed.info/sct/900000000000207008/version/20230430	Appendicitis
351	http://www.nlm.nih.gov/research/umls/rxnorm	315567	0.0.1	carbamazepine 400 MG
352	http://www.nlm.nih.gov/research/umls/rxnorm	197581	0.0.1	dexamethasone 2 MG Oral Tablet
353	http://www.nlm.nih.gov/research/umls/rxnorm	617314	0.0.1	atorvastatin 10 MG Oral Tablet [Lipitor]
354	http://snomed.info/sct	428830000	http://snomed.info/sct/900000000000207008/version/20230430	Pretransplant evaluation of kidney recipient (procedure)
355	http://loinc.org	17856-6		Hemoglobin A1c/Hemoglobin.total in Blood by HPLC
356	http://www.nlm.nih.gov/research/umls/rxnorm	866438	0.0.1	24 HR metoprolol succinate 50 MG Extended Release Oral Tablet [Toprol]
357	http://www.nlm.nih.gov/research/umls/rxnorm	1091637	0.0.1	diltiazem hydrochloride 360 MG [Matzim]
358	http://snomed.info/sct	235919008	http://snomed.info/sct/900000000000207008/version/20230430	Cholelithiasis
359	http://www.nlm.nih.gov/research/umls/rxnorm	831324	0.0.1	diltiazem hydrochloride 300 MG [Taztia]
360	http://www.nlm.nih.gov/research/umls/rxnorm	849115	0.0.1	dexamethasone 0.5 MG/ML / tobramycin 3 MG/ML Ophthalmic Suspension
361	http://www.nlm.nih.gov/research/umls/rxnorm	748962	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Camila 28 Day]
362	http://www.nlm.nih.gov/research/umls/rxnorm	863604	0.0.1	erythromycin ethylsuccinate 400 MG [E.E.S.]
363	http://www.nlm.nih.gov/research/umls/rxnorm	830883	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Tablet [Cardizem]
364	http://www.nlm.nih.gov/research/umls/rxnorm	197381	0.0.1	atenolol 50 MG Oral Tablet
365	http://loinc.org	26499-4		Neutrophils [#/volume] in Blood
366	http://www.nlm.nih.gov/research/umls/rxnorm	1008830	0.0.1	itraconazole / secnidazole
367	http://www.nlm.nih.gov/research/umls/rxnorm	1359020	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack [Microgestin 1/20 21 Day]
368	http://www.nlm.nih.gov/research/umls/rxnorm	562251	0.0.1	Amoxicillin 250 MG / Clavulanate 125 MG Oral Tablet
369	http://snomed.info/sct	427419006	http://snomed.info/sct/900000000000207008/version/20230430	Transformed migraine (disorder)
370	http://www.nlm.nih.gov/research/umls/rxnorm	597730	0.0.1	lopinavir 200 MG / Ritonavir 50 MG Oral Tablet
371	http://www.nlm.nih.gov/research/umls/rxnorm	897683	0.0.1	verapamil hydrochloride 80 MG Oral Tablet
372	http://snomed.info/sct	703151001	http://snomed.info/sct/900000000000207008/version/20230430	History of single seizure (situation)
373	http://www.nlm.nih.gov/research/umls/rxnorm	1856424	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Nylia 7/7/7 28 Day]
374	http://snomed.info/sct	34896006	http://snomed.info/sct/900000000000207008/version/20230430	Incision (procedure)
375	http://snomed.info/sct	88039007	http://snomed.info/sct/900000000000207008/version/20230430	Transplant of lung (procedure)
376	http://www.nlm.nih.gov/research/umls/rxnorm	900470	0.0.1	aspirin 1 MG/MG Oral Powder
377	http://www.nlm.nih.gov/research/umls/rxnorm	282422	0.0.1	aspirin / butalbital / caffeine
378	http://www.nlm.nih.gov/research/umls/rxnorm	1537010	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1916 MG [Bromo Seltzer Antacid Pain Reliever]
379	http://www.nlm.nih.gov/research/umls/rxnorm	308972	0.0.1	carbamazepine 200 MG Oral Tablet [Tegretol]
380	http://www.nlm.nih.gov/research/umls/rxnorm	729768	0.0.1	ketoconazole 20 MG/ML Topical Foam [Extina]
381	http://snomed.info/sct	256355007	http://snomed.info/sct/900000000000207008/version/20230430	Soy bean
382	http://www.nlm.nih.gov/research/umls/rxnorm	685543	0.0.1	24 HR clarithromycin 500 MG Extended Release Oral Tablet [Biaxin]
383	http://snomed.info/sct	1571000087109	http://snomed.info/sct/900000000000207008/version/20230430	Ultrasonography of bilateral breasts (procedure)
384	http://www.nlm.nih.gov/research/umls/rxnorm	854228	0.0.1	0.3 ML Enoxaparin sodium 100 MG/ML Prefilled Syringe
385	http://snomed.info/sct	401303003	http://snomed.info/sct/900000000000207008/version/20230430	Acute ST segment elevation myocardial infarction (disorder)
386	http://www.nlm.nih.gov/research/umls/rxnorm	1293665	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [Aspir-Low]
387	http://www.nlm.nih.gov/research/umls/rxnorm	486959	0.0.1	erythromycin estolate 25 MG/ML
388	http://snomed.info/sct	173521004	http://snomed.info/sct/900000000000207008/version/20230430	Transposition of submandibular duct (procedure)
389	http://www.nlm.nih.gov/research/umls/rxnorm	572216	0.0.1	aspirin 500 MG [Bayer Aspirin]
390	http://snomed.info/sct	90781000119102	http://snomed.info/sct/900000000000207008/version/20230430	Microalbuminuria due to type 2 diabetes mellitus (disorder)
391	http://www.nlm.nih.gov/research/umls/rxnorm	1092587	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Topical Spray
392	http://www.nlm.nih.gov/research/umls/rxnorm	2262026	0.0.1	amoxicillin 250 MG / omeprazole 10 MG / rifabutin 12.5 MG Delayed Release Oral Capsule
393	http://snomed.info/sct	229095001	http://snomed.info/sct/900000000000207008/version/20230430	Exercise class
394	http://www.nlm.nih.gov/research/umls/rxnorm	1534846	0.0.1	ketoconazole 1 MG/ML / phytosphingosine 0.1 MG/ML Topical Solution
395	http://www.nlm.nih.gov/research/umls/rxnorm	750267	0.0.1	{12 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Aranelle 28]
396	http://www.nlm.nih.gov/research/umls/rxnorm	686405	0.0.1	erythromycin ethylsuccinate 400 MG Oral Tablet
397	http://www.nlm.nih.gov/research/umls/rxnorm	106809	0.0.1	aspirin 500 MG / glycine 133 MG Disintegrating Oral Tablet
398	http://snomed.info/sct	225415001	http://snomed.info/sct/900000000000207008/version/20230430	Close observation (regime/therapy)
399	http://www.nlm.nih.gov/research/umls/rxnorm	315425	0.0.1	aspirin 60 MG
400	http://www.nlm.nih.gov/research/umls/rxnorm	830860	0.0.1	diltiazem hydrochloride 120 MG
401	http://loinc.org	21908-9		Stage group.clinical Cancer
402	http://snomed.info/sct	225158009	http://snomed.info/sct/900000000000207008/version/20230430	Auscultation of the fetal heart
403	http://www.nlm.nih.gov/research/umls/rxnorm	82122	0.0.1	levofloxacin
404	http://www.nlm.nih.gov/research/umls/rxnorm	830869	0.0.1	12 HR diltiazem hydrochloride 90 MG Extended Release Oral Capsule
405	http://www.nlm.nih.gov/research/umls/rxnorm	200349	0.0.1	100 ML eptifibatide 0.75 MG/ML Injection
406	http://snomed.info/sct	271280005	http://snomed.info/sct/900000000000207008/version/20230430	Removal of endotracheal tube (procedure)
407	http://www.nlm.nih.gov/research/umls/rxnorm	1665355	0.0.1	aspirin 162.5 MG
408	http://snomed.info/sct	422034002	http://snomed.info/sct/900000000000207008/version/20230430	Retinopathy due to type 2 diabetes mellitus (disorder)
409	http://www.nlm.nih.gov/research/umls/rxnorm	830863	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Cardizem]
410	http://www.nlm.nih.gov/research/umls/rxnorm	855888	0.0.1	phenytoin sodium 50 MG/ML
411	http://www.nlm.nih.gov/research/umls/rxnorm	898359	0.0.1	amlodipine 5 MG / benazepril hydrochloride 40 MG Oral Capsule
412	http://snomed.info/sct	48724000	http://snomed.info/sct/900000000000207008/version/20230430	Mitral valve regurgitation (disorder)
413	http://www.nlm.nih.gov/research/umls/rxnorm	897626	0.0.1	24 HR verapamil hydrochloride 240 MG Extended Release Oral Capsule [Verelan]
414	http://www.nlm.nih.gov/research/umls/rxnorm	1116635	0.0.1	ticagrelor 90 MG Oral Tablet
415	http://www.nlm.nih.gov/research/umls/rxnorm	35617	0.0.1	rifapentine
416	http://www.nlm.nih.gov/research/umls/rxnorm	2538834	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Topical Foam
417	http://www.nlm.nih.gov/research/umls/rxnorm	1313889	0.0.1	phenytoin 18 MG/ML
418	http://www.nlm.nih.gov/research/umls/rxnorm	244374	0.0.1	benzoyl peroxide 0.05 MG/MG / erythromycin 0.03 MG/MG Topical Gel
419	http://www.nlm.nih.gov/research/umls/rxnorm	794228	0.0.1	aspirin 81 MG [Bayer Aspirin]
420	http://snomed.info/sct	315124004	http://snomed.info/sct/900000000000207008/version/20230430	Human immunodeficiency virus viral load (procedure)
421	http://loinc.org	85352-3		Lymph nodes with isolated tumor cells [#] in Cancer specimen by Light microscopy
422	http://www.nlm.nih.gov/research/umls/rxnorm	1988316	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Tiadylt]
423	http://www.nlm.nih.gov/research/umls/rxnorm	897619	0.0.1	verapamil hydrochloride 180 MG [Verelan]
424	http://snomed.info/sct	412809002	http://snomed.info/sct/900000000000207008/version/20230430	Viral hepatitis screening test (procedure)
425	http://www.nlm.nih.gov/research/umls/rxnorm	835603	0.0.1	tramadol hydrochloride 50 MG Oral Tablet
426	http://www.nlm.nih.gov/research/umls/rxnorm	2563428	0.0.1	aspirin 325 MG Oral Capsule [Vazalore]
427	http://loinc.org	66524-0		Percentage area affected by eczema Upper extremity - bilateral [PhenX]
428	http://www.nlm.nih.gov/research/umls/rxnorm	2559715	0.0.1	phenobarbital 30 MG [Nobatol]
429	http://www.nlm.nih.gov/research/umls/rxnorm	261356	0.0.1	oxcarbazepine 150 MG Oral Tablet [Trileptal]
430	http://www.nlm.nih.gov/research/umls/rxnorm	831214	0.0.1	diltiazem hydrochloride 120 MG [Dilt]
431	http://www.nlm.nih.gov/research/umls/rxnorm	20481	0.0.1	cefepime
432	http://www.nlm.nih.gov/research/umls/rxnorm	1536678	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1916 MG [Alka-Seltzer]
433	http://www.nlm.nih.gov/research/umls/rxnorm	831320	0.0.1	diltiazem hydrochloride 300 MG [Cartia]
434	http://www.nlm.nih.gov/research/umls/rxnorm	2458971	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML Otic Solution
435	http://www.nlm.nih.gov/research/umls/rxnorm	476351	0.0.1	ezetimibe 10 MG / simvastatin 80 MG Oral Tablet
436	http://www.nlm.nih.gov/research/umls/rxnorm	1008949	0.0.1	caffeine / phenobarbital
437	http://snomed.info/sct	86849004	http://snomed.info/sct/900000000000207008/version/20230430	Suicidal deliberate poisoning
438	http://www.nlm.nih.gov/research/umls/rxnorm	212033	0.0.1	aspirin 325 MG Oral Tablet
439	http://www.nlm.nih.gov/research/umls/rxnorm	858817	0.0.1	enalapril maleate 10 MG Oral Tablet
440	http://www.nlm.nih.gov/research/umls/rxnorm	901446	0.0.1	verapamil hydrochloride 240 MG Oral Tablet
441	http://www.nlm.nih.gov/research/umls/rxnorm	1251501	0.0.1	84 HR estradiol 0.00208 MG/HR / norethindrone acetate 0.0104 MG/HR Transdermal System [Combipatch]
442	http://www.nlm.nih.gov/research/umls/rxnorm	723530	0.0.1	acetaminophen 250 MG / aspirin 250 MG Oral Tablet [Excedrin Back & Body]
443	http://www.nlm.nih.gov/research/umls/rxnorm	205863	0.0.1	clarithromycin 250 MG Oral Tablet [Biaxin]
444	http://www.nlm.nih.gov/research/umls/rxnorm	143975	0.0.1	glycopyrrolate 1.5 MG Oral Tablet [Glycate]
445	http://www.nlm.nih.gov/research/umls/rxnorm	2261802	0.0.1	dexamethasone 20 MG Oral Tablet
446	http://snomed.info/sct	180207008	http://snomed.info/sct/900000000000207008/version/20230430	Intravenous blood transfusion of packed cells (procedure)
447	http://www.nlm.nih.gov/research/umls/rxnorm	329378	0.0.1	erythromycin 0.03 MG/MG
448	http://www.nlm.nih.gov/research/umls/rxnorm	2262028	0.0.1	amoxicillin 250 MG / omeprazole 10 MG / rifabutin 12.5 MG [Talicia]
449	http://snomed.info/sct	315276005	http://snomed.info/sct/900000000000207008/version/20230430	Suspected skin cancer (situation)
450	http://www.nlm.nih.gov/research/umls/rxnorm	1652084	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Junel Fe 24 1/20 28 Day]
451	http://www.nlm.nih.gov/research/umls/rxnorm	351137	0.0.1	albuterol 0.21 MG/ML Inhalation Solution
452	http://www.nlm.nih.gov/research/umls/rxnorm	214258	0.0.1	aspirin / phenyltoloxamine
453	http://www.nlm.nih.gov/research/umls/rxnorm	575233	0.0.1	dexamethasone 0.75 MG [Decadron]
454	http://www.nlm.nih.gov/research/umls/rxnorm	567074	0.0.1	erythromycin 0.02 MG/MG [Emgel]
455	http://snomed.info/sct	449214001	http://snomed.info/sct/900000000000207008/version/20230430	Transfer to stepdown
456	http://snomed.info/sct	268533009	http://snomed.info/sct/900000000000207008/version/20230430	Sterilization education (procedure)
457	http://snomed.info/sct	48447003	http://snomed.info/sct/900000000000207008/version/20230430	Chronic heart failure (disorder)
458	http://www.nlm.nih.gov/research/umls/rxnorm	1359027	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Microgestin Fe 1.5/30 28 Day]
459	http://loinc.org	19994-3		Oxygen/Total gas setting [Volume Fraction] Ventilator
460	http://www.nlm.nih.gov/research/umls/rxnorm	979494	0.0.1	losartan potassium 50 MG Oral Tablet [Cozaar]
461	http://www.nlm.nih.gov/research/umls/rxnorm	1811630	0.0.1	aspirin / omeprazole
462	http://www.nlm.nih.gov/research/umls/rxnorm	206211	0.0.1	erythromycin 0.02 MG/MG Topical Gel [Emgel]
463	http://www.nlm.nih.gov/research/umls/rxnorm	1536503	0.0.1	aspirin 500 MG / dextromethorphan hydrobromide 10 MG / doxylamine succinate 6.25 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet
464	http://www.nlm.nih.gov/research/umls/rxnorm	1804799	0.0.1	Alteplase 100 MG Injection
465	http://www.nlm.nih.gov/research/umls/rxnorm	317364	0.0.1	erythromycin 250 MG
466	http://www.nlm.nih.gov/research/umls/rxnorm	486912	0.0.1	erythromycin estolate 500 MG Oral Tablet
467	http://www.nlm.nih.gov/research/umls/rxnorm	1789958	0.0.1	Dysport botulinum toxin A 300 UNT Injection
468	http://www.nlm.nih.gov/research/umls/rxnorm	213432	0.0.1	telmisartan 80 MG Oral Tablet [Micardis]
469	http://www.nlm.nih.gov/research/umls/rxnorm	205669	0.0.1	dexamethasone 1 MG/ML Ophthalmic Suspension [Maxidex]
470	http://snomed.info/sct	302870006	http://snomed.info/sct/900000000000207008/version/20230430	Hypertriglyceridemia (disorder)
471	http://www.nlm.nih.gov/research/umls/rxnorm	1007218	0.0.1	ouabain / phenobarbital
472	http://snomed.info/sct	80146002	http://snomed.info/sct/900000000000207008/version/20230430	Appendectomy
473	http://www.nlm.nih.gov/research/umls/rxnorm	1440183	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Larin Fe 1/20]
474	http://snomed.info/sct	133899007	http://snomed.info/sct/900000000000207008/version/20230430	Postoperative care (regime/therapy)
475	http://www.nlm.nih.gov/research/umls/rxnorm	1100184	0.0.1	Donepezil hydrochloride 23 MG Oral Tablet
476	http://snomed.info/sct	254632001	http://snomed.info/sct/900000000000207008/version/20230430	Small cell carcinoma of lung (disorder)
477	http://www.nlm.nih.gov/research/umls/rxnorm	830868	0.0.1	diltiazem hydrochloride 90 MG
478	http://www.nlm.nih.gov/research/umls/rxnorm	861650	0.0.1	pitavastatin calcium 2 MG Oral Tablet [Livalo]
479	http://www.nlm.nih.gov/research/umls/rxnorm	821542	0.0.1	cyproheptadine / dexamethasone
480	http://www.nlm.nih.gov/research/umls/rxnorm	252857	0.0.1	aspirin 81 MG Oral Capsule
481	http://www.nlm.nih.gov/research/umls/rxnorm	1484769	0.0.1	chlorhexidine / ketoconazole / salicyloyl phytosphingosine
482	http://www.nlm.nih.gov/research/umls/rxnorm	1495199	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML / salicyloyl phytosphingosine 0.2 MG/ML Topical Spray
483	http://www.nlm.nih.gov/research/umls/rxnorm	833237	0.0.1	diltiazem hydrochloride 180 MG / enalapril maleate 5 MG Extended Release Oral Tablet
484	http://www.nlm.nih.gov/research/umls/rxnorm	2609847	0.0.1	ketoconazole 2 MG/ML Otic Solution
485	http://www.nlm.nih.gov/research/umls/rxnorm	197319	0.0.1	Allopurinol 100 MG Oral Tablet
486	http://snomed.info/sct	372130007	http://snomed.info/sct/900000000000207008/version/20230430	Malignant neoplasm of skin (disorder)
487	http://www.nlm.nih.gov/research/umls/rxnorm	309683	0.0.1	dexamethasone 1 MG/ML / tobramycin 3 MG/ML Ophthalmic Suspension
488	http://snomed.info/sct	171128005	http://snomed.info/sct/900000000000207008/version/20230430	Venereal disease screening (procedure)
489	http://snomed.info/sct	82423001	http://snomed.info/sct/900000000000207008/version/20230430	Chronic pain
490	http://www.nlm.nih.gov/research/umls/rxnorm	1111420	0.0.1	aspirin / chlorpheniramine / dextromethorphan / phenylephrine
491	http://www.nlm.nih.gov/research/umls/rxnorm	487143	0.0.1	erythromycin stearate 250 MG
492	http://www.nlm.nih.gov/research/umls/rxnorm	1313890	0.0.1	phenytoin 18 MG/ML Oral Suspension
493	http://www.nlm.nih.gov/research/umls/rxnorm	105585	0.0.1	Methotrexate 2.5 MG Oral Tablet
494	http://www.nlm.nih.gov/research/umls/rxnorm	315777	0.0.1	dexamethasone 1.5 MG
495	http://snomed.info/sct	15081005	http://snomed.info/sct/900000000000207008/version/20230430	Pulmonary rehabilitation (regime/therapy)
496	http://www.nlm.nih.gov/research/umls/rxnorm	316642	0.0.1	rifampin 300 MG
497	http://www.nlm.nih.gov/research/umls/rxnorm	1087757	0.0.1	dexamethasone 2 MG/ML Injectable Solution [Dexasone]
498	http://www.nlm.nih.gov/research/umls/rxnorm	317299	0.0.1	aspirin 200 MG
499	http://www.nlm.nih.gov/research/umls/rxnorm	2052064	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Incassia 28 Day]
500	http://loinc.org	6833-8		Cat dander IgE Ab [Units/volume] in Serum
501	http://snomed.info/sct	710841007	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of anxiety (procedure)
502	http://www.nlm.nih.gov/research/umls/rxnorm	1365842	0.0.1	24 HR oxcarbazepine 300 MG Extended Release Oral Tablet
503	http://snomed.info/sct	73430006	http://snomed.info/sct/900000000000207008/version/20230430	Sleep apnea (disorder)
504	http://www.nlm.nih.gov/research/umls/rxnorm	1359126	0.0.1	estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet
505	http://www.nlm.nih.gov/research/umls/rxnorm	1313885	0.0.1	phenytoin 50 MG Chewable Tablet
506	http://snomed.info/sct	401314000	http://snomed.info/sct/900000000000207008/version/20230430	Acute non-ST segment elevation myocardial infarction (disorder)
507	http://loinc.org	21924-6		Tumor marker Cancer
508	http://www.nlm.nih.gov/research/umls/rxnorm	744842	0.0.1	raltegravir 400 MG Oral Tablet
509	http://www.nlm.nih.gov/research/umls/rxnorm	1873983	0.0.1	ribociclib 200 MG Oral Tablet
510	http://www.nlm.nih.gov/research/umls/rxnorm	830801	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule
511	http://www.nlm.nih.gov/research/umls/rxnorm	866305	0.0.1	12 HR carbamazepine 200 MG Extended Release Oral Tablet [Tegretol]
512	http://www.nlm.nih.gov/research/umls/rxnorm	1242787	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Alyacen 7/7/7]
513	http://www.nlm.nih.gov/research/umls/rxnorm	214478	0.0.1	dexamethasone / lidocaine
514	http://www.nlm.nih.gov/research/umls/rxnorm	197591	0.0.1	Diazepam 5 MG Oral Tablet
515	http://www.nlm.nih.gov/research/umls/rxnorm	1007330	0.0.1	pentaerythritol / phenobarbital
516	http://www.nlm.nih.gov/research/umls/rxnorm	830803	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Cardizem]
517	http://www.nlm.nih.gov/research/umls/rxnorm	900528	0.0.1	aspirin 850 MG / caffeine 65 MG Oral Powder
518	http://www.nlm.nih.gov/research/umls/rxnorm	689608	0.0.1	atropine / kaolin / phenobarbital
519	http://www.nlm.nih.gov/research/umls/rxnorm	315418	0.0.1	aspirin 300 MG
520	http://www.nlm.nih.gov/research/umls/rxnorm	1664986	0.0.1	Aztreonam 2000 MG Injection
521	http://snomed.info/sct	361055000	http://snomed.info/sct/900000000000207008/version/20230430	Misuses drugs (finding)
522	http://www.nlm.nih.gov/research/umls/rxnorm	1007628	0.0.1	dexamethasone / dobesilic acid / lidocaine
523	http://www.nlm.nih.gov/research/umls/rxnorm	859863	0.0.1	saquinavir mesylate 500 MG Oral Tablet
524	http://snomed.info/sct	194828000	http://snomed.info/sct/900000000000207008/version/20230430	Angina (disorder)
525	http://www.nlm.nih.gov/research/umls/rxnorm	487139	0.0.1	erythromycin stearate 500 MG
526	http://www.nlm.nih.gov/research/umls/rxnorm	542347	0.0.1	isoflurane 99.9 % Inhalation Solution
527	http://www.nlm.nih.gov/research/umls/rxnorm	1297965	0.0.1	ketoconazole 1 MG/ML Topical Solution [T8 Keto Flush]
528	http://www.nlm.nih.gov/research/umls/rxnorm	562366	0.0.1	desflurane 1000 MG/ML Inhalation Solution
529	http://www.nlm.nih.gov/research/umls/rxnorm	748961	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack
530	http://www.nlm.nih.gov/research/umls/rxnorm	898356	0.0.1	amlodipine 5 MG / benazepril hydrochloride 20 MG Oral Capsule
531	http://www.nlm.nih.gov/research/umls/rxnorm	859424	0.0.1	rosuvastatin calcium 5 MG Oral Tablet
532	http://snomed.info/sct	60573004	http://snomed.info/sct/900000000000207008/version/20230430	Aortic valve stenosis (disorder)
533	http://snomed.info/sct	441763001	http://snomed.info/sct/900000000000207008/version/20230430	Endoscopic third ventriculostomy (procedure)
534	http://snomed.info/sct	10509002	http://snomed.info/sct/900000000000207008/version/20230430	Acute bronchitis (disorder)
535	http://www.nlm.nih.gov/research/umls/rxnorm	994529	0.0.1	aspirin 385 MG / caffeine 30 MG / orphenadrine citrate 25 MG [Norgesic]
536	http://www.nlm.nih.gov/research/umls/rxnorm	1359023	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack
537	http://snomed.info/sct	430193006	http://snomed.info/sct/900000000000207008/version/20230430	Medication Reconciliation (procedure)
538	http://www.nlm.nih.gov/research/umls/rxnorm	903891	0.0.1	fluvoxamine maleate 50 MG Oral Tablet
539	http://www.nlm.nih.gov/research/umls/rxnorm	1046999	0.0.1	atropine sulfate 0.0582 MG / hyoscyamine sulfate 0.311 MG / phenobarbital 48.6 MG / scopolamine hydrobromide 0.0195 MG Extended Release Oral Tablet [Donnatal]
540	http://www.nlm.nih.gov/research/umls/rxnorm	823777	0.0.1	{12 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack
541	http://snomed.info/sct	24623002	http://snomed.info/sct/900000000000207008/version/20230430	Screening mammography (procedure)
542	http://www.nlm.nih.gov/research/umls/rxnorm	476349	0.0.1	ezetimibe 10 MG / simvastatin 20 MG Oral Tablet
543	http://snomed.info/sct	236931002	http://snomed.info/sct/900000000000207008/version/20230430	Methotrexate injection into tubal pregnancy
544	http://www.nlm.nih.gov/research/umls/rxnorm	1431987	0.0.1	24 HR tacrolimus 5 MG Extended Release Oral Capsule
545	http://www.nlm.nih.gov/research/umls/rxnorm	1091638	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Tablet [Matzim]
546	http://snomed.info/sct	310417005	http://snomed.info/sct/900000000000207008/version/20230430	Certification procedure (procedure)
547	http://snomed.info/sct	3718001	http://snomed.info/sct/900000000000207008/version/20230430	Cow's milk (substance)
548	http://www.nlm.nih.gov/research/umls/rxnorm	310154	0.0.1	erythromycin 250 MG Delayed Release Oral Capsule
549	http://www.nlm.nih.gov/research/umls/rxnorm	486911	0.0.1	erythromycin estolate 500 MG
550	http://www.nlm.nih.gov/research/umls/rxnorm	141918	0.0.1	Terfenadine 60 MG Oral Tablet
551	http://www.nlm.nih.gov/research/umls/rxnorm	211832	0.0.1	aspirin 81 MG Chewable Tablet [St. Joseph Aspirin]
552	http://www.nlm.nih.gov/research/umls/rxnorm	1809905	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule) / 4 (ferrous fumarate 75 MG Oral Capsule) } Pack [Taytulla 28 Day]
553	http://www.nlm.nih.gov/research/umls/rxnorm	2043465	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Tulana 28 Day]
554	http://snomed.info/sct	167271000	http://snomed.info/sct/900000000000207008/version/20230430	Urine protein test
555	http://www.nlm.nih.gov/research/umls/rxnorm	904467	0.0.1	pravastatin sodium 20 MG Oral Tablet
556	http://www.nlm.nih.gov/research/umls/rxnorm	866511	0.0.1	metoprolol tartrate 100 MG Oral Tablet
557	http://snomed.info/sct	91251008	http://snomed.info/sct/900000000000207008/version/20230430	Physical therapy procedure (regime/therapy)
558	http://snomed.info/sct	709010006	http://snomed.info/sct/900000000000207008/version/20230430	Liaising with referral source (procedure)
559	http://snomed.info/sct	254837009	http://snomed.info/sct/900000000000207008/version/20230430	Malignant neoplasm of breast (disorder)
560	http://loinc.org	3024-7		Thyroxine (T4) free [Mass/volume] in Serum or Plasma
561	http://www.nlm.nih.gov/research/umls/rxnorm	308979	0.0.1	carbamazepine 200 MG Oral Tablet
562	http://snomed.info/sct	312608009	http://snomed.info/sct/900000000000207008/version/20230430	Laceration - injury (disorder)
563	http://loinc.org	6246-3		Shrimp IgE Ab [Units/volume] in Serum
564	http://www.nlm.nih.gov/research/umls/rxnorm	312370	0.0.1	phenobarbital 130 MG/ML Injectable Solution
565	http://www.nlm.nih.gov/research/umls/rxnorm	331417	0.0.1	phenobarbital 97.2 MG
566	http://www.nlm.nih.gov/research/umls/rxnorm	831325	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Taztia]
567	http://www.nlm.nih.gov/research/umls/rxnorm	317626	0.0.1	clarithromycin 50 MG/ML
568	http://www.nlm.nih.gov/research/umls/rxnorm	2118829	0.0.1	{21 (dexamethasone 1.5 MG Oral Tablet) } Pack [HiDex 6-Day Taper]
569	http://www.nlm.nih.gov/research/umls/rxnorm	896027	0.0.1	60 ACTUAT fluticasone propionate 0.25 MG/ACTUAT Dry Powder Inhaler [Flovent]
570	http://snomed.info/sct	43075005	http://snomed.info/sct/900000000000207008/version/20230430	Partial resection of colon
571	http://www.nlm.nih.gov/research/umls/rxnorm	204844	0.0.1	azithromycin 600 MG Oral Tablet
572	http://www.nlm.nih.gov/research/umls/rxnorm	1537029	0.0.1	aspirin 325 MG / chlorpheniramine maleate 2 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet
573	http://www.nlm.nih.gov/research/umls/rxnorm	1483744	0.0.1	Naltrexone hydrochloride 50 MG Oral Tablet
574	http://www.nlm.nih.gov/research/umls/rxnorm	1242786	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Alyacen 1/35]
575	http://www.nlm.nih.gov/research/umls/rxnorm	751870	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Nortrel 1/35 28 Day]
576	http://www.nlm.nih.gov/research/umls/rxnorm	994237	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule
577	http://www.nlm.nih.gov/research/umls/rxnorm	1359131	0.0.1	ethinyl estradiol 0.035 MG / norethindrone acetate 1 MG Oral Tablet
578	http://www.nlm.nih.gov/research/umls/rxnorm	392508	0.0.1	erythromycin / tretinoin
579	http://snomed.info/sct	19030005	http://snomed.info/sct/900000000000207008/version/20230430	Human immunodeficiency virus (organism)
580	http://loinc.org	72106-8		Total score [MMSE]
581	http://snomed.info/sct	110030002	http://snomed.info/sct/900000000000207008/version/20230430	Concussion injury of brain (disorder)
582	http://www.nlm.nih.gov/research/umls/rxnorm	897699	0.0.1	verapamil hydrochloride 180 MG [Isoptin]
583	http://www.nlm.nih.gov/research/umls/rxnorm	106892	0.0.1	insulin isophane, human 70 UNT/ML / insulin, regular, human 30 UNT/ML Injectable Suspension [Humulin]
584	http://www.nlm.nih.gov/research/umls/rxnorm	831284	0.0.1	diltiazem hydrochloride 240 MG [Dilt]
585	http://snomed.info/sct	609496007	http://snomed.info/sct/900000000000207008/version/20230430	Complication occuring during pregnancy
586	http://www.nlm.nih.gov/research/umls/rxnorm	351109	0.0.1	budesonide 0.25 MG/ML Inhalation Suspension
587	http://www.nlm.nih.gov/research/umls/rxnorm	339992	0.0.1	erythromycin 0.04 MG/MG
588	http://www.nlm.nih.gov/research/umls/rxnorm	1797515	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Topical Spray [Keto-C]
589	http://snomed.info/sct	173160006	http://snomed.info/sct/900000000000207008/version/20230430	Diagnostic fiberoptic bronchoscopy (procedure)
590	http://www.nlm.nih.gov/research/umls/rxnorm	1485182	0.0.1	chlorhexidine gluconate 3 MG/ML / ketoconazole 3 MG/ML Topical Solution
591	http://www.nlm.nih.gov/research/umls/rxnorm	1091621	0.0.1	diltiazem hydrochloride 420 MG [Matzim]
592	http://www.nlm.nih.gov/research/umls/rxnorm	352219	0.0.1	voriconazole 200 MG Oral Tablet [Vfend]
593	http://loinc.org	14804-9		Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma by Lactate to pyruvate reaction
594	http://www.nlm.nih.gov/research/umls/rxnorm	859753	0.0.1	rosuvastatin calcium 20 MG Oral Tablet [Crestor]
595	http://www.nlm.nih.gov/research/umls/rxnorm	1043400	0.0.1	Acetaminophen 21.7 MG/ML / Dextromethorphan Hydrobromide 1 MG/ML / doxylamine succinate 0.417 MG/ML Oral Solution
596	http://www.nlm.nih.gov/research/umls/rxnorm	197580	0.0.1	dexamethasone 1.5 MG Oral Tablet
597	http://www.nlm.nih.gov/research/umls/rxnorm	30125	0.0.1	modafinil
598	http://snomed.info/sct	166001	http://snomed.info/sct/900000000000207008/version/20230430	Behavioral therapy (regime/therapy)
599	http://www.nlm.nih.gov/research/umls/rxnorm	979485	0.0.1	Losartan Potassium 25 MG Oral Tablet
600	http://www.nlm.nih.gov/research/umls/rxnorm	387090	0.0.1	aspirin 325 MG Delayed Release Oral Tablet [Bayer Aspirin]
601	http://snomed.info/sct	171131006	http://snomed.info/sct/900000000000207008/version/20230430	Meningocele (disorder)
602	http://www.nlm.nih.gov/research/umls/rxnorm	807283	0.0.1	Mirena 52 MG Intrauterine System
603	http://www.nlm.nih.gov/research/umls/rxnorm	1359021	0.0.1	norethindrone acetate 1.5 MG
604	http://snomed.info/sct	252895004	http://snomed.info/sct/900000000000207008/version/20230430	Urodynamic studies (procedure
605	http://www.nlm.nih.gov/research/umls/rxnorm	1091892	0.0.1	chloroxylenol 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo
606	http://www.nlm.nih.gov/research/umls/rxnorm	311372	0.0.1	Loratadine 10 MG Oral Tablet
607	http://snomed.info/sct	51387008	http://snomed.info/sct/900000000000207008/version/20230430	Acidosis (disorder)
608	http://www.nlm.nih.gov/research/umls/rxnorm	1536467	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1700 MG Effervescent Oral Tablet
609	http://www.nlm.nih.gov/research/umls/rxnorm	1087918	0.0.1	dexamethasone 3 MG/ML [Dexium]
610	http://www.nlm.nih.gov/research/umls/rxnorm	1650201	0.0.1	{24 (ethinyl estradiol 0.025 MG / norethindrone 0.8 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Layolis Fe 28]
611	http://snomed.info/sct	125605004	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of bone (disorder)
612	http://www.nlm.nih.gov/research/umls/rxnorm	1488616	0.0.1	{1 (1.5 ML leuprolide acetate 7.5 MG/ML Prefilled Syringe) / 90 (norethindrone acetate 5 MG Oral Tablet) } Pack
613	http://www.nlm.nih.gov/research/umls/rxnorm	1100453	0.0.1	pentobarbital sodium 390 MG/ML / phenytoin sodium 50 MG/ML Injectable Solution [Euthasol]
614	http://snomed.info/sct	32798002	http://snomed.info/sct/900000000000207008/version/20230430	Parkinsonism (disorder)
615	http://www.nlm.nih.gov/research/umls/rxnorm	404630	0.0.1	ciprofloxacin 3 MG/ML / dexamethasone 1 MG/ML Otic Suspension [Ciprodex]
616	http://www.nlm.nih.gov/research/umls/rxnorm	1791233	0.0.1	25 ML diltiazem hydrochloride 5 MG/ML Injection
617	http://snomed.info/sct	414564002	http://snomed.info/sct/900000000000207008/version/20230430	Kyphosis deformity of spine (disorder)
618	http://snomed.info/sct	710839006	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of cardiac status using monitoring device (procedure)
619	http://www.nlm.nih.gov/research/umls/rxnorm	2180	0.0.1	Cefazolin
620	http://loinc.org	46240-8		History of Hospitalizations+Outpatient visits Narrative
621	http://www.nlm.nih.gov/research/umls/rxnorm	686418	0.0.1	erythromycin ethylsuccinate 80 MG/ML Oral Suspension
622	http://www.nlm.nih.gov/research/umls/rxnorm	830861	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule
623	http://www.nlm.nih.gov/research/umls/rxnorm	310385	0.0.1	FLUoxetine 20 MG Oral Capsule
624	http://www.nlm.nih.gov/research/umls/rxnorm	1367439	0.0.1	NuvaRing 0.12/0.015 MG per 24HR 21 Day Vaginal System
625	http://www.nlm.nih.gov/research/umls/rxnorm	897659	0.0.1	verapamil hydrochloride 120 MG Extended Release Oral Tablet
626	http://loinc.org	75443-2		Mental health Outpatient Note
627	http://snomed.info/sct	256277009	http://snomed.info/sct/900000000000207008/version/20230430	Grass pollen (substance)
628	http://www.nlm.nih.gov/research/umls/rxnorm	1359030	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Junel 1.5/30 21 Day]
629	http://www.nlm.nih.gov/research/umls/rxnorm	979492	0.0.1	losartan potassium 50 MG Oral Tablet
630	http://www.nlm.nih.gov/research/umls/rxnorm	1539955	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Sharobel 28 Day]
631	http://snomed.info/sct	42825003	http://snomed.info/sct/900000000000207008/version/20230430	Cannulation (procedure)
632	http://www.nlm.nih.gov/research/umls/rxnorm	830901	0.0.1	diltiazem hydrochloride 420 MG [Cardizem]
633	http://www.nlm.nih.gov/research/umls/rxnorm	1606350	0.0.1	ketoconazole 0.0015 MG/MG
634	http://www.nlm.nih.gov/research/umls/rxnorm	688214	0.0.1	aspirin 2.5 MG/ML Oral Solution
635	http://snomed.info/sct	6525002	http://snomed.info/sct/900000000000207008/version/20230430	Dependent drug abuse (disorder)
636	http://www.nlm.nih.gov/research/umls/rxnorm	1539953	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Deblitane 28 Day]
637	http://snomed.info/sct	71651007	http://snomed.info/sct/900000000000207008/version/20230430	Mammography (procedure)
638	http://snomed.info/sct	235595009	http://snomed.info/sct/900000000000207008/version/20230430	Gastroesophageal reflux disease (disorder)
639	http://www.nlm.nih.gov/research/umls/rxnorm	1998772	0.0.1	Breath-Actuated 120 ACTUAT beclomethasone dipropionate 0.08 MG/ACTUAT Metered Dose Inhaler [Qvar]
640	http://snomed.info/sct	241645008	http://snomed.info/sct/900000000000207008/version/20230430	Magnetic resonance imaging of spine (procedure)
641	http://www.nlm.nih.gov/research/umls/rxnorm	686417	0.0.1	erythromycin ethylsuccinate 80 MG/ML
642	http://www.nlm.nih.gov/research/umls/rxnorm	994276	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG [Fiorinal with Codeine]
643	http://www.nlm.nih.gov/research/umls/rxnorm	349516	0.0.1	aspirin 800 MG Oral Tablet
644	http://www.nlm.nih.gov/research/umls/rxnorm	1297835	0.0.1	aspirin 500 MG / caffeine 32.5 MG [Bayer Headache Relief]
645	http://www.nlm.nih.gov/research/umls/rxnorm	311205	0.0.1	itraconazole 10 MG/ML Injectable Solution
646	http://www.nlm.nih.gov/research/umls/rxnorm	316514	0.0.1	phenytoin 6 MG/ML
647	http://www.nlm.nih.gov/research/umls/rxnorm	883826	0.0.1	Tranexamic Acid 650 MG Oral Tablet
648	http://www.nlm.nih.gov/research/umls/rxnorm	897682	0.0.1	verapamil hydrochloride 80 MG
649	http://www.nlm.nih.gov/research/umls/rxnorm	284531	0.0.1	telmisartan 20 MG Oral Tablet [Micardis]
650	http://www.nlm.nih.gov/research/umls/rxnorm	746466	0.0.1	200 ACTUAT levalbuterol 0.045 MG/ACTUAT Metered Dose Inhaler [Xopenex]
651	http://snomed.info/sct	224295006	http://snomed.info/sct/900000000000207008/version/20230430	Only received primary school education (finding)
652	http://www.nlm.nih.gov/research/umls/rxnorm	903873	0.0.1	24 HR fluvoxamine maleate 100 MG Extended Release Oral Capsule
653	http://www.nlm.nih.gov/research/umls/rxnorm	1872088	0.0.1	aspirin 500 MG / citric acid 1000 MG / sodium bicarbonate 1985 MG Granules for Oral Solution [Alka-Seltzer]
654	http://snomed.info/sct	182836005	http://snomed.info/sct/900000000000207008/version/20230430	Review of Medication (procedure)
655	http://www.nlm.nih.gov/research/umls/rxnorm	1433630	0.0.1	aspirin 120 MG Chewable Tablet
656	http://www.nlm.nih.gov/research/umls/rxnorm	208602	0.0.1	dexamethasone 0.001 MG/MG / neomycin 0.0035 MG/MG / polymyxin B 10 UNT/MG Ophthalmic Ointment [Poly-Dex]
657	http://snomed.info/sct	268400002	http://snomed.info/sct/900000000000207008/version/20230430	12 lead electrocardiogram (procedure)
658	http://www.nlm.nih.gov/research/umls/rxnorm	689502	0.0.1	aluminum hydroxide / aspirin / calcium carbonate / magnesium hydroxide
659	http://loinc.org	85344-0		Lymph nodes with micrometastases [#] in Cancer specimen by Light microscopy
660	http://www.nlm.nih.gov/research/umls/rxnorm	763138	0.0.1	reteplase 10 UNT Injection
661	http://www.nlm.nih.gov/research/umls/rxnorm	309322	0.0.1	clarithromycin 50 MG/ML Oral Suspension
662	http://www.nlm.nih.gov/research/umls/rxnorm	1999667	0.0.1	bictegravir 50 MG / emtricitabine 200 MG / tenofovir alafenamide 25 MG Oral Tablet
663	http://www.nlm.nih.gov/research/umls/rxnorm	261962	0.0.1	ramipril 10 MG Oral Capsule
664	http://www.nlm.nih.gov/research/umls/rxnorm	1365656	0.0.1	oxcarbazepine 150 MG [Oxtellar]
665	http://www.nlm.nih.gov/research/umls/rxnorm	312748	0.0.1	quinapril 10 MG Oral Tablet
666	http://snomed.info/sct	7200002	http://snomed.info/sct/900000000000207008/version/20230430	Alcoholism
667	http://www.nlm.nih.gov/research/umls/rxnorm	831281	0.0.1	diltiazem hydrochloride 240 MG [Diltzac]
668	http://www.nlm.nih.gov/research/umls/rxnorm	1374372	0.0.1	dexamethasone acetate 8 MG/ML Injectable Suspension
669	http://www.nlm.nih.gov/research/umls/rxnorm	308192	0.0.1	Amoxicillin 500 MG Oral Tablet
670	http://www.nlm.nih.gov/research/umls/rxnorm	313096	0.0.1	spironolactone 25 MG Oral Tablet
671	http://www.nlm.nih.gov/research/umls/rxnorm	746763	0.0.1	NDA020503 200 ACTUAT albuterol 0.09 MG/ACTUAT Metered Dose Inhaler [Proventil]
672	http://www.nlm.nih.gov/research/umls/rxnorm	690792	0.0.1	aminophylline / phenobarbital
673	http://www.nlm.nih.gov/research/umls/rxnorm	702316	0.0.1	aspirin 500 MG / caffeine 32.5 MG Oral Tablet
674	http://www.nlm.nih.gov/research/umls/rxnorm	797023	0.0.1	{51 (dexamethasone 1.5 MG Oral Tablet) } Pack [DexPak TaperPak 13 Day]
675	http://www.nlm.nih.gov/research/umls/rxnorm	282462	0.0.1	phenobarbital 30 MG/ML Injectable Solution
676	http://www.nlm.nih.gov/research/umls/rxnorm	563142	0.0.1	rifampin 300 MG [Rifadin]
677	http://www.nlm.nih.gov/research/umls/rxnorm	352001	0.0.1	valsartan 320 MG Oral Tablet [Diovan]
678	http://www.nlm.nih.gov/research/umls/rxnorm	199885	0.0.1	levofloxacin 500 MG Oral Tablet
679	http://www.nlm.nih.gov/research/umls/rxnorm	1250907	0.0.1	aspirin 500 MG / diphenhydramine citrate 38.3 MG Oral Tablet
680	http://www.nlm.nih.gov/research/umls/rxnorm	1722244	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG [Jevantique]
681	http://snomed.info/sct	711018006	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of social support (procedure)
682	http://www.nlm.nih.gov/research/umls/rxnorm	896209	0.0.1	60 ACTUAT Fluticasone propionate 0.25 MG/ACTUAT / salmeterol 0.05 MG/ACTUAT Dry Powder Inhaler
683	http://snomed.info/sct	398254007	http://snomed.info/sct/900000000000207008/version/20230430	Preeclampsia
684	http://snomed.info/sct	313613002	http://snomed.info/sct/900000000000207008/version/20230430	Hepatitis A antibody test (procedure)
685	http://snomed.info/sct	385781007	http://snomed.info/sct/900000000000207008/version/20230430	Home health aide service (regime/therapy)
686	http://www.nlm.nih.gov/research/umls/rxnorm	315565	0.0.1	carbamazepine 200 MG
687	http://www.nlm.nih.gov/research/umls/rxnorm	672910	0.0.1	12 HR carbamazepine 200 MG Extended Release Oral Capsule [Equetro]
688	http://www.nlm.nih.gov/research/umls/rxnorm	313931	0.0.1	12 HR carbamazepine 300 MG Extended Release Oral Capsule [Carbatrol]
689	http://www.nlm.nih.gov/research/umls/rxnorm	226343	0.0.1	dexamethasone phosphate 1 MG/ML Ophthalmic Solution
690	http://loinc.org	778-1		Platelets [#/volume] in Blood by Manual count
691	http://snomed.info/sct	157265008	http://snomed.info/sct/900000000000207008/version/20230430	Dislocation of hip joint (disorder)
692	http://loinc.org	85318-4		ERBB2 gene duplication [Presence] in Breast cancer specimen by FISH
693	http://loinc.org	9279-1		Respiratory rate
694	http://www.nlm.nih.gov/research/umls/rxnorm	689507	0.0.1	aspirin / butalbital / caffeine / phenacetin
695	http://www.nlm.nih.gov/research/umls/rxnorm	2002	0.0.1	carbamazepine
696	http://snomed.info/sct	46028000	http://snomed.info/sct/900000000000207008/version/20230430	Amputation of left hand
697	http://www.nlm.nih.gov/research/umls/rxnorm	689518	0.0.1	aspirin / caffeine / propoxyphene
698	http://snomed.info/sct	68254000	http://snomed.info/sct/900000000000207008/version/20230430	Removal of intrauterine device
699	http://www.nlm.nih.gov/research/umls/rxnorm	351875	0.0.1	72 HR Scopolamine 0.0139 MG/HR Transdermal System [Transdermal Scop]
700	http://www.nlm.nih.gov/research/umls/rxnorm	214263	0.0.1	atropine / phenobarbital
701	http://www.nlm.nih.gov/research/umls/rxnorm	751905	0.0.1	Trinessa 28 Day Pack
702	http://snomed.info/sct	16983000	http://snomed.info/sct/900000000000207008/version/20230430	Death in hospital (event)
703	http://snomed.info/sct	315268008	http://snomed.info/sct/900000000000207008/version/20230430	Suspected prostate cancer (situation)
704	http://snomed.info/sct	197927001	http://snomed.info/sct/900000000000207008/version/20230430	Recurrent urinary tract infection
705	http://www.nlm.nih.gov/research/umls/rxnorm	1482662	0.0.1	chlorhexidine gluconate 23 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo [Ketochlor]
706	http://www.nlm.nih.gov/research/umls/rxnorm	897629	0.0.1	verapamil hydrochloride 360 MG
707	http://www.nlm.nih.gov/research/umls/rxnorm	1534845	0.0.1	ketoconazole / phytosphingosine
708	http://snomed.info/sct	443529005	http://snomed.info/sct/900000000000207008/version/20230430	Detection of chromosomal aneuploidy in prenatal amniotic fluid specimen using fluorescence in situ hybridization screening technique (procedure)
709	http://www.nlm.nih.gov/research/umls/rxnorm	898350	0.0.1	amlodipine 2.5 MG / benazepril hydrochloride 10 MG Oral Capsule
710	http://www.nlm.nih.gov/research/umls/rxnorm	197905	0.0.1	lovastatin 40 MG Oral Tablet
711	http://www.nlm.nih.gov/research/umls/rxnorm	199964	0.0.1	phenobarbital 200 MG/ML Injectable Solution
712	http://www.nlm.nih.gov/research/umls/rxnorm	1091628	0.0.1	diltiazem hydrochloride 240 MG [Matzim]
713	http://www.nlm.nih.gov/research/umls/rxnorm	205326	0.0.1	lisinopril 30 MG Oral Tablet
714	http://www.nlm.nih.gov/research/umls/rxnorm	905377	0.0.1	hydralazine hydrochloride 37.5 MG / isosorbide dinitrate 20 MG Oral Tablet
715	http://snomed.info/sct	43724002	http://snomed.info/sct/900000000000207008/version/20230430	Chill (finding)
716	http://snomed.info/sct	44054006	http://snomed.info/sct/900000000000207008/version/20230430	Diabetes mellitus type 2 (disorder)
717	http://www.nlm.nih.gov/research/umls/rxnorm	854175	0.0.1	dexamethasone 0.7 MG
718	http://www.nlm.nih.gov/research/umls/rxnorm	863601	0.0.1	erythromycin ethylsuccinate 40 MG/ML [E.E.S.]
719	http://snomed.info/sct	306206005	http://snomed.info/sct/900000000000207008/version/20230430	Referral to service (procedure)
720	http://www.nlm.nih.gov/research/umls/rxnorm	749869	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) } Pack
721	http://www.nlm.nih.gov/research/umls/rxnorm	830877	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Tablet
722	http://snomed.info/sct	417746004	http://snomed.info/sct/900000000000207008/version/20230430	Traumatic injury (disorder)
723	http://www.nlm.nih.gov/research/umls/rxnorm	1482657	0.0.1	chlorhexidine gluconate 23 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo
724	http://www.nlm.nih.gov/research/umls/rxnorm	569470	0.0.1	dexamethasone 0.001 MG/MG / tobramycin 0.003 MG/MG [Tobradex]
725	http://www.nlm.nih.gov/research/umls/rxnorm	309680	0.0.1	dexamethasone 1 MG/ML / neomycin 3.5 MG/ML / polymyxin B 10000 UNT/ML Ophthalmic Suspension
726	http://snomed.info/sct	305342007	http://snomed.info/sct/900000000000207008/version/20230430	Admission to ward (procedure
727	http://www.nlm.nih.gov/research/umls/rxnorm	569262	0.0.1	dexamethasone 1 MG/ML / neomycin 3.5 MG/ML / polymyxin B 10000 UNT/ML [Maxitrol]
728	http://www.nlm.nih.gov/research/umls/rxnorm	333834	0.0.1	aspirin 60 MG Chewable Tablet
729	http://www.nlm.nih.gov/research/umls/rxnorm	854255	0.0.1	enoxaparin sodium 100 MG/ML Injectable Solution
730	http://www.nlm.nih.gov/research/umls/rxnorm	345816	0.0.1	dexamethasone 0.75 MG
731	http://www.nlm.nih.gov/research/umls/rxnorm	1657981	0.0.1	20 ML tocilizumab 20 MG/ML Injection
732	http://www.nlm.nih.gov/research/umls/rxnorm	831244	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Tiazac]
733	http://www.nlm.nih.gov/research/umls/rxnorm	1251498	0.0.1	norethindrone acetate 0.0104 MG/HR
734	http://www.nlm.nih.gov/research/umls/rxnorm	1812078	0.0.1	dexamethasone phosphate 10 MG/ML
735	http://www.nlm.nih.gov/research/umls/rxnorm	312124	0.0.1	ethinyl estradiol 0.05 MG / norethindrone 1 MG Oral Tablet
736	http://snomed.info/sct	430701006	http://snomed.info/sct/900000000000207008/version/20230430	Resuscitation using intravenous fluid (procedure)
737	http://www.nlm.nih.gov/research/umls/rxnorm	1433873	0.0.1	dolutegravir 50 MG Oral Tablet
738	http://www.nlm.nih.gov/research/umls/rxnorm	331416	0.0.1	phenobarbital 32.4 MG
739	http://www.nlm.nih.gov/research/umls/rxnorm	1091631	0.0.1	diltiazem hydrochloride 180 MG [Matzim]
740	http://www.nlm.nih.gov/research/umls/rxnorm	1032187	0.0.1	belladonna alkaloids / ergotamine / phenobarbital
741	http://www.nlm.nih.gov/research/umls/rxnorm	1484770	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML / salicyloyl phytosphingosine 0.5 MG/ML Medicated Shampoo
742	http://www.nlm.nih.gov/research/umls/rxnorm	575736	0.0.1	oxcarbazepine 60 MG/ML [Trileptal]
743	http://www.nlm.nih.gov/research/umls/rxnorm	795716	0.0.1	{12 (dexamethasone 0.75 MG Oral Tablet [Decadron]) } Pack [Decadron 5-12]
744	http://www.nlm.nih.gov/research/umls/rxnorm	108515	0.0.1	1 ML tacrolimus 5 MG/ML Injection
745	http://www.nlm.nih.gov/research/umls/rxnorm	308411	0.0.1	aspirin 650 MG Delayed Release Oral Tablet
746	http://www.nlm.nih.gov/research/umls/rxnorm	2123111	0.0.1	NDA020503 200 ACTUAT Albuterol 0.09 MG/ACTUAT Metered Dose Inhaler
747	http://snomed.info/sct	22253000	http://snomed.info/sct/900000000000207008/version/20230430	Pain (finding)
748	http://snomed.info/sct	223487003	http://snomed.info/sct/900000000000207008/version/20230430	Discussion about options (procedure)
749	http://snomed.info/sct	444448004	http://snomed.info/sct/900000000000207008/version/20230430	Injury of medial collateral ligament of knee
750	http://www.nlm.nih.gov/research/umls/rxnorm	1095362	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Balziva 28 Day]
751	http://www.nlm.nih.gov/research/umls/rxnorm	831192	0.0.1	diltiazem hydrochloride 120 MG [Tiazac]
752	http://www.nlm.nih.gov/research/umls/rxnorm	1191	0.0.1	aspirin
753	http://www.nlm.nih.gov/research/umls/rxnorm	334693	0.0.1	norethindrone 0.7 MG
754	http://www.nlm.nih.gov/research/umls/rxnorm	859749	0.0.1	rosuvastatin calcium 10 MG Oral Tablet [Crestor]
755	http://snomed.info/sct	19169002	http://snomed.info/sct/900000000000207008/version/20230430	Miscarriage in first trimester
756	http://www.nlm.nih.gov/research/umls/rxnorm	1008684	0.0.1	aspirin / lithium / quinine
757	http://www.nlm.nih.gov/research/umls/rxnorm	566754	0.0.1	clarithromycin 500 MG [Biaxin]
758	http://snomed.info/sct	422587007	http://snomed.info/sct/900000000000207008/version/20230430	Nausea (finding)
759	http://www.nlm.nih.gov/research/umls/rxnorm	10864	0.0.1	troleandomycin
760	http://snomed.info/sct	85548006	http://snomed.info/sct/900000000000207008/version/20230430	Episiotomy
761	http://snomed.info/sct	447759004	http://snomed.info/sct/900000000000207008/version/20230430	Brachytherapy of breast (procedure)
874	http://www.nlm.nih.gov/research/umls/rxnorm	1008066	0.0.1	ketoconazole / secnidazole
762	http://snomed.info/sct	710824005	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of health and social care needs (procedure)
763	http://snomed.info/sct	59621000	http://snomed.info/sct/900000000000207008/version/20230430	Essential hypertension (disorder)
764	http://www.nlm.nih.gov/research/umls/rxnorm	1649485	0.0.1	ivabradine 5 MG Oral Tablet
765	http://www.nlm.nih.gov/research/umls/rxnorm	724444	0.0.1	aspirin 81 MG Oral Tablet [Anacin Aspirin Regimen]
766	http://www.nlm.nih.gov/research/umls/rxnorm	205860	0.0.1	clarithromycin 50 MG/ML Oral Suspension [Biaxin]
767	http://www.nlm.nih.gov/research/umls/rxnorm	2045406	0.0.1	dexamethasone 103.4 MG/ML [Dexycu]
768	http://www.nlm.nih.gov/research/umls/rxnorm	315776	0.0.1	dexamethasone 1 MG
769	http://snomed.info/sct	33195004	http://snomed.info/sct/900000000000207008/version/20230430	External beam radiation therapy procedure (procedure)
770	http://snomed.info/sct	433112001	http://snomed.info/sct/900000000000207008/version/20230430	Percutaneous mechanical thrombectomy of portal vein using fluoroscopic guidance with contrast (procedure)
771	http://www.nlm.nih.gov/research/umls/rxnorm	1094543	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Briellyn 28 Day]
772	http://www.nlm.nih.gov/research/umls/rxnorm	393540	0.0.1	laureth-4
773	http://www.nlm.nih.gov/research/umls/rxnorm	1367691	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Gildagia]
774	http://www.nlm.nih.gov/research/umls/rxnorm	1008991	0.0.1	aminobutyrate / phenobarbital / phenytoin
775	http://www.nlm.nih.gov/research/umls/rxnorm	994538	0.0.1	aspirin 770 MG / caffeine 60 MG / orphenadrine citrate 50 MG [Orphengesic]
776	http://snomed.info/sct	23745001	http://snomed.info/sct/900000000000207008/version/20230430	Documentation procedure (procedure)
777	http://www.nlm.nih.gov/research/umls/rxnorm	309045	0.0.1	Cefaclor 250 MG Oral Capsule
778	http://www.nlm.nih.gov/research/umls/rxnorm	1944656	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Melodetta 24 Fe Chewable 28 Day]
779	http://snomed.info/sct	262574004	http://snomed.info/sct/900000000000207008/version/20230430	Bullet wound
780	http://snomed.info/sct	314529007	http://snomed.info/sct/900000000000207008/version/20230430	Medication review due (situation)
781	http://www.nlm.nih.gov/research/umls/rxnorm	205923	0.0.1	1 ML Epoetin Alfa 4000 UNT/ML Injection [Epogen]
782	http://www.nlm.nih.gov/research/umls/rxnorm	1049504	0.0.1	Abuse-Deterrent 12 HR Oxycodone Hydrochloride 10 MG Extended Release Oral Tablet [Oxycontin]
783	http://www.nlm.nih.gov/research/umls/rxnorm	817405	0.0.1	aspirin / phenylpropanolamine
784	http://snomed.info/sct	418470004	http://snomed.info/sct/900000000000207008/version/20230430	Porphyria (disorder)
785	http://www.nlm.nih.gov/research/umls/rxnorm	1797511	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML Topical Solution [Keto-C]
786	http://www.nlm.nih.gov/research/umls/rxnorm	312368	0.0.1	phenobarbital 90 MG Oral Tablet
787	http://www.nlm.nih.gov/research/umls/rxnorm	349201	0.0.1	valsartan 160 MG Oral Tablet
788	http://www.nlm.nih.gov/research/umls/rxnorm	1008988	0.0.1	aspirin / nafronyl
789	http://www.nlm.nih.gov/research/umls/rxnorm	313002	0.0.1	Sodium Chloride 9 MG/ML Injectable Solution
790	http://snomed.info/sct	423121009	http://snomed.info/sct/900000000000207008/version/20230430	Non-small cell carcinoma of lung, TNM stage 4 (disorder)
791	http://www.nlm.nih.gov/research/umls/rxnorm	1147334	0.0.1	emtricitabine 200 MG / rilpivirine 25 MG / tenofovir disoproxil fumarate 300 MG Oral Tablet
792	http://www.nlm.nih.gov/research/umls/rxnorm	433353	0.0.1	aspirin 300 MG Chewable Tablet
793	http://snomed.info/sct	125601008	http://snomed.info/sct/900000000000207008/version/20230430	Injury of knee (disorder)
794	http://www.nlm.nih.gov/research/umls/rxnorm	690788	0.0.1	aminophylline / ephedrine / guaifenesin / phenobarbital
795	http://www.nlm.nih.gov/research/umls/rxnorm	897589	0.0.1	verapamil hydrochloride 200 MG
796	http://www.nlm.nih.gov/research/umls/rxnorm	240741	0.0.1	clarithromycin 25 MG/ML Oral Suspension
797	http://www.nlm.nih.gov/research/umls/rxnorm	817778	0.0.1	aspirin / caffeine / quinine
798	http://snomed.info/sct	263102004	http://snomed.info/sct/900000000000207008/version/20230430	Fracture subluxation of wrist
799	http://www.nlm.nih.gov/research/umls/rxnorm	1006885	0.0.1	bromhexine / erythromycin
800	http://www.nlm.nih.gov/research/umls/rxnorm	2671206	0.0.1	phenobarbital sodium 65 MG/ML
801	http://snomed.info/sct	445912000	http://snomed.info/sct/900000000000207008/version/20230430	Excision of fallopian tube and surgical removal of ectopic pregnancy
802	http://www.nlm.nih.gov/research/umls/rxnorm	1251336	0.0.1	{28 (ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG Oral Tablet) } Pack
803	http://www.nlm.nih.gov/research/umls/rxnorm	855671	0.0.1	phenytoin sodium 100 MG Extended Release Oral Capsule
804	http://www.nlm.nih.gov/research/umls/rxnorm	866924	0.0.1	metoprolol tartrate 25 MG Oral Tablet
805	http://www.nlm.nih.gov/research/umls/rxnorm	1439953	0.0.1	acetic acid 20 MG/ML / chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo [Mal-A-Ket]
806	http://www.nlm.nih.gov/research/umls/rxnorm	1373463	0.0.1	canagliflozin 100 MG Oral Tablet
807	http://snomed.info/sct	267102003	http://snomed.info/sct/900000000000207008/version/20230430	Sore throat symptom (finding)
808	http://www.nlm.nih.gov/research/umls/rxnorm	903886	0.0.1	fluvoxamine maleate 25 MG
809	http://www.nlm.nih.gov/research/umls/rxnorm	465355	0.0.1	voriconazole 40 MG/ML Oral Suspension
810	http://www.nlm.nih.gov/research/umls/rxnorm	197583	0.0.1	dexamethasone 6 MG Oral Tablet
811	http://www.nlm.nih.gov/research/umls/rxnorm	261418	0.0.1	hyoscyamine / phenobarbital
812	http://www.nlm.nih.gov/research/umls/rxnorm	702519	0.0.1	phenobarbital 4 MG/ML Oral Solution
813	http://www.nlm.nih.gov/research/umls/rxnorm	1656318	0.0.1	Cefotaxime 2000 MG Injection
814	http://www.nlm.nih.gov/research/umls/rxnorm	312938	0.0.1	Sertraline 100 MG Oral Tablet
815	http://www.nlm.nih.gov/research/umls/rxnorm	1090994	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG [Jinteli]
816	http://www.nlm.nih.gov/research/umls/rxnorm	1091635	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Tablet [Matzim]
817	http://www.nlm.nih.gov/research/umls/rxnorm	1736776	0.0.1	10 ML oxaliplatin 5 MG/ML Injection
818	http://www.nlm.nih.gov/research/umls/rxnorm	2669487	0.0.1	ketoconazole / salicylic acid
819	http://loinc.org	6189-5		White Oak IgE Ab [Units/volume] in Serum
820	http://www.nlm.nih.gov/research/umls/rxnorm	336053	0.0.1	phenobarbital 48.6 MG
821	http://www.nlm.nih.gov/research/umls/rxnorm	335921	0.0.1	rifampin 120 MG
822	http://www.nlm.nih.gov/research/umls/rxnorm	350643	0.0.1	voriconazole 50 MG
823	http://snomed.info/sct	169230002	http://snomed.info/sct/900000000000207008/version/20230430	Ultrasound scan for fetal viability
824	http://loinc.org	28245-9		Abuse Status [OMAHA]
825	http://www.nlm.nih.gov/research/umls/rxnorm	315877	0.0.1	erythromycin 500 MG
826	http://snomed.info/sct	30832001	http://snomed.info/sct/900000000000207008/version/20230430	Rupture of patellar tendon
827	http://www.nlm.nih.gov/research/umls/rxnorm	1723208	0.0.1	10 ML Alfentanil 0.5 MG/ML Injection
828	http://www.nlm.nih.gov/research/umls/rxnorm	1371364	0.0.1	chlorhexidine / ketoconazole
829	http://snomed.info/sct	446573003	http://snomed.info/sct/900000000000207008/version/20230430	Continuous positive airway pressure titration (procedure)
830	http://www.nlm.nih.gov/research/umls/rxnorm	756260	0.0.1	belladonna alkaloids 0.026 MG/ML / phenobarbital 3.24 MG/ML Oral Solution
831	http://www.nlm.nih.gov/research/umls/rxnorm	831248	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Taztia]
832	http://snomed.info/sct	237602007	http://snomed.info/sct/900000000000207008/version/20230430	Metabolic syndrome X (disorder)
833	http://www.nlm.nih.gov/research/umls/rxnorm	403978	0.0.1	nelfinavir 625 MG Oral Tablet
834	http://www.nlm.nih.gov/research/umls/rxnorm	727762	0.0.1	5 ML fulvestrant 50 MG/ML Prefilled Syringe
835	http://snomed.info/sct	161622006	http://snomed.info/sct/900000000000207008/version/20230430	History of lower limb amputation (situation)
836	http://www.nlm.nih.gov/research/umls/rxnorm	1007974	0.0.1	hydrochlorothiazide / verapamil
837	http://www.nlm.nih.gov/research/umls/rxnorm	312821	0.0.1	rifampin 600 MG Injection
838	http://www.nlm.nih.gov/research/umls/rxnorm	28031	0.0.1	itraconazole
839	http://www.nlm.nih.gov/research/umls/rxnorm	1550964	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack [Lopreeza 0.5/0.1 28 Day]
840	http://www.nlm.nih.gov/research/umls/rxnorm	604649	0.0.1	ketoconazole 20 MG/ML [Kuric]
841	http://www.nlm.nih.gov/research/umls/rxnorm	1007942	0.0.1	quinidine / verapamil
842	http://www.nlm.nih.gov/research/umls/rxnorm	2583731	0.0.1	aspirin 500 MG / butalbital 50 MG / caffeine 40 MG Oral Capsule
843	http://www.nlm.nih.gov/research/umls/rxnorm	572150	0.0.1	carbamazepine 200 MG [Epitol]
844	http://www.nlm.nih.gov/research/umls/rxnorm	198405	0.0.1	Ibuprofen 100 MG Oral Tablet
845	http://www.nlm.nih.gov/research/umls/rxnorm	1426600	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack
846	http://snomed.info/sct	840544004	http://snomed.info/sct/900000000000207008/version/20230430	Suspected COVID-19
847	http://www.nlm.nih.gov/research/umls/rxnorm	831300	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Taztia]
848	http://snomed.info/sct	15802004	http://snomed.info/sct/900000000000207008/version/20230430	Dystonia (disorder)
849	http://www.nlm.nih.gov/research/umls/rxnorm	1997015	0.0.1	bivalirudin 50 ML; 5 MG/ML Injection
850	http://www.nlm.nih.gov/research/umls/rxnorm	389251	0.0.1	erythromycin 40 MG/ML / tretinoin 0.25 MG/ML Topical Solution
851	http://www.nlm.nih.gov/research/umls/rxnorm	199378	0.0.1	12 HR carbamazepine 100 MG Extended Release Oral Tablet
852	http://snomed.info/sct	127783003	http://snomed.info/sct/900000000000207008/version/20230430	Spirometry (procedure)
853	http://www.nlm.nih.gov/research/umls/rxnorm	332278	0.0.1	oxcarbazepine 60 MG/ML
854	http://www.nlm.nih.gov/research/umls/rxnorm	2231	0.0.1	Cephalexin
855	http://www.nlm.nih.gov/research/umls/rxnorm	691231	0.0.1	ephedrine / phenobarbital
856	http://www.nlm.nih.gov/research/umls/rxnorm	854181	0.0.1	dexamethasone 0.7 MG Drug Implant [Ozurdex]
857	http://snomed.info/sct	762993000	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using Morse Fall Scale (procedure)
858	http://www.nlm.nih.gov/research/umls/rxnorm	2119861	0.0.1	carbamazepine 10 MG/ML [Carnexiv]
859	http://snomed.info/sct	77477000	http://snomed.info/sct/900000000000207008/version/20230430	Computed tomography (procedure)
860	http://www.nlm.nih.gov/research/umls/rxnorm	897611	0.0.1	verapamil hydrochloride 120 MG
861	http://www.nlm.nih.gov/research/umls/rxnorm	819817	0.0.1	aspirin / cyclizine
862	http://snomed.info/sct	88848003	http://snomed.info/sct/900000000000207008/version/20230430	Psychiatric follow-up
863	http://www.nlm.nih.gov/research/umls/rxnorm	1722691	0.0.1	aspirin 81 MG / calcium carbonate 777 MG [Bayer Womens]
864	http://www.nlm.nih.gov/research/umls/rxnorm	197582	0.0.1	dexamethasone 4 MG Oral Tablet
865	http://www.nlm.nih.gov/research/umls/rxnorm	1008832	0.0.1	aspirin / sulfur
866	http://www.nlm.nih.gov/research/umls/rxnorm	1668267	0.0.1	erythromycin lactobionate 500 MG Injection [Erythrocin]
867	http://loinc.org	33914-3		Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum or Plasma by Creatinine-based formula (MDRD)
868	http://www.nlm.nih.gov/research/umls/rxnorm	197516	0.0.1	clarithromycin 250 MG Oral Tablet
869	http://snomed.info/sct	73761001	http://snomed.info/sct/900000000000207008/version/20230430	Colonoscopy
870	http://www.nlm.nih.gov/research/umls/rxnorm	103941	0.0.1	carbamazepine 125 MG Rectal Suppository
871	http://www.nlm.nih.gov/research/umls/rxnorm	665078	0.0.1	Loratadine 5 MG Chewable Tablet
872	http://www.nlm.nih.gov/research/umls/rxnorm	242671	0.0.1	rifapentine 150 MG Oral Tablet
873	http://www.nlm.nih.gov/research/umls/rxnorm	1488617	0.0.1	{1 (1.5 ML leuprolide acetate 7.5 MG/ML Prefilled Syringe [Lupron]) / 90 (norethindrone acetate 5 MG Oral Tablet) } Pack [Lupaneta Pack 3-Month]
875	http://www.nlm.nih.gov/research/umls/rxnorm	1988324	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Capsule [Tiadylt]
876	http://www.nlm.nih.gov/research/umls/rxnorm	854177	0.0.1	dexamethasone 0.7 MG Drug Implant
877	http://www.nlm.nih.gov/research/umls/rxnorm	898372	0.0.1	benazepril hydrochloride 20 MG / hydrochlorothiazide 25 MG Oral Tablet
878	http://www.nlm.nih.gov/research/umls/rxnorm	830845	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule
879	http://www.nlm.nih.gov/research/umls/rxnorm	2559719	0.0.1	phenobarbital 30 MG Oral Tablet [Nobatol]
880	http://www.nlm.nih.gov/research/umls/rxnorm	855875	0.0.1	phenytoin sodium 300 MG Extended Release Oral Capsule [Phenytek]
881	http://www.nlm.nih.gov/research/umls/rxnorm	566603	0.0.1	dexamethasone 4 MG [Decadron]
882	http://snomed.info/sct	108243003	http://snomed.info/sct/900000000000207008/version/20230430	Sleep disorder test AND/OR procedure (procedure)
883	http://www.nlm.nih.gov/research/umls/rxnorm	759697	0.0.1	{35 (dexamethasone 1.5 MG Oral Tablet) } Pack
884	http://www.nlm.nih.gov/research/umls/rxnorm	349200	0.0.1	valsartan 320 MG Oral Tablet
885	http://www.nlm.nih.gov/research/umls/rxnorm	205305	0.0.1	telmisartan 80 MG Oral Tablet
886	http://www.nlm.nih.gov/research/umls/rxnorm	197441	0.0.1	carbamazepine 100 MG Oral Tablet
887	http://www.nlm.nih.gov/research/umls/rxnorm	1098666	0.0.1	nefazodone hydrochloride 150 MG Oral Tablet
888	http://www.nlm.nih.gov/research/umls/rxnorm	818139	0.0.1	dexamethasone / terfenadine
889	http://www.nlm.nih.gov/research/umls/rxnorm	2371764	0.0.1	elagolix 300 MG / estradiol 1 MG / norethindrone 0.5 MG Oral Capsule
890	http://www.nlm.nih.gov/research/umls/rxnorm	317656	0.0.1	norethindrone 0.4 MG
891	http://www.nlm.nih.gov/research/umls/rxnorm	200094	0.0.1	irbesartan 75 MG Oral Tablet
892	http://www.nlm.nih.gov/research/umls/rxnorm	2003642	0.0.1	ketoconazole 1.5 MG/ML
893	http://www.nlm.nih.gov/research/umls/rxnorm	830866	0.0.1	diltiazem hydrochloride 60 MG [Cardizem]
894	http://www.nlm.nih.gov/research/umls/rxnorm	104475	0.0.1	aspirin 75 MG Disintegrating Oral Tablet
895	http://www.nlm.nih.gov/research/umls/rxnorm	310965	0.0.1	Ibuprofen 200 MG Oral Tablet
896	http://snomed.info/sct	49915006	http://snomed.info/sct/900000000000207008/version/20230430	Tricuspid valve stenosis (disorder)
897	http://www.nlm.nih.gov/research/umls/rxnorm	238135	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG Oral Tablet
898	http://www.nlm.nih.gov/research/umls/rxnorm	1536833	0.0.1	aspirin 500 MG / citric acid 1000 MG / sodium bicarbonate 1985 MG Effervescent Oral Tablet
899	http://snomed.info/sct	446654005	http://snomed.info/sct/900000000000207008/version/20230430	Refugee (person)
900	http://www.nlm.nih.gov/research/umls/rxnorm	1099637	0.0.1	norethindrone 0.8 MG
901	http://snomed.info/sct	13995008	http://snomed.info/sct/900000000000207008/version/20230430	Amputation of right arm
902	http://snomed.info/sct	156073000	http://snomed.info/sct/900000000000207008/version/20230430	Complete miscarriage (disorder)
903	http://www.nlm.nih.gov/research/umls/rxnorm	1600991	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [Aspi-Cor]
904	http://www.nlm.nih.gov/research/umls/rxnorm	997488	0.0.1	Fexofenadine hydrochloride 30 MG Oral Tablet
905	http://www.nlm.nih.gov/research/umls/rxnorm	574548	0.0.1	aspirin 25 MG / dipyridamole 200 MG [Aggrenox]
906	http://www.nlm.nih.gov/research/umls/rxnorm	198189	0.0.1	ramipril 5 MG Oral Capsule
907	http://www.nlm.nih.gov/research/umls/rxnorm	198203	0.0.1	isoniazid 150 MG / rifampin 300 MG Oral Capsule
908	http://www.nlm.nih.gov/research/umls/rxnorm	2606079	0.0.1	aspirin 325 MG Effervescent Oral Tablet
909	http://snomed.info/sct	446987006	http://snomed.info/sct/900000000000207008/version/20230430	Determination of susceptibility of Human immunodeficiency virus 1 to panel of antiretroviral drugs using genotypic technique (procedure)
910	http://www.nlm.nih.gov/research/umls/rxnorm	308363	0.0.1	aspirin 325 MG / caffeine 16 MG / salicylamide 95 MG Oral Tablet
911	http://www.nlm.nih.gov/research/umls/rxnorm	2280761	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Charlotte 24 Fe Chewable 28 Day]
912	http://www.nlm.nih.gov/research/umls/rxnorm	2463741	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule) / 4 (ferrous fumarate 75 MG Oral Capsule) } Pack [Gemmily 28 Day]
913	http://www.nlm.nih.gov/research/umls/rxnorm	897583	0.0.1	verapamil hydrochloride 100 MG
914	http://loinc.org	2857-1		Prostate specific Ag [Mass/volume] in Serum or Plasma
915	http://www.nlm.nih.gov/research/umls/rxnorm	388755	0.0.1	dexamethasone 1 MG/ML Topical Solution
916	http://www.nlm.nih.gov/research/umls/rxnorm	897584	0.0.1	24 HR verapamil hydrochloride 100 MG Extended Release Oral Capsule
917	http://snomed.info/sct	428211000124100	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of substance use (procedure)
918	http://www.nlm.nih.gov/research/umls/rxnorm	1100448	0.0.1	pentobarbital / phenytoin
919	http://www.nlm.nih.gov/research/umls/rxnorm	608139	0.0.1	atomoxetine 100 MG Oral Capsule
920	http://loinc.org	85339-0		Progesterone receptor Ag [Presence] in Breast cancer specimen by Immune stain
921	http://www.nlm.nih.gov/research/umls/rxnorm	1000126	0.0.1	1 ML medroxyprogesterone acetate 150 MG/ML Injection
922	http://www.nlm.nih.gov/research/umls/rxnorm	830878	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Tablet [Cardizem]
923	http://snomed.info/sct	80583007	http://snomed.info/sct/900000000000207008/version/20230430	Severe anxiety (panic) (finding)
924	http://www.nlm.nih.gov/research/umls/rxnorm	308403	0.0.1	aspirin 165 MG Delayed Release Oral Tablet
925	http://www.nlm.nih.gov/research/umls/rxnorm	584532	0.0.1	erythromycin 0.005 MG/MG [Eyemycin]
926	http://snomed.info/sct	47020004	http://snomed.info/sct/900000000000207008/version/20230430	Ventriculoperitoneal shunt (procedure)
927	http://snomed.info/sct	57676002	http://snomed.info/sct/900000000000207008/version/20230430	Joint pain (finding)
928	http://snomed.info/sct	73211009	http://snomed.info/sct/900000000000207008/version/20230430	Diabetes mellitus (disorder)
929	http://www.nlm.nih.gov/research/umls/rxnorm	830795	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Capsule
930	http://www.nlm.nih.gov/research/umls/rxnorm	203088	0.0.1	ketoconazole 20 MG/ML Topical Cream
931	http://www.nlm.nih.gov/research/umls/rxnorm	7514	0.0.1	norethindrone
932	http://www.nlm.nih.gov/research/umls/rxnorm	2119859	0.0.1	carbamazepine 10 MG/ML
933	http://www.nlm.nih.gov/research/umls/rxnorm	897620	0.0.1	24 HR verapamil hydrochloride 180 MG Extended Release Oral Capsule [Verelan]
934	http://www.nlm.nih.gov/research/umls/rxnorm	1488619	0.0.1	{1 (1 ML leuprolide acetate 3.75 MG/ML Prefilled Syringe [Lupron]) / 30 (norethindrone acetate 5 MG Oral Tablet) } Pack [Lupaneta Pack 1-Month]
935	http://www.nlm.nih.gov/research/umls/rxnorm	545158	0.0.1	ciprofloxacin 3 MG/ML / dexamethasone 1 MG/ML [Ciprodex]
936	http://www.nlm.nih.gov/research/umls/rxnorm	571790	0.0.1	carbamazepine 200 MG [Carbatrol]
937	http://www.nlm.nih.gov/research/umls/rxnorm	689516	0.0.1	aspirin / caffeine / ipecac / opium
938	http://www.nlm.nih.gov/research/umls/rxnorm	1251325	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet [Femhrt]
939	http://www.nlm.nih.gov/research/umls/rxnorm	68139	0.0.1	rocuronium
940	http://www.nlm.nih.gov/research/umls/rxnorm	866412	0.0.1	24 HR metoprolol succinate 100 MG Extended Release Oral Tablet
941	http://snomed.info/sct	177157003	http://snomed.info/sct/900000000000207008/version/20230430	Spontaneous breech delivery
942	http://www.nlm.nih.gov/research/umls/rxnorm	486956	0.0.1	erythromycin estolate 50 MG/ML
943	http://snomed.info/sct	403190006	http://snomed.info/sct/900000000000207008/version/20230430	Epidermal burn of skin (disorder)
944	http://www.nlm.nih.gov/research/umls/rxnorm	316480	0.0.1	phenobarbital 3 MG/ML
945	http://www.nlm.nih.gov/research/umls/rxnorm	1439947	0.0.1	acetic acid / chlorhexidine / ketoconazole
946	http://www.nlm.nih.gov/research/umls/rxnorm	636045	0.0.1	hydrochlorothiazide 25 MG / valsartan 320 MG Oral Tablet
947	http://snomed.info/sct	60951000119105	http://snomed.info/sct/900000000000207008/version/20230430	Blindness due to type 2 diabetes mellitus (disorder)
948	http://www.nlm.nih.gov/research/umls/rxnorm	103863	0.0.1	aspirin 150 MG Rectal Suppository
949	http://www.nlm.nih.gov/research/umls/rxnorm	1007147	0.0.1	homatropine / phenobarbital
950	http://www.nlm.nih.gov/research/umls/rxnorm	328572	0.0.1	phenobarbital 130 MG/ML
951	http://www.nlm.nih.gov/research/umls/rxnorm	1009102	0.0.1	ergotamine / levorotatory alkaloids of belladonna / phenobarbital
952	http://snomed.info/sct	267036007	http://snomed.info/sct/900000000000207008/version/20230430	Dyspnea (finding)
953	http://www.nlm.nih.gov/research/umls/rxnorm	1294394	0.0.1	belladonna alkaloids 0.2 MG / ergotamine tartrate 0.6 MG / phenobarbital 40 MG Oral Tablet
954	http://www.nlm.nih.gov/research/umls/rxnorm	201867	0.0.1	rifampin 150 MG Oral Capsule [Rifadin]
955	http://snomed.info/sct	233174007	http://snomed.info/sct/900000000000207008/version/20230430	Cardiac pacemaker procedure (procedure)
956	http://www.nlm.nih.gov/research/umls/rxnorm	863185	0.0.1	aspirin 410 MG
957	http://www.nlm.nih.gov/research/umls/rxnorm	830902	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Tablet [Cardizem]
958	http://www.nlm.nih.gov/research/umls/rxnorm	209468	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Excedrin]
959	http://snomed.info/sct	249497008	http://snomed.info/sct/900000000000207008/version/20230430	Vomiting symptom (finding)
960	http://snomed.info/sct	51116004	http://snomed.info/sct/900000000000207008/version/20230430	Passive immunization (procedure)
961	http://snomed.info/sct	200936003	http://snomed.info/sct/900000000000207008/version/20230430	Lupus erythematosus
962	http://snomed.info/sct	84229001	http://snomed.info/sct/900000000000207008/version/20230430	Fatigue (finding)
963	http://snomed.info/sct	234817001	http://snomed.info/sct/900000000000207008/version/20230430	Insertion of oral appliance for the handicapped (procedure)
964	http://snomed.info/sct	206523001	http://snomed.info/sct/900000000000207008/version/20230430	Meconium Ileus
965	http://snomed.info/sct	36971009	http://snomed.info/sct/900000000000207008/version/20230430	Sinusitis (disorder)
966	http://www.nlm.nih.gov/research/umls/rxnorm	563439	0.0.1	rifabutin 150 MG [Mycobutin]
967	http://www.nlm.nih.gov/research/umls/rxnorm	1053327	0.0.1	aspirin 845 MG / caffeine 65 MG Oral Powder [Stanback Headache Powder Reformulated Jan 2011]
968	http://www.nlm.nih.gov/research/umls/rxnorm	574349	0.0.1	rifapentine 150 MG [Priftin]
969	http://www.nlm.nih.gov/research/umls/rxnorm	898690	0.0.1	benazepril hydrochloride 20 MG Oral Tablet
970	http://snomed.info/sct	127295002	http://snomed.info/sct/900000000000207008/version/20230430	Traumatic brain injury (disorder)
971	http://www.nlm.nih.gov/research/umls/rxnorm	854179	0.0.1	dexamethasone 0.7 MG [Ozurdex]
972	http://www.nlm.nih.gov/research/umls/rxnorm	830880	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Tablet [Cardizem]
973	http://www.nlm.nih.gov/research/umls/rxnorm	727711	0.0.1	0.67 ML anakinra 149 MG/ML Prefilled Syringe
974	http://snomed.info/sct	410770002	http://snomed.info/sct/900000000000207008/version/20230430	Administration of anesthesia for procedure (procedure)
975	http://www.nlm.nih.gov/research/umls/rxnorm	1098709	0.0.1	nefazodone hydrochloride 300 MG
976	http://www.nlm.nih.gov/research/umls/rxnorm	1247402	0.0.1	aspirin 845 MG / caffeine 65 MG Oral Powder [BC Original Formula]
977	http://www.nlm.nih.gov/research/umls/rxnorm	328768	0.0.1	troleandomycin 250 MG
978	http://www.nlm.nih.gov/research/umls/rxnorm	751868	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Nortrel 0.5/35 28 Day]
979	http://www.nlm.nih.gov/research/umls/rxnorm	897122	0.0.1	3 ML liraglutide 6 MG/ML Pen Injector
980	http://snomed.info/sct	108290001	http://snomed.info/sct/900000000000207008/version/20230430	Radiation oncology AND/OR radiotherapy
981	http://www.nlm.nih.gov/research/umls/rxnorm	2556806	0.0.1	estradiol / norethindrone / relugolix
982	http://www.nlm.nih.gov/research/umls/rxnorm	617311	0.0.1	atorvastatin 40 MG Oral Tablet
983	http://www.nlm.nih.gov/research/umls/rxnorm	1098674	0.0.1	nefazodone hydrochloride 250 MG Oral Tablet
984	http://www.nlm.nih.gov/research/umls/rxnorm	1091264	0.0.1	phenobarbital 10 MG/ML
985	http://snomed.info/sct	444470001	http://snomed.info/sct/900000000000207008/version/20230430	Injury of anterior cruciate ligament
986	http://www.nlm.nih.gov/research/umls/rxnorm	828585	0.0.1	aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 32 MG Oral Capsule
987	http://snomed.info/sct	48333001	http://snomed.info/sct/900000000000207008/version/20230430	Burn injury (morphologic abnormality)
988	http://snomed.info/sct	413107006	http://snomed.info/sct/900000000000207008/version/20230430	Hepatitis C screening (procedure)
989	http://www.nlm.nih.gov/research/umls/rxnorm	315090	0.0.1	erythromycin 333 MG Delayed Release Oral Tablet
990	http://snomed.info/sct	129574000	http://snomed.info/sct/900000000000207008/version/20230430	Postoperative myocardial infarction (disorder)
991	http://snomed.info/sct	395123002	http://snomed.info/sct/900000000000207008/version/20230430	Urine screening test for diabetes
992	http://www.nlm.nih.gov/research/umls/rxnorm	979473	0.0.1	hydrochlorothiazide 25 MG / losartan potassium 100 MG Oral Tablet [Hyzaar]
993	http://www.nlm.nih.gov/research/umls/rxnorm	402681	0.0.1	ketoconazole 0.02 MG/MG
994	http://snomed.info/sct	281790008	http://snomed.info/sct/900000000000207008/version/20230430	Intravenous antibiotic therapy
995	http://www.nlm.nih.gov/research/umls/rxnorm	689509	0.0.1	aspirin / caffeine / chlorpheniramine
996	http://www.nlm.nih.gov/research/umls/rxnorm	1994334	0.0.1	chlorhexidine 0.02 MG/MG / ketoconazole 0.01 MG/MG [Keto-C]
997	http://www.nlm.nih.gov/research/umls/rxnorm	208813	0.0.1	dexamethasone 1 MG/ML / tobramycin 3 MG/ML Ophthalmic Suspension [Tobradex]
998	http://www.nlm.nih.gov/research/umls/rxnorm	1435630	0.0.1	enalapril maleate 1 MG/ML Oral Solution [Epaned]
999	http://snomed.info/sct	312157006	http://snomed.info/sct/900000000000207008/version/20230430	Infectious mediastinitis (disorder)
1000	http://snomed.info/sct	183976008	http://snomed.info/sct/900000000000207008/version/20230430	Operative procedure planned (situation)
1001	http://www.nlm.nih.gov/research/umls/rxnorm	848927	0.0.1	aspirin 325 MG / oxycodone hydrochloride 4.84 MG [Endodan Reformulated May 2009]
1002	http://snomed.info/sct	359817006	http://snomed.info/sct/900000000000207008/version/20230430	Closed fracture of hip
1003	http://www.nlm.nih.gov/research/umls/rxnorm	729766	0.0.1	ketoconazole 20 MG/ML [Extina]
1004	http://www.nlm.nih.gov/research/umls/rxnorm	692836	0.0.1	acetaminophen 325 MG / aspirin 500 MG / caffeine 65 MG Oral Powder
1005	http://www.nlm.nih.gov/research/umls/rxnorm	205304	0.0.1	telmisartan 40 MG Oral Tablet
1006	http://www.nlm.nih.gov/research/umls/rxnorm	689552	0.0.1	acetaminophen / aspirin / caffeine / codeine / salicylamide
1007	http://www.nlm.nih.gov/research/umls/rxnorm	315563	0.0.1	carbamazepine 100 MG
1008	http://www.nlm.nih.gov/research/umls/rxnorm	1358775	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Microgestin Fe 1/20 28 Day]
1009	http://snomed.info/sct	305428000	http://snomed.info/sct/900000000000207008/version/20230430	Admission to orthopedic department
1010	http://www.nlm.nih.gov/research/umls/rxnorm	830846	0.0.1	diltiazem hydrochloride 180 MG [Cardizem]
1011	http://www.nlm.nih.gov/research/umls/rxnorm	1007337	0.0.1	aspirin / isosorbide
1012	http://snomed.info/sct	274031008	http://snomed.info/sct/900000000000207008/version/20230430	Rectal polypectomy
1013	http://snomed.info/sct	110467000	http://snomed.info/sct/900000000000207008/version/20230430	Pre-surgery testing (procedure)
1014	http://snomed.info/sct	52765003	http://snomed.info/sct/900000000000207008/version/20230430	Intubation
1015	http://www.nlm.nih.gov/research/umls/rxnorm	2262021	0.0.1	rifabutin 12.5 MG
1016	http://loinc.org	72166-2		Tobacco smoking status
1017	http://www.nlm.nih.gov/research/umls/rxnorm	833218	0.0.1	diltiazem hydrochloride 30 MG [Cardizem]
1018	http://snomed.info/sct	42839003	http://snomed.info/sct/900000000000207008/version/20230430	Repair of myelomeningocele (procedure)
1019	http://snomed.info/sct	698423002	http://snomed.info/sct/900000000000207008/version/20230430	History of disarticulation at wrist (situation)
1020	http://www.nlm.nih.gov/research/umls/rxnorm	1805285	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Topical Lotion
1021	http://snomed.info/sct	698306007	http://snomed.info/sct/900000000000207008/version/20230430	Awaiting transplantation of kidney (situation)
1022	http://loinc.org	6085-5		Common Ragweed IgE Ab [Units/volume] in Serum
1023	http://www.nlm.nih.gov/research/umls/rxnorm	749853	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Ortho-Novum 7/7/7 28 Day]
1024	http://www.nlm.nih.gov/research/umls/rxnorm	330866	0.0.1	oxcarbazepine 150 MG
1025	http://www.nlm.nih.gov/research/umls/rxnorm	198200	0.0.1	rifabutin 150 MG Oral Capsule
1026	http://www.nlm.nih.gov/research/umls/rxnorm	1099638	0.0.1	ethinyl estradiol 0.025 MG / norethindrone 0.8 MG Chewable Tablet
1027	http://snomed.info/sct	49727002	http://snomed.info/sct/900000000000207008/version/20230430	Cough (finding)
1028	http://www.nlm.nih.gov/research/umls/rxnorm	1251500	0.0.1	estradiol 0.00208 MG/HR / norethindrone acetate 0.0104 MG/HR [Combipatch]
1029	http://www.nlm.nih.gov/research/umls/rxnorm	251854	0.0.1	clarithromycin 50 MG/ML Injectable Suspension
1030	http://www.nlm.nih.gov/research/umls/rxnorm	830802	0.0.1	diltiazem hydrochloride 300 MG [Cardizem]
1031	http://www.nlm.nih.gov/research/umls/rxnorm	636042	0.0.1	hydrochlorothiazide 12.5 MG / valsartan 320 MG Oral Tablet
1032	http://www.nlm.nih.gov/research/umls/rxnorm	2624207	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Rhuzdah 28 Day]
1033	http://snomed.info/sct	40095003	http://snomed.info/sct/900000000000207008/version/20230430	Injury of kidney (disorder)
1034	http://snomed.info/sct	265764009	http://snomed.info/sct/900000000000207008/version/20230430	Renal dialysis (procedure)
1035	http://www.nlm.nih.gov/research/umls/rxnorm	848165	0.0.1	aspirin 500 MG [Bufferin]
1036	http://www.nlm.nih.gov/research/umls/rxnorm	994535	0.0.1	aspirin 770 MG / caffeine 60 MG / orphenadrine citrate 50 MG Oral Tablet
1037	http://www.nlm.nih.gov/research/umls/rxnorm	2267026	0.0.1	aspirin 1000 MG / caffeine 150 MG Oral Powder
1038	http://www.nlm.nih.gov/research/umls/rxnorm	979464	0.0.1	hydrochlorothiazide 12.5 MG / losartan potassium 100 MG Oral Tablet
1039	http://www.nlm.nih.gov/research/umls/rxnorm	2047241	0.0.1	baricitinib 2 MG Oral Tablet
1040	http://snomed.info/sct	60151004	http://snomed.info/sct/900000000000207008/version/20230430	Neonatal Screening
1041	http://loinc.org	8331-1		Oral temperature
1042	http://snomed.info/sct	371908008	http://snomed.info/sct/900000000000207008/version/20230430	Oxygen administration by mask (procedure)
1043	http://www.nlm.nih.gov/research/umls/rxnorm	315422	0.0.1	aspirin 400 MG
1044	http://snomed.info/sct	72892002	http://snomed.info/sct/900000000000207008/version/20230430	Normal pregnancy
1045	http://www.nlm.nih.gov/research/umls/rxnorm	392662	0.0.1	ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet
1046	http://www.nlm.nih.gov/research/umls/rxnorm	898342	0.0.1	amlodipine 10 MG / benazepril hydrochloride 20 MG Oral Capsule
1047	http://www.nlm.nih.gov/research/umls/rxnorm	1593110	0.0.1	acetaminophen 250 MG / aspirin 250 MG / diphenhydramine citrate 38 MG Oral Tablet
1048	http://www.nlm.nih.gov/research/umls/rxnorm	763116	0.0.1	acetaminophen 260 MG / aspirin 520 MG / caffeine 32.5 MG Oral Powder
1049	http://www.nlm.nih.gov/research/umls/rxnorm	2393784	0.0.1	aspirin 6 MG/ML Oral Spray
1050	http://www.nlm.nih.gov/research/umls/rxnorm	596926	0.0.1	duloxetine 20 MG Delayed Release Oral Capsule
1051	http://snomed.info/sct	763228001	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using Canadian Study of Health and Aging Clinical Frailty Scale (procedure)
1052	http://www.nlm.nih.gov/research/umls/rxnorm	214253	0.0.1	aspirin / hydrocodone
1053	http://snomed.info/sct	73595000	http://snomed.info/sct/900000000000207008/version/20230430	Stress (finding)
1054	http://www.nlm.nih.gov/research/umls/rxnorm	1736656	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG Oral Tablet [Fyavolv]
1055	http://www.nlm.nih.gov/research/umls/rxnorm	1486801	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Lomedia 24 Fe]
1056	http://www.nlm.nih.gov/research/umls/rxnorm	199755	0.0.1	isoniazid 100 MG / rifampin 150 MG Oral Tablet
1057	http://snomed.info/sct	266257000	http://snomed.info/sct/900000000000207008/version/20230430	Transient ischemic attack (disorder)
1058	http://snomed.info/sct	283545005	http://snomed.info/sct/900000000000207008/version/20230430	Gunshot wound (disorder)
1059	http://loinc.org	9843-4		Head Occipital-frontal circumference
1060	http://snomed.info/sct	87628006	http://snomed.info/sct/900000000000207008/version/20230430	Bacterial infectious disease (disorder)
1061	http://www.nlm.nih.gov/research/umls/rxnorm	1593109	0.0.1	acetaminophen / aspirin / diphenhydramine
1062	http://www.nlm.nih.gov/research/umls/rxnorm	1306292	0.0.1	cobicistat 150 MG / elvitegravir 150 MG / emtricitabine 200 MG / tenofovir disoproxil fumarate 300 MG Oral Tablet
1063	http://snomed.info/sct	104375008	http://snomed.info/sct/900000000000207008/version/20230430	Hepatitis C antibody, confirmatory test
1064	http://loinc.org	44963-7		Capillary refill [Time] of Nail bed
1065	http://snomed.info/sct	5602001	http://snomed.info/sct/900000000000207008/version/20230430	Opioid abuse (disorder)
1066	http://www.nlm.nih.gov/research/umls/rxnorm	2262032	0.0.1	amoxicillin 250 MG / omeprazole 10 MG / rifabutin 12.5 MG Delayed Release Oral Capsule [Talicia]
1067	http://snomed.info/sct	86175003	http://snomed.info/sct/900000000000207008/version/20230430	Injury of heart (disorder)
1068	http://www.nlm.nih.gov/research/umls/rxnorm	1358770	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Loestrin Fe 1/20 28 Day]
1069	http://www.nlm.nih.gov/research/umls/rxnorm	664961	0.0.1	ketoconazole 0.02 MG/MG Topical Gel [Xolegel]
1070	http://www.nlm.nih.gov/research/umls/rxnorm	198767	0.0.1	Pancreatin 600 MG Oral Tablet
1071	http://loinc.org	59576-9		Body mass index (BMI) [Percentile] Per age and sex
1072	http://snomed.info/sct	241149003	http://snomed.info/sct/900000000000207008/version/20230430	Videofluoroscopy swallow (procedure)
1073	http://www.nlm.nih.gov/research/umls/rxnorm	830844	0.0.1	diltiazem hydrochloride 180 MG
1074	http://snomed.info/sct	261554009	http://snomed.info/sct/900000000000207008/version/20230430	Reoperation (qualifier value)
1075	http://snomed.info/sct	60554003	http://snomed.info/sct/900000000000207008/version/20230430	Polysomnography (procedure)
1076	http://www.nlm.nih.gov/research/umls/rxnorm	1251493	0.0.1	84 HR estradiol 0.00208 MG/HR / norethindrone acetate 0.00583 MG/HR Transdermal System
1077	http://www.nlm.nih.gov/research/umls/rxnorm	1098665	0.0.1	nefazodone hydrochloride 150 MG
1078	http://loinc.org	8867-4		Heart rate
1079	http://www.nlm.nih.gov/research/umls/rxnorm	818205	0.0.1	rifampin / trimethoprim
1080	http://www.nlm.nih.gov/research/umls/rxnorm	897597	0.0.1	verapamil hydrochloride 300 MG [Verelan]
1081	http://snomed.info/sct	201834006	http://snomed.info/sct/900000000000207008/version/20230430	Localized, primary osteoarthritis of the hand
1082	http://www.nlm.nih.gov/research/umls/rxnorm	903872	0.0.1	fluvoxamine maleate 100 MG
1083	http://www.nlm.nih.gov/research/umls/rxnorm	1300911	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Wera 28 Day]
1084	http://www.nlm.nih.gov/research/umls/rxnorm	242969	0.0.1	4 ML norepinephrine 1 MG/ML Injection
1085	http://www.nlm.nih.gov/research/umls/rxnorm	689556	0.0.1	acetaminophen / aspirin / phenylpropanolamine
1086	http://loinc.org	6844-5		Honey bee IgE Ab [Units/volume] in Serum
1087	http://snomed.info/sct	271737000	http://snomed.info/sct/900000000000207008/version/20230430	Anemia (disorder)
1088	http://www.nlm.nih.gov/research/umls/rxnorm	315430	0.0.1	aspirin 800 MG
1089	http://www.nlm.nih.gov/research/umls/rxnorm	248175	0.0.1	dexamethasone 0.02 MG/ACTUAT / tramazoline 0.12 MG/ACTUAT Nasal Spray
1090	http://www.nlm.nih.gov/research/umls/rxnorm	831012	0.0.1	diltiazem hydrochloride 60 MG Oral Capsule
1091	http://www.nlm.nih.gov/research/umls/rxnorm	198464	0.0.1	aspirin 300 MG Rectal Suppository
1092	http://snomed.info/sct	92691004	http://snomed.info/sct/900000000000207008/version/20230430	Carcinoma in situ of prostate (disorder)
1093	http://www.nlm.nih.gov/research/umls/rxnorm	240812	0.0.1	ketoconazole 10 MG/ML Medicated Shampoo
1094	http://www.nlm.nih.gov/research/umls/rxnorm	8782	0.0.1	propofol
1095	http://www.nlm.nih.gov/research/umls/rxnorm	855868	0.0.1	phenytoin sodium 30 MG
1096	http://snomed.info/sct	37849005	http://snomed.info/sct/900000000000207008/version/20230430	Congenital uterine anomaly
1097	http://www.nlm.nih.gov/research/umls/rxnorm	328354	0.0.1	erythromycin 40 MG/ML
1098	http://snomed.info/sct	86406008	http://snomed.info/sct/900000000000207008/version/20230430	Human immunodeficiency virus infection (disorder)
1099	http://www.nlm.nih.gov/research/umls/rxnorm	686420	0.0.1	erythromycin ethylsuccinate 80 MG/ML Oral Suspension [EryPed]
1100	http://www.nlm.nih.gov/research/umls/rxnorm	1744259	0.0.1	5 ML metoprolol tartrate 1 MG/ML Cartridge
1101	http://www.nlm.nih.gov/research/umls/rxnorm	2595466	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule) / 4 (ferrous fumarate 75 MG Oral Capsule) } Pack [Merzee 28 Day]
1102	http://www.nlm.nih.gov/research/umls/rxnorm	317443	0.0.1	norethindrone 0.5 MG
1103	http://snomed.info/sct	709138001	http://snomed.info/sct/900000000000207008/version/20230430	Notification of treatment plan (procedure)
1104	http://snomed.info/sct	213150003	http://snomed.info/sct/900000000000207008/version/20230430	Kidney transplant failure and rejection (disorder)
1105	http://snomed.info/sct	431856006	http://snomed.info/sct/900000000000207008/version/20230430	Chronic kidney disease stage 2 (disorder)
1106	http://snomed.info/sct	715252007	http://snomed.info/sct/900000000000207008/version/20230430	Depression screening using Patient Health Questionnaire Nine Item score (procedure)
1107	http://loinc.org	65750-2		Drugs of abuse 5 panel - Urine by Screen method
1108	http://loinc.org	6301-6		INR in Platelet poor plasma by Coagulation assay
1109	http://www.nlm.nih.gov/research/umls/rxnorm	425351	0.0.1	erythromycin 100 MG/ML Oral Suspension
1110	http://www.nlm.nih.gov/research/umls/rxnorm	2118835	0.0.1	{27 (dexamethasone 1.5 MG Oral Tablet) } Pack [TaperDex 7-Day Taper]
1111	http://snomed.info/sct	313191000	http://snomed.info/sct/900000000000207008/version/20230430	Injection of epinephrine (procedure)
1112	http://www.nlm.nih.gov/research/umls/rxnorm	339981	0.0.1	dexamethasone 0.001 MG/MG
1113	http://www.nlm.nih.gov/research/umls/rxnorm	35296	0.0.1	Ramipril
1114	http://snomed.info/sct	312384001	http://snomed.info/sct/900000000000207008/version/20230430	Multidisciplinary assessment (procedure)
1115	http://loinc.org	85343-2		Lymph nodes with macrometastases [#] in Cancer specimen by Light microscopy
1116	http://www.nlm.nih.gov/research/umls/rxnorm	575199	0.0.1	carbamazepine 300 MG [Carbatrol]
1117	http://snomed.info/sct	33737001	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of rib
1118	http://www.nlm.nih.gov/research/umls/rxnorm	1046998	0.0.1	atropine sulfate 0.0582 MG / hyoscyamine sulfate 0.311 MG / phenobarbital 48.6 MG / scopolamine hydrobromide 0.0195 MG [Donnatal]
1119	http://snomed.info/sct	232657004	http://snomed.info/sct/900000000000207008/version/20230430	Lung Transplant
1120	http://snomed.info/sct	243063003	http://snomed.info/sct/900000000000207008/version/20230430	Postoperative procedure education (procedure)
1121	http://snomed.info/sct	424144002		GegenwÃ¤rtiges chronologisches Alter
1122	http://www.nlm.nih.gov/research/umls/rxnorm	830872	0.0.1	12 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule
1123	http://www.nlm.nih.gov/research/umls/rxnorm	2565491	0.0.1	aspirin 325 MG / dextromethorphan hydrobromide 10 MG / doxylamine succinate 6.25 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet
1124	http://www.nlm.nih.gov/research/umls/rxnorm	897700	0.0.1	verapamil hydrochloride 180 MG Extended Release Oral Tablet [Isoptin]
1125	http://www.nlm.nih.gov/research/umls/rxnorm	392499	0.0.1	aspirin / glycine
1126	http://www.nlm.nih.gov/research/umls/rxnorm	866436	0.0.1	24 HR metoprolol succinate 50 MG Extended Release Oral Tablet
1127	http://snomed.info/sct	262521009	http://snomed.info/sct/900000000000207008/version/20230430	Traumatic injury of spinal cord and/or vertebral column (disorder)
1128	http://www.nlm.nih.gov/research/umls/rxnorm	1008860	0.0.1	amphetamine / phenobarbital
1129	http://www.nlm.nih.gov/research/umls/rxnorm	1722695	0.0.1	aspirin 81 MG / calcium carbonate 777 MG Oral Tablet [Bayer Womens]
1130	http://www.nlm.nih.gov/research/umls/rxnorm	566037	0.0.1	rifampin 150 MG [Rifadin]
1131	http://www.nlm.nih.gov/research/umls/rxnorm	689794	0.0.1	acetaminophen / phenobarbital
1132	http://www.nlm.nih.gov/research/umls/rxnorm	855874	0.0.1	phenytoin sodium 300 MG [Phenytek]
1133	http://www.nlm.nih.gov/research/umls/rxnorm	1007941	0.0.1	estradiol / estriol / norethindrone
1134	http://www.nlm.nih.gov/research/umls/rxnorm	340095	0.0.1	erythromycin 0.02 MG/MG
1135	http://www.nlm.nih.gov/research/umls/rxnorm	1495161	0.0.1	ketoconazole 2 MG/ML
1136	http://www.nlm.nih.gov/research/umls/rxnorm	896006	0.0.1	120 ACTUAT fluticasone propionate 0.22 MG/ACTUAT Metered Dose Inhaler [Flovent]
1137	http://www.nlm.nih.gov/research/umls/rxnorm	315773	0.0.1	dexamethasone 0.1 MG/ML
1138	http://www.nlm.nih.gov/research/umls/rxnorm	329731	0.0.1	erythromycin 100 MG/ML
1139	http://snomed.info/sct	76601001	http://snomed.info/sct/900000000000207008/version/20230430	Intramuscular injection
1140	http://snomed.info/sct	698754002	http://snomed.info/sct/900000000000207008/version/20230430	Chronic paralysis due to lesion of spinal cord
1141	http://www.nlm.nih.gov/research/umls/rxnorm	565987	0.0.1	carbamazepine 200 MG [Tegretol]
1142	http://snomed.info/sct	392021009	http://snomed.info/sct/900000000000207008/version/20230430	Lumpectomy of breast (procedure)
1143	http://www.nlm.nih.gov/research/umls/rxnorm	310152	0.0.1	erythromycin 0.02 MG/MG Topical Gel
1144	http://www.nlm.nih.gov/research/umls/rxnorm	2108015	0.0.1	dexamethasone 0.4 MG Drug Implant
1145	http://www.nlm.nih.gov/research/umls/rxnorm	897784	0.0.1	trandolapril 2 MG / verapamil hydrochloride 180 MG [Tarka]
1146	http://snomed.info/sct	67831000119107	http://snomed.info/sct/900000000000207008/version/20230430	Primary small cell malignant neoplasm of lung, TNM stage 3 (disorder)
1147	http://www.nlm.nih.gov/research/umls/rxnorm	315432	0.0.1	aspirin 850 MG
1148	http://snomed.info/sct	403191005	http://snomed.info/sct/900000000000207008/version/20230430	Second degree burn
1149	http://www.nlm.nih.gov/research/umls/rxnorm	1856402	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Nylia 1/35 28 Day]
1150	http://snomed.info/sct	97331000119101	http://snomed.info/sct/900000000000207008/version/20230430	Macular edema and retinopathy due to type 2 diabetes mellitus (disorder)
1151	http://www.nlm.nih.gov/research/umls/rxnorm	897785	0.0.1	24 HR trandolapril 2 MG / verapamil hydrochloride 180 MG Extended Release Oral Tablet [Tarka]
1152	http://www.nlm.nih.gov/research/umls/rxnorm	315429	0.0.1	aspirin 75 MG
1153	http://www.nlm.nih.gov/research/umls/rxnorm	1053120	0.0.1	aspirin / dextromethorphan / doxylamine / phenylephrine
1154	http://www.nlm.nih.gov/research/umls/rxnorm	1046997	0.0.1	atropine sulfate 0.0582 MG / hyoscyamine sulfate 0.311 MG / phenobarbital 48.6 MG / scopolamine hydrobromide 0.0195 MG Extended Release Oral Tablet
1155	http://www.nlm.nih.gov/research/umls/rxnorm	1000407	0.0.1	norethindrone acetate 5 MG Oral Tablet [Aygestin]
1156	http://www.nlm.nih.gov/research/umls/rxnorm	1101754	0.0.1	acetaminophen 194 MG / aspirin 227 MG / caffeine 33 MG Oral Tablet [Vanquish]
1157	http://www.nlm.nih.gov/research/umls/rxnorm	1303159	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Arthriten Inflammatory Pain]
1158	http://snomed.info/sct	14768001	http://snomed.info/sct/900000000000207008/version/20230430	Peripheral blood smear interpretation
1159	http://www.nlm.nih.gov/research/umls/rxnorm	349477	0.0.1	efavirenz 600 MG Oral Tablet
1160	http://www.nlm.nih.gov/research/umls/rxnorm	898353	0.0.1	amlodipine 5 MG / benazepril hydrochloride 10 MG Oral Capsule
1161	http://snomed.info/sct	79733001	http://snomed.info/sct/900000000000207008/version/20230430	Amputation of left leg
1162	http://snomed.info/sct	160903007	http://snomed.info/sct/900000000000207008/version/20230430	Full-time employment (finding)
1163	http://snomed.info/sct	13569004	http://snomed.info/sct/900000000000207008/version/20230430	Transfusion of plasma (procedure)
1164	http://www.nlm.nih.gov/research/umls/rxnorm	200033	0.0.1	carvedilol 25 MG Oral Tablet
1165	http://www.nlm.nih.gov/research/umls/rxnorm	1994337	0.0.1	chlorhexidine 0.02 MG/MG / ketoconazole 0.01 MG/MG Medicated Pad [Keto-C]
1166	http://snomed.info/sct	313660005	http://snomed.info/sct/900000000000207008/version/20230430	Absolute CD4 count procedure (procedure)
1167	http://www.nlm.nih.gov/research/umls/rxnorm	1988319	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Tiadylt]
1168	http://www.nlm.nih.gov/research/umls/rxnorm	897613	0.0.1	verapamil hydrochloride 120 MG [Verelan]
1169	http://snomed.info/sct	62564004	http://snomed.info/sct/900000000000207008/version/20230430	Concussion with loss of consciousness
1170	http://snomed.info/sct	373786007	http://snomed.info/sct/900000000000207008/version/20230430	Reasons for treatment delay (finding)
1171	http://snomed.info/sct	252480006	http://snomed.info/sct/900000000000207008/version/20230430	Simple walk test (procedure)
1172	http://www.nlm.nih.gov/research/umls/rxnorm	331283	0.0.1	carbamazepine 250 MG
1173	http://www.nlm.nih.gov/research/umls/rxnorm	1094107	0.0.1	Phenazopyridine hydrochloride 100 MG Oral Tablet
1174	http://snomed.info/sct	58828004	http://snomed.info/sct/900000000000207008/version/20230430	Application of dressing, sterile (procedure)
1175	http://snomed.info/sct	274474001	http://snomed.info/sct/900000000000207008/version/20230430	Bone immobilization
1176	http://snomed.info/sct	45595009	http://snomed.info/sct/900000000000207008/version/20230430	Laparoscopic Removal of Gall Bladder
1177	http://www.nlm.nih.gov/research/umls/rxnorm	1601380	0.0.1	palbociclib 100 MG Oral Capsule
1178	http://snomed.info/sct	76164006	http://snomed.info/sct/900000000000207008/version/20230430	Biopsy of colon
1179	http://loinc.org	8310-5		Body temperature
1180	http://www.nlm.nih.gov/research/umls/rxnorm	691251	0.0.1	ergotamine / hyoscyamine / phenobarbital
1181	http://www.nlm.nih.gov/research/umls/rxnorm	2664074	0.0.1	{1 (aspirin 325 MG / chlorpheniramine maleate 2 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) / 1 (aspirin 325 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) } Pack
1182	http://www.nlm.nih.gov/research/umls/rxnorm	1488618	0.0.1	{1 (1 ML leuprolide acetate 3.75 MG/ML Prefilled Syringe) / 30 (norethindrone acetate 5 MG Oral Tablet) } Pack
1183	http://www.nlm.nih.gov/research/umls/rxnorm	994539	0.0.1	aspirin 770 MG / caffeine 60 MG / orphenadrine citrate 50 MG Oral Tablet [Orphengesic]
1184	http://www.nlm.nih.gov/research/umls/rxnorm	1439948	0.0.1	acetic acid 20 MG/ML / chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo
1185	http://www.nlm.nih.gov/research/umls/rxnorm	104474	0.0.1	aspirin 75 MG Oral Tablet
1186	http://www.nlm.nih.gov/research/umls/rxnorm	1943550	0.0.1	{49 (dexamethasone 1.5 MG Oral Tablet) } Pack
1187	http://www.nlm.nih.gov/research/umls/rxnorm	209387	0.0.1	Acetaminophen 325 MG Oral Tablet [Tylenol]
1188	http://www.nlm.nih.gov/research/umls/rxnorm	859419	0.0.1	rosuvastatin calcium 40 MG Oral Tablet
1189	http://snomed.info/sct	180325003	http://snomed.info/sct/900000000000207008/version/20230430	Direct current cardioversion (procedure)
1190	http://www.nlm.nih.gov/research/umls/rxnorm	898362	0.0.1	benazepril hydrochloride 10 MG / hydrochlorothiazide 12.5 MG Oral Tablet
1191	http://www.nlm.nih.gov/research/umls/rxnorm	854908	0.0.1	bisoprolol fumarate 10 MG / hydrochlorothiazide 6.25 MG Oral Tablet
1192	http://loinc.org	21907-1		Distant metastases.clinical [Class] Cancer
1193	http://www.nlm.nih.gov/research/umls/rxnorm	1007854	0.0.1	clotrimazole / dexamethasone
1194	http://snomed.info/sct	3457005	http://snomed.info/sct/900000000000207008/version/20230430	Patient referral (procedure)
1195	http://www.nlm.nih.gov/research/umls/rxnorm	351136	0.0.1	albuterol 0.417 MG/ML Inhalation Solution
1196	http://www.nlm.nih.gov/research/umls/rxnorm	214256	0.0.1	aspirin / oxycodone
1197	http://www.nlm.nih.gov/research/umls/rxnorm	349148	0.0.1	erythromycin 0.005 MG/MG Topical Ointment
1198	http://www.nlm.nih.gov/research/umls/rxnorm	260218	0.0.1	modafinil 100 MG Oral Tablet
1251	http://www.nlm.nih.gov/research/umls/rxnorm	897845	0.0.1	trandolapril 2 MG / verapamil hydrochloride 240 MG [Tarka]
1199	http://www.nlm.nih.gov/research/umls/rxnorm	1724801	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Blisovi 21 Fe 1/20 28 Day Pack]
1200	http://www.nlm.nih.gov/research/umls/rxnorm	1037182	0.0.1	norethindrone acetate 1 MG
1201	http://www.nlm.nih.gov/research/umls/rxnorm	830838	0.0.1	diltiazem hydrochloride 240 MG [Cardizem]
1202	http://www.nlm.nih.gov/research/umls/rxnorm	830874	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Tablet
1203	http://www.nlm.nih.gov/research/umls/rxnorm	831346	0.0.1	diltiazem hydrochloride 360 MG [Tiazac]
1204	http://www.nlm.nih.gov/research/umls/rxnorm	860518	0.0.1	24 HR carvedilol phosphate 20 MG Extended Release Oral Capsule [Coreg]
1205	http://www.nlm.nih.gov/research/umls/rxnorm	831347	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Capsule [Tiazac]
1206	http://www.nlm.nih.gov/research/umls/rxnorm	849860	0.0.1	diltiazem malate 240 MG Oral Tablet
1207	http://snomed.info/sct	43878008	http://snomed.info/sct/900000000000207008/version/20230430	Streptococcal sore throat (disorder)
1208	http://snomed.info/sct	707418001	http://snomed.info/sct/900000000000207008/version/20230430	Male infertility due to cystic fibrosis (disorder)
1209	http://snomed.info/sct	31208007	http://snomed.info/sct/900000000000207008/version/20230430	Medical induction of labor
1210	http://loinc.org	2777-1		Phosphate [Mass/volume] in Serum or Plasma
1211	http://www.nlm.nih.gov/research/umls/rxnorm	1732122	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML / salicyloyl phytosphingosine 0.5 MG/ML Topical Foam
1212	http://www.nlm.nih.gov/research/umls/rxnorm	238015	0.0.1	ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet
1213	http://www.nlm.nih.gov/research/umls/rxnorm	316386	0.0.1	norethindrone 1 MG
1214	http://snomed.info/sct	415070008	http://snomed.info/sct/900000000000207008/version/20230430	Percutaneous coronary intervention (procedure)
1215	http://www.nlm.nih.gov/research/umls/rxnorm	200095	0.0.1	irbesartan 150 MG Oral Tablet
1216	http://www.nlm.nih.gov/research/umls/rxnorm	199756	0.0.1	isoniazid 150 MG / rifampin 300 MG Oral Tablet
1217	http://www.nlm.nih.gov/research/umls/rxnorm	856578	0.0.1	propranolol hydrochloride 80 MG Oral Tablet
1218	http://snomed.info/sct	232965003	http://snomed.info/sct/900000000000207008/version/20230430	Implantation of ventricular assist device (procedure)
1219	http://www.nlm.nih.gov/research/umls/rxnorm	216524	0.0.1	dexamethasone / neomycin
1220	http://www.nlm.nih.gov/research/umls/rxnorm	1234872	0.0.1	aspirin 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule
1221	http://snomed.info/sct	25656009	http://snomed.info/sct/900000000000207008/version/20230430	Physical examination, complete (procedure)
1222	http://www.nlm.nih.gov/research/umls/rxnorm	2360605	0.0.1	acetaminophen 500 MG / aspirin 500 MG / caffeine 65 MG Oral Powder
1223	http://www.nlm.nih.gov/research/umls/rxnorm	1856546	0.0.1	Kyleena 19.5 MG Intrauterine System
1224	http://www.nlm.nih.gov/research/umls/rxnorm	858813	0.0.1	enalapril maleate 5 MG Oral Tablet
1225	http://snomed.info/sct	698314001	http://snomed.info/sct/900000000000207008/version/20230430	Consultation for treatment (procedure)
1226	http://snomed.info/sct	1551000119108	http://snomed.info/sct/900000000000207008/version/20230430	Nonproliferative diabetic retinopathy due to type 2 diabetes mellitus (disorder)
1227	http://www.nlm.nih.gov/research/umls/rxnorm	966524	0.0.1	120 ACTUAT budesonide 0.18 MG/ACTUAT Dry Powder Inhaler [Pulmicort]
1228	http://snomed.info/sct	61977001	http://snomed.info/sct/900000000000207008/version/20230430	Chronic type B viral hepatitis (disorder)
1229	http://snomed.info/sct	414545008	http://snomed.info/sct/900000000000207008/version/20230430	Ischemic heart disease (disorder)
1230	http://snomed.info/sct	162864005	http://snomed.info/sct/900000000000207008/version/20230430	Body mass index 30+ - obesity (finding)
1231	http://snomed.info/sct	301011002	http://snomed.info/sct/900000000000207008/version/20230430	Escherichia coli urinary tract infection
1232	http://www.nlm.nih.gov/research/umls/rxnorm	1593116	0.0.1	acetaminophen 250 MG / aspirin 250 MG / diphenhydramine citrate 38 MG Oral Tablet [Excedrin PM Triple Action]
1233	http://www.nlm.nih.gov/research/umls/rxnorm	1495165	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML / salicyloyl phytosphingosine 0.2 MG/ML Topical Solution
1234	http://www.nlm.nih.gov/research/umls/rxnorm	1251322	0.0.1	norethindrone acetate 0.5 MG
1235	http://www.nlm.nih.gov/research/umls/rxnorm	350637	0.0.1	voriconazole 200 MG
1236	http://snomed.info/sct	126877002	http://snomed.info/sct/900000000000207008/version/20230430	Disorder of glucose metabolism (disorder)
1237	http://snomed.info/sct	431855005	http://snomed.info/sct/900000000000207008/version/20230430	Chronic kidney disease stage 1 (disorder)
1238	http://www.nlm.nih.gov/research/umls/rxnorm	200032	0.0.1	carvedilol 12.5 MG Oral Tablet
1239	http://snomed.info/sct	367498001	http://snomed.info/sct/900000000000207008/version/20230430	Seasonal allergic rhinitis
1240	http://www.nlm.nih.gov/research/umls/rxnorm	564044	0.0.1	dexamethasone 0.5 MG [Decadron]
1241	http://www.nlm.nih.gov/research/umls/rxnorm	898316	0.0.1	4 ML verapamil hydrochloride 2.5 MG/ML Prefilled Syringe
1242	http://snomed.info/sct	40617009	http://snomed.info/sct/900000000000207008/version/20230430	Artificial respiration (procedure)
1243	http://www.nlm.nih.gov/research/umls/rxnorm	1008619	0.0.1	belladonna alkaloids / caffeine / ergotamine / phenobarbital
1244	http://snomed.info/sct	35999006	http://snomed.info/sct/900000000000207008/version/20230430	Blighted ovum
1245	http://www.nlm.nih.gov/research/umls/rxnorm	1235874	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Philith 28 Day]
1246	http://www.nlm.nih.gov/research/umls/rxnorm	566749	0.0.1	clarithromycin 50 MG/ML [Biaxin]
1247	http://www.nlm.nih.gov/research/umls/rxnorm	2119860	0.0.1	20 ML carbamazepine 10 MG/ML Injection
1248	http://snomed.info/sct	26212005	http://snomed.info/sct/900000000000207008/version/20230430	Replacement of aortic valve (procedure)
1249	http://www.nlm.nih.gov/research/umls/rxnorm	831360	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Capsule [Tiazac]
1250	http://loinc.org	19123-9		Magnesium [Mass/volume] in Serum or Plasma
1252	http://snomed.info/sct	102263004	http://snomed.info/sct/900000000000207008/version/20230430	Eggs (edible) (substance)
1253	http://www.nlm.nih.gov/research/umls/rxnorm	1988315	0.0.1	diltiazem hydrochloride 240 MG [Tiadylt]
1254	http://snomed.info/sct	448417001	http://snomed.info/sct/900000000000207008/version/20230430	Sepsis caused by Staphylococcus aureus
1255	http://www.nlm.nih.gov/research/umls/rxnorm	198182	0.0.1	pyrimethamine 25 MG Oral Tablet
1256	http://loinc.org	74006-8		Weight difference [Mass difference] --pre dialysis - post dialysis
1257	http://www.nlm.nih.gov/research/umls/rxnorm	597195	0.0.1	Carboplatin 10 MG/ML Injectable Solution
1258	http://www.nlm.nih.gov/research/umls/rxnorm	854916	0.0.1	bisoprolol fumarate 2.5 MG / hydrochlorothiazide 6.25 MG Oral Tablet
1259	http://snomed.info/sct	711069006	http://snomed.info/sct/900000000000207008/version/20230430	Coordination of care plan (procedure)
1260	http://www.nlm.nih.gov/research/umls/rxnorm	1730187	0.0.1	{1 (aspirin 325 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) / 1 (aspirin 500 MG / dextromethorphan hydrobromide 10 MG / doxylamine succinate 6.25 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) } Pack
1261	http://snomed.info/sct	63697000	http://snomed.info/sct/900000000000207008/version/20230430	Cardiopulmonary bypass operation (procedure)
1262	http://loinc.org	6158-0		Latex IgE Ab [Units/volume] in Serum
1263	http://snomed.info/sct	733863009	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of readiness for self-management (procedure)
1264	http://www.nlm.nih.gov/research/umls/rxnorm	1009392	0.0.1	dexamethasone 1 MG/ML / neomycin 3.2 MG/ML / thiabendazole 40 MG/ML Topical Solution [Tresaderm]
1265	http://snomed.info/sct	236077008	http://snomed.info/sct/900000000000207008/version/20230430	Protracted diarrhea
1266	http://snomed.info/sct	713458007	http://snomed.info/sct/900000000000207008/version/20230430	Lack of access to transportation (finding)
1267	http://www.nlm.nih.gov/research/umls/rxnorm	316477	0.0.1	phenobarbital 15 MG/ML
1268	http://www.nlm.nih.gov/research/umls/rxnorm	572393	0.0.1	aspirin 325 MG [Ecotrin]
1269	http://www.nlm.nih.gov/research/umls/rxnorm	855812	0.0.1	prasugrel 10 MG Oral Tablet
1270	http://www.nlm.nih.gov/research/umls/rxnorm	751871	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) } Pack [Nortrel 1/35 21 Day]
1271	http://loinc.org	8289-1		Head Occipital-frontal circumference Percentile
1272	http://www.nlm.nih.gov/research/umls/rxnorm	1099897	0.0.1	{24 (ethinyl estradiol 0.025 MG / norethindrone 0.8 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Generess Fe 28]
1273	http://www.nlm.nih.gov/research/umls/rxnorm	2387355	0.0.1	{25 (dexamethasone 1.5 MG Oral Tablet) } Pack
1274	http://snomed.info/sct	22523008	http://snomed.info/sct/900000000000207008/version/20230430	Vasectomy
1275	http://loinc.org	80271-0		Physical findings of Abdomen by Palpation
1276	http://www.nlm.nih.gov/research/umls/rxnorm	213082	0.0.1	benzoyl peroxide 0.05 MG/MG / erythromycin 0.03 MG/MG Topical Gel [Benzamycin]
1277	http://www.nlm.nih.gov/research/umls/rxnorm	830800	0.0.1	diltiazem hydrochloride 300 MG
1278	http://www.nlm.nih.gov/research/umls/rxnorm	856569	0.0.1	24 HR propranolol hydrochloride 80 MG Extended Release Oral Capsule
1279	http://www.nlm.nih.gov/research/umls/rxnorm	1593112	0.0.1	acetaminophen 250 MG / aspirin 250 MG / diphenhydramine citrate 38 MG [Excedrin PM Triple Action]
1280	http://www.nlm.nih.gov/research/umls/rxnorm	1359022	0.0.1	ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet
1281	http://www.nlm.nih.gov/research/umls/rxnorm	897632	0.0.1	24 HR verapamil hydrochloride 360 MG Extended Release Oral Capsule [Verelan]
1282	http://www.nlm.nih.gov/research/umls/rxnorm	1046978	0.0.1	atropine sulfate 0.0194 MG / hyoscyamine sulfate 0.1037 MG / phenobarbital 16.2 MG / scopolamine hydrobromide 0.0065 MG Oral Tablet [Donnatal]
1283	http://www.nlm.nih.gov/research/umls/rxnorm	312749	0.0.1	quinapril 20 MG Oral Tablet
1284	http://www.nlm.nih.gov/research/umls/rxnorm	689746	0.0.1	phenobarbital / sodium nitrite
1285	http://www.nlm.nih.gov/research/umls/rxnorm	856556	0.0.1	propranolol hydrochloride 60 MG Oral Tablet
1286	http://www.nlm.nih.gov/research/umls/rxnorm	751620	0.0.1	nebivolol 2.5 MG Oral Tablet [Bystolic]
1287	http://snomed.info/sct	91434003	http://snomed.info/sct/900000000000207008/version/20230430	Pulmonic valve regurgitation (disorder)
1288	http://snomed.info/sct	117010004	http://snomed.info/sct/900000000000207008/version/20230430	Urine culture
1289	http://snomed.info/sct	278860009	http://snomed.info/sct/900000000000207008/version/20230430	Chronic low back pain (finding)
1290	http://www.nlm.nih.gov/research/umls/rxnorm	1100449	0.0.1	pentobarbital sodium 390 MG/ML / phenytoin sodium 50 MG/ML Injectable Solution
1291	http://www.nlm.nih.gov/research/umls/rxnorm	1798297	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Pad
1292	http://www.nlm.nih.gov/research/umls/rxnorm	335933	0.0.1	aspirin 389 MG
1293	http://loinc.org	6276-0		Wheat IgE Ab [Units/volume] in Serum
1294	http://www.nlm.nih.gov/research/umls/rxnorm	1791229	0.0.1	5 ML diltiazem hydrochloride 5 MG/ML Injection
1295	http://www.nlm.nih.gov/research/umls/rxnorm	896758	0.0.1	labetalol hydrochloride 100 MG Oral Tablet
1296	http://snomed.info/sct	52052004	http://snomed.info/sct/900000000000207008/version/20230430	Rehabilitation therapy (regime/therapy)
1297	http://loinc.org	87626-8		Suicide prevention note
1298	http://www.nlm.nih.gov/research/umls/rxnorm	897591	0.0.1	verapamil hydrochloride 200 MG [Verelan]
1299	http://www.nlm.nih.gov/research/umls/rxnorm	465397	0.0.1	ciprofloxacin / dexamethasone
1300	http://snomed.info/sct	236423003	http://snomed.info/sct/900000000000207008/version/20230430	Renal impairment (disorder)
1301	http://www.nlm.nih.gov/research/umls/rxnorm	848768	0.0.1	aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet
1302	http://www.nlm.nih.gov/research/umls/rxnorm	1087919	0.0.1	dexamethasone 3 MG/ML Injectable Solution [Dexium]
1303	http://www.nlm.nih.gov/research/umls/rxnorm	814504	0.0.1	dexamethasone / indomethacin
1304	http://www.nlm.nih.gov/research/umls/rxnorm	349353	0.0.1	hydrochlorothiazide 25 MG / valsartan 160 MG Oral Tablet
1305	http://www.nlm.nih.gov/research/umls/rxnorm	313988	0.0.1	Furosemide 40 MG Oral Tablet
1306	http://www.nlm.nih.gov/research/umls/rxnorm	2261801	0.0.1	dexamethasone 20 MG
1307	http://snomed.info/sct	275272006	http://snomed.info/sct/900000000000207008/version/20230430	Brain damage - traumatic
1308	http://www.nlm.nih.gov/research/umls/rxnorm	830900	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Tablet
1309	http://snomed.info/sct	385488000	http://snomed.info/sct/900000000000207008/version/20230430	Surgical procedure on chest wall (procedure)
1310	http://www.nlm.nih.gov/research/umls/rxnorm	1359132	0.0.1	{5 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ethinyl estradiol 0.03 MG / norethindrone acetate 1 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack
1311	http://www.nlm.nih.gov/research/umls/rxnorm	349483	0.0.1	valsartan 40 MG Oral Tablet
1312	http://www.nlm.nih.gov/research/umls/rxnorm	1014676	0.0.1	cetirizine hydrochloride 5 MG Oral Tablet
1313	http://snomed.info/sct	64859006	http://snomed.info/sct/900000000000207008/version/20230430	Osteoporosis (disorder)
1314	http://www.nlm.nih.gov/research/umls/rxnorm	831243	0.0.1	diltiazem hydrochloride 180 MG [Tiazac]
1315	http://www.nlm.nih.gov/research/umls/rxnorm	798131	0.0.1	erythromycin 20 MG/ML [Ery]
1316	http://www.nlm.nih.gov/research/umls/rxnorm	643066	0.0.1	efavirenz 600 MG / emtricitabine 200 MG / tenofovir disoproxil fumarate 300 MG Oral Tablet
1317	http://snomed.info/sct	74857009	http://snomed.info/sct/900000000000207008/version/20230430	Hospital admission, short-term, 24 hours
1318	http://www.nlm.nih.gov/research/umls/rxnorm	328353	0.0.1	erythromycin 50 MG/ML
1319	http://www.nlm.nih.gov/research/umls/rxnorm	2193	0.0.1	Ceftriaxone
1320	http://www.nlm.nih.gov/research/umls/rxnorm	1806890	0.0.1	lisinopril 1 MG/ML Oral Solution [Qbrelis]
1321	http://www.nlm.nih.gov/research/umls/rxnorm	691232	0.0.1	ephedrine / phenobarbital / potassium iodide / theophylline
1322	http://www.nlm.nih.gov/research/umls/rxnorm	2394058	0.0.1	aspirin / menthol
1323	http://www.nlm.nih.gov/research/umls/rxnorm	1053325	0.0.1	aspirin 845 MG / caffeine 65 MG [Stanback Headache Powder Reformulated Jan 2011]
1324	http://www.nlm.nih.gov/research/umls/rxnorm	1304215	0.0.1	aspirin 500 MG / caffeine 32.5 MG Oral Tablet [Bayer Headache Relief]
1325	http://www.nlm.nih.gov/research/umls/rxnorm	866429	0.0.1	24 HR metoprolol succinate 25 MG Extended Release Oral Tablet [Toprol]
1326	http://www.nlm.nih.gov/research/umls/rxnorm	608843	0.0.1	ketoconazole 10 MG/ML [Nizoral]
1327	http://www.nlm.nih.gov/research/umls/rxnorm	261360	0.0.1	oxcarbazepine 300 MG Oral Tablet [Trileptal]
1328	http://snomed.info/sct	9002005	http://snomed.info/sct/900000000000207008/version/20230430	Manual testing of muscle function (procedure)
1329	http://www.nlm.nih.gov/research/umls/rxnorm	309684	0.0.1	dexamethasone 1 MG/ML Oral Solution
1330	http://www.nlm.nih.gov/research/umls/rxnorm	332981	0.0.1	dexamethasone 3 MG/ML
1331	http://www.nlm.nih.gov/research/umls/rxnorm	575940	0.0.1	voriconazole 200 MG [Vfend]
1332	http://snomed.info/sct	225444004	http://snomed.info/sct/900000000000207008/version/20230430	At risk for suicide (finding)
1333	http://www.nlm.nih.gov/research/umls/rxnorm	1791701	0.0.1	10 ML Fluorouracil 50 MG/ML Injection
1334	http://www.nlm.nih.gov/research/umls/rxnorm	597454	0.0.1	clarithromycin 1000 MG
1335	http://www.nlm.nih.gov/research/umls/rxnorm	477139	0.0.1	voriconazole 40 MG/ML
1336	http://www.nlm.nih.gov/research/umls/rxnorm	1049386	0.0.1	dexamethasone 2 MG/ML Injectable Solution [Dexium]
1337	http://www.nlm.nih.gov/research/umls/rxnorm	1944109	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Arthriten Max]
1338	http://www.nlm.nih.gov/research/umls/rxnorm	1863367	0.0.1	rifampin 600 MG [Rifadin]
1339	http://www.nlm.nih.gov/research/umls/rxnorm	1245441	0.0.1	ezetimibe 10 MG / simvastatin 40 MG Oral Tablet [Vytorin]
1340	http://www.nlm.nih.gov/research/umls/rxnorm	904475	0.0.1	pravastatin sodium 40 MG Oral Tablet
1341	http://www.nlm.nih.gov/research/umls/rxnorm	855930	0.0.1	phenytoin sodium 100 MG Oral Tablet
1342	http://snomed.info/sct	200619008	http://snomed.info/sct/900000000000207008/version/20230430	Comprehensive interview and evaluation (procedure)
1343	http://snomed.info/sct	306706006	http://snomed.info/sct/900000000000207008/version/20230430	Discharge to ward (procedure)
1344	http://snomed.info/sct	269828009	http://snomed.info/sct/900000000000207008/version/20230430	Syphilis infectious titer test (procedure)
1345	http://snomed.info/sct	306316000	http://snomed.info/sct/900000000000207008/version/20230430	Referral to transplant surgeon (procedure)
1346	http://www.nlm.nih.gov/research/umls/rxnorm	1251327	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG Oral Tablet [Femhrt]
1347	http://www.nlm.nih.gov/research/umls/rxnorm	1927366	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack [Aurovela 1/20 21 Day]
1348	http://snomed.info/sct	302761001	http://snomed.info/sct/900000000000207008/version/20230430	Walking exercise test (procedure)
1349	http://www.nlm.nih.gov/research/umls/rxnorm	1359133	0.0.1	{5 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ethinyl estradiol 0.03 MG / norethindrone acetate 1 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Estrostep Fe 28 Day]
1350	http://www.nlm.nih.gov/research/umls/rxnorm	103954	0.0.1	aspirin 75 MG Delayed Release Oral Tablet
1351	http://snomed.info/sct	157141000119108	http://snomed.info/sct/900000000000207008/version/20230430	Proteinuria due to type 2 diabetes mellitus (disorder)
1352	http://www.nlm.nih.gov/research/umls/rxnorm	686404	0.0.1	erythromycin ethylsuccinate 400 MG
1353	http://www.nlm.nih.gov/research/umls/rxnorm	896762	0.0.1	labetalol hydrochloride 200 MG Oral Tablet
1354	http://www.nlm.nih.gov/research/umls/rxnorm	308977	0.0.1	12 HR carbamazepine 200 MG Extended Release Oral Capsule [Carbatrol]
1355	http://www.nlm.nih.gov/research/umls/rxnorm	831323	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Tiazac]
1356	http://www.nlm.nih.gov/research/umls/rxnorm	1534422	0.0.1	aspirin / carbidopa
1357	http://www.nlm.nih.gov/research/umls/rxnorm	897631	0.0.1	verapamil hydrochloride 360 MG [Verelan]
1358	http://www.nlm.nih.gov/research/umls/rxnorm	689245	0.0.1	aprobarbital / butabarbital / phenobarbital
1359	http://www.nlm.nih.gov/research/umls/rxnorm	466549	0.0.1	aspirin / caffeine / orphenadrine
1360	http://www.nlm.nih.gov/research/umls/rxnorm	753536	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Zenchent 28 Day]
1361	http://loinc.org	753-4		Neutrophils [#/volume] in Blood by Manual count
1362	http://loinc.org	29554-3		Procedure Narrative
1363	http://www.nlm.nih.gov/research/umls/rxnorm	818496	0.0.1	aspirin / chlorpheniramine / phenylephrine
1364	http://snomed.info/sct	65363002	http://snomed.info/sct/900000000000207008/version/20230430	Otitis media
1365	http://snomed.info/sct	103750000	http://snomed.info/sct/900000000000207008/version/20230430	Sleep apnea assessment (procedure)
1366	http://www.nlm.nih.gov/research/umls/rxnorm	141952	0.0.1	carbamazepine 400 MG Oral Tablet
1367	http://www.nlm.nih.gov/research/umls/rxnorm	2106641	0.0.1	itraconazole 65 MG
1368	http://www.nlm.nih.gov/research/umls/rxnorm	1365850	0.0.1	24 HR oxcarbazepine 600 MG Extended Release Oral Tablet [Oxtellar]
1369	http://snomed.info/sct	239872002	http://snomed.info/sct/900000000000207008/version/20230430	Osteoarthritis of hip
1370	http://www.nlm.nih.gov/research/umls/rxnorm	208601	0.0.1	dexamethasone 0.001 MG/MG / neomycin 0.0035 MG/MG / polymyxin B 10 UNT/MG Ophthalmic Ointment [Maxitrol]
1371	http://www.nlm.nih.gov/research/umls/rxnorm	2559721	0.0.1	phenobarbital 60 MG Oral Tablet [Nobatol]
1372	http://www.nlm.nih.gov/research/umls/rxnorm	605252	0.0.1	aspirin 650 MG / caffeine 33.3 MG / salicylamide 195 MG Oral Powder
1373	http://www.nlm.nih.gov/research/umls/rxnorm	310150	0.0.1	erythromycin 15 MG/ML Topical Solution
1374	http://www.nlm.nih.gov/research/umls/rxnorm	571739	0.0.1	aspirin 400 MG / caffeine 32 MG [P-A-C Analgesic]
1375	http://www.nlm.nih.gov/research/umls/rxnorm	848166	0.0.1	aspirin 500 MG Oral Tablet [Bufferin]
1376	http://www.nlm.nih.gov/research/umls/rxnorm	896766	0.0.1	labetalol hydrochloride 300 MG Oral Tablet
1377	http://www.nlm.nih.gov/research/umls/rxnorm	689515	0.0.1	aspirin / caffeine / hydrocodone
1378	http://www.nlm.nih.gov/research/umls/rxnorm	1049635	0.0.1	Acetaminophen 325 MG / oxyCODONE Hydrochloride 2.5 MG Oral Tablet
1379	http://www.nlm.nih.gov/research/umls/rxnorm	797050	0.0.1	aspirin 650 MG / caffeine 32 MG / salicylamide 200 MG Oral Powder
1380	http://snomed.info/sct	9564003	http://snomed.info/sct/900000000000207008/version/20230430	Complete blood count with white cell differential, automated (procedure)
1381	http://www.nlm.nih.gov/research/umls/rxnorm	198463	0.0.1	aspirin 200 MG Rectal Suppository
1382	http://snomed.info/sct	167252002	http://snomed.info/sct/900000000000207008/version/20230430	Urine pregnancy test (procedure)
1383	http://snomed.info/sct	449868002	http://snomed.info/sct/900000000000207008/version/20230430	Smokes tobacco daily
1384	http://www.nlm.nih.gov/research/umls/rxnorm	1049399	0.0.1	dexamethasone sodium phosphate 4 MG/ML
1385	http://www.nlm.nih.gov/research/umls/rxnorm	897592	0.0.1	24 HR verapamil hydrochloride 200 MG Extended Release Oral Capsule [Verelan]
1386	http://www.nlm.nih.gov/research/umls/rxnorm	895996	0.0.1	120 ACTUAT fluticasone propionate 0.044 MG/ACTUAT Metered Dose Inhaler [Flovent]
1387	http://www.nlm.nih.gov/research/umls/rxnorm	1732186	0.0.1	100 ML Epirubicin Hydrochloride 2 MG/ML Injection
1388	http://www.nlm.nih.gov/research/umls/rxnorm	859421	0.0.1	rosuvastatin calcium 40 MG Oral Tablet [Crestor]
1389	http://www.nlm.nih.gov/research/umls/rxnorm	1007464	0.0.1	oxyphencyclimine / phenobarbital
1390	http://snomed.info/sct	274531002	http://snomed.info/sct/900000000000207008/version/20230430	Abnormal findings diagnostic imaging heart+coronary circulat (finding)
1391	http://snomed.info/sct	128302006	http://snomed.info/sct/900000000000207008/version/20230430	Chronic hepatitis C (disorder)
1392	http://www.nlm.nih.gov/research/umls/rxnorm	688213	0.0.1	aspirin 2.5 MG/ML
1393	http://snomed.info/sct	866148006	http://snomed.info/sct/900000000000207008/version/20230430	Screening for domestic abuse (procedure)
1394	http://www.nlm.nih.gov/research/umls/rxnorm	2176	0.0.1	Cefaclor
1395	http://snomed.info/sct	267060006	http://snomed.info/sct/900000000000207008/version/20230430	Diarrhea symptom (finding)
1396	http://www.nlm.nih.gov/research/umls/rxnorm	1007112	0.0.1	aspirin / pyridinolcarbamate
1397	http://www.nlm.nih.gov/research/umls/rxnorm	1007816	0.0.1	phenobarbital / propantheline
1398	http://www.nlm.nih.gov/research/umls/rxnorm	891136	0.0.1	aspirin 31200 MG Oral Tablet
1399	http://www.nlm.nih.gov/research/umls/rxnorm	261101	0.0.1	rifapentine 150 MG Oral Tablet [Priftin]
1400	http://snomed.info/sct	110359009	http://snomed.info/sct/900000000000207008/version/20230430	Intellectual disability (disorder)
1401	http://www.nlm.nih.gov/research/umls/rxnorm	1053102	0.0.1	aspirin / dextromethorphan / phenylephrine
1402	http://snomed.info/sct	301884003	http://snomed.info/sct/900000000000207008/version/20230430	Removal of aortic cross clamp (procedure)
1403	http://snomed.info/sct	406602003	http://snomed.info/sct/900000000000207008/version/20230430	Infection caused by Staphylococcus aureus
1404	http://www.nlm.nih.gov/research/umls/rxnorm	861646	0.0.1	pitavastatin calcium 1 MG Oral Tablet [Livalo]
1405	http://www.nlm.nih.gov/research/umls/rxnorm	1860491	0.0.1	12 HR Hydrocodone Bitartrate 10 MG Extended Release Oral Capsule
1406	http://snomed.info/sct	120991000119102	http://snomed.info/sct/900000000000207008/version/20230430	History of undergoing in utero procedure while a fetus (situation)
1407	http://www.nlm.nih.gov/research/umls/rxnorm	318202	0.0.1	erythromycin 20 MG/ML Topical Solution
1408	http://www.nlm.nih.gov/research/umls/rxnorm	105392	0.0.1	dexamethasone 0.5 MG Oral Tablet [Decadron]
1409	http://www.nlm.nih.gov/research/umls/rxnorm	1092680	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Medicated Pad [Pharmaseb]
1410	http://www.nlm.nih.gov/research/umls/rxnorm	198211	0.0.1	simvastatin 40 MG Oral Tablet
1411	http://www.nlm.nih.gov/research/umls/rxnorm	689744	0.0.1	phenobarbital / phenytoin
1412	http://snomed.info/sct	736169004	http://snomed.info/sct/900000000000207008/version/20230430	Post anesthesia care management (procedure)
1413	http://www.nlm.nih.gov/research/umls/rxnorm	1116926	0.0.1	dexamethasone phosphate 4 MG/ML
2179	http://www.nlm.nih.gov/research/umls/rxnorm	214249	0.0.1	aspirin / butalbital
1414	http://www.nlm.nih.gov/research/umls/rxnorm	672908	0.0.1	12 HR carbamazepine 100 MG Extended Release Oral Capsule [Equetro]
1415	http://www.nlm.nih.gov/research/umls/rxnorm	393545	0.0.1	norethindrone 0.75 MG
1416	http://www.nlm.nih.gov/research/umls/rxnorm	831054	0.0.1	diltiazem hydrochloride 120 MG Oral Tablet
1417	http://snomed.info/sct	69031006	http://snomed.info/sct/900000000000207008/version/20230430	Excision of breast tissue (procedure)
1418	http://www.nlm.nih.gov/research/umls/rxnorm	1359129	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Mimvey]
1419	http://www.nlm.nih.gov/research/umls/rxnorm	351992	0.0.1	oxcarbazepine 60 MG/ML Oral Suspension [Trileptal]
1420	http://www.nlm.nih.gov/research/umls/rxnorm	198337	0.0.1	troleandomycin 250 MG Oral Capsule
1421	http://www.nlm.nih.gov/research/umls/rxnorm	896001	0.0.1	120 ACTUAT fluticasone propionate 0.11 MG/ACTUAT Metered Dose Inhaler [Flovent]
1422	http://www.nlm.nih.gov/research/umls/rxnorm	855946	0.0.1	phenytoin sodium 50 MG Oral Capsule
1423	http://snomed.info/sct	410538000	http://snomed.info/sct/900000000000207008/version/20230430	Scheduling (procedure)
1424	http://www.nlm.nih.gov/research/umls/rxnorm	311204	0.0.1	itraconazole 100 MG Oral Capsule
1425	http://www.nlm.nih.gov/research/umls/rxnorm	749737	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Ovcon 35 28 Day]
1426	http://loinc.org	21377-7		Magnesium [Mass/volume] in Blood
1427	http://snomed.info/sct	428061005	http://snomed.info/sct/900000000000207008/version/20230430	Malignant neoplasm of brain (disorder)
1428	http://www.nlm.nih.gov/research/umls/rxnorm	247137	0.0.1	aspirin 650 MG Oral Powder
1429	http://www.nlm.nih.gov/research/umls/rxnorm	226716	0.0.1	aspirin / dipyridamole
1430	http://www.nlm.nih.gov/research/umls/rxnorm	897596	0.0.1	24 HR verapamil hydrochloride 300 MG Extended Release Oral Capsule
1431	http://www.nlm.nih.gov/research/umls/rxnorm	689555	0.0.1	acetaminophen / aspirin / codeine
1432	http://www.nlm.nih.gov/research/umls/rxnorm	853501	0.0.1	aspirin 228 MG Chewing Gum [Aspergum]
1433	http://snomed.info/sct	707577004	http://snomed.info/sct/900000000000207008/version/20230430	Female Infertility
1434	http://www.nlm.nih.gov/research/umls/rxnorm	1358762	0.0.1	ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet
1435	http://snomed.info/sct	422968005	http://snomed.info/sct/900000000000207008/version/20230430	Non-small cell carcinoma of lung, TNM stage 3 (disorder)
1436	http://www.nlm.nih.gov/research/umls/rxnorm	897675	0.0.1	verapamil hydrochloride 180 MG [Calan]
1437	http://snomed.info/sct	230690007	http://snomed.info/sct/900000000000207008/version/20230430	Cerebrovascular accident (disorder)
1438	http://www.nlm.nih.gov/research/umls/rxnorm	328349	0.0.1	erythromycin 0.005 MG/MG
1439	http://www.nlm.nih.gov/research/umls/rxnorm	330469	0.0.1	ketoconazole 20 MG/ML
1440	http://www.nlm.nih.gov/research/umls/rxnorm	1007005	0.0.1	aspirin / quinine
1441	http://www.nlm.nih.gov/research/umls/rxnorm	1365846	0.0.1	oxcarbazepine 300 MG [Oxtellar]
1442	http://www.nlm.nih.gov/research/umls/rxnorm	1007450	0.0.1	aminophylline / papaverine / phenobarbital
1443	http://www.nlm.nih.gov/research/umls/rxnorm	335953	0.0.1	aspirin 250 MG
1444	http://www.nlm.nih.gov/research/umls/rxnorm	1946840	0.0.1	Verzenio 100 MG Oral Tablet
1445	http://www.nlm.nih.gov/research/umls/rxnorm	575098	0.0.1	carbamazepine 100 MG [Tegretol]
1446	http://snomed.info/sct	725351001	http://snomed.info/sct/900000000000207008/version/20230430	Transcatheter aortic valve replacement (procedure)
1447	http://www.nlm.nih.gov/research/umls/rxnorm	1359123	0.0.1	estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet
1448	http://www.nlm.nih.gov/research/umls/rxnorm	1656346	0.0.1	sacubitril 24 MG / valsartan 26 MG Oral Tablet [Entresto]
1449	http://www.nlm.nih.gov/research/umls/rxnorm	316475	0.0.1	phenobarbital 100 MG
1450	http://www.nlm.nih.gov/research/umls/rxnorm	1049384	0.0.1	dexamethasone 2 MG/ML [Dexium]
1451	http://www.nlm.nih.gov/research/umls/rxnorm	198031	0.0.1	nicotine 7 MG/Day 24HR Transdermal System
1452	http://www.nlm.nih.gov/research/umls/rxnorm	1495092	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Norlyroc 28 Day]
1453	http://www.nlm.nih.gov/research/umls/rxnorm	200082	0.0.1	lamivudine 150 MG / zidovudine 300 MG Oral Tablet
1454	http://www.nlm.nih.gov/research/umls/rxnorm	1008144	0.0.1	liver,desiccated / phenobarbital
1455	http://www.nlm.nih.gov/research/umls/rxnorm	2099508	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Hailey Fe 1.5/30 28 Day]
1456	http://www.nlm.nih.gov/research/umls/rxnorm	608695	0.0.1	aspirin 500 MG / caffeine 32 MG [Anacin]
1457	http://www.nlm.nih.gov/research/umls/rxnorm	315564	0.0.1	carbamazepine 20 MG/ML
1458	http://www.nlm.nih.gov/research/umls/rxnorm	1427300	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Pirmella 1/35 28 Day]
1459	http://www.nlm.nih.gov/research/umls/rxnorm	1303155	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Arthriten Inflammatory Pain]
1460	http://www.nlm.nih.gov/research/umls/rxnorm	2586034	0.0.1	125 ML diltiazem hydrochloride 1 MG/ML Injection
1461	http://www.nlm.nih.gov/research/umls/rxnorm	309043	0.0.1	12 HR Cefaclor 500 MG Extended Release Oral Tablet
1462	http://snomed.info/sct	55822004	http://snomed.info/sct/900000000000207008/version/20230430	Hyperlipidemia
1463	http://snomed.info/sct	232967006	http://snomed.info/sct/900000000000207008/version/20230430	Implantation of left ventricular assist device (procedure)
1464	http://www.nlm.nih.gov/research/umls/rxnorm	831171	0.0.1	diltiazem hydrochloride 120 MG [Diltzac]
1465	http://www.nlm.nih.gov/research/umls/rxnorm	1371365	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Topical Spray
1466	http://www.nlm.nih.gov/research/umls/rxnorm	251325	0.0.1	phenobarbital 15 MG/ML Injectable Solution
1467	http://www.nlm.nih.gov/research/umls/rxnorm	866427	0.0.1	24 HR metoprolol succinate 25 MG Extended Release Oral Tablet
1468	http://www.nlm.nih.gov/research/umls/rxnorm	243670	0.0.1	aspirin 81 MG Oral Tablet
1469	http://loinc.org	33762-6		Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma
1470	http://www.nlm.nih.gov/research/umls/rxnorm	831055	0.0.1	diltiazem hydrochloride 120 MG Oral Tablet [Cardizem]
1471	http://www.nlm.nih.gov/research/umls/rxnorm	1668264	0.0.1	erythromycin lactobionate 500 MG Injection
1472	http://www.nlm.nih.gov/research/umls/rxnorm	855863	0.0.1	phenytoin sodium 200 MG Extended Release Oral Capsule [Phenytek]
1473	http://www.nlm.nih.gov/research/umls/rxnorm	197945	0.0.1	aspirin 325 MG / methocarbamol 400 MG Oral Tablet
1474	http://www.nlm.nih.gov/research/umls/rxnorm	315424	0.0.1	aspirin 500 MG
1475	http://www.nlm.nih.gov/research/umls/rxnorm	317394	0.0.1	itraconazole 100 MG
1476	http://www.nlm.nih.gov/research/umls/rxnorm	865098	0.0.1	Insulin Lispro 100 UNT/ML Injectable Solution [Humalog]
1477	http://www.nlm.nih.gov/research/umls/rxnorm	2588850	0.0.1	levoketoconazole 150 MG [Recorlev]
1478	http://www.nlm.nih.gov/research/umls/rxnorm	1046787	0.0.1	atropine sulfate 0.00388 MG/ML / hyoscyamine sulfate 0.0207 MG/ML / phenobarbital 3.24 MG/ML / scopolamine hydrobromide 0.0013 MG/ML Oral Solution
1479	http://www.nlm.nih.gov/research/umls/rxnorm	723528	0.0.1	acetaminophen 250 MG / aspirin 250 MG [Excedrin Back & Body]
1480	http://snomed.info/sct	27712000	http://snomed.info/sct/900000000000207008/version/20230430	Hypervitaminosis D (disorder)
1481	http://www.nlm.nih.gov/research/umls/rxnorm	1009038	0.0.1	aspirin / papaverine / phenobarbital
1482	http://snomed.info/sct	419199007	http://snomed.info/sct/900000000000207008/version/20230430	Allergy to substance (finding)
1483	http://snomed.info/sct	84478008	http://snomed.info/sct/900000000000207008/version/20230430	Occupational therapy (regime/therapy)
1484	http://www.nlm.nih.gov/research/umls/rxnorm	315876	0.0.1	erythromycin 333 MG
1485	http://snomed.info/sct	65275009	http://snomed.info/sct/900000000000207008/version/20230430	Acute Cholecystitis
1486	http://www.nlm.nih.gov/research/umls/rxnorm	689745	0.0.1	phenobarbital / potassium iodide / sodium bicarbonate / theobromine
1487	http://www.nlm.nih.gov/research/umls/rxnorm	103518	0.0.1	erythromycin 20 MG/ML Topical Lotion
1488	http://www.nlm.nih.gov/research/umls/rxnorm	833216	0.0.1	diltiazem hydrochloride 30 MG
1489	http://www.nlm.nih.gov/research/umls/rxnorm	891133	0.0.1	aspirin 15600 MG
1490	http://www.nlm.nih.gov/research/umls/rxnorm	199167	0.0.1	phenobarbital 32.4 MG Oral Tablet
1491	http://snomed.info/sct	4557003	http://snomed.info/sct/900000000000207008/version/20230430	Preinfarction syndrome (disorder)
1492	http://www.nlm.nih.gov/research/umls/rxnorm	1940648	0.0.1	neratinib 40 MG Oral Tablet
1493	http://snomed.info/sct	79619009	http://snomed.info/sct/900000000000207008/version/20230430	Mitral valve stenosis (disorder)
1495	http://www.nlm.nih.gov/research/umls/rxnorm	1007811	0.0.1	estrogens, conjugated (USP) / phenobarbital
1496	http://www.nlm.nih.gov/research/umls/rxnorm	1665362	0.0.1	24 HR aspirin 162.5 MG Extended Release Oral Capsule [Durlaza]
1497	http://www.nlm.nih.gov/research/umls/rxnorm	198477	0.0.1	aspirin 162 MG Delayed Release Oral Tablet
1498	http://www.nlm.nih.gov/research/umls/rxnorm	10831	0.0.1	Sulfamethoxazole / Trimethoprim
1499	http://www.nlm.nih.gov/research/umls/rxnorm	315426	0.0.1	aspirin 600 MG
1500	http://www.nlm.nih.gov/research/umls/rxnorm	746811	0.0.1	14 ACTUAT mometasone furoate 0.22 MG/ACTUAT Dry Powder Inhaler [Asmanex]
1501	http://loinc.org	6106-9		Egg white IgE Ab [Units/volume] in Serum
1502	http://snomed.info/sct	8290005	http://snomed.info/sct/900000000000207008/version/20230430	Induced cardioplegia (procedure)
1503	http://www.nlm.nih.gov/research/umls/rxnorm	317396	0.0.1	ketoconazole 200 MG
1504	http://www.nlm.nih.gov/research/umls/rxnorm	308297	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet
1505	http://www.nlm.nih.gov/research/umls/rxnorm	1665358	0.0.1	aspirin 162.5 MG [Durlaza]
1506	http://www.nlm.nih.gov/research/umls/rxnorm	309097	0.0.1	Cefuroxime 250 MG Oral Tablet
1507	http://www.nlm.nih.gov/research/umls/rxnorm	997501	0.0.1	Fexofenadine hydrochloride 60 MG Oral Tablet
1508	http://www.nlm.nih.gov/research/umls/rxnorm	349434	0.0.1	voriconazole 200 MG Oral Tablet
1509	http://www.nlm.nih.gov/research/umls/rxnorm	1665061	0.0.1	4 ML verapamil hydrochloride 2.5 MG/ML Injection
1510	http://snomed.info/sct	162676008	http://snomed.info/sct/900000000000207008/version/20230430	Brief general examination (procedure)
1511	http://www.nlm.nih.gov/research/umls/rxnorm	798133	0.0.1	erythromycin 20 MG/ML Medicated Pad [Ery]
1512	http://www.nlm.nih.gov/research/umls/rxnorm	103899	0.0.1	rifabutin 150 MG Oral Capsule [Mycobutin]
1513	http://www.nlm.nih.gov/research/umls/rxnorm	815833	0.0.1	chloramphenicol / dexamethasone
1514	http://www.nlm.nih.gov/research/umls/rxnorm	672909	0.0.1	12 HR carbamazepine 300 MG Extended Release Oral Capsule [Equetro]
1515	http://snomed.info/sct	246677007	http://snomed.info/sct/900000000000207008/version/20230430	Passive conjunctival congestion (finding)
1516	http://www.nlm.nih.gov/research/umls/rxnorm	311354	0.0.1	lisinopril 5 MG Oral Tablet
1517	http://snomed.info/sct	65966004	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of forearm
1518	http://www.nlm.nih.gov/research/umls/rxnorm	994530	0.0.1	aspirin 385 MG / caffeine 30 MG / orphenadrine citrate 25 MG Oral Tablet [Norgesic]
1519	http://www.nlm.nih.gov/research/umls/rxnorm	1736654	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet [Fyavolv]
1520	http://www.nlm.nih.gov/research/umls/rxnorm	608696	0.0.1	aspirin 500 MG / caffeine 32 MG Oral Tablet [Anacin]
1521	http://snomed.info/sct	243174005	http://snomed.info/sct/900000000000207008/version/20230430	Weaning from mechanically assisted ventilation (procedure)
1522	http://www.nlm.nih.gov/research/umls/rxnorm	1313112	0.0.1	phenytoin 25 MG/ML Oral Suspension
1523	http://www.nlm.nih.gov/research/umls/rxnorm	283536	0.0.1	oxcarbazepine 60 MG/ML Oral Suspension
1524	http://www.nlm.nih.gov/research/umls/rxnorm	311353	0.0.1	lisinopril 2.5 MG Oral Tablet
1525	http://www.nlm.nih.gov/research/umls/rxnorm	1092681	0.0.1	chloroxylenol 20 MG/ML / ketoconazole 10 MG/ML [Pharmaseb]
1526	http://www.nlm.nih.gov/research/umls/rxnorm	994238	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG [Ascomp]
1527	http://www.nlm.nih.gov/research/umls/rxnorm	2559720	0.0.1	phenobarbital 60 MG [Nobatol]
1528	http://www.nlm.nih.gov/research/umls/rxnorm	197885	0.0.1	hydrochlorothiazide 12.5 MG / lisinopril 10 MG Oral Tablet
1529	http://www.nlm.nih.gov/research/umls/rxnorm	1537012	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1916 MG Effervescent Oral Tablet [Bromo Seltzer Antacid Pain Reliever]
1530	http://www.nlm.nih.gov/research/umls/rxnorm	197904	0.0.1	lovastatin 20 MG Oral Tablet
1531	http://www.nlm.nih.gov/research/umls/rxnorm	569272	0.0.1	dexamethasone 0.001 MG/MG / neomycin 0.0035 MG/MG / polymyxin B 10 UNT/MG [Maxitrol]
1532	http://www.nlm.nih.gov/research/umls/rxnorm	1539190	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack [Mimvey Lo 28 Day]
1533	http://www.nlm.nih.gov/research/umls/rxnorm	994277	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Fiorinal with Codeine]
1534	http://snomed.info/sct	84757009	http://snomed.info/sct/900000000000207008/version/20230430	Epilepsy (disorder)
1535	http://www.nlm.nih.gov/research/umls/rxnorm	1251323	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet
1536	http://snomed.info/sct	65710008	http://snomed.info/sct/900000000000207008/version/20230430	Acute respiratory failure (disorder)
1537	http://www.nlm.nih.gov/research/umls/rxnorm	1365847	0.0.1	24 HR oxcarbazepine 300 MG Extended Release Oral Tablet [Oxtellar]
1538	http://www.nlm.nih.gov/research/umls/rxnorm	1098670	0.0.1	nefazodone hydrochloride 200 MG Oral Tablet
1539	http://www.nlm.nih.gov/research/umls/rxnorm	831255	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Cartia]
1540	http://snomed.info/sct	45170000	http://snomed.info/sct/900000000000207008/version/20230430	Encephalitis (disorder)
1541	http://loinc.org	57905-2		Hemoglobin.gastrointestinal.lower [Presence] in Stool by Immunoassay --1st specimen
1542	http://snomed.info/sct	386516004	http://snomed.info/sct/900000000000207008/version/20230430	Anticipatory guidance (procedure)
1543	http://www.nlm.nih.gov/research/umls/rxnorm	198471	0.0.1	aspirin 500 MG Oral Tablet
1544	http://www.nlm.nih.gov/research/umls/rxnorm	310463	0.0.1	ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet
1545	http://snomed.info/sct	58000006	http://snomed.info/sct/900000000000207008/version/20230430	Patient discharge (procedure)
1546	http://snomed.info/sct	423315002	http://snomed.info/sct/900000000000207008/version/20230430	Limited social contact (finding)
1547	http://www.nlm.nih.gov/research/umls/rxnorm	350460	0.0.1	aspirin 856 MG
1548	http://snomed.info/sct	88805009	http://snomed.info/sct/900000000000207008/version/20230430	Chronic congestive heart failure (disorder)
1549	http://www.nlm.nih.gov/research/umls/rxnorm	198475	0.0.1	aspirin 650 MG Oral Tablet
1550	http://www.nlm.nih.gov/research/umls/rxnorm	315778	0.0.1	dexamethasone 4 MG
1551	http://loinc.org	63513-6		Are you covered by health insurance or some other kind of health care plan [PhenX]
1552	http://www.nlm.nih.gov/research/umls/rxnorm	831356	0.0.1	diltiazem hydrochloride 420 MG [Tiazac]
1553	http://www.nlm.nih.gov/research/umls/rxnorm	249869	0.0.1	estradiol 2 MG / norethindrone 1 MG Oral Tablet
1554	http://snomed.info/sct	706870000	http://snomed.info/sct/900000000000207008/version/20230430	Acute pulmonary embolism (disorder)
1555	http://www.nlm.nih.gov/research/umls/rxnorm	2624721	0.0.1	phenobarbital sodium 100 MG [Sezaby]
1556	http://www.nlm.nih.gov/research/umls/rxnorm	315420	0.0.1	aspirin 356.4 MG
1557	http://snomed.info/sct	312681000	http://snomed.info/sct/900000000000207008/version/20230430	Bone density scan (procedure)
1558	http://www.nlm.nih.gov/research/umls/rxnorm	813683	0.0.1	dexamethasone / theophylline
1559	http://snomed.info/sct	40733004	http://snomed.info/sct/900000000000207008/version/20230430	Infectious disease (disorder)
1560	http://www.nlm.nih.gov/research/umls/rxnorm	831196	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Taztia]
1561	http://snomed.info/sct	82808001	http://snomed.info/sct/900000000000207008/version/20230430	Sleep apnea monitoring with alarm (regime/therapy)
1562	http://www.nlm.nih.gov/research/umls/rxnorm	1739887	0.0.1	atropine sulfate 0.0194 MG / hyoscyamine sulfate 0.1037 MG / phenobarbital 16.2 MG / scopolamine hydrobromide 0.0065 MG Oral Tablet [Phenohytro]
1563	http://www.nlm.nih.gov/research/umls/rxnorm	311989	0.0.1	Nitrofurantoin 5 MG/ML Oral Suspension
1564	http://loinc.org	2708-6		Oxygen saturation in Arterial blood
1565	http://www.nlm.nih.gov/research/umls/rxnorm	831103	0.0.1	diltiazem hydrochloride 60 MG Oral Tablet
1566	http://www.nlm.nih.gov/research/umls/rxnorm	211874	0.0.1	aspirin 325 MG Oral Tablet [Bayer Aspirin]
1567	http://www.nlm.nih.gov/research/umls/rxnorm	847225	0.0.1	{21 (dexamethasone 1.5 MG Oral Tablet) } Pack [DexPak TaperPak 6 Day]
1568	http://www.nlm.nih.gov/research/umls/rxnorm	1359028	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack
1569	http://www.nlm.nih.gov/research/umls/rxnorm	335766	0.0.1	dexamethasone 0.02 MG/ACTUAT
1570	http://snomed.info/sct	66071002	http://snomed.info/sct/900000000000207008/version/20230430	Viral hepatitis type B (disorder)
1571	http://www.nlm.nih.gov/research/umls/rxnorm	1101753	0.0.1	acetaminophen 194 MG / aspirin 227 MG / caffeine 33 MG [Vanquish]
1572	http://www.nlm.nih.gov/research/umls/rxnorm	897679	0.0.1	verapamil hydrochloride 240 MG [Calan]
1573	http://www.nlm.nih.gov/research/umls/rxnorm	1605091	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Larin 24 Fe 1/20]
1574	http://www.nlm.nih.gov/research/umls/rxnorm	1366343	0.0.1	Levonorgestrel 0.00354 MG/HR Drug Implant
1575	http://www.nlm.nih.gov/research/umls/rxnorm	284988	0.0.1	didanosine 400 MG Delayed Release Oral Capsule
1576	http://www.nlm.nih.gov/research/umls/rxnorm	351209	0.0.1	voriconazole 200 MG Injection
1577	http://www.nlm.nih.gov/research/umls/rxnorm	1047040	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Cyclafem 1/35 28 Day]
1578	http://loinc.org	33756-8		Polyp size greatest dimension
1579	http://www.nlm.nih.gov/research/umls/rxnorm	849574	0.0.1	Naproxen sodium 220 MG Oral Tablet
1580	http://www.nlm.nih.gov/research/umls/rxnorm	812525	0.0.1	aspirin / phenobarbital
1581	http://snomed.info/sct	302297009	http://snomed.info/sct/900000000000207008/version/20230430	Congenital deformity of foot (disorder)
1582	http://www.nlm.nih.gov/research/umls/rxnorm	1659263	0.0.1	1 ML heparin sodium, porcine 5000 UNT/ML Injection
1583	http://www.nlm.nih.gov/research/umls/rxnorm	994811	0.0.1	aspirin 856 MG / caffeine 60 MG / orphenadrine citrate 50 MG Oral Tablet
1584	http://snomed.info/sct	1121000119107	http://snomed.info/sct/900000000000207008/version/20230430	Chronic neck pain (finding)
1585	http://www.nlm.nih.gov/research/umls/rxnorm	1791232	0.0.1	10 ML diltiazem hydrochloride 5 MG/ML Injection
1586	http://www.nlm.nih.gov/research/umls/rxnorm	1008217	0.0.1	clemastine / dexamethasone
1587	http://www.nlm.nih.gov/research/umls/rxnorm	1007608	0.0.1	belladonna alkaloids / phenobarbital
1588	http://www.nlm.nih.gov/research/umls/rxnorm	198084	0.0.1	phenobarbital 16 MG Oral Capsule
1589	http://www.nlm.nih.gov/research/umls/rxnorm	897685	0.0.1	verapamil hydrochloride 80 MG Oral Tablet [Calan]
1590	http://snomed.info/sct	298382003	http://snomed.info/sct/900000000000207008/version/20230430	Scoliosis deformity of spine (disorder)
1591	http://loinc.org	2532-0		Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma
1592	http://www.nlm.nih.gov/research/umls/rxnorm	817455	0.0.1	ascorbic acid / aspirin / caffeine
1593	http://www.nlm.nih.gov/research/umls/rxnorm	1811632	0.0.1	aspirin 325 MG / omeprazole 40 MG Delayed Release Oral Tablet
1594	http://snomed.info/sct	473231009	http://snomed.info/sct/900000000000207008/version/20230430	Renal disorder medication review (procedure)
1595	http://www.nlm.nih.gov/research/umls/rxnorm	198335	0.0.1	sulfamethoxazole 800 MG / trimethoprim 160 MG Oral Tablet
1596	http://www.nlm.nih.gov/research/umls/rxnorm	797452	0.0.1	erythromycin 20 MG/ML Medicated Pad
1597	http://www.nlm.nih.gov/research/umls/rxnorm	979092	0.0.1	Hydroxychloroquine Sulfate 200 MG Oral Tablet
1598	http://www.nlm.nih.gov/research/umls/rxnorm	259255	0.0.1	atorvastatin 80 MG Oral Tablet
1599	http://www.nlm.nih.gov/research/umls/rxnorm	2394057	0.0.1	aspirin 6 MG
1600	http://www.nlm.nih.gov/research/umls/rxnorm	690789	0.0.1	aminophylline / ephedrine / phenobarbital
1601	http://www.nlm.nih.gov/research/umls/rxnorm	2604804	0.0.1	{56 (amoxicillin 500 MG Oral Capsule) / 28 (clarithromycin 500 MG Oral Tablet) / 28 (vonoprazan 20 MG Oral Tablet) } Pack [Voquezna 14 Day TriplePak 20;500;500]
1602	http://snomed.info/sct	37729005	http://snomed.info/sct/900000000000207008/version/20230430	Patient transfer, in-hospital (procedure)
1603	http://www.nlm.nih.gov/research/umls/rxnorm	749762	0.0.1	Seasonique 91 Day Pack
1604	http://www.nlm.nih.gov/research/umls/rxnorm	572220	0.0.1	aspirin 500 MG [Norwich Aspirin]
1605	http://www.nlm.nih.gov/research/umls/rxnorm	2108020	0.0.1	dexamethasone 0.4 MG Drug Implant [Dextenza]
1606	http://snomed.info/sct	18946005	http://snomed.info/sct/900000000000207008/version/20230430	Epidural anesthesia
1607	http://snomed.info/sct	417511005	http://snomed.info/sct/900000000000207008/version/20230430	Referral to home health care service (procedure)
1608	http://snomed.info/sct	103746007	http://snomed.info/sct/900000000000207008/version/20230430	Heparin therapy (procedure)
1609	http://www.nlm.nih.gov/research/umls/rxnorm	750841	0.0.1	erythromycin stearate 500 MG Oral Tablet [Erythrocin Stearate]
1610	http://snomed.info/sct	54550000	http://snomed.info/sct/900000000000207008/version/20230430	Electroencephalogram (procedure)
1611	http://snomed.info/sct	387685009	http://snomed.info/sct/900000000000207008/version/20230430	Surgical manipulation of shoulder joint
1612	http://snomed.info/sct	17881005	http://snomed.info/sct/900000000000207008/version/20230430	Cauterization of choroid plexus (procedure)
1613	http://snomed.info/sct	300916003	http://snomed.info/sct/900000000000207008/version/20230430	Allergy to latex (finding)
1614	http://www.nlm.nih.gov/research/umls/rxnorm	830898	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Tablet [Cardizem]
1615	http://www.nlm.nih.gov/research/umls/rxnorm	477045	0.0.1	Chlorpheniramine Maleate 2 MG/ML Oral Solution
1616	http://www.nlm.nih.gov/research/umls/rxnorm	466424	0.0.1	aspirin / caffeine / cinnamedrine
1617	http://www.nlm.nih.gov/research/umls/rxnorm	1670351	0.0.1	2 ML phenytoin sodium 50 MG/ML Injection
1618	http://www.nlm.nih.gov/research/umls/rxnorm	1797508	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML [Keto-C]
1619	http://snomed.info/sct	94260004	http://snomed.info/sct/900000000000207008/version/20230430	Secondary malignant neoplasm of colon
1620	http://www.nlm.nih.gov/research/umls/rxnorm	833219	0.0.1	diltiazem hydrochloride 30 MG Oral Tablet [Cardizem]
1621	http://www.nlm.nih.gov/research/umls/rxnorm	113588	0.0.1	erythromycin / sulfisoxazole
1622	http://www.nlm.nih.gov/research/umls/rxnorm	1430383	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Lyza]
1623	http://www.nlm.nih.gov/research/umls/rxnorm	2586036	0.0.1	250 ML diltiazem hydrochloride 1 MG/ML Injection
1624	http://www.nlm.nih.gov/research/umls/rxnorm	1092591	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Topical Spray [Pharmaseb]
1625	http://www.nlm.nih.gov/research/umls/rxnorm	1359294	0.0.1	norethindrone acetate 1 MG Oral Tablet
1626	http://www.nlm.nih.gov/research/umls/rxnorm	312136	0.0.1	oxcarbazepine 150 MG Oral Tablet
1627	http://snomed.info/sct	412071004	http://snomed.info/sct/900000000000207008/version/20230430	Wheat (substance)
1628	http://snomed.info/sct	311707005	http://snomed.info/sct/900000000000207008/version/20230430	Oromotor Exercises
1629	http://snomed.info/sct	384692006	http://snomed.info/sct/900000000000207008/version/20230430	Intracavitary brachytherapy (procedure)
1630	http://snomed.info/sct	263495000		Geschlecht
1631	http://www.nlm.nih.gov/research/umls/rxnorm	1358853	0.0.1	acetaminophen 110 MG / aspirin 162 MG / caffeine 32.4 MG / salicylamide 152 MG Oral Tablet [Exaprin]
1632	http://www.nlm.nih.gov/research/umls/rxnorm	309696	0.0.1	dexamethasone phosphate 10 MG/ML Injectable Solution
1633	http://www.nlm.nih.gov/research/umls/rxnorm	2194	0.0.1	Cefuroxime
1634	http://www.nlm.nih.gov/research/umls/rxnorm	154643	0.0.1	mestranol / norethindrone
1635	http://www.nlm.nih.gov/research/umls/rxnorm	576621	0.0.1	carbamazepine 100 MG [Carbatrol]
1636	http://www.nlm.nih.gov/research/umls/rxnorm	903887	0.0.1	fluvoxamine maleate 25 MG Oral Tablet
1637	http://snomed.info/sct	311555007	http://snomed.info/sct/900000000000207008/version/20230430	Speech and language therapy regime (regime/therapy)
1638	http://www.nlm.nih.gov/research/umls/rxnorm	1599803	0.0.1	24 HR Donepezil hydrochloride 10 MG / Memantine hydrochloride 28 MG Extended Release Oral Capsule
1639	http://www.nlm.nih.gov/research/umls/rxnorm	1359122	0.0.1	norethindrone acetate 0.1 MG
1640	http://www.nlm.nih.gov/research/umls/rxnorm	831338	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Cartia]
1641	http://www.nlm.nih.gov/research/umls/rxnorm	1291987	0.0.1	{4 (amoxicillin 500 MG Oral Capsule) / 2 (clarithromycin 500 MG Oral Tablet) / 2 (omeprazole 20 MG Delayed Release Oral Capsule) } Pack [Omeclamox]
1642	http://snomed.info/sct	446096008	http://snomed.info/sct/900000000000207008/version/20230430	Perennial allergic rhinitis
1643	http://www.nlm.nih.gov/research/umls/rxnorm	486953	0.0.1	erythromycin estolate 250 MG
1644	http://www.nlm.nih.gov/research/umls/rxnorm	897623	0.0.1	verapamil hydrochloride 240 MG
1645	http://www.nlm.nih.gov/research/umls/rxnorm	215451	0.0.1	aspirin / oxycodone hydrochloride / oxycodone terephthalate
1646	http://snomed.info/sct	36576007	http://snomed.info/sct/900000000000207008/version/20230430	Infusion (procedure)
1647	http://snomed.info/sct	433236007	http://snomed.info/sct/900000000000207008/version/20230430	Transthoracic echocardiography (procedure)
1648	http://www.nlm.nih.gov/research/umls/rxnorm	1722689	0.0.1	aspirin 81 MG / calcium carbonate 777 MG Oral Tablet
1649	http://www.nlm.nih.gov/research/umls/rxnorm	1251492	0.0.1	norethindrone acetate 0.00583 MG/HR
1650	http://www.nlm.nih.gov/research/umls/rxnorm	815052	0.0.1	aspirin / diphenhydramine / phenylpropanolamine
1651	http://snomed.info/sct	241615005	http://snomed.info/sct/900000000000207008/version/20230430	Magnetic resonance imaging of breast (procedure)
1652	http://www.nlm.nih.gov/research/umls/rxnorm	1811917	0.0.1	aspirin 81 MG / omeprazole 40 MG [Yosprala]
1653	http://www.nlm.nih.gov/research/umls/rxnorm	1358763	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack
1654	http://snomed.info/sct	429280009	http://snomed.info/sct/900000000000207008/version/20230430	History of amputation of foot (situation)
1655	http://www.nlm.nih.gov/research/umls/rxnorm	197442	0.0.1	carbamazepine 200 MG Chewable Tablet
1656	http://www.nlm.nih.gov/research/umls/rxnorm	313185	0.0.1	Tacrine 10 MG Oral Capsule
1657	http://loinc.org	4549-2		Hemoglobin A1c/Hemoglobin.total in Blood by Electrophoresis
1658	http://www.nlm.nih.gov/research/umls/rxnorm	392494	0.0.1	erythromycin / isotretinoin
1659	http://www.nlm.nih.gov/research/umls/rxnorm	1359026	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Loestrin Fe 1.5/30 28 Day]
1660	http://www.nlm.nih.gov/research/umls/rxnorm	689524	0.0.1	aspirin / citric acid / sodium bicarbonate
1661	http://www.nlm.nih.gov/research/umls/rxnorm	1007353	0.0.1	aspirin / chlorpheniramine / dextromethorphan
1662	http://www.nlm.nih.gov/research/umls/rxnorm	897713	0.0.1	verapamil hydrochloride 240 MG [Isoptin]
1663	http://www.nlm.nih.gov/research/umls/rxnorm	900469	0.0.1	aspirin 1 MG/MG
1664	http://www.nlm.nih.gov/research/umls/rxnorm	310261	0.0.1	exemestane 25 MG Oral Tablet
1665	http://www.nlm.nih.gov/research/umls/rxnorm	689554	0.0.1	acetaminophen / aspirin / caffeine / salicylamide
1666	http://www.nlm.nih.gov/research/umls/rxnorm	856987	0.0.1	Acetaminophen 300 MG / HYDROcodone Bitartrate 5 MG Oral Tablet
1667	http://www.nlm.nih.gov/research/umls/rxnorm	1605257	0.0.1	Liletta 52 MG Intrauterine System
1668	http://www.nlm.nih.gov/research/umls/rxnorm	689519	0.0.1	aspirin / caffeine / salicylamide
1669	http://www.nlm.nih.gov/research/umls/rxnorm	2556798	0.0.1	estradiol 1 MG / norethindrone acetate 0.5 MG [Myfembree]
1670	http://www.nlm.nih.gov/research/umls/rxnorm	1001474	0.0.1	aspirin 325 MG [Ecpirin]
1671	http://www.nlm.nih.gov/research/umls/rxnorm	866514	0.0.1	metoprolol tartrate 50 MG Oral Tablet
1672	http://www.nlm.nih.gov/research/umls/rxnorm	583214	0.0.1	Paclitaxel 100 MG Injection
1673	http://snomed.info/sct	6471006	http://snomed.info/sct/900000000000207008/version/20230430	Suicidal thoughts (finding)
1674	http://loinc.org	48065-7		Fibrin D-dimer FEU [Mass/volume] in Platelet poor plasma
1675	http://www.nlm.nih.gov/research/umls/rxnorm	2119862	0.0.1	20 ML carbamazepine 10 MG/ML Injection [Carnexiv]
1676	http://www.nlm.nih.gov/research/umls/rxnorm	336028	0.0.1	aspirin 230 MG
1677	http://www.nlm.nih.gov/research/umls/rxnorm	197930	0.0.1	aspirin 325 MG / meprobamate 200 MG Oral Tablet
1678	http://snomed.info/sct	45816000	http://snomed.info/sct/900000000000207008/version/20230430	Pyelonephritis
1679	http://snomed.info/sct	62106007	http://snomed.info/sct/900000000000207008/version/20230430	Concussion with no loss of consciousness
1680	http://www.nlm.nih.gov/research/umls/rxnorm	1988330	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Capsule [Tiadylt]
1681	http://loinc.org	18752-6		Exercise stress test study
1682	http://www.nlm.nih.gov/research/umls/rxnorm	574575	0.0.1	oxcarbazepine 150 MG [Trileptal]
1683	http://www.nlm.nih.gov/research/umls/rxnorm	1359134	0.0.1	{5 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ethinyl estradiol 0.03 MG / norethindrone acetate 1 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Tilia Fe]
1684	http://snomed.info/sct	87433001	http://snomed.info/sct/900000000000207008/version/20230430	Pulmonary emphysema (disorder)
1685	http://www.nlm.nih.gov/research/umls/rxnorm	1421459	0.0.1	ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule
1686	http://www.nlm.nih.gov/research/umls/rxnorm	834102	0.0.1	Penicillin V Potassium 500 MG Oral Tablet
1687	http://snomed.info/sct	225338004	http://snomed.info/sct/900000000000207008/version/20230430	Risk assessment (procedure)
1688	http://www.nlm.nih.gov/research/umls/rxnorm	806446	0.0.1	aspirin 500 MG / caffeine 65 MG Oral Tablet
1689	http://www.nlm.nih.gov/research/umls/rxnorm	1361398	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Backaid IPF]
1690	http://www.nlm.nih.gov/research/umls/rxnorm	42355	0.0.1	fluvoxamine
1691	http://snomed.info/sct	370995009	http://snomed.info/sct/900000000000207008/version/20230430	Health risks education (procedure)
1692	http://snomed.info/sct	90470006	http://snomed.info/sct/900000000000207008/version/20230430	Prostatectomy
1693	http://www.nlm.nih.gov/research/umls/rxnorm	201868	0.0.1	rifampin 300 MG Oral Capsule [Rifadin]
1694	http://www.nlm.nih.gov/research/umls/rxnorm	211292	0.0.1	aspirin 400 MG / caffeine 32 MG Oral Tablet [Anacin]
1695	http://www.nlm.nih.gov/research/umls/rxnorm	316483	0.0.1	phenobarbital 30 MG
1696	http://www.nlm.nih.gov/research/umls/rxnorm	21212	0.0.1	clarithromycin
1697	http://www.nlm.nih.gov/research/umls/rxnorm	571342	0.0.1	acetaminophen 115 MG / aspirin 210 MG / caffeine 16 MG / salicylamide 65 MG [Saleto]
1698	http://loinc.org	6248-9		Soybean IgE Ab [Units/volume] in Serum
1699	http://snomed.info/sct	62479008	http://snomed.info/sct/900000000000207008/version/20230430	Acquired immune deficiency syndrome (disorder)
1700	http://www.nlm.nih.gov/research/umls/rxnorm	313572	0.0.1	Vancomycin 50 MG/ML Injectable Solution
1701	http://www.nlm.nih.gov/research/umls/rxnorm	2099700	0.0.1	1 ML dexamethasone phosphate 10 MG/ML Prefilled Syringe
1702	http://www.nlm.nih.gov/research/umls/rxnorm	690828	0.0.1	butabarbital / phenobarbital / secobarbital
1703	http://www.nlm.nih.gov/research/umls/rxnorm	1008045	0.0.1	belladonna extract, USP / phenobarbital
1704	http://www.nlm.nih.gov/research/umls/rxnorm	830865	0.0.1	12 HR diltiazem hydrochloride 60 MG Extended Release Oral Capsule
1705	http://www.nlm.nih.gov/research/umls/rxnorm	763111	0.0.1	acetaminophen 325 MG / aspirin 500 MG Oral Powder
1706	http://www.nlm.nih.gov/research/umls/rxnorm	979466	0.0.1	hydrochlorothiazide 12.5 MG / losartan potassium 100 MG Oral Tablet [Hyzaar]
1707	http://www.nlm.nih.gov/research/umls/rxnorm	198334	0.0.1	sulfamethoxazole 400 MG / trimethoprim 80 MG Oral Tablet
1708	http://snomed.info/sct	38822007	http://snomed.info/sct/900000000000207008/version/20230430	Cystitis
1709	http://www.nlm.nih.gov/research/umls/rxnorm	198461	0.0.1	aspirin 120 MG Rectal Suppository
1710	http://www.nlm.nih.gov/research/umls/rxnorm	1359125	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack [Activella 0.5/0.1 28 Day]
1711	http://www.nlm.nih.gov/research/umls/rxnorm	2671207	0.0.1	1 ML phenobarbital sodium 65 MG/ML Injection
1712	http://www.nlm.nih.gov/research/umls/rxnorm	284215	0.0.1	Clindamycin 300mg
1713	http://www.nlm.nih.gov/research/umls/rxnorm	205717	0.0.1	dexamethasone 6 MG Oral Tablet [Decadron]
1714	http://www.nlm.nih.gov/research/umls/rxnorm	313760	0.0.1	zalcitabine 0.75 MG Oral Tablet
1715	http://www.nlm.nih.gov/research/umls/rxnorm	1251494	0.0.1	estradiol 0.00208 MG/HR / norethindrone acetate 0.00583 MG/HR [Combipatch]
1716	http://www.nlm.nih.gov/research/umls/rxnorm	198042	0.0.1	norethindrone 0.35 MG Oral Tablet
1717	http://www.nlm.nih.gov/research/umls/rxnorm	435681	0.0.1	dexamethasone 2 MG/ML Injectable Solution
1718	http://snomed.info/sct	65546002	http://snomed.info/sct/900000000000207008/version/20230430	Extraction of wisdom tooth
1719	http://snomed.info/sct	233678006	http://snomed.info/sct/900000000000207008/version/20230430	Childhood asthma
1720	http://www.nlm.nih.gov/research/umls/rxnorm	198368	0.0.1	phenobarbital 65 MG/ML Injectable Solution
1721	http://www.nlm.nih.gov/research/umls/rxnorm	897692	0.0.1	verapamil hydrochloride 120 MG [Isoptin]
1722	http://www.nlm.nih.gov/research/umls/rxnorm	1291986	0.0.1	{4 (amoxicillin 500 MG Oral Capsule) / 2 (clarithromycin 500 MG Oral Tablet) / 2 (omeprazole 20 MG Delayed Release Oral Capsule) } Pack
1723	http://www.nlm.nih.gov/research/umls/rxnorm	546622	0.0.1	voriconazole 40 MG/ML [Vfend]
1724	http://www.nlm.nih.gov/research/umls/rxnorm	855870	0.0.1	phenytoin sodium 30 MG [Dilantin]
1725	http://snomed.info/sct	161679004	http://snomed.info/sct/900000000000207008/version/20230430	History of artificial joint (situation)
1726	http://www.nlm.nih.gov/research/umls/rxnorm	198440	0.0.1	Acetaminophen 500 MG Oral Tablet
1727	http://snomed.info/sct	49436004	http://snomed.info/sct/900000000000207008/version/20230430	Atrial fibrillation (disorder)
1728	http://www.nlm.nih.gov/research/umls/rxnorm	310149	0.0.1	erythromycin 0.005 MG/MG Ophthalmic Ointment
1729	http://snomed.info/sct	167995008	http://snomed.info/sct/900000000000207008/version/20230430	Sputum microscopy (procedure)
1730	http://snomed.info/sct	40701008	http://snomed.info/sct/900000000000207008/version/20230430	Echocardiography (procedure)
1731	http://www.nlm.nih.gov/research/umls/rxnorm	897649	0.0.1	verapamil hydrochloride 240 MG Extended Release Oral Tablet
1732	http://snomed.info/sct	385186005	http://snomed.info/sct/900000000000207008/version/20230430	Enema
1733	http://snomed.info/sct	312853008	http://snomed.info/sct/900000000000207008/version/20230430	Medical records review (procedure)
1734	http://www.nlm.nih.gov/research/umls/rxnorm	1049400	0.0.1	dexamethasone sodium phosphate 4 MG/ML Injectable Solution
1735	http://www.nlm.nih.gov/research/umls/rxnorm	994239	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Ascomp]
1736	http://snomed.info/sct	235856003	http://snomed.info/sct/900000000000207008/version/20230430	Disorder of liver (disorder)
1737	http://www.nlm.nih.gov/research/umls/rxnorm	1798546	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo [Keto-C]
1738	http://www.nlm.nih.gov/research/umls/rxnorm	316476	0.0.1	phenobarbital 15 MG
1739	http://snomed.info/sct	104308009	http://snomed.info/sct/900000000000207008/version/20230430	Serologic test for Toxoplasma gondii (procedure)
1740	http://www.nlm.nih.gov/research/umls/rxnorm	309362	0.0.1	Clopidogrel 75 MG Oral Tablet
1741	http://www.nlm.nih.gov/research/umls/rxnorm	897614	0.0.1	24 HR verapamil hydrochloride 120 MG Extended Release Oral Capsule [Verelan]
1742	http://www.nlm.nih.gov/research/umls/rxnorm	1008791	0.0.1	aspirin / caffeine / magnesium carbonate / magnesium salicylate
1743	http://www.nlm.nih.gov/research/umls/rxnorm	211887	0.0.1	aspirin 500 MG Oral Tablet [Bayer Aspirin]
1744	http://www.nlm.nih.gov/research/umls/rxnorm	897590	0.0.1	24 HR verapamil hydrochloride 200 MG Extended Release Oral Capsule
1745	http://loinc.org	718-7		Hemoglobin [Mass/volume] in Blood
1746	http://www.nlm.nih.gov/research/umls/rxnorm	1189781	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [Ecotrin]
1747	http://snomed.info/sct	428915008	http://snomed.info/sct/900000000000207008/version/20230430	Toxoplasma gondii antibody positive (finding)
1748	http://snomed.info/sct	112011000119102	http://snomed.info/sct/900000000000207008/version/20230430	negative screening for PHQ9
1749	http://www.nlm.nih.gov/research/umls/rxnorm	349199	0.0.1	valsartan 80 MG Oral Tablet
1750	http://www.nlm.nih.gov/research/umls/rxnorm	856535	0.0.1	24 HR propranolol hydrochloride 60 MG Extended Release Oral Capsule
1751	http://www.nlm.nih.gov/research/umls/rxnorm	206228	0.0.1	erythromycin 20 MG/ML Topical Solution [Theramycin]
1752	http://www.nlm.nih.gov/research/umls/rxnorm	686400	0.0.1	erythromycin ethylsuccinate 40 MG/ML Oral Suspension
1753	http://www.nlm.nih.gov/research/umls/rxnorm	199281	0.0.1	aspirin 300 MG Oral Tablet
1754	http://www.nlm.nih.gov/research/umls/rxnorm	7984	0.0.1	Penicillin V
1755	http://www.nlm.nih.gov/research/umls/rxnorm	1358765	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Junel Fe 1/20 28 Day]
1756	http://www.nlm.nih.gov/research/umls/rxnorm	828594	0.0.1	aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 65 MG Oral Capsule
1757	http://snomed.info/sct	1155885007	http://snomed.info/sct/900000000000207008/version/20230430	Repair of aortic valve (procedure)
1758	http://www.nlm.nih.gov/research/umls/rxnorm	994434	0.0.1	aspirin 845 MG
1759	http://www.nlm.nih.gov/research/umls/rxnorm	1006892	0.0.1	belladonna alkaloids / kaolin / phenobarbital
1760	http://www.nlm.nih.gov/research/umls/rxnorm	1988308	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Tiadylt]
1761	http://snomed.info/sct	160904001	http://snomed.info/sct/900000000000207008/version/20230430	Part-time employment (finding)
1762	http://www.nlm.nih.gov/research/umls/rxnorm	1482659	0.0.1	chlorhexidine gluconate 23 MG/ML / ketoconazole 10 MG/ML [Ketochlor]
1763	http://www.nlm.nih.gov/research/umls/rxnorm	312357	0.0.1	phenobarbital 15 MG Oral Tablet
1764	http://www.nlm.nih.gov/research/umls/rxnorm	686382	0.0.1	erythromycin ethylsuccinate 40 MG/ML
1765	http://snomed.info/sct	225386006	http://snomed.info/sct/900000000000207008/version/20230430	Pre-discharge assessment (procedure)
1766	http://www.nlm.nih.gov/research/umls/rxnorm	1664463	0.0.1	24 HR tacrolimus 1 MG Extended Release Oral Tablet
1767	http://snomed.info/sct	84489001	http://snomed.info/sct/900000000000207008/version/20230430	Mold (organism)
1768	http://www.nlm.nih.gov/research/umls/rxnorm	1250908	0.0.1	aspirin 500 MG / diphenhydramine citrate 38.3 MG [Bayer Aspirin PM Reformulated Nov 2011]
1769	http://www.nlm.nih.gov/research/umls/rxnorm	1008436	0.0.1	glycopyrronium / phenobarbital
1770	http://www.nlm.nih.gov/research/umls/rxnorm	854901	0.0.1	bisoprolol fumarate 10 MG Oral Tablet
1771	http://www.nlm.nih.gov/research/umls/rxnorm	750840	0.0.1	erythromycin stearate 500 MG [Erythrocin Stearate]
1772	http://www.nlm.nih.gov/research/umls/rxnorm	1046809	0.0.1	atropine sulfate 0.0194 MG / hyoscyamine sulfate 0.1037 MG / phenobarbital 16.2 MG / scopolamine hydrobromide 0.0065 MG [Donnatal]
1773	http://snomed.info/sct	385763009	http://snomed.info/sct/900000000000207008/version/20230430	Hospice care (regime/therapy)
1774	http://snomed.info/sct	62718007	http://snomed.info/sct/900000000000207008/version/20230430	Dribbling from mouth (finding)
1775	http://www.nlm.nih.gov/research/umls/rxnorm	476350	0.0.1	ezetimibe 10 MG / simvastatin 40 MG Oral Tablet
1776	http://snomed.info/sct	26929004	http://snomed.info/sct/900000000000207008/version/20230430	Alzheimer's disease (disorder)
1777	http://www.nlm.nih.gov/research/umls/rxnorm	1092589	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML [Pharmaseb]
1778	http://www.nlm.nih.gov/research/umls/rxnorm	212086	0.0.1	aspirin 325 MG Delayed Release Oral Tablet [Ecotrin]
1779	http://www.nlm.nih.gov/research/umls/rxnorm	2394061	0.0.1	aspirin 6 MG / menthol 5 MG Oral Lozenge
1780	http://www.nlm.nih.gov/research/umls/rxnorm	391930	0.0.1	aspirin 975 MG Oral Tablet
1781	http://www.nlm.nih.gov/research/umls/rxnorm	332311	0.0.1	phenobarbital 200 MG/ML
1782	http://loinc.org	3184-9		Activated clotting time (ACT) of Blood by Coagulation assay
1783	http://www.nlm.nih.gov/research/umls/rxnorm	664959	0.0.1	ketoconazole 0.02 MG/MG [Xolegel]
1784	http://www.nlm.nih.gov/research/umls/rxnorm	1011080	0.0.1	dexamethasone 0.5 MG/ML / tobramycin 3 MG/ML Ophthalmic Suspension [Tobradex]
1785	http://snomed.info/sct	195967001	http://snomed.info/sct/900000000000207008/version/20230430	Asthma
1786	http://www.nlm.nih.gov/research/umls/rxnorm	814321	0.0.1	ethambutol / isoniazid / rifampin
1787	http://www.nlm.nih.gov/research/umls/rxnorm	198043	0.0.1	mestranol 0.05 MG / norethindrone 1 MG Oral Tablet
1788	http://www.nlm.nih.gov/research/umls/rxnorm	757969	0.0.1	{4 (amoxicillin 500 MG Oral Capsule [Trimox]) / 2 (clarithromycin 500 MG Oral Tablet [Biaxin]) / 2 (lansoprazole 30 MG Delayed Release Oral Capsule [Prevacid]) } Pack [Prevpac]
1789	http://www.nlm.nih.gov/research/umls/rxnorm	2183102	0.0.1	pexidartinib
1790	http://www.nlm.nih.gov/research/umls/rxnorm	1424016	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo
1791	http://www.nlm.nih.gov/research/umls/rxnorm	403908	0.0.1	ciprofloxacin 3 MG/ML / dexamethasone 1 MG/ML Otic Suspension
1792	http://www.nlm.nih.gov/research/umls/rxnorm	314076	0.0.1	lisinopril 10 MG Oral Tablet
1793	http://www.nlm.nih.gov/research/umls/rxnorm	352220	0.0.1	voriconazole 200 MG Injection [Vfend]
1794	http://www.nlm.nih.gov/research/umls/rxnorm	897846	0.0.1	24 HR trandolapril 2 MG / verapamil hydrochloride 240 MG Extended Release Oral Tablet [Tarka]
1795	http://www.nlm.nih.gov/research/umls/rxnorm	1659149	0.0.1	Piperacillin 4000 MG / tazobactam 500 MG Injection
1796	http://www.nlm.nih.gov/research/umls/rxnorm	1359117	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack
1797	http://snomed.info/sct	410006001	http://snomed.info/sct/900000000000207008/version/20230430	Digital examination of rectum
1798	http://www.nlm.nih.gov/research/umls/rxnorm	1727521	0.0.1	{24 (ethinyl estradiol 0.025 MG / norethindrone 0.8 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Kaitlib Fe 28 Day]
1799	http://snomed.info/sct	284549007	http://snomed.info/sct/900000000000207008/version/20230430	Laceration of hand
1800	http://snomed.info/sct	241929008	http://snomed.info/sct/900000000000207008/version/20230430	Acute allergic reaction
1801	http://www.nlm.nih.gov/research/umls/rxnorm	313968	0.0.1	erythromycin 25 MG/ML Oral Suspension
1802	http://www.nlm.nih.gov/research/umls/rxnorm	897640	0.0.1	verapamil hydrochloride 180 MG Extended Release Oral Tablet
1803	http://www.nlm.nih.gov/research/umls/rxnorm	689606	0.0.1	atropine / hyoscyamine / phenobarbital / scopolamine
1804	http://www.nlm.nih.gov/research/umls/rxnorm	313782	0.0.1	Acetaminophen 325 MG Oral Tablet
1805	http://www.nlm.nih.gov/research/umls/rxnorm	583141	0.0.1	carbamazepine 300 MG [Equetro]
1806	http://www.nlm.nih.gov/research/umls/rxnorm	751623	0.0.1	nebivolol 5 MG Oral Tablet [Bystolic]
1807	http://www.nlm.nih.gov/research/umls/rxnorm	1600987	0.0.1	aspirin 81 MG [Aspi-Cor]
1808	http://loinc.org	24467-3		CD3+CD4+ (T4 helper) cells [#/volume] in Blood
1809	http://www.nlm.nih.gov/research/umls/rxnorm	1247399	0.0.1	aspirin 845 MG / caffeine 65 MG [BC Original Formula]
1810	http://snomed.info/sct	47200007	http://snomed.info/sct/900000000000207008/version/20230430	Non-low risk pregnancy
1811	http://www.nlm.nih.gov/research/umls/rxnorm	833707	0.0.1	12 HR diltiazem hydrochloride 60 MG Extended Release Oral Tablet
1812	http://www.nlm.nih.gov/research/umls/rxnorm	316113	0.0.1	itraconazole 10 MG/ML
1813	http://www.nlm.nih.gov/research/umls/rxnorm	352218	0.0.1	voriconazole 50 MG Oral Tablet [Vfend]
1814	http://www.nlm.nih.gov/research/umls/rxnorm	197903	0.0.1	lovastatin 10 MG Oral Tablet
1815	http://www.nlm.nih.gov/research/umls/rxnorm	1649987	0.0.1	doxycycline hyclate 100 MG
1816	http://www.nlm.nih.gov/research/umls/rxnorm	1421461	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule) / 4 (ferrous fumarate 75 MG Oral Capsule) } Pack
1817	http://snomed.info/sct	83664006	http://snomed.info/sct/900000000000207008/version/20230430	Idiopathic atrophic hypothyroidism
1818	http://snomed.info/sct	190905008	http://snomed.info/sct/900000000000207008/version/20230430	Cystic Fibrosis
1819	http://www.nlm.nih.gov/research/umls/rxnorm	1008360	0.0.1	adiphenine / phenobarbital
1820	http://www.nlm.nih.gov/research/umls/rxnorm	1008080	0.0.1	aspirin / methylprednisolone
1821	http://www.nlm.nih.gov/research/umls/rxnorm	1091623	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Tablet [Matzim]
1822	http://www.nlm.nih.gov/research/umls/rxnorm	1729584	0.0.1	remifentanil 2 MG Injection
1823	http://www.nlm.nih.gov/research/umls/rxnorm	1796676	0.0.1	25 ML protamine sulfate (USP) 10 MG/ML Injection
1824	http://loinc.org	88040-1		Response to cancer treatment
1825	http://www.nlm.nih.gov/research/umls/rxnorm	1007613	0.0.1	aspirin / chlorpheniramine / dextromethorphan / phenylpropanolamine
1826	http://www.nlm.nih.gov/research/umls/rxnorm	883815	0.0.1	dexamethasone / tobramycin
1827	http://www.nlm.nih.gov/research/umls/rxnorm	1098677	0.0.1	nefazodone hydrochloride 50 MG
1828	http://www.nlm.nih.gov/research/umls/rxnorm	831295	0.0.1	diltiazem hydrochloride 240 MG [Tiazac]
1829	http://snomed.info/sct	230265002	http://snomed.info/sct/900000000000207008/version/20230430	Familial Alzheimer's disease of early onset (disorder)
1830	http://www.nlm.nih.gov/research/umls/rxnorm	197447	0.0.1	aspirin 325 MG / carisoprodol 200 MG Oral Tablet
1831	http://www.nlm.nih.gov/research/umls/rxnorm	1114085	0.0.1	100 ML zoledronic acid 0.04 MG/ML Injection
1832	http://snomed.info/sct	223495004	http://snomed.info/sct/900000000000207008/version/20230430	Preparation of patient for procedure (regime/therapy)
1833	http://www.nlm.nih.gov/research/umls/rxnorm	153371	0.0.1	erythromycin 0.02 MG/MG / isotretinoin 0.0005 MG/MG Topical Gel
1834	http://www.nlm.nih.gov/research/umls/rxnorm	315774	0.0.1	dexamethasone 0.25 MG
1835	http://www.nlm.nih.gov/research/umls/rxnorm	1251334	0.0.1	{28 (ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack
1836	http://www.nlm.nih.gov/research/umls/rxnorm	336430	0.0.1	aspirin 227 MG
1837	http://loinc.org	77606-2		Weight-for-length Per age and sex
1838	http://snomed.info/sct	67821000119109	http://snomed.info/sct/900000000000207008/version/20230430	Primary small cell malignant neoplasm of lung, TNM stage 2 (disorder)
1839	http://www.nlm.nih.gov/research/umls/rxnorm	1359124	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack
1840	http://www.nlm.nih.gov/research/umls/rxnorm	1037185	0.0.1	{24 (ethinyl estradiol 0.01 MG / norethindrone acetate 1 MG Oral Tablet) / 2 (ethinyl estradiol 0.01 MG Oral Tablet) / 2 (ferrous fumarate 75 MG Oral Tablet) } Pack [Lo Loestrin Fe 28 Day]
1841	http://www.nlm.nih.gov/research/umls/rxnorm	309845	0.0.1	Diazepam 5 MG/ML Injectable Solution
1842	http://snomed.info/sct	66348005	http://snomed.info/sct/900000000000207008/version/20230430	Childbirth
1843	http://snomed.info/sct	16114001	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of ankle
1844	http://www.nlm.nih.gov/research/umls/rxnorm	1736650	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG [Fyavolv]
1845	http://www.nlm.nih.gov/research/umls/rxnorm	2624717	0.0.1	phenobarbital sodium 100 MG
1846	http://www.nlm.nih.gov/research/umls/rxnorm	1656356	0.0.1	sacubitril 97 MG / valsartan 103 MG Oral Tablet
1847	http://www.nlm.nih.gov/research/umls/rxnorm	855332	0.0.1	Warfarin Sodium 5 MG Oral Tablet
1848	http://www.nlm.nih.gov/research/umls/rxnorm	317297	0.0.1	aspirin 120 MG
1849	http://www.nlm.nih.gov/research/umls/rxnorm	308416	0.0.1	aspirin 81 MG Delayed Release Oral Tablet
1850	http://www.nlm.nih.gov/research/umls/rxnorm	854919	0.0.1	bisoprolol fumarate 5 MG / hydrochlorothiazide 6.25 MG Oral Tablet
1851	http://www.nlm.nih.gov/research/umls/rxnorm	2588847	0.0.1	levoketoconazole 150 MG
1852	http://www.nlm.nih.gov/research/umls/rxnorm	647253	0.0.1	ketoconazole 0.02 MG/MG Topical Gel
1853	http://www.nlm.nih.gov/research/umls/rxnorm	864718	0.0.1	Methadone Hydrochloride 5 MG Oral Tablet
1854	http://www.nlm.nih.gov/research/umls/rxnorm	745752	0.0.1	NDA021457 200 ACTUAT albuterol 0.09 MG/ACTUAT Metered Dose Inhaler [ProAir]
1855	http://snomed.info/sct	384682003	http://snomed.info/sct/900000000000207008/version/20230430	Multidisciplinary care conference (procedure)
1856	http://www.nlm.nih.gov/research/umls/rxnorm	315414	0.0.1	aspirin 165 MG
1857	http://www.nlm.nih.gov/research/umls/rxnorm	855869	0.0.1	phenytoin sodium 30 MG Extended Release Oral Capsule
1858	http://www.nlm.nih.gov/research/umls/rxnorm	1234995	0.0.1	Rocuronium bromide 10 MG/ML Injectable Solution
1859	http://www.nlm.nih.gov/research/umls/rxnorm	310325	0.0.1	ferrous sulfate 325 MG Oral Tablet
1860	http://www.nlm.nih.gov/research/umls/rxnorm	690250	0.0.1	benzocaine / calcium carbonate / magnesium carbonate / phenobarbital
1861	http://snomed.info/sct	762952008	http://snomed.info/sct/900000000000207008/version/20230430	Peanut (substance)
1862	http://snomed.info/sct	283371005	http://snomed.info/sct/900000000000207008/version/20230430	Laceration of forearm
1863	http://www.nlm.nih.gov/research/umls/rxnorm	689522	0.0.1	aspirin / carisoprodol / codeine
1864	http://snomed.info/sct	224355006	http://snomed.info/sct/900000000000207008/version/20230430	Served in armed forces (finding)
1865	http://snomed.info/sct	111282000	http://snomed.info/sct/900000000000207008/version/20230430	Acute respiratory insufficiency (disorder)
1866	http://snomed.info/sct	82078001	http://snomed.info/sct/900000000000207008/version/20230430	Take blood sample
1867	http://www.nlm.nih.gov/research/umls/rxnorm	212390	0.0.1	carvedilol 25 MG Oral Tablet [Coreg]
1868	http://www.nlm.nih.gov/research/umls/rxnorm	351266	0.0.1	buprenorphine 2 MG / naloxone 0.5 MG Sublingual Tablet
1869	http://www.nlm.nih.gov/research/umls/rxnorm	897660	0.0.1	verapamil hydrochloride 120 MG [Calan]
1870	http://www.nlm.nih.gov/research/umls/rxnorm	1007423	0.0.1	dexamethasone / oxytetracycline
1871	http://www.nlm.nih.gov/research/umls/rxnorm	329292	0.0.1	aspirin 100 MG
1872	http://www.nlm.nih.gov/research/umls/rxnorm	1098678	0.0.1	nefazodone hydrochloride 50 MG Oral Tablet
1873	http://snomed.info/sct	133900002	http://snomed.info/sct/900000000000207008/version/20230430	Intraoperative care (regime/therapy)
1874	http://www.nlm.nih.gov/research/umls/rxnorm	1008613	0.0.1	phenobarbital / pipenzolate
1875	http://www.nlm.nih.gov/research/umls/rxnorm	1251335	0.0.1	{28 (ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Femhrt 0.5/2.5 28 Day]
1876	http://www.nlm.nih.gov/research/umls/rxnorm	798113	0.0.1	erythromycin 20 MG/ML [Emcin Clear]
1877	http://www.nlm.nih.gov/research/umls/rxnorm	757968	0.0.1	{4 (amoxicillin 500 MG Oral Capsule) / 2 (clarithromycin 500 MG Oral Tablet) / 2 (lansoprazole 30 MG Delayed Release Oral Capsule) } Pack
1878	http://www.nlm.nih.gov/research/umls/rxnorm	104899	0.0.1	aspirin 300 MG Delayed Release Oral Tablet
1879	http://www.nlm.nih.gov/research/umls/rxnorm	979480	0.0.1	losartan potassium 100 MG Oral Tablet
1880	http://www.nlm.nih.gov/research/umls/rxnorm	855862	0.0.1	phenytoin sodium 200 MG [Phenytek]
1881	http://www.nlm.nih.gov/research/umls/rxnorm	1988304	0.0.1	diltiazem hydrochloride 120 MG [Tiadylt]
1882	http://www.nlm.nih.gov/research/umls/rxnorm	3827	0.0.1	Enalapril
1883	http://www.nlm.nih.gov/research/umls/rxnorm	861467	0.0.1	Meperidine Hydrochloride 50 MG Oral Tablet
1884	http://www.nlm.nih.gov/research/umls/rxnorm	350459	0.0.1	aspirin 428 MG
1885	http://www.nlm.nih.gov/research/umls/rxnorm	979487	0.0.1	losartan potassium 25 MG Oral Tablet [Cozaar]
1886	http://www.nlm.nih.gov/research/umls/rxnorm	1007256	0.0.1	clioquinol / dexamethasone
1887	http://snomed.info/sct	404909007	http://snomed.info/sct/900000000000207008/version/20230430	Injection of botulinum toxin (procedure)
1888	http://www.nlm.nih.gov/research/umls/rxnorm	830862	0.0.1	diltiazem hydrochloride 120 MG [Cardizem]
1889	http://www.nlm.nih.gov/research/umls/rxnorm	994429	0.0.1	aspirin 1000 MG
1890	http://www.nlm.nih.gov/research/umls/rxnorm	1811918	0.0.1	aspirin 81 MG / omeprazole 40 MG Delayed Release Oral Tablet [Yosprala]
1891	http://www.nlm.nih.gov/research/umls/rxnorm	1812079	0.0.1	1 ML dexamethasone phosphate 10 MG/ML Injection
1892	http://www.nlm.nih.gov/research/umls/rxnorm	1536675	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1916 MG Effervescent Oral Tablet
1893	http://www.nlm.nih.gov/research/umls/rxnorm	1427301	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Pirmella 7/7/7 28 Day]
1894	http://www.nlm.nih.gov/research/umls/rxnorm	827318	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Capsule
1895	http://www.nlm.nih.gov/research/umls/rxnorm	816812	0.0.1	acetanilide / aspirin / caffeine / ephedrine
1896	http://www.nlm.nih.gov/research/umls/rxnorm	1314580	0.0.1	bitter orange oil
1897	http://www.nlm.nih.gov/research/umls/rxnorm	200131	0.0.1	12 HR carbamazepine 300 MG Extended Release Oral Capsule
1898	http://www.nlm.nih.gov/research/umls/rxnorm	1243052	0.0.1	Kalydeco 150 MG Oral Tablet
1899	http://snomed.info/sct	266934004	http://snomed.info/sct/900000000000207008/version/20230430	Transport problem (finding)
1900	http://snomed.info/sct	180178009	http://snomed.info/sct/900000000000207008/version/20230430	Continuous subcutaneous infusion of insulin (procedure)
1901	http://www.nlm.nih.gov/research/umls/rxnorm	860975	0.0.1	24 HR Metformin hydrochloride 500 MG Extended Release Oral Tablet
1902	http://www.nlm.nih.gov/research/umls/rxnorm	36453	0.0.1	sevoflurane
1903	http://loinc.org	85319-2		HER2 [Presence] in Breast cancer specimen by Immune stain
1904	http://www.nlm.nih.gov/research/umls/rxnorm	246461	0.0.1	aspirin 100 MG Oral Tablet
1905	http://www.nlm.nih.gov/research/umls/rxnorm	343033	0.0.1	dexamethasone 0.75 MG Oral Tablet
1906	http://www.nlm.nih.gov/research/umls/rxnorm	1091629	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Tablet [Matzim]
1907	http://www.nlm.nih.gov/research/umls/rxnorm	315779	0.0.1	dexamethasone 6 MG
1908	http://www.nlm.nih.gov/research/umls/rxnorm	817958	0.0.1	aspirin / calcium carbonate
1909	http://www.nlm.nih.gov/research/umls/rxnorm	834061	0.0.1	Penicillin V Potassium 250 MG Oral Tablet
1910	http://www.nlm.nih.gov/research/umls/rxnorm	855882	0.0.1	phenytoin sodium 50 MG
1911	http://www.nlm.nih.gov/research/umls/rxnorm	833162	0.0.1	itraconazole 100 MG [Sporanox]
1912	http://www.nlm.nih.gov/research/umls/rxnorm	245314	0.0.1	albuterol 5 MG/ML Inhalation Solution
1913	http://snomed.info/sct	283385000	http://snomed.info/sct/900000000000207008/version/20230430	Laceration of thigh
1914	http://snomed.info/sct	782576004	http://snomed.info/sct/900000000000207008/version/20230430	Tree pollen (substance)
1915	http://www.nlm.nih.gov/research/umls/rxnorm	1809104	0.0.1	5 ML SUFentanil 0.05 MG/ML Injection
1916	http://www.nlm.nih.gov/research/umls/rxnorm	1807513	0.0.1	vancomycin 1000 MG Injection
1917	http://snomed.info/sct	43060002	http://snomed.info/sct/900000000000207008/version/20230430	Intravenous injection (procedure)
1918	http://www.nlm.nih.gov/research/umls/rxnorm	904419	0.0.1	Alendronic acid 10 MG Oral Tablet
1919	http://www.nlm.nih.gov/research/umls/rxnorm	197517	0.0.1	clarithromycin 500 MG Oral Tablet
1920	http://snomed.info/sct	232816009	http://snomed.info/sct/900000000000207008/version/20230430	Aortic valve and adjacent structure operations (procedure)
1921	http://loinc.org	39156-5		Body mass index (BMI) [Ratio]
1922	http://www.nlm.nih.gov/research/umls/rxnorm	1091891	0.0.1	chloroxylenol / ketoconazole
1923	http://www.nlm.nih.gov/research/umls/rxnorm	329295	0.0.1	aspirin 25 MG
1924	http://www.nlm.nih.gov/research/umls/rxnorm	897718	0.0.1	verapamil hydrochloride 40 MG
1925	http://snomed.info/sct	310861008	http://snomed.info/sct/900000000000207008/version/20230430	Chlamydia antigen test
1926	http://www.nlm.nih.gov/research/umls/rxnorm	816818	0.0.1	aspirin / chlorpheniramine
1927	http://snomed.info/sct	24079001	http://snomed.info/sct/900000000000207008/version/20230430	Atopic dermatitis
1928	http://www.nlm.nih.gov/research/umls/rxnorm	260847	0.0.1	aspirin 325 MG Oral Tablet [Bufferin]
1929	http://snomed.info/sct	370789001	http://snomed.info/sct/900000000000207008/version/20230430	Development of individualized plan of care (procedure)
1930	http://www.nlm.nih.gov/research/umls/rxnorm	1739988	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML / salicyloyl phytosphingosine 0.4 MG/ML Medicated Pad
1931	http://snomed.info/sct	237072009	http://snomed.info/sct/900000000000207008/version/20230430	Endometrial hyperplasia (disorder)
1932	http://www.nlm.nih.gov/research/umls/rxnorm	1806684	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Amabelz 1/0.5 28 Day]
1933	http://www.nlm.nih.gov/research/umls/rxnorm	1009390	0.0.1	dexamethasone 1 MG/ML / neomycin 3.2 MG/ML / thiabendazole 40 MG/ML [Tresaderm]
1934	http://snomed.info/sct	117015009	http://snomed.info/sct/900000000000207008/version/20230430	Throat culture (procedure)
1935	http://snomed.info/sct	116861002	http://snomed.info/sct/900000000000207008/version/20230430	Transfusion of fresh frozen plasma (procedure)
1936	http://www.nlm.nih.gov/research/umls/rxnorm	2047760	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Hailey 1.5/30 21 Day]
1937	http://www.nlm.nih.gov/research/umls/rxnorm	1007302	0.0.1	guaifenesin / phenobarbital / theophylline
1938	http://snomed.info/sct	706893006	http://snomed.info/sct/900000000000207008/version/20230430	Victim of intimate partner abuse (finding)
1939	http://www.nlm.nih.gov/research/umls/rxnorm	1483558	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet) / 7 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Zenchent Fe 28 Day]
1940	http://www.nlm.nih.gov/research/umls/rxnorm	574672	0.0.1	oxcarbazepine 600 MG [Trileptal]
1941	http://snomed.info/sct	268556000	http://snomed.info/sct/900000000000207008/version/20230430	Urine screening for glucose
1942	http://www.nlm.nih.gov/research/umls/rxnorm	997223	0.0.1	Donepezil hydrochloride 10 MG Oral Tablet
1943	http://www.nlm.nih.gov/research/umls/rxnorm	329294	0.0.1	aspirin 421 MG
1944	http://www.nlm.nih.gov/research/umls/rxnorm	854905	0.0.1	bisoprolol fumarate 5 MG Oral Tablet
1945	http://snomed.info/sct	77386006	http://snomed.info/sct/900000000000207008/version/20230430	Pregnancy (finding)
1946	http://www.nlm.nih.gov/research/umls/rxnorm	312750	0.0.1	quinapril 5 MG Oral Tablet
1947	http://www.nlm.nih.gov/research/umls/rxnorm	1424018	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML [Vital-Ketodine]
1948	http://www.nlm.nih.gov/research/umls/rxnorm	859426	0.0.1	rosuvastatin calcium 5 MG Oral Tablet [Crestor]
1949	http://www.nlm.nih.gov/research/umls/rxnorm	833705	0.0.1	24 HR diltiazem hydrochloride 300 MG Extended Release Oral Capsule [Diltzac]
1950	http://www.nlm.nih.gov/research/umls/rxnorm	996988	0.0.1	aspirin 300 MG / codeine phosphate 8 MG Oral Tablet
1951	http://www.nlm.nih.gov/research/umls/rxnorm	897661	0.0.1	verapamil hydrochloride 120 MG Extended Release Oral Tablet [Calan]
1952	http://www.nlm.nih.gov/research/umls/rxnorm	389221	0.0.1	Etonogestrel 68 MG Drug Implant
1953	http://www.nlm.nih.gov/research/umls/rxnorm	855911	0.0.1	2 ML phenytoin sodium 50 MG/ML Cartridge
1954	http://www.nlm.nih.gov/research/umls/rxnorm	831225	0.0.1	diltiazem hydrochloride 120 MG [Cartia]
1955	http://www.nlm.nih.gov/research/umls/rxnorm	856448	0.0.1	propranolol hydrochloride 10 MG Oral Tablet
1956	http://www.nlm.nih.gov/research/umls/rxnorm	820465	0.0.1	carisoprodol / dexamethasone / ibuprofen
1957	http://www.nlm.nih.gov/research/umls/rxnorm	1116927	0.0.1	dexamethasone phosphate 4 MG/ML Injectable Solution
1958	http://www.nlm.nih.gov/research/umls/rxnorm	1547672	0.0.1	30 ACTUAT fluticasone furoate 0.2 MG/ACTUAT Dry Powder Inhaler [Arnuity]
1959	http://www.nlm.nih.gov/research/umls/rxnorm	584534	0.0.1	erythromycin 0.005 MG/MG Ophthalmic Ointment [Eyemycin]
1960	http://snomed.info/sct	267253006	http://snomed.info/sct/900000000000207008/version/20230430	Fetus with chromosomal abnormality
1961	http://www.nlm.nih.gov/research/umls/rxnorm	1361048	0.0.1	heparin sodium, porcine 100 UNT/ML Injectable Solution
1962	http://www.nlm.nih.gov/research/umls/rxnorm	831102	0.0.1	diltiazem hydrochloride 90 MG Oral Tablet
1963	http://www.nlm.nih.gov/research/umls/rxnorm	750839	0.0.1	erythromycin stearate 250 MG Oral Tablet [Erythrocin Stearate]
1964	http://www.nlm.nih.gov/research/umls/rxnorm	211881	0.0.1	aspirin 325 MG Oral Tablet [Norwich Aspirin]
1965	http://snomed.info/sct	160701002	http://snomed.info/sct/900000000000207008/version/20230430	Social migrant (finding)
1966	http://snomed.info/sct	239720000	http://snomed.info/sct/900000000000207008/version/20230430	Tear of meniscus of knee
2231	http://www.nlm.nih.gov/research/umls/rxnorm	198083	0.0.1	phenobarbital 100 MG Oral Tablet
1967	http://www.nlm.nih.gov/research/umls/rxnorm	897714	0.0.1	verapamil hydrochloride 240 MG Extended Release Oral Tablet [Isoptin]
1968	http://www.nlm.nih.gov/research/umls/rxnorm	892160	0.0.1	aspirin 3900 MG Oral Tablet
1969	http://www.nlm.nih.gov/research/umls/rxnorm	690997	0.0.1	aluminum hydroxide / aspirin / magnesium hydroxide
1970	http://www.nlm.nih.gov/research/umls/rxnorm	691018	0.0.1	calcium carbonate / phenobarbital
1971	http://www.nlm.nih.gov/research/umls/rxnorm	313110	0.0.1	stavudine 40 MG Oral Capsule
1972	http://www.nlm.nih.gov/research/umls/rxnorm	2566439	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Capsule) / 4 (ferrous fumarate 75 MG Oral Capsule) } Pack [Taysofy 28 Day]
1973	http://www.nlm.nih.gov/research/umls/rxnorm	2387356	0.0.1	{25 (dexamethasone 1.5 MG Oral Tablet) } Pack [Zcort 7 Day Taper]
1974	http://www.nlm.nih.gov/research/umls/rxnorm	227142	0.0.1	dexamethasone 1 MG/ML / hypromellose 5 MG/ML Ophthalmic Solution
1975	http://www.nlm.nih.gov/research/umls/rxnorm	403875	0.0.1	emtricitabine 200 MG Oral Capsule
1976	http://snomed.info/sct	384709000	http://snomed.info/sct/900000000000207008/version/20230430	Sprain (morphologic abnormality)
1977	http://www.nlm.nih.gov/research/umls/rxnorm	1812095	0.0.1	1 ML dexamethasone phosphate 4 MG/ML Prefilled Syringe
1978	http://snomed.info/sct	182777000	http://snomed.info/sct/900000000000207008/version/20230430	Monitoring of patient (regime/therapy)
1979	http://www.nlm.nih.gov/research/umls/rxnorm	853499	0.0.1	aspirin 228 MG Chewing Gum
1980	http://www.nlm.nih.gov/research/umls/rxnorm	1359135	0.0.1	{5 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ethinyl estradiol 0.03 MG / norethindrone acetate 1 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Tri-Legest 28 Day]
1981	http://www.nlm.nih.gov/research/umls/rxnorm	831252	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Dilt]
1982	http://snomed.info/sct	127294003	http://snomed.info/sct/900000000000207008/version/20230430	Traumatic or nontraumatic brain injury (disorder)
1983	http://snomed.info/sct	876882001	http://snomed.info/sct/900000000000207008/version/20230430	Died in hospice (finding)
1984	http://www.nlm.nih.gov/research/umls/rxnorm	1049625	0.0.1	Acetaminophen 325 MG / Oxycodone Hydrochloride 10 MG Oral Tablet [Percocet]
1985	http://www.nlm.nih.gov/research/umls/rxnorm	316481	0.0.1	phenobarbital 3.24 MG/ML
1986	http://snomed.info/sct	445988008	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using health assessment questionnaire (procedure)
1987	http://snomed.info/sct	15220000	http://snomed.info/sct/900000000000207008/version/20230430	Laboratory test (procedure)
1988	http://www.nlm.nih.gov/research/umls/rxnorm	750264	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Necon 7/7/7 28 Day]
1989	http://snomed.info/sct	241055006	http://snomed.info/sct/900000000000207008/version/20230430	Mammogram - symptomatic (procedure)
1990	http://www.nlm.nih.gov/research/umls/rxnorm	2108017	0.0.1	dexamethasone 0.4 MG [Dextenza]
1991	http://www.nlm.nih.gov/research/umls/rxnorm	2121587	0.0.1	{39 (dexamethasone 1.5 MG Oral Tablet) } Pack
1992	http://www.nlm.nih.gov/research/umls/rxnorm	691014	0.0.1	calcium carbonate / magnesium hydroxide / phenobarbital
1993	http://www.nlm.nih.gov/research/umls/rxnorm	411759	0.0.1	24 HR trandolapril 2 MG / verapamil hydrochloride 180 MG Extended Release Oral Capsule
1994	http://snomed.info/sct	290045001	http://snomed.info/sct/900000000000207008/version/20230430	Kitchen practice
1995	http://snomed.info/sct	288086009	http://snomed.info/sct/900000000000207008/version/20230430	Suture open wound
1996	http://snomed.info/sct	40930008	http://snomed.info/sct/900000000000207008/version/20230430	Hypothyroidism (disorder)
1997	http://www.nlm.nih.gov/research/umls/rxnorm	1006995	0.0.1	aluminum hydroxide / aspirin / caffeine
1998	http://www.nlm.nih.gov/research/umls/rxnorm	1098710	0.0.1	nefazodone hydrochloride 300 MG Oral Tablet
1999	http://www.nlm.nih.gov/research/umls/rxnorm	1537188	0.0.1	ketoconazole 2.5 MG/ML
2000	http://www.nlm.nih.gov/research/umls/rxnorm	830899	0.0.1	diltiazem hydrochloride 420 MG
2001	http://www.nlm.nih.gov/research/umls/rxnorm	308460	0.0.1	Azithromycin 250 MG Oral Tablet
2002	http://snomed.info/sct	162573006	http://snomed.info/sct/900000000000207008/version/20230430	Suspected lung cancer (situation)
2003	http://www.nlm.nih.gov/research/umls/rxnorm	897855	0.0.1	24 HR trandolapril 4 MG / verapamil hydrochloride 240 MG Extended Release Oral Tablet [Tarka]
2004	http://snomed.info/sct	40275004	http://snomed.info/sct/900000000000207008/version/20230430	Contact dermatitis
2005	http://loinc.org	21905-5		Primary tumor.clinical [Class] Cancer
2006	http://www.nlm.nih.gov/research/umls/rxnorm	200096	0.0.1	irbesartan 300 MG Oral Tablet
2007	http://www.nlm.nih.gov/research/umls/rxnorm	855860	0.0.1	phenytoin sodium 200 MG
2008	http://loinc.org	2713-6		Oxygen saturation Calculated from oxygen partial pressure in Blood
2009	http://www.nlm.nih.gov/research/umls/rxnorm	1797506	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML Topical Solution
2010	http://www.nlm.nih.gov/research/umls/rxnorm	329220	0.0.1	phenobarbital 64.8 MG
2011	http://www.nlm.nih.gov/research/umls/rxnorm	996994	0.0.1	aspirin 325 MG / codeine phosphate 60 MG Oral Tablet
2012	http://www.nlm.nih.gov/research/umls/rxnorm	1297958	0.0.1	ketoconazole 1 MG/ML
2013	http://www.nlm.nih.gov/research/umls/rxnorm	200243	0.0.1	sevoflurane 1000 MG/ML Inhalation Solution
2014	http://www.nlm.nih.gov/research/umls/rxnorm	855935	0.0.1	phenytoin sodium 25 MG
2015	http://www.nlm.nih.gov/research/umls/rxnorm	197862	0.0.1	leucovorin 25 MG Oral Tablet
2016	http://snomed.info/sct	397923000	http://snomed.info/sct/900000000000207008/version/20230430	Somatization disorder (disorder)
2017	http://snomed.info/sct	38102005	http://snomed.info/sct/900000000000207008/version/20230430	Open Removal of Gall Bladder
2069	http://snomed.info/sct	47693006	http://snomed.info/sct/900000000000207008/version/20230430	Rupture of appendix
2070	http://www.nlm.nih.gov/research/umls/rxnorm	574579	0.0.1	oxcarbazepine 300 MG [Trileptal]
2018	http://www.nlm.nih.gov/research/umls/rxnorm	1047041	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Cyclafem 7/7/7 28 Day]
2019	http://www.nlm.nih.gov/research/umls/rxnorm	1090996	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG Oral Tablet [Jinteli]
2020	http://www.nlm.nih.gov/research/umls/rxnorm	617310	0.0.1	atorvastatin 20 MG Oral Tablet
2021	http://www.nlm.nih.gov/research/umls/rxnorm	310157	0.0.1	erythromycin 500 MG Delayed Release Oral Tablet
2022	http://loinc.org	22577-1		Toxoplasma gondii Ab [Presence] in Serum
2023	http://www.nlm.nih.gov/research/umls/rxnorm	1426601	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Minastrin 24 Fe Chewable 28 Day]
2024	http://www.nlm.nih.gov/research/umls/rxnorm	897666	0.0.1	verapamil hydrochloride 120 MG Oral Tablet
2025	http://www.nlm.nih.gov/research/umls/rxnorm	2565492	0.0.1	{1 (aspirin 325 MG / dextromethorphan hydrobromide 10 MG / doxylamine succinate 6.25 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) / 1 (aspirin 325 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet) } Pack
2026	http://www.nlm.nih.gov/research/umls/rxnorm	749736	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack
2027	http://snomed.info/sct	260147004	http://snomed.info/sct/900000000000207008/version/20230430	House dust mite (organism)
2028	http://www.nlm.nih.gov/research/umls/rxnorm	206978	0.0.1	ketoconazole 20 MG/ML Medicated Shampoo [Nizoral]
2029	http://loinc.org	38208-5		Pain severity - Reported
2030	http://loinc.org	38265-5		DXA Radius and Ulna [T-score] Bone density
2031	http://www.nlm.nih.gov/research/umls/rxnorm	890952	0.0.1	erythromycin 0.0053 MG/ML
2032	http://www.nlm.nih.gov/research/umls/rxnorm	343040	0.0.1	dexamethasone 0.75 MG Oral Tablet [Decadron]
2033	http://snomed.info/sct	386661006	http://snomed.info/sct/900000000000207008/version/20230430	Fever (finding)
2034	http://www.nlm.nih.gov/research/umls/rxnorm	1856398	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Cyonanz 28 Day]
2035	http://www.nlm.nih.gov/research/umls/rxnorm	1313111	0.0.1	phenytoin 25 MG/ML
2036	http://www.nlm.nih.gov/research/umls/rxnorm	1007648	0.0.1	mannitol / phenobarbital
2037	http://www.nlm.nih.gov/research/umls/rxnorm	819182	0.0.1	mephobarbital / phenobarbital / phenytoin
2038	http://www.nlm.nih.gov/research/umls/rxnorm	105078	0.0.1	Penicillin G 375 MG/ML Injectable Solution
2039	http://www.nlm.nih.gov/research/umls/rxnorm	597194	0.0.1	erythromycin estolate 50 MG/ML Oral Suspension
2040	http://www.nlm.nih.gov/research/umls/rxnorm	2045404	0.0.1	0.005 ML dexamethasone 103.4 MG/ML Injection
2041	http://www.nlm.nih.gov/research/umls/rxnorm	672149	0.0.1	lapatinib 250 MG Oral Tablet
2042	http://www.nlm.nih.gov/research/umls/rxnorm	831349	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Capsule [Taztia]
2043	http://www.nlm.nih.gov/research/umls/rxnorm	331282	0.0.1	carbamazepine 125 MG
2044	http://www.nlm.nih.gov/research/umls/rxnorm	570399	0.0.1	aspirin 325 MG / meprobamate 200 MG [Equagesic]
2045	http://www.nlm.nih.gov/research/umls/rxnorm	360110	0.0.1	Sirolimus 2 MG Oral Tablet
2046	http://www.nlm.nih.gov/research/umls/rxnorm	1988311	0.0.1	24 HR diltiazem hydrochloride 180 MG Extended Release Oral Capsule [Tiadylt]
2047	http://snomed.info/sct	28163009	http://snomed.info/sct/900000000000207008/version/20230430	Skin test for tuberculosis, Tine test (procedure)
2048	http://www.nlm.nih.gov/research/umls/rxnorm	1190766	0.0.1	atropine sulfate 0.31 MG/ML Ophthalmic Solution (used Sublingual)
2049	http://loinc.org	751-8		Neutrophils [#/volume] in Blood by Automated count
2050	http://snomed.info/sct	443165006	http://snomed.info/sct/900000000000207008/version/20230430	Pathological fracture due to osteoporosis (disorder)
2051	http://www.nlm.nih.gov/research/umls/rxnorm	1873704	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Mibelas 24 Fe Chewable 28 Day]
2052	http://snomed.info/sct	267064002	http://snomed.info/sct/900000000000207008/version/20230430	Retention of urine (disorder)
2053	http://www.nlm.nih.gov/research/umls/rxnorm	2626726	0.0.1	aspirin 650 MG / caffeine 65 MG Oral Powder
2054	http://www.nlm.nih.gov/research/umls/rxnorm	1007929	0.0.1	hydrochlorothiazide / triamterene / verapamil
2055	http://snomed.info/sct	58214004	http://snomed.info/sct/900000000000207008/version/20230430	Schizophrenia (disorder)
2056	http://www.nlm.nih.gov/research/umls/rxnorm	994810	0.0.1	aspirin 428 MG / caffeine 30 MG / orphenadrine citrate 25 MG Oral Tablet
2057	http://www.nlm.nih.gov/research/umls/rxnorm	831348	0.0.1	diltiazem hydrochloride 360 MG [Taztia]
2058	http://www.nlm.nih.gov/research/umls/rxnorm	282755	0.0.1	telmisartan 20 MG Oral Tablet
2059	http://snomed.info/sct	264287008	http://snomed.info/sct/900000000000207008/version/20230430	Animal dander (substance)
2060	http://www.nlm.nih.gov/research/umls/rxnorm	689553	0.0.1	acetaminophen / aspirin / caffeine / hydrocodone
2061	http://www.nlm.nih.gov/research/umls/rxnorm	5640	0.0.1	Ibuprofen
2062	http://www.nlm.nih.gov/research/umls/rxnorm	1359031	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Loestrin 1.5/30 21 Day]
2063	http://www.nlm.nih.gov/research/umls/rxnorm	996991	0.0.1	aspirin 325 MG / codeine phosphate 30 MG Oral Tablet
2064	http://snomed.info/sct	399261000	http://snomed.info/sct/900000000000207008/version/20230430	History of coronary artery bypass grafting (situation)
2065	http://www.nlm.nih.gov/research/umls/rxnorm	748856	0.0.1	Yaz 28 Day Pack
2066	http://www.nlm.nih.gov/research/umls/rxnorm	757594	0.0.1	Jolivette 28 Day Pack
2067	http://www.nlm.nih.gov/research/umls/rxnorm	1235867	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Dasetta 7/7/7 28 Day]
2068	http://www.nlm.nih.gov/research/umls/rxnorm	197576	0.0.1	dexamethasone 0.25 MG Oral Tablet
2071	http://www.nlm.nih.gov/research/umls/rxnorm	749858	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack
2072	http://www.nlm.nih.gov/research/umls/rxnorm	896019	0.0.1	60 ACTUAT fluticasone propionate 0.05 MG/ACTUAT Dry Powder Inhaler [Flovent]
2073	http://www.nlm.nih.gov/research/umls/rxnorm	723533	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Anacin Advanced Headache Formula]
2074	http://www.nlm.nih.gov/research/umls/rxnorm	1000406	0.0.1	norethindrone acetate 5 MG [Aygestin]
2075	http://snomed.info/sct	112001000119100	http://snomed.info/sct/900000000000207008/version/20230430	positive screening for PHQ-9
2076	http://www.nlm.nih.gov/research/umls/rxnorm	1251499	0.0.1	84 HR estradiol 0.00208 MG/HR / norethindrone acetate 0.0104 MG/HR Transdermal System
2077	http://www.nlm.nih.gov/research/umls/rxnorm	8516	0.0.1	polyethylene glycols
2078	http://www.nlm.nih.gov/research/umls/rxnorm	8134	0.0.1	phenobarbital
2079	http://www.nlm.nih.gov/research/umls/rxnorm	214255	0.0.1	aspirin / methocarbamol
2080	http://www.nlm.nih.gov/research/umls/rxnorm	801095	0.0.1	NDA020983 60 ACTUAT albuterol 0.09 MG/ACTUAT Metered Dose Inhaler [Ventolin]
2081	http://snomed.info/sct	128613002	http://snomed.info/sct/900000000000207008/version/20230430	Seizure disorder (disorder)
2082	http://loinc.org	8478-0		Mean blood pressure
2083	http://snomed.info/sct	48387007	http://snomed.info/sct/900000000000207008/version/20230430	Incision of trachea (procedure)
2084	http://snomed.info/sct	6072007	http://snomed.info/sct/900000000000207008/version/20230430	Bleeding from anus
2085	http://www.nlm.nih.gov/research/umls/rxnorm	1008033	0.0.1	hydrocortisone / ketoconazole
2086	http://www.nlm.nih.gov/research/umls/rxnorm	979470	0.0.1	hydrochlorothiazide 12.5 MG / losartan potassium 50 MG Oral Tablet [Hyzaar]
2087	http://www.nlm.nih.gov/research/umls/rxnorm	831251	0.0.1	diltiazem hydrochloride 180 MG [Dilt]
2088	http://www.nlm.nih.gov/research/umls/rxnorm	198240	0.0.1	Tamoxifen 10 MG Oral Tablet
2089	http://snomed.info/sct	118001005	http://snomed.info/sct/900000000000207008/version/20230430	Streptococcus pneumoniae group B antigen assay
2090	http://www.nlm.nih.gov/research/umls/rxnorm	1536815	0.0.1	aspirin 500 MG / caffeine 65 MG Effervescent Oral Tablet
2091	http://www.nlm.nih.gov/research/umls/rxnorm	402109	0.0.1	fosamprenavir 700 MG Oral Tablet
2092	http://snomed.info/sct	396487001	http://snomed.info/sct/900000000000207008/version/20230430	Sentinel lymph node biopsy (procedure)
2093	http://snomed.info/sct	90560007	http://snomed.info/sct/900000000000207008/version/20230430	Gout
2094	http://snomed.info/sct	104326007	http://snomed.info/sct/900000000000207008/version/20230430	Measurement of Varicella-zoster virus antibody
2095	http://www.nlm.nih.gov/research/umls/rxnorm	1811763	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Norlyda 28 Day]
2096	http://snomed.info/sct	403192003	http://snomed.info/sct/900000000000207008/version/20230430	Third degree burn
2097	http://www.nlm.nih.gov/research/umls/rxnorm	243694	0.0.1	acetaminophen 194 MG / aspirin 227 MG / caffeine 33 MG Oral Tablet
2098	http://snomed.info/sct	113120007	http://snomed.info/sct/900000000000207008/version/20230430	Interstitial brachytherapy (procedure)
2099	http://www.nlm.nih.gov/research/umls/rxnorm	213471	0.0.1	modafinil 200 MG Oral Tablet [Provigil]
2100	http://snomed.info/sct	65200003	http://snomed.info/sct/900000000000207008/version/20230430	Insertion of intrauterine contraceptive device (procedure)
2101	http://www.nlm.nih.gov/research/umls/rxnorm	332336	0.0.1	aspirin 520 MG
2102	http://snomed.info/sct	56019007	http://snomed.info/sct/900000000000207008/version/20230430	Systemic disease (disorder)
2103	http://www.nlm.nih.gov/research/umls/rxnorm	863186	0.0.1	aspirin 410 MG / caffeine 60 MG / salicylamide 30 MG Oral Tablet
2104	http://www.nlm.nih.gov/research/umls/rxnorm	2556799	0.0.1	estradiol 1 MG / norethindrone acetate 0.5 MG / relugolix 40 MG Oral Tablet
2105	http://www.nlm.nih.gov/research/umls/rxnorm	2047428	0.0.1	{100 (acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Excedrin]) / 24 (acetaminophen 250 MG / aspirin 250 MG / diphenhydramine citrate 38 MG Oral Tablet [Excedrin PM Triple Action]) } Pack [Excedrin PM Triple Action Caplets and Excedrin Extra Strength Pain Reliever]
2106	http://www.nlm.nih.gov/research/umls/rxnorm	848928	0.0.1	aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet [Endodan Reformulated May 2009]
2107	http://snomed.info/sct	192127007	http://snomed.info/sct/900000000000207008/version/20230430	Child attention deficit disorder
2108	http://snomed.info/sct	116863004	http://snomed.info/sct/900000000000207008/version/20230430	Transfusion of red blood cells (procedure)
2109	http://www.nlm.nih.gov/research/umls/rxnorm	312033	0.0.1	ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet
2110	http://snomed.info/sct	165197003	http://snomed.info/sct/900000000000207008/version/20230430	Diagnostic assessment (procedure)
2111	http://snomed.info/sct	61594008	http://snomed.info/sct/900000000000207008/version/20230430	Microbial culture (procedure)
2112	http://www.nlm.nih.gov/research/umls/rxnorm	1313884	0.0.1	phenytoin 25 MG/ML Oral Suspension [Dilantin]
2113	http://www.nlm.nih.gov/research/umls/rxnorm	308971	0.0.1	carbamazepine 20 MG/ML Oral Suspension [Tegretol]
2114	http://www.nlm.nih.gov/research/umls/rxnorm	485053	0.0.1	carbamazepine 20 MG/ML [Tegretol]
2115	http://www.nlm.nih.gov/research/umls/rxnorm	226426	0.0.1	modafinil 100 MG Oral Tablet [Provigil]
2116	http://www.nlm.nih.gov/research/umls/rxnorm	1297960	0.0.1	ketoconazole 1 MG/ML Topical Solution
2117	http://www.nlm.nih.gov/research/umls/rxnorm	1091392	0.0.1	Methylphenidate Hydrochloride 20 MG Oral Tablet
2118	http://www.nlm.nih.gov/research/umls/rxnorm	702320	0.0.1	aspirin 500 MG / caffeine 32.5 MG Oral Tablet [Bayer Back and Body Pain]
2119	http://www.nlm.nih.gov/research/umls/rxnorm	820701	0.0.1	acetaminophen / aspirin / salicylamide
2120	http://www.nlm.nih.gov/research/umls/rxnorm	1537209	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Larin 1.5/30]
2121	http://snomed.info/sct	169690007	http://snomed.info/sct/900000000000207008/version/20230430	Rubella screening
2122	http://snomed.info/sct	237001001	http://snomed.info/sct/900000000000207008/version/20230430	Augmentation of labor
2123	http://snomed.info/sct	267020005	http://snomed.info/sct/900000000000207008/version/20230430	History of tubal ligation (situation)
2124	http://www.nlm.nih.gov/research/umls/rxnorm	212389	0.0.1	carvedilol 12.5 MG Oral Tablet [Coreg]
2125	http://snomed.info/sct	385892002	http://snomed.info/sct/900000000000207008/version/20230430	Mental health screening (procedure)
2126	http://www.nlm.nih.gov/research/umls/rxnorm	199663	0.0.1	zidovudine 300 MG Oral Tablet
2127	http://www.nlm.nih.gov/research/umls/rxnorm	208591	0.0.1	dexamethasone 1 MG/ML / neomycin 3.5 MG/ML / polymyxin B 10000 UNT/ML Ophthalmic Suspension [Maxitrol]
2128	http://www.nlm.nih.gov/research/umls/rxnorm	316640	0.0.1	rifabutin 150 MG
2129	http://www.nlm.nih.gov/research/umls/rxnorm	404742	0.0.1	12 HR carbamazepine 100 MG Extended Release Oral Capsule [Carbatrol]
2130	http://snomed.info/sct	305425002	http://snomed.info/sct/900000000000207008/version/20230430	Admission to neurosurgical department
2131	http://snomed.info/sct	367336001	http://snomed.info/sct/900000000000207008/version/20230430	Chemotherapy (procedure)
2132	http://snomed.info/sct	422650009	http://snomed.info/sct/900000000000207008/version/20230430	Social isolation (finding)
2133	http://www.nlm.nih.gov/research/umls/rxnorm	664741	0.0.1	atazanavir 300 MG Oral Capsule
2134	http://loinc.org	3173-2		aPTT in Blood by Coagulation assay
2135	http://www.nlm.nih.gov/research/umls/rxnorm	1658084	0.0.1	ado-trastuzumab emtansine 100 MG Injection
2136	http://www.nlm.nih.gov/research/umls/rxnorm	2586033	0.0.1	diltiazem hydrochloride 1 MG/ML
2137	http://www.nlm.nih.gov/research/umls/rxnorm	1806683	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack [Amabelz 0.5/0.1 28 Day]
2138	http://snomed.info/sct	233703007	http://snomed.info/sct/900000000000207008/version/20230430	 Interstitial lung disease (disorder)
2139	http://www.nlm.nih.gov/research/umls/rxnorm	1358780	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack [Junel 1/20 21 Day]
2140	http://loinc.org	2157-6		Creatine kinase [Enzymatic activity/volume] in Serum or Plasma
2141	http://www.nlm.nih.gov/research/umls/rxnorm	897595	0.0.1	verapamil hydrochloride 300 MG
2142	http://snomed.info/sct	230745008	http://snomed.info/sct/900000000000207008/version/20230430	Hydrocephalus (disorder)
2143	http://snomed.info/sct	68235000	http://snomed.info/sct/900000000000207008/version/20230430	Nasal congestion (finding)
2144	http://snomed.info/sct	389087006	http://snomed.info/sct/900000000000207008/version/20230430	Hypoxemia (disorder)
2145	http://www.nlm.nih.gov/research/umls/rxnorm	1437975	0.0.1	Glycopyrrolate 1.5 MG Oral Tablet [Glycate]
2146	http://www.nlm.nih.gov/research/umls/rxnorm	575939	0.0.1	voriconazole 50 MG [Vfend]
2147	http://loinc.org	76690-7		Sexual orientation
2148	http://snomed.info/sct	433114000	http://snomed.info/sct/900000000000207008/version/20230430	Human epidermal growth factor receptor 2 gene detection by immunohistochemistry (procedure)
2149	http://www.nlm.nih.gov/research/umls/rxnorm	831299	0.0.1	diltiazem hydrochloride 240 MG [Taztia]
2150	http://www.nlm.nih.gov/research/umls/rxnorm	994435	0.0.1	aspirin 845 MG / caffeine 65 MG Oral Powder
2151	http://www.nlm.nih.gov/research/umls/rxnorm	859751	0.0.1	rosuvastatin calcium 20 MG Oral Tablet
2152	http://snomed.info/sct	19829001	http://snomed.info/sct/900000000000207008/version/20230430	Disorder of lung (disorder)
2153	http://www.nlm.nih.gov/research/umls/rxnorm	2671204	0.0.1	1 ML phenobarbital sodium 130 MG/ML Injection
2154	http://www.nlm.nih.gov/research/umls/rxnorm	1359032	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Microgestin 1.5/30 21 Day]
2155	http://www.nlm.nih.gov/research/umls/rxnorm	630208	0.0.1	albuterol 0.83 MG/ML Inhalation Solution
2156	http://www.nlm.nih.gov/research/umls/rxnorm	686355	0.0.1	erythromycin stearate 250 MG Oral Tablet
2157	http://snomed.info/sct	70704007	http://snomed.info/sct/900000000000207008/version/20230430	Sprain of wrist
2158	http://www.nlm.nih.gov/research/umls/rxnorm	206080	0.0.1	erythromycin 500 MG Delayed Release Oral Tablet [Ery-Tab]
2159	http://www.nlm.nih.gov/research/umls/rxnorm	214160	0.0.1	aspirin / butalbital / caffeine / codeine
2160	http://www.nlm.nih.gov/research/umls/rxnorm	1008006	0.0.1	aspirin / caffeine / magnesium salicylate
2161	http://www.nlm.nih.gov/research/umls/rxnorm	226719	0.0.1	Etoposide 100 MG Injection
2162	http://www.nlm.nih.gov/research/umls/rxnorm	749879	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack
2163	http://www.nlm.nih.gov/research/umls/rxnorm	315431	0.0.1	aspirin 81 MG
2164	http://www.nlm.nih.gov/research/umls/rxnorm	567515	0.0.1	isoniazid 150 MG / rifampin 300 MG [Rifamate]
2165	http://snomed.info/sct	287182007	http://snomed.info/sct/900000000000207008/version/20230430	Attempted suicide - suffocation
2166	http://www.nlm.nih.gov/research/umls/rxnorm	214866	0.0.1	trandolapril / verapamil
2167	http://www.nlm.nih.gov/research/umls/rxnorm	311995	0.0.1	NITROFURANTOIN, MACROCRYSTALS 50 MG Oral Capsule
2168	http://www.nlm.nih.gov/research/umls/rxnorm	1091634	0.0.1	diltiazem hydrochloride 300 MG [Matzim]
2169	http://www.nlm.nih.gov/research/umls/rxnorm	831287	0.0.1	diltiazem hydrochloride 240 MG [Cartia]
2170	http://snomed.info/sct	65575008	http://snomed.info/sct/900000000000207008/version/20230430	Biopsy of prostate
2171	http://snomed.info/sct	15777000	http://snomed.info/sct/900000000000207008/version/20230430	Prediabetes
2172	http://www.nlm.nih.gov/research/umls/rxnorm	211297	0.0.1	aspirin 400 MG / caffeine 32 MG Oral Tablet [P-A-C Analgesic]
2173	http://www.nlm.nih.gov/research/umls/rxnorm	1994333	0.0.1	chlorhexidine 0.02 MG/MG / ketoconazole 0.01 MG/MG Medicated Pad
2174	http://loinc.org	89579-7		Troponin I.cardiac [Mass/volume] in Serum or Plasma by High sensitivity method
2175	http://snomed.info/sct	94225005	http://snomed.info/sct/900000000000207008/version/20230430	Metastatic malignant neoplasm to brain (disorder)
2176	http://www.nlm.nih.gov/research/umls/rxnorm	1007368	0.0.1	anisotropine / phenobarbital
2177	http://www.nlm.nih.gov/research/umls/rxnorm	55672	0.0.1	rifabutin
2178	http://www.nlm.nih.gov/research/umls/rxnorm	831247	0.0.1	diltiazem hydrochloride 180 MG [Taztia]
2180	http://snomed.info/sct	409066002	http://snomed.info/sct/900000000000207008/version/20230430	Education, guidance and counseling (procedure)
2181	http://snomed.info/sct	703423002	http://snomed.info/sct/900000000000207008/version/20230430	Combined chemotherapy and radiation therapy (procedure)
2182	http://www.nlm.nih.gov/research/umls/rxnorm	2003647	0.0.1	hydrocortisone 10 MG/ML / ketoconazole 1.5 MG/ML [Malacetic]
2183	http://www.nlm.nih.gov/research/umls/rxnorm	316513	0.0.1	phenytoin 50 MG
2184	http://www.nlm.nih.gov/research/umls/rxnorm	994536	0.0.1	aspirin 770 MG / caffeine 60 MG / orphenadrine citrate 50 MG [Norgesic]
2185	http://www.nlm.nih.gov/research/umls/rxnorm	897586	0.0.1	24 HR verapamil hydrochloride 100 MG Extended Release Oral Capsule [Verelan]
2186	http://www.nlm.nih.gov/research/umls/rxnorm	214250	0.0.1	aspirin / caffeine
2187	http://www.nlm.nih.gov/research/umls/rxnorm	198085	0.0.1	phenobarbital 16 MG Oral Tablet
2188	http://www.nlm.nih.gov/research/umls/rxnorm	825180	0.0.1	aspirin 81 MG Chewable Tablet [Bayer Aspirin]
2189	http://www.nlm.nih.gov/research/umls/rxnorm	749148	0.0.1	{12 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 9 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Leena 28 Day]
2190	http://snomed.info/sct	609588000	http://snomed.info/sct/900000000000207008/version/20230430	Total knee replacement
2191	http://www.nlm.nih.gov/research/umls/rxnorm	687304	0.0.1	dexamethasone / tramazoline
2192	http://snomed.info/sct	39848009	http://snomed.info/sct/900000000000207008/version/20230430	Whiplash injury to neck
2193	http://www.nlm.nih.gov/research/umls/rxnorm	992413	0.0.1	itraconazole 200 MG Oral Tablet
2194	http://www.nlm.nih.gov/research/umls/rxnorm	992412	0.0.1	itraconazole 200 MG
2195	http://www.nlm.nih.gov/research/umls/rxnorm	2642136	0.0.1	{28 (estradiol 0.5 MG / norethindrone acetate 0.1 MG Oral Tablet) } Pack [Etyqa 0.5/0.1 28 Day]
2196	http://www.nlm.nih.gov/research/umls/rxnorm	762007	0.0.1	{7 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 0.75 MG Oral Tablet) / 7 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Nortrel 7/7/7 28 Day]
2197	http://snomed.info/sct	288328004	http://snomed.info/sct/900000000000207008/version/20230430	Bee venom (substance)
2198	http://www.nlm.nih.gov/research/umls/rxnorm	466584	0.0.1	acetaminophen / aspirin / caffeine
2199	http://snomed.info/sct	384700001	http://snomed.info/sct/900000000000207008/version/20230430	Injection of tetanus antitoxin
2200	http://www.nlm.nih.gov/research/umls/rxnorm	311700	0.0.1	Midazolam 1 MG/ML Injectable Solution
2201	http://www.nlm.nih.gov/research/umls/rxnorm	1439950	0.0.1	acetic acid 20 MG/ML / chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML [Mal-A-Ket]
2202	http://snomed.info/sct	78275009	http://snomed.info/sct/900000000000207008/version/20230430	Obstructive sleep apnea syndrome (disorder)
2203	http://www.nlm.nih.gov/research/umls/rxnorm	2118008	0.0.1	atropine sulfate 0.00388 MG/ML / hyoscyamine sulfate 0.0207 MG/ML / phenobarbital 3.24 MG/ML / scopolamine hydrobromide 0.0013 MG/ML [Phenohytro]
2204	http://loinc.org	8302-2		Body height
2205	http://www.nlm.nih.gov/research/umls/rxnorm	1358781	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack [Loestrin 1/20 21 Day]
2206	http://snomed.info/sct	126906006	http://snomed.info/sct/900000000000207008/version/20230430	Neoplasm of prostate
2207	http://www.nlm.nih.gov/research/umls/rxnorm	897612	0.0.1	24 HR verapamil hydrochloride 120 MG Extended Release Oral Capsule
2208	http://snomed.info/sct	399217008	http://snomed.info/sct/900000000000207008/version/20230430	Cardioassist by aortic balloon pump (procedure)
2209	http://www.nlm.nih.gov/research/umls/rxnorm	1606353	0.0.1	hydrocortisone 0.01 MG/MG / ketoconazole 0.0015 MG/MG Otic Ointment
2210	http://snomed.info/sct	275408006	http://snomed.info/sct/900000000000207008/version/20230430	Postoperative renal failure (disorder)
2211	http://snomed.info/sct	46706006	http://snomed.info/sct/900000000000207008/version/20230430	Replacement of contraceptive intrauterine device (procedure)
2212	http://snomed.info/sct	69896004	http://snomed.info/sct/900000000000207008/version/20230430	Rheumatoid arthritis
2213	http://www.nlm.nih.gov/research/umls/rxnorm	1007711	0.0.1	isosorbide dinitrate / verapamil
2214	http://www.nlm.nih.gov/research/umls/rxnorm	198202	0.0.1	rifampin 300 MG Oral Capsule
2215	http://www.nlm.nih.gov/research/umls/rxnorm	689551	0.0.1	acetaminophen / aspirin / caffeine / calcium gluconate
2216	http://www.nlm.nih.gov/research/umls/rxnorm	1007424	0.0.1	ascorbic acid / aspirin / diphenylpyraline
2217	http://www.nlm.nih.gov/research/umls/rxnorm	866516	0.0.1	metoprolol tartrate 50 MG Oral Tablet [Lopressor]
2218	http://www.nlm.nih.gov/research/umls/rxnorm	438889	0.0.1	dexamethasone 0.5 MG/ML
2219	http://loinc.org	66519-0		Percentage area affected by eczema Head and Neck [PhenX]
2220	http://snomed.info/sct	414667000	http://snomed.info/sct/900000000000207008/version/20230430	Meningomyelocele (disorder)
2221	http://www.nlm.nih.gov/research/umls/rxnorm	2669490	0.0.1	ketoconazole 1 MG/ML / salicylic acid 1.5 MG/ML Otic Solution
2222	http://www.nlm.nih.gov/research/umls/rxnorm	1536993	0.0.1	aspirin 500 MG / chlorpheniramine maleate 2 MG / phenylephrine bitartrate 8 MG Effervescent Oral Tablet
2223	http://snomed.info/sct	90460009	http://snomed.info/sct/900000000000207008/version/20230430	Injury of neck (disorder)
2224	http://snomed.info/sct	90739004	http://snomed.info/sct/900000000000207008/version/20230430	Thyrotoxicosis (disorder)
2225	http://www.nlm.nih.gov/research/umls/rxnorm	402506	0.0.1	12 HR carbamazepine 400 MG Extended Release Oral Tablet
2226	http://snomed.info/sct	429609002	http://snomed.info/sct/900000000000207008/version/20230430	Lung volume reduction surgery (procedure)
2227	http://snomed.info/sct	112790001	http://snomed.info/sct/900000000000207008/version/20230430	Nasal sinus endoscopy (procedure)
2228	http://www.nlm.nih.gov/research/umls/rxnorm	1659131	0.0.1	piperacillin 2000 MG / tazobactam 250 MG Injection
2229	http://snomed.info/sct	311791003	http://snomed.info/sct/900000000000207008/version/20230430	Information gathering (procedure)
2230	http://snomed.info/sct	424132000	http://snomed.info/sct/900000000000207008/version/20230430	Non-small cell carcinoma of lung, TNM stage 1 (disorder)
2232	http://snomed.info/sct	444814009	http://snomed.info/sct/900000000000207008/version/20230430	Viral sinusitis (disorder)
2233	http://snomed.info/sct	161665007	http://snomed.info/sct/900000000000207008/version/20230430	History of renal transplant (situation)
2234	http://www.nlm.nih.gov/research/umls/rxnorm	724614	0.0.1	aspirin 325 MG / oxycodone hydrochloride 2.25 MG / oxycodone terephthalate 0.19 MG Oral Tablet
2235	http://snomed.info/sct	741062008	http://snomed.info/sct/900000000000207008/version/20230430	Not in labor force (finding)
2236	http://www.nlm.nih.gov/research/umls/rxnorm	833217	0.0.1	diltiazem hydrochloride 30 MG Oral Tablet
2237	http://www.nlm.nih.gov/research/umls/rxnorm	314077	0.0.1	lisinopril 20 MG Oral Tablet
2238	http://www.nlm.nih.gov/research/umls/rxnorm	1607990	0.0.1	{24 (ethinyl estradiol 0.025 MG / norethindrone 0.8 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Chewable Tablet) } Pack
2239	http://snomed.info/sct	161621004	http://snomed.info/sct/900000000000207008/version/20230430	History of upper limb amputation (situation)
2240	http://www.nlm.nih.gov/research/umls/rxnorm	1998482	0.0.1	{21 (dexamethasone 1.5 MG Oral Tablet) } Pack [TaperDex 6 Day Taper]
2241	http://snomed.info/sct	122460008	http://snomed.info/sct/900000000000207008/version/20230430	Reexploration procedure (procedure)
2242	http://snomed.info/sct	35025007	http://snomed.info/sct/900000000000207008/version/20230430	Manual pelvic examination (procedure)
2243	http://www.nlm.nih.gov/research/umls/rxnorm	241834	0.0.1	cycloSPORINE, modified 100 MG Oral Capsule
2244	http://snomed.info/sct	55680006	http://snomed.info/sct/900000000000207008/version/20230430	Drug overdose
2245	http://www.nlm.nih.gov/research/umls/rxnorm	567090	0.0.1	erythromycin 20 MG/ML [Theramycin]
2246	http://www.nlm.nih.gov/research/umls/rxnorm	1049683	0.0.1	oxyCODONE Hydrochloride 10 MG Oral Tablet
2247	http://www.nlm.nih.gov/research/umls/rxnorm	1536840	0.0.1	aspirin 325 MG / chlorpheniramine maleate 2 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet
2248	http://www.nlm.nih.gov/research/umls/rxnorm	310155	0.0.1	erythromycin 250 MG Delayed Release Oral Tablet
2249	http://www.nlm.nih.gov/research/umls/rxnorm	198086	0.0.1	phenobarbital 16.2 MG Oral Tablet
2250	http://snomed.info/sct	67811000119102	http://snomed.info/sct/900000000000207008/version/20230430	Primary small cell malignant neoplasm of lung, TNM stage 1 (disorder)
2251	http://www.nlm.nih.gov/research/umls/rxnorm	2626482	0.0.1	pentobarbital sodium 390 MG/ML / phenytoin sodium 50 MG/ML [Euthaphen]
2252	http://www.nlm.nih.gov/research/umls/rxnorm	486960	0.0.1	erythromycin estolate 25 MG/ML Oral Suspension
2253	http://www.nlm.nih.gov/research/umls/rxnorm	197379	0.0.1	atenolol 100 MG Oral Tablet
2254	http://www.nlm.nih.gov/research/umls/rxnorm	106258	0.0.1	Hydrocortisone 10 MG/ML Topical Cream
2255	http://www.nlm.nih.gov/research/umls/rxnorm	308973	0.0.1	carbamazepine 100 MG Chewable Tablet
2256	http://snomed.info/sct	363346000	http://snomed.info/sct/900000000000207008/version/20230430	Malignant neoplastic disease (disorder)
2257	http://www.nlm.nih.gov/research/umls/rxnorm	1359234	0.0.1	norethindrone enanthate 200 MG/ML
2258	http://snomed.info/sct	122548005	http://snomed.info/sct/900000000000207008/version/20230430	Biopsy of breast (procedure)
2259	http://www.nlm.nih.gov/research/umls/rxnorm	328565	0.0.1	phenobarbital 30 MG/ML
2260	http://www.nlm.nih.gov/research/umls/rxnorm	6135	0.0.1	ketoconazole
2261	http://www.nlm.nih.gov/research/umls/rxnorm	1656351	0.0.1	sacubitril 49 MG / valsartan 51 MG Oral Tablet [Entresto]
2262	http://www.nlm.nih.gov/research/umls/rxnorm	106336	0.0.1	ketoconazole 20 MG/ML Medicated Shampoo
2263	http://www.nlm.nih.gov/research/umls/rxnorm	903879	0.0.1	24 HR fluvoxamine maleate 150 MG Extended Release Oral Capsule
2264	http://www.nlm.nih.gov/research/umls/rxnorm	388311	0.0.1	12 HR carbamazepine 100 MG Extended Release Oral Capsule
2265	http://snomed.info/sct	717778001	http://snomed.info/sct/900000000000207008/version/20230430	Mouth care (regime/therapy)
2266	http://loinc.org	20447-9		HIV 1 RNA [#/volume] (viral load) in Serum or Plasma by NAA with probe detection
2267	http://www.nlm.nih.gov/research/umls/rxnorm	858810	0.0.1	enalapril maleate 20 MG Oral Tablet
2268	http://snomed.info/sct	42343007	http://snomed.info/sct/900000000000207008/version/20230430	Congestive heart failure (disorder)
2269	http://snomed.info/sct	40055000	http://snomed.info/sct/900000000000207008/version/20230430	Chronic sinusitis (disorder)
2270	http://snomed.info/sct	68962001	http://snomed.info/sct/900000000000207008/version/20230430	Muscle pain (finding)
2271	http://www.nlm.nih.gov/research/umls/rxnorm	748987	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Ortho Micronor 28 Day]
2272	http://snomed.info/sct	225337009	http://snomed.info/sct/900000000000207008/version/20230430	Suicide risk assessment (procedure)
2273	http://snomed.info/sct	185086009	http://snomed.info/sct/900000000000207008/version/20230430	Chronic obstructive bronchitis (disorder)
2274	http://www.nlm.nih.gov/research/umls/rxnorm	563866	0.0.1	carbamazepine 400 MG [Tegretol]
2275	http://www.nlm.nih.gov/research/umls/rxnorm	856980	0.0.1	Acetaminophen/Hydrocodone
2276	http://www.nlm.nih.gov/research/umls/rxnorm	686350	0.0.1	erythromycin ethylsuccinate 200 MG Chewable Tablet
2277	http://snomed.info/sct	312421008	http://snomed.info/sct/900000000000207008/version/20230430	Radionuclide Imaging
2278	http://www.nlm.nih.gov/research/umls/rxnorm	830836	0.0.1	diltiazem hydrochloride 240 MG
2279	http://snomed.info/sct	711446003	http://snomed.info/sct/900000000000207008/version/20230430	Transplantation of kidney regime (regime/therapy)
2280	http://www.nlm.nih.gov/research/umls/rxnorm	235389	0.0.1	Mestranol / Norethynodrel
2281	http://snomed.info/sct	160968000	http://snomed.info/sct/900000000000207008/version/20230430	Risk activity involvement (finding)
2282	http://loinc.org	19926-5		Fev1/Fvc
2283	http://www.nlm.nih.gov/research/umls/rxnorm	854235	0.0.1	0.4 ML Enoxaparin sodium 100 MG/ML Prefilled Syringe
2284	http://www.nlm.nih.gov/research/umls/rxnorm	349491	0.0.1	lamivudine 300 MG Oral Tablet
2285	http://www.nlm.nih.gov/research/umls/rxnorm	2393781	0.0.1	aspirin 6 MG/ML
2286	http://www.nlm.nih.gov/research/umls/rxnorm	830798	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Capsule [Cardizem]
2287	http://www.nlm.nih.gov/research/umls/rxnorm	689513	0.0.1	aspirin / caffeine / dihydrocodeine / promethazine
2288	http://www.nlm.nih.gov/research/umls/rxnorm	212388	0.0.1	carvedilol 6.25 MG Oral Tablet [Coreg]
2289	http://www.nlm.nih.gov/research/umls/rxnorm	846192	0.0.1	{21 (dexamethasone 1.5 MG Oral Tablet) } Pack
2290	http://www.nlm.nih.gov/research/umls/rxnorm	616830	0.0.1	budesonide 0.125 MG/ML Inhalation Suspension [Pulmicort]
2291	http://www.nlm.nih.gov/research/umls/rxnorm	1313888	0.0.1	phenytoin 6 MG/ML Oral Suspension
2292	http://www.nlm.nih.gov/research/umls/rxnorm	1869047	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet) / 7 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Nexesta Fe 28 Day]
2293	http://www.nlm.nih.gov/research/umls/rxnorm	308976	0.0.1	carbamazepine 20 MG/ML Oral Suspension
2294	http://www.nlm.nih.gov/research/umls/rxnorm	2397128	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Lyleq 28 Day]
2295	http://www.nlm.nih.gov/research/umls/rxnorm	448	0.0.1	ethanol
2296	http://www.nlm.nih.gov/research/umls/rxnorm	833704	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Diltzac]
2297	http://www.nlm.nih.gov/research/umls/rxnorm	314203	0.0.1	quinapril 40 MG Oral Tablet
2298	http://snomed.info/sct	44608003	http://snomed.info/sct/900000000000207008/version/20230430	Blood group typing (procedure)
2299	http://snomed.info/sct	398152000	http://snomed.info/sct/900000000000207008/version/20230430	Poor muscle tone (finding)
2300	http://www.nlm.nih.gov/research/umls/rxnorm	1374371	0.0.1	dexamethasone acetate 8 MG/ML
2301	http://www.nlm.nih.gov/research/umls/rxnorm	1860154	0.0.1	Abuse-Deterrent 12 HR Oxycodone Hydrochloride 15 MG Extended Release Oral Tablet
2302	http://snomed.info/sct	840539006	http://snomed.info/sct/900000000000207008/version/20230430	Covid-19
2303	http://www.nlm.nih.gov/research/umls/rxnorm	830839	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule [Cardizem]
2304	http://www.nlm.nih.gov/research/umls/rxnorm	1313887	0.0.1	phenytoin 50 MG Chewable Tablet [Dilantin]
2305	http://www.nlm.nih.gov/research/umls/rxnorm	1721613	0.0.1	cobicistat 150 MG / elvitegravir 150 MG / emtricitabine 200 MG / tenofovir alafenamide 10 MG Oral Tablet
2306	http://www.nlm.nih.gov/research/umls/rxnorm	1090992	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG Oral Tablet
2307	http://www.nlm.nih.gov/research/umls/rxnorm	966529	0.0.1	60 ACTUAT budesonide 0.09 MG/ACTUAT Dry Powder Inhaler [Pulmicort]
2308	http://www.nlm.nih.gov/research/umls/rxnorm	1485332	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Vyfemla 28 Day]
2309	http://www.nlm.nih.gov/research/umls/rxnorm	750837	0.0.1	erythromycin stearate 250 MG [Erythrocin Stearate]
2310	http://www.nlm.nih.gov/research/umls/rxnorm	689540	0.0.1	aspirin / promethazine / pseudoephedrine
2311	http://snomed.info/sct	408919008	http://snomed.info/sct/900000000000207008/version/20230430	Psychosocial care (regime/therapy)
2312	http://www.nlm.nih.gov/research/umls/rxnorm	979468	0.0.1	hydrochlorothiazide 12.5 MG / losartan potassium 50 MG Oral Tablet
2313	http://snomed.info/sct	305433001	http://snomed.info/sct/900000000000207008/version/20230430	Admission to trauma surgery department
2314	http://www.nlm.nih.gov/research/umls/rxnorm	1247394	0.0.1	aspirin 1000 MG / caffeine 65 MG [BC Arthritis]
2315	http://www.nlm.nih.gov/research/umls/rxnorm	831195	0.0.1	diltiazem hydrochloride 120 MG [Taztia]
2316	http://loinc.org	70006-2		Medication management note
2317	http://www.nlm.nih.gov/research/umls/rxnorm	686406	0.0.1	erythromycin stearate 500 MG Oral Tablet
2318	http://snomed.info/sct	171122006	http://snomed.info/sct/900000000000207008/version/20230430	Hepatitis B screening (procedure)
2319	http://snomed.info/sct	305340004	http://snomed.info/sct/900000000000207008/version/20230430	Admission to long stay hospital
2320	http://www.nlm.nih.gov/research/umls/rxnorm	1359269	0.0.1	darunavir 800 MG Oral Tablet
2321	http://www.nlm.nih.gov/research/umls/rxnorm	214257	0.0.1	aspirin / pentazocine
2322	http://www.nlm.nih.gov/research/umls/rxnorm	898719	0.0.1	benazepril hydrochloride 40 MG Oral Tablet
2323	http://www.nlm.nih.gov/research/umls/rxnorm	1536498	0.0.1	aspirin 325 MG / dextromethorphan hydrobromide 10 MG / phenylephrine bitartrate 7.8 MG Effervescent Oral Tablet
2324	http://www.nlm.nih.gov/research/umls/rxnorm	1989873	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Hailey Fe 1/20 28 Day]
2325	http://www.nlm.nih.gov/research/umls/rxnorm	830864	0.0.1	diltiazem hydrochloride 60 MG
2326	http://snomed.info/sct	313077009	http://snomed.info/sct/900000000000207008/version/20230430	Human immunodeficiency virus counseling (procedure)
2327	http://www.nlm.nih.gov/research/umls/rxnorm	402917	0.0.1	ketoconazole 0.01 MG/MG
2328	http://www.nlm.nih.gov/research/umls/rxnorm	1362082	0.0.1	12 HR aspirin 25 MG / dipyridamole 200 MG Extended Release Oral Capsule [Aggrenox]
2329	http://www.nlm.nih.gov/research/umls/rxnorm	2106642	0.0.1	itraconazole 65 MG Oral Capsule
2330	http://snomed.info/sct	23426006	http://snomed.info/sct/900000000000207008/version/20230430	Measurement of respiratory function (procedure)
2331	http://www.nlm.nih.gov/research/umls/rxnorm	2122519	0.0.1	dolutegravir 50 MG / lamivudine 300 MG Oral Tablet
2332	http://www.nlm.nih.gov/research/umls/rxnorm	861654	0.0.1	pitavastatin calcium 4 MG Oral Tablet [Livalo]
2333	http://snomed.info/sct	84728005	http://snomed.info/sct/900000000000207008/version/20230430	Neurological examination (procedure)
2334	http://snomed.info/sct	314994000	http://snomed.info/sct/900000000000207008/version/20230430	Metastasis from malignant tumor of prostate (disorder)
2335	http://www.nlm.nih.gov/research/umls/rxnorm	686401	0.0.1	erythromycin ethylsuccinate 40 MG/ML [EryPed]
2336	http://www.nlm.nih.gov/research/umls/rxnorm	315413	0.0.1	aspirin 150 MG
2337	http://www.nlm.nih.gov/research/umls/rxnorm	901450	0.0.1	verapamil hydrochloride 8 MG/ML Oral Solution
2338	http://www.nlm.nih.gov/research/umls/rxnorm	1797513	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML [Keto-C]
2339	http://snomed.info/sct	180256009	http://snomed.info/sct/900000000000207008/version/20230430	Subcutaneous immunotherapy
2557	http://www.nlm.nih.gov/research/umls/rxnorm	903878	0.0.1	fluvoxamine maleate 150 MG
2340	http://www.nlm.nih.gov/research/umls/rxnorm	243685	0.0.1	aspirin 421 MG / caffeine 32 MG Oral Tablet
2341	http://www.nlm.nih.gov/research/umls/rxnorm	901449	0.0.1	verapamil hydrochloride 8 MG/ML
2342	http://www.nlm.nih.gov/research/umls/rxnorm	723531	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Anacin Advanced Headache Formula]
2343	http://www.nlm.nih.gov/research/umls/rxnorm	1721965	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Microgestin 24 Fe 28 Day]
2344	http://www.nlm.nih.gov/research/umls/rxnorm	1251495	0.0.1	84 HR estradiol 0.00208 MG/HR / norethindrone acetate 0.00583 MG/HR Transdermal System [Combipatch]
2345	http://snomed.info/sct	248595008	http://snomed.info/sct/900000000000207008/version/20230430	Sputum finding (finding)
2346	http://www.nlm.nih.gov/research/umls/rxnorm	197380	0.0.1	atenolol 25 MG Oral Tablet
2347	http://loinc.org	66534-9		Percentage area affected by eczema Lower extremity - bilateral [PhenX]
2348	http://www.nlm.nih.gov/research/umls/rxnorm	312617	0.0.1	predniSONE 5 MG Oral Tablet
2349	http://snomed.info/sct	427089005	http://snomed.info/sct/900000000000207008/version/20230430	Diabetes from Cystic Fibrosis
2350	http://www.nlm.nih.gov/research/umls/rxnorm	705129	0.0.1	Nitroglycerin 0.4 MG/ACTUAT Mucosal Spray
2351	http://www.nlm.nih.gov/research/umls/rxnorm	1359235	0.0.1	norethindrone enanthate 200 MG/ML Injectable Solution
2352	http://snomed.info/sct	52448006	http://snomed.info/sct/900000000000207008/version/20230430	Dementia (disorder)
2353	http://snomed.info/sct	399014008	http://snomed.info/sct/900000000000207008/version/20230430	Administration of diphtheria, pertussis, and tetanus vaccine
2354	http://www.nlm.nih.gov/research/umls/rxnorm	2624719	0.0.1	phenobarbital sodium 100 MG Injection
2355	http://www.nlm.nih.gov/research/umls/rxnorm	817816	0.0.1	mephobarbital / phenytoin
2356	http://www.nlm.nih.gov/research/umls/rxnorm	200133	0.0.1	12 HR carbamazepine 200 MG Extended Release Oral Capsule
2357	http://www.nlm.nih.gov/research/umls/rxnorm	317346	0.0.1	dexamethasone 2 MG
2358	http://www.nlm.nih.gov/research/umls/rxnorm	897618	0.0.1	24 HR verapamil hydrochloride 180 MG Extended Release Oral Capsule
2359	http://snomed.info/sct	47758006	http://snomed.info/sct/900000000000207008/version/20230430	Hepatitis B Surface Antigen Measurement
2360	http://www.nlm.nih.gov/research/umls/rxnorm	37333	0.0.1	sulfanilylurea
2361	http://snomed.info/sct	287664005	http://snomed.info/sct/900000000000207008/version/20230430	Ligation of bilateral fallopian tubes (procedure)
2362	http://snomed.info/sct	387607004	http://snomed.info/sct/900000000000207008/version/20230430	Construction of diverting colostomy
2363	http://www.nlm.nih.gov/research/umls/rxnorm	1249712	0.0.1	dexamethasone sodium phosphate 0.4 MG/ML Injectable Solution
2364	http://www.nlm.nih.gov/research/umls/rxnorm	1736854	0.0.1	Cisplatin 50 MG Injection
2365	http://www.nlm.nih.gov/research/umls/rxnorm	855675	0.0.1	phenytoin sodium 100 MG Oral Capsule
2366	http://www.nlm.nih.gov/research/umls/rxnorm	205251	0.0.1	acetaminophen 160 MG / aspirin 230 MG / caffeine 33 MG Oral Tablet
2367	http://www.nlm.nih.gov/research/umls/rxnorm	822000	0.0.1	carisoprodol / dexamethasone / tenoxicam
2368	http://www.nlm.nih.gov/research/umls/rxnorm	1052678	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [Miniprin]
2369	http://www.nlm.nih.gov/research/umls/rxnorm	1249711	0.0.1	dexamethasone sodium phosphate 0.4 MG/ML
2370	http://www.nlm.nih.gov/research/umls/rxnorm	2371767	0.0.1	{28 (elagolix 300 MG / estradiol 1 MG / norethindrone 0.5 MG Oral Capsule) / 28 (elagolix 300 MG Oral Capsule) } Pack
2371	http://www.nlm.nih.gov/research/umls/rxnorm	797022	0.0.1	{35 (dexamethasone 1.5 MG Oral Tablet) } Pack [DexPak TaperPak Junior 10 Day]
2372	http://www.nlm.nih.gov/research/umls/rxnorm	2671203	0.0.1	phenobarbital sodium 130 MG/ML
2373	http://snomed.info/sct	228557008	http://snomed.info/sct/900000000000207008/version/20230430	Cognitive and behavioral therapy (regime/therapy)
2374	http://www.nlm.nih.gov/research/umls/rxnorm	1988310	0.0.1	diltiazem hydrochloride 180 MG [Tiadylt]
2375	http://loinc.org	71425-3		Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Blood by Immunoassay
2376	http://snomed.info/sct	204949001	http://snomed.info/sct/900000000000207008/version/20230430	Renal dysplasia (disorder)
2377	http://www.nlm.nih.gov/research/umls/rxnorm	855861	0.0.1	phenytoin sodium 200 MG Extended Release Oral Capsule
2378	http://www.nlm.nih.gov/research/umls/rxnorm	994528	0.0.1	aspirin 385 MG / caffeine 30 MG / orphenadrine citrate 25 MG Oral Tablet
2379	http://www.nlm.nih.gov/research/umls/rxnorm	571734	0.0.1	aspirin 400 MG / caffeine 32 MG [Anacin]
2380	http://www.nlm.nih.gov/research/umls/rxnorm	328567	0.0.1	phenobarbital 60 MG/ML
2381	http://www.nlm.nih.gov/research/umls/rxnorm	200284	0.0.1	hydrochlorothiazide 12.5 MG / valsartan 80 MG Oral Tablet
2382	http://snomed.info/sct	185087000	http://snomed.info/sct/900000000000207008/version/20230430	Notifications (procedure)
2383	http://www.nlm.nih.gov/research/umls/rxnorm	2121735	0.0.1	{39 (dexamethasone 1.5 MG Oral Tablet) } Pack [Dxevo 11 Day Taper]
2384	http://www.nlm.nih.gov/research/umls/rxnorm	759696	0.0.1	{12 (dexamethasone 0.75 MG Oral Tablet) } Pack
2385	http://www.nlm.nih.gov/research/umls/rxnorm	598006	0.0.1	erythromycin 250 MG Oral Tablet
2386	http://www.nlm.nih.gov/research/umls/rxnorm	1740467	0.0.1	2 ML Ondansetron 2 MG/ML Injection
2387	http://www.nlm.nih.gov/research/umls/rxnorm	1358849	0.0.1	acetaminophen 110 MG / aspirin 162 MG / caffeine 32.4 MG / salicylamide 152 MG [Exaprin]
2388	http://www.nlm.nih.gov/research/umls/rxnorm	29046	0.0.1	Lisinopril
2389	http://www.nlm.nih.gov/research/umls/rxnorm	1803932	0.0.1	Leucovorin 100 MG Injection
2390	http://www.nlm.nih.gov/research/umls/rxnorm	1098648	0.0.1	nefazodone hydrochloride 100 MG
2391	http://www.nlm.nih.gov/research/umls/rxnorm	546624	0.0.1	voriconazole 40 MG/ML Oral Suspension [Vfend]
2392	http://www.nlm.nih.gov/research/umls/rxnorm	1359118	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Loestrin 24 Fe 28 Day]
2393	http://www.nlm.nih.gov/research/umls/rxnorm	1300538	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Dasetta 1/35 28 Day]
2394	http://www.nlm.nih.gov/research/umls/rxnorm	897624	0.0.1	24 HR verapamil hydrochloride 240 MG Extended Release Oral Capsule
2395	http://www.nlm.nih.gov/research/umls/rxnorm	1988318	0.0.1	diltiazem hydrochloride 300 MG [Tiadylt]
2396	http://www.nlm.nih.gov/research/umls/rxnorm	833135	0.0.1	Milnacipran hydrochloride 100 MG Oral Tablet
2397	http://loinc.org	3016-3		Thyrotropin [Units/volume] in Serum or Plasma
2398	http://www.nlm.nih.gov/research/umls/rxnorm	2045409	0.0.1	0.005 ML dexamethasone 103.4 MG/ML Injection [Dexycu]
2399	http://www.nlm.nih.gov/research/umls/rxnorm	206075	0.0.1	erythromycin 250 MG Delayed Release Oral Tablet [Ery-Tab]
2400	http://snomed.info/sct	414088005	http://snomed.info/sct/900000000000207008/version/20230430	Emergency coronary artery bypass graft (procedure)
2401	http://snomed.info/sct	76746007	http://snomed.info/sct/900000000000207008/version/20230430	Cardiovascular stress testing (procedure)
2402	http://snomed.info/sct	266948004	http://snomed.info/sct/900000000000207008/version/20230430	Has a criminal record (finding)
2403	http://www.nlm.nih.gov/research/umls/rxnorm	2045403	0.0.1	dexamethasone 103.4 MG/ML
2404	http://www.nlm.nih.gov/research/umls/rxnorm	1536144	0.0.1	120 ACTUAT mometasone furoate 0.1 MG/ACTUAT Metered Dose Inhaler [Asmanex]
2405	http://www.nlm.nih.gov/research/umls/rxnorm	566608	0.0.1	dexamethasone 6 MG [Decadron]
2406	http://www.nlm.nih.gov/research/umls/rxnorm	336012	0.0.1	aspirin 770 MG
2407	http://www.nlm.nih.gov/research/umls/rxnorm	1665356	0.0.1	24 HR aspirin 162.5 MG Extended Release Oral Capsule
2408	http://www.nlm.nih.gov/research/umls/rxnorm	690679	0.0.1	dicyclomine / phenobarbital
2409	http://www.nlm.nih.gov/research/umls/rxnorm	759481	0.0.1	{51 (dexamethasone 1.5 MG Oral Tablet) } Pack
2410	http://www.nlm.nih.gov/research/umls/rxnorm	994430	0.0.1	aspirin 1000 MG / caffeine 65 MG Oral Powder
2411	http://snomed.info/sct	67782005	http://snomed.info/sct/900000000000207008/version/20230430	Acute respiratory distress syndrome (disorder)
2412	http://www.nlm.nih.gov/research/umls/rxnorm	312137	0.0.1	oxcarbazepine 300 MG Oral Tablet
2413	http://www.nlm.nih.gov/research/umls/rxnorm	315695	0.0.1	clarithromycin 500 MG
2414	http://snomed.info/sct	88594005	http://snomed.info/sct/900000000000207008/version/20230430	Herpes simplex (disorder)
2415	http://snomed.info/sct	434363004	http://snomed.info/sct/900000000000207008/version/20230430	Human epidermal growth factor receptor 2 gene detection by fluorescence in situ hybridization (procedure)
2416	http://www.nlm.nih.gov/research/umls/rxnorm	830897	0.0.1	24 HR diltiazem hydrochloride 360 MG Extended Release Oral Tablet
2417	http://www.nlm.nih.gov/research/umls/rxnorm	121243	0.0.1	voriconazole
2418	http://snomed.info/sct	183519002	http://snomed.info/sct/900000000000207008/version/20230430	Referral to cardiology service (procedure)
2419	http://www.nlm.nih.gov/research/umls/rxnorm	308429	0.0.1	atovaquone 150 MG/ML Oral Suspension
2420	http://www.nlm.nih.gov/research/umls/rxnorm	1191222	0.0.1	naloxone hydrochloride 0.4 MG/ML Injectable Solution
2421	http://www.nlm.nih.gov/research/umls/rxnorm	141962	0.0.1	Azithromycin 250 MG Oral Capsule
2422	http://www.nlm.nih.gov/research/umls/rxnorm	751879	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 1 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Necon 1/35 28 Day]
2423	http://www.nlm.nih.gov/research/umls/rxnorm	604651	0.0.1	ketoconazole 20 MG/ML Topical Cream [Kuric]
2424	http://www.nlm.nih.gov/research/umls/rxnorm	573359	0.0.1	modafinil 200 MG [Provigil]
2425	http://www.nlm.nih.gov/research/umls/rxnorm	1944113	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Arthriten Max]
2426	http://www.nlm.nih.gov/research/umls/rxnorm	860510	0.0.1	24 HR carvedilol phosphate 10 MG Extended Release Oral Capsule
2427	http://www.nlm.nih.gov/research/umls/rxnorm	1648132	0.0.1	chlorhexidine gluconate 20 MG/ML / hydrocortisone 10 MG/ML / ketoconazole 10 MG/ML Medicated Shampoo
2428	http://snomed.info/sct	183856001	http://snomed.info/sct/900000000000207008/version/20230430	Referral to hypertension clinic
2429	http://www.nlm.nih.gov/research/umls/rxnorm	1812194	0.0.1	1 ML dexamethasone phosphate 4 MG/ML Injection
2430	http://www.nlm.nih.gov/research/umls/rxnorm	569273	0.0.1	dexamethasone 0.001 MG/MG / neomycin 0.0035 MG/MG / polymyxin B 10 UNT/MG [Poly-Dex]
2431	http://www.nlm.nih.gov/research/umls/rxnorm	315775	0.0.1	dexamethasone 0.5 MG
2432	http://snomed.info/sct	91602002	http://snomed.info/sct/900000000000207008/version/20230430	Thoracentesis (procedure)
2433	http://www.nlm.nih.gov/research/umls/rxnorm	1092209	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Topical Solution
2434	http://snomed.info/sct	868187001	http://snomed.info/sct/900000000000207008/version/20230430	Assessment using Car, Relax, Alone, Forget, Friends, Trouble Screening Test (procedure)
2435	http://www.nlm.nih.gov/research/umls/rxnorm	897684	0.0.1	verapamil hydrochloride 80 MG [Calan]
2436	http://www.nlm.nih.gov/research/umls/rxnorm	349435	0.0.1	voriconazole 50 MG Oral Tablet
2437	http://www.nlm.nih.gov/research/umls/rxnorm	198473	0.0.1	aspirin 600 MG Rectal Suppository
2438	http://www.nlm.nih.gov/research/umls/rxnorm	896884	0.0.1	aspirin 742 MG / caffeine 38 MG / salicylamide 222 MG Oral Powder
2439	http://www.nlm.nih.gov/research/umls/rxnorm	566951	0.0.1	erythromycin 250 MG [Ery-Tab]
2440	http://snomed.info/sct	399211009	http://snomed.info/sct/900000000000207008/version/20230430	History of myocardial infarction (situation)
2441	http://www.nlm.nih.gov/research/umls/rxnorm	1732136	0.0.1	1 ML Morphine Sulfate 5 MG/ML Injection
2442	http://www.nlm.nih.gov/research/umls/rxnorm	206905	0.0.1	Ibuprofen 400 MG Oral Tablet [Ibu]
2443	http://www.nlm.nih.gov/research/umls/rxnorm	486955	0.0.1	erythromycin estolate 250 MG Oral Capsule
2444	http://www.nlm.nih.gov/research/umls/rxnorm	686349	0.0.1	erythromycin ethylsuccinate 200 MG
2445	http://www.nlm.nih.gov/research/umls/rxnorm	691226	0.0.1	ephedrine / guaifenesin / phenobarbital / theophylline
2446	http://www.nlm.nih.gov/research/umls/rxnorm	856457	0.0.1	propranolol hydrochloride 20 MG Oral Tablet
2447	http://www.nlm.nih.gov/research/umls/rxnorm	313820	0.0.1	Acetaminophen 160 MG Chewable Tablet
2448	http://www.nlm.nih.gov/research/umls/rxnorm	2624724	0.0.1	phenobarbital sodium 100 MG Injection [Sezaby]
2449	http://www.nlm.nih.gov/research/umls/rxnorm	1359127	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack
2450	http://www.nlm.nih.gov/research/umls/rxnorm	32624	0.0.1	oxcarbazepine
2451	http://www.nlm.nih.gov/research/umls/rxnorm	880649	0.0.1	dexamethasone 3 MG/ML Injectable Solution
2452	http://www.nlm.nih.gov/research/umls/rxnorm	316641	0.0.1	rifampin 150 MG
2453	http://www.nlm.nih.gov/research/umls/rxnorm	200031	0.0.1	carvedilol 6.25 MG Oral Tablet
2454	http://snomed.info/sct	311834001	http://snomed.info/sct/900000000000207008/version/20230430	Fiberoptic Endoscopic Evaluation of Swallowing
2455	http://snomed.info/sct	14760008	http://snomed.info/sct/900000000000207008/version/20230430	Constipation (finding)
2456	http://www.nlm.nih.gov/research/umls/rxnorm	689511	0.0.1	aspirin / caffeine / codeine
2457	http://www.nlm.nih.gov/research/umls/rxnorm	1049630	0.0.1	diphenhydrAMINE Hydrochloride 25 MG Oral Tablet
2458	http://snomed.info/sct	22298006	http://snomed.info/sct/900000000000207008/version/20230430	Myocardial infarction (disorder)
2459	http://www.nlm.nih.gov/research/umls/rxnorm	214662	0.0.1	isoniazid / pyrazinamide / rifampin
2460	http://loinc.org	59557-9		Treatment status Cancer
2461	http://www.nlm.nih.gov/research/umls/rxnorm	242754	0.0.1	levalbuterol 0.417 MG/ML Inhalation Solution
2462	http://snomed.info/sct	302497006	http://snomed.info/sct/900000000000207008/version/20230430	Hemodialysis (procedure)
2463	http://www.nlm.nih.gov/research/umls/rxnorm	199224	0.0.1	anastrozole 1 MG Oral Tablet
2464	http://snomed.info/sct	47505003	http://snomed.info/sct/900000000000207008/version/20230430	Posttraumatic stress disorder
2465	http://www.nlm.nih.gov/research/umls/rxnorm	2107008	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Tarina 24 FE 1/20 28 Day]
2466	http://www.nlm.nih.gov/research/umls/rxnorm	1807510	0.0.1	150 ML vancomycin 5 MG/ML Injection
2467	http://snomed.info/sct	709506004	http://snomed.info/sct/900000000000207008/version/20230430	Assessment of readiness for disclosure of health status (procedure)
2468	http://snomed.info/sct	373587001	http://snomed.info/sct/900000000000207008/version/20230430	Chiari malformation type II (disorder)
2469	http://www.nlm.nih.gov/research/umls/rxnorm	897853	0.0.1	24 HR trandolapril 4 MG / verapamil hydrochloride 240 MG Extended Release Oral Tablet
2470	http://snomed.info/sct	196416002	http://snomed.info/sct/900000000000207008/version/20230430	Impacted molars
2471	http://www.nlm.nih.gov/research/umls/rxnorm	259081	0.0.1	12 HR aspirin 25 MG / dipyridamole 200 MG Extended Release Oral Capsule
2472	http://www.nlm.nih.gov/research/umls/rxnorm	312615	0.0.1	predniSONE 20 MG Oral Tablet
2473	http://www.nlm.nih.gov/research/umls/rxnorm	830837	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Capsule
2474	http://www.nlm.nih.gov/research/umls/rxnorm	316484	0.0.1	phenobarbital 4 MG/ML
2475	http://snomed.info/sct	47318007	http://snomed.info/sct/900000000000207008/version/20230430	Neutropenia (disorder)
2476	http://snomed.info/sct	203082005	http://snomed.info/sct/900000000000207008/version/20230430	Fibromyalgia (disorder)
2477	http://snomed.info/sct	1734006	http://snomed.info/sct/900000000000207008/version/20230430	Fracture of the vertebral column with spinal cord injury
2478	http://www.nlm.nih.gov/research/umls/rxnorm	749880	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.5 MG Oral Tablet) / 7 (inert ingredients 1 MG Oral Tablet) } Pack [Brevicon 28 Day]
2479	http://www.nlm.nih.gov/research/umls/rxnorm	384410	0.0.1	ethinyl estradiol / norethindrone
2480	http://www.nlm.nih.gov/research/umls/rxnorm	863603	0.0.1	erythromycin ethylsuccinate 40 MG/ML Oral Suspension [E.E.S.]
2481	http://loinc.org	4548-4		Hemoglobin A1c/Hemoglobin.total in Blood
2482	http://www.nlm.nih.gov/research/umls/rxnorm	1007105	0.0.1	astemizole / dexamethasone
2483	http://www.nlm.nih.gov/research/umls/rxnorm	2532523	0.0.1	chlorhexidine gluconate 20 MG/ML / ketoconazole 10 MG/ML [Mal-A-Ket Wipes]
2484	http://snomed.info/sct	432231006	http://snomed.info/sct/900000000000207008/version/20230430	Fine needle aspiration biopsy of lung (procedure)
2485	http://loinc.org	21906-3		Regional lymph nodes.clinical [Class] Cancer
2486	http://www.nlm.nih.gov/research/umls/rxnorm	402505	0.0.1	12 HR carbamazepine 200 MG Extended Release Oral Tablet
2487	http://www.nlm.nih.gov/research/umls/rxnorm	311034	0.0.1	insulin, regular, human 100 UNT/ML Injectable Solution
2488	http://www.nlm.nih.gov/research/umls/rxnorm	1487086	0.0.1	{21 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) } Pack [Larin 1/20]
2489	http://www.nlm.nih.gov/research/umls/rxnorm	451789	0.0.1	dexamethasone 2 MG/ML
2490	http://www.nlm.nih.gov/research/umls/rxnorm	897680	0.0.1	verapamil hydrochloride 240 MG Extended Release Oral Tablet [Calan]
2491	http://snomed.info/sct	112798008	http://snomed.info/sct/900000000000207008/version/20230430	Insertion of endotracheal tube (procedure)
2492	http://www.nlm.nih.gov/research/umls/rxnorm	200064	0.0.1	letrozole 2.5 MG Oral Tablet
2493	http://snomed.info/sct	709640007	http://snomed.info/sct/900000000000207008/version/20230430	Doppler ultrasonography of renal vein (procedure)
2494	http://www.nlm.nih.gov/research/umls/rxnorm	1009387	0.0.1	dexamethasone / neomycin / thiabendazole
2495	http://snomed.info/sct	104091002	http://snomed.info/sct/900000000000207008/version/20230430	Hemogram, automated, with RBC, WBC, Hgb, Hct, Indices, Platelet count, and manual WBC differential
2496	http://snomed.info/sct	75498004	http://snomed.info/sct/900000000000207008/version/20230430	Acute bacterial sinusitis (disorder)
2497	http://snomed.info/sct	76916001	http://snomed.info/sct/900000000000207008/version/20230430	Spina bifida occulta (disorder)
2498	http://www.nlm.nih.gov/research/umls/rxnorm	1927957	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Aurovela Fe 24 1/20 28 Day]
2499	http://www.nlm.nih.gov/research/umls/rxnorm	789980	0.0.1	Ampicillin 100 MG/ML Injectable Solution
2500	http://www.nlm.nih.gov/research/umls/rxnorm	282463	0.0.1	phenobarbital 60 MG/ML Injectable Solution
2501	http://www.nlm.nih.gov/research/umls/rxnorm	833715	0.0.1	diltiazem hydrochloride 200 MG
2558	http://www.nlm.nih.gov/research/umls/rxnorm	1431224	0.0.1	grapefruit juice
2502	http://snomed.info/sct	409089005	http://snomed.info/sct/900000000000207008/version/20230430	Febrile neutropenia (disorder)
2503	http://www.nlm.nih.gov/research/umls/rxnorm	1440937	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Larin Fe 1.5/30]
2504	http://loinc.org	6095-4		American house dust mite IgE Ab [Units/volume] in Serum
2505	http://www.nlm.nih.gov/research/umls/rxnorm	687078	0.0.1	acetaminophen / aspirin
2506	http://www.nlm.nih.gov/research/umls/rxnorm	583136	0.0.1	carbamazepine 100 MG [Equetro]
2507	http://www.nlm.nih.gov/research/umls/rxnorm	1925789	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1700 MG [Alka-Seltzer]
2508	http://www.nlm.nih.gov/research/umls/rxnorm	8183	0.0.1	phenytoin
2509	http://www.nlm.nih.gov/research/umls/rxnorm	335100	0.0.1	ketoconazole 10 MG/ML
2510	http://www.nlm.nih.gov/research/umls/rxnorm	798115	0.0.1	erythromycin 20 MG/ML Medicated Pad [Emcin Clear]
2511	http://snomed.info/sct	169673001	http://snomed.info/sct/900000000000207008/version/20230430	Antenatal RhD antibody screening
2512	http://www.nlm.nih.gov/research/umls/rxnorm	2284960	0.0.1	remdesivir 100 MG Injection
2513	http://www.nlm.nih.gov/research/umls/rxnorm	897598	0.0.1	24 HR verapamil hydrochloride 300 MG Extended Release Oral Capsule [Verelan]
2514	http://www.nlm.nih.gov/research/umls/rxnorm	1650142	0.0.1	Doxycycline Monohydrate 100 MG Oral Tablet
2515	http://loinc.org	6075-6		Cladosporium herbarum IgE Ab [Units/volume] in Serum
2516	http://www.nlm.nih.gov/research/umls/rxnorm	904477	0.0.1	pravastatin sodium 40 MG Oral Tablet [Pravachol]
2517	http://www.nlm.nih.gov/research/umls/rxnorm	314231	0.0.1	Simvastatin 10 MG Oral Tablet
2518	http://www.nlm.nih.gov/research/umls/rxnorm	206698	0.0.1	isoniazid 50 MG / pyrazinamide 300 MG / rifampin 120 MG Oral Tablet [Rifater]
2519	http://www.nlm.nih.gov/research/umls/rxnorm	2047427	0.0.1	{100 (acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet) / 24 (acetaminophen 250 MG / aspirin 250 MG / diphenhydramine citrate 38 MG Oral Tablet) } Pack
2520	http://www.nlm.nih.gov/research/umls/rxnorm	252559	0.0.1	budesonide 0.5 MG/ML Inhalation Suspension
2521	http://www.nlm.nih.gov/research/umls/rxnorm	2048017	0.0.1	atropine sulfate 0.00388 MG/ML / hyoscyamine sulfate 0.0207 MG/ML / phenobarbital 3.24 MG/ML / scopolamine hydrobromide 0.0013 MG/ML Oral Solution [Phenohytro]
2522	http://www.nlm.nih.gov/research/umls/rxnorm	2262025	0.0.1	amoxicillin / omeprazole / rifabutin
2523	http://snomed.info/sct	85116003	http://snomed.info/sct/900000000000207008/version/20230430	Miscarriage in second trimester
2524	http://snomed.info/sct	433144002	http://snomed.info/sct/900000000000207008/version/20230430	Chronic kidney disease stage 3 (disorder)
2525	http://snomed.info/sct	425048006	http://snomed.info/sct/900000000000207008/version/20230430	Non-small cell carcinoma of lung, TNM stage 2 (disorder)
2526	http://www.nlm.nih.gov/research/umls/rxnorm	2604803	0.0.1	{56 (amoxicillin 500 MG Oral Capsule) / 28 (clarithromycin 500 MG Oral Tablet) / 28 (vonoprazan 20 MG Oral Tablet) } Pack
2527	http://www.nlm.nih.gov/research/umls/rxnorm	831359	0.0.1	24 HR diltiazem hydrochloride 420 MG Extended Release Oral Capsule
2528	http://www.nlm.nih.gov/research/umls/rxnorm	333249	0.0.1	rifampin 20 MG/ML
2529	http://www.nlm.nih.gov/research/umls/rxnorm	1728805	0.0.1	2 ML morphine sulfate 1 MG/ML Injection
2530	http://www.nlm.nih.gov/research/umls/rxnorm	316478	0.0.1	phenobarbital 16 MG
2531	http://snomed.info/sct	50711007	http://snomed.info/sct/900000000000207008/version/20230430	 Viral hepatitis type C (disorder)
2532	http://snomed.info/sct	27942005	http://snomed.info/sct/900000000000207008/version/20230430	Shock (disorder)
2533	http://www.nlm.nih.gov/research/umls/rxnorm	1860480	0.0.1	1 ML DOCEtaxel 20 MG/ML Injection
2534	http://www.nlm.nih.gov/research/umls/rxnorm	25037	0.0.1	cefdinir
2535	http://snomed.info/sct	44465007	http://snomed.info/sct/900000000000207008/version/20230430	Sprain of ankle
2536	http://loinc.org	46288-7		US Guidance for biopsy of Prostate
2537	http://snomed.info/sct	65677008	http://snomed.info/sct/900000000000207008/version/20230430	Pulmonary catheterization with Swan-Ganz catheter (procedure)
2538	http://www.nlm.nih.gov/research/umls/rxnorm	830879	0.0.1	24 HR diltiazem hydrochloride 240 MG Extended Release Oral Tablet
2539	http://snomed.info/sct	713106006	http://snomed.info/sct/900000000000207008/version/20230430	Screening for drug abuse (procedure)
2540	http://www.nlm.nih.gov/research/umls/rxnorm	1011079	0.0.1	dexamethasone 0.5 MG/ML / tobramycin 3 MG/ML [Tobradex]
2541	http://www.nlm.nih.gov/research/umls/rxnorm	316488	0.0.1	phenobarbital 90 MG
2542	http://www.nlm.nih.gov/research/umls/rxnorm	1426288	0.0.1	ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet
2543	http://www.nlm.nih.gov/research/umls/rxnorm	2563431	0.0.1	aspirin 81 MG Oral Capsule [Vazalore]
2544	http://www.nlm.nih.gov/research/umls/rxnorm	1722245	0.0.1	ethinyl estradiol 0.0025 MG / norethindrone acetate 0.5 MG Oral Tablet [Jevantique]
2545	http://www.nlm.nih.gov/research/umls/rxnorm	749882	0.0.1	Norinyl 1+50 28 Day Pack
2546	http://snomed.info/sct	46177005	http://snomed.info/sct/900000000000207008/version/20230430	End-stage renal disease (disorder)
2547	http://loinc.org	75325-1		Symptom
2548	http://www.nlm.nih.gov/research/umls/rxnorm	756143	0.0.1	phenobarbital 3 MG/ML Oral Solution
2549	http://snomed.info/sct	1231000119100	http://snomed.info/sct/900000000000207008/version/20230430	History of aortic valve replacement (situation)
2550	http://snomed.info/sct	301807007	http://snomed.info/sct/900000000000207008/version/20230430	Removal of subcutaneous contraceptive
2551	http://loinc.org	71802-3		Housing status
2552	http://www.nlm.nih.gov/research/umls/rxnorm	2191	0.0.1	Ceftazidime
2553	http://www.nlm.nih.gov/research/umls/rxnorm	855872	0.0.1	phenytoin sodium 300 MG
2554	http://www.nlm.nih.gov/research/umls/rxnorm	690996	0.0.1	aluminum hydroxide / aspirin / codeine / magnesium hydroxide
2555	http://snomed.info/sct	399912005	http://snomed.info/sct/900000000000207008/version/20230430	Pressure ulcer (disorder)
2556	http://snomed.info/sct	124171000119105	http://snomed.info/sct/900000000000207008/version/20230430	Chronic intractable migraine without aura
2559	http://www.nlm.nih.gov/research/umls/rxnorm	310988	0.0.1	indinavir 400 MG Oral Capsule
2560	http://snomed.info/sct	79586000	http://snomed.info/sct/900000000000207008/version/20230430	Tubal pregnancy
2561	http://www.nlm.nih.gov/research/umls/rxnorm	856519	0.0.1	propranolol hydrochloride 40 MG Oral Tablet
2562	http://www.nlm.nih.gov/research/umls/rxnorm	1244908	0.0.1	{21 (ethinyl estradiol 0.035 MG / norethindrone 0.4 MG Chewable Tablet) / 7 (ferrous fumarate 75 MG Chewable Tablet) } Pack [Femcon Fe 28 Day]
2563	http://www.nlm.nih.gov/research/umls/rxnorm	205712	0.0.1	dexamethasone 4 MG Oral Tablet [Decadron]
2564	http://loinc.org	6082-2		Codfish IgE Ab [Units/volume] in Serum
2565	http://www.nlm.nih.gov/research/umls/rxnorm	637540	0.0.1	aspirin 325 MG / oxycodone hydrochloride 4.5 MG / oxycodone terephthalate 0.38 MG Oral Tablet
2566	http://www.nlm.nih.gov/research/umls/rxnorm	238134	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG Oral Capsule
2567	http://www.nlm.nih.gov/research/umls/rxnorm	359385	0.0.1	24 HR clarithromycin 500 MG Extended Release Oral Tablet
2568	http://www.nlm.nih.gov/research/umls/rxnorm	35208	0.0.1	quinapril
2569	http://www.nlm.nih.gov/research/umls/rxnorm	1989507	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Oral Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Hailey 24 Fe 28 Day]
2571	http://snomed.info/sct	11466000	http://snomed.info/sct/900000000000207008/version/20230430	Cesarean section
2572	http://snomed.info/sct	14152002	http://snomed.info/sct/900000000000207008/version/20230430	Intravenous infusion (procedure)
2573	http://www.nlm.nih.gov/research/umls/rxnorm	332427	0.0.1	rifapentine 150 MG
2574	http://www.nlm.nih.gov/research/umls/rxnorm	834393	0.0.1	diltiazem hydrochloride 60 MG Oral Tablet [Cardizem]
2575	http://www.nlm.nih.gov/research/umls/rxnorm	197853	0.0.1	ketoconazole 200 MG Oral Tablet
2576	http://snomed.info/sct	18286008	http://snomed.info/sct/900000000000207008/version/20230430	Catheter ablation of tissue of heart (procedure)
2577	http://snomed.info/sct	408512008	http://snomed.info/sct/900000000000207008/version/20230430	Body mass index 40+ - severely obese (finding)
2578	http://snomed.info/sct	287185009	http://snomed.info/sct/900000000000207008/version/20230430	Attempted suicide - cut/stab
2579	http://snomed.info/sct	443497002	http://snomed.info/sct/900000000000207008/version/20230430	Excision of sentinel lymph node (procedure)
2580	http://www.nlm.nih.gov/research/umls/rxnorm	831533	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Errin 28 Day]
2581	http://snomed.info/sct	129721000119106	http://snomed.info/sct/900000000000207008/version/20230430	Acute renal failure on dialysis (disorder)
2582	http://www.nlm.nih.gov/research/umls/rxnorm	1359025	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Junel Fe 1.5/30 28 Day]
2583	http://www.nlm.nih.gov/research/umls/rxnorm	312138	0.0.1	oxcarbazepine 600 MG Oral Tablet
2584	http://www.nlm.nih.gov/research/umls/rxnorm	817275	0.0.1	aspirin / brompheniramine / dextromethorphan / phenylpropanolamine
2585	http://www.nlm.nih.gov/research/umls/rxnorm	647977	0.0.1	aspirin 360 MG
2586	http://snomed.info/sct	109838007	http://snomed.info/sct/900000000000207008/version/20230430	Overlapping malignant neoplasm of colon
2587	http://www.nlm.nih.gov/research/umls/rxnorm	200346	0.0.1	Cefdinir
2588	http://www.nlm.nih.gov/research/umls/rxnorm	349094	0.0.1	budesonide 0.125 MG/ML Inhalation Suspension
2589	http://snomed.info/sct	302351005	http://snomed.info/sct/900000000000207008/version/20230430	Ligation of salivary duct (procedure)
2590	http://www.nlm.nih.gov/research/umls/rxnorm	1668262	0.0.1	erythromycin lactobionate 500 MG
2591	http://www.nlm.nih.gov/research/umls/rxnorm	1007083	0.0.1	diltiazem / hydrochlorothiazide
2592	http://www.nlm.nih.gov/research/umls/rxnorm	1736655	0.0.1	ethinyl estradiol 0.005 MG / norethindrone acetate 1 MG [Fyavolv]
2593	http://www.nlm.nih.gov/research/umls/rxnorm	152854	0.0.1	itraconazole 10 MG/ML Oral Solution [Sporanox]
2594	http://loinc.org	66529-9		Percentage area affected by eczema Trunk [PhenX]
2595	http://loinc.org	32693-4		Lactate [Moles/volume] in Blood
2596	http://loinc.org	1988-5		C reactive protein [Mass/volume] in Serum or Plasma
2597	http://www.nlm.nih.gov/research/umls/rxnorm	2626828	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Emzahh 28 Day]
2598	http://www.nlm.nih.gov/research/umls/rxnorm	198201	0.0.1	rifampin 150 MG Oral Capsule
2599	http://www.nlm.nih.gov/research/umls/rxnorm	309686	0.0.1	dexamethasone 0.1 MG/ML Oral Solution
2600	http://www.nlm.nih.gov/research/umls/rxnorm	1365849	0.0.1	oxcarbazepine 600 MG [Oxtellar]
2601	http://snomed.info/sct	261352009	http://snomed.info/sct/900000000000207008/version/20230430	Face mask (physical object)
2602	http://www.nlm.nih.gov/research/umls/rxnorm	746815	0.0.1	60 ACTUAT mometasone furoate 0.22 MG/ACTUAT Dry Powder Inhaler [Asmanex]
2603	http://www.nlm.nih.gov/research/umls/rxnorm	866303	0.0.1	12 HR carbamazepine 100 MG Extended Release Oral Tablet [Tegretol]
2604	http://www.nlm.nih.gov/research/umls/rxnorm	1547660	0.0.1	30 ACTUAT fluticasone furoate 0.1 MG/ACTUAT Dry Powder Inhaler [Arnuity]
2605	http://snomed.info/sct	26763009	http://snomed.info/sct/900000000000207008/version/20230430	Controlled ventilation procedure and therapy, initiation and management (procedure)
2606	http://snomed.info/sct	269911007	http://snomed.info/sct/900000000000207008/version/20230430	Sputum examination (procedure)
2607	http://loinc.org	33959-8		Procalcitonin [Mass/volume] in Serum or Plasma
2608	http://www.nlm.nih.gov/research/umls/rxnorm	392556	0.0.1	benzoyl peroxide / erythromycin
2609	http://www.nlm.nih.gov/research/umls/rxnorm	197604	0.0.1	Digoxin 0.125 MG Oral Tablet
2610	http://www.nlm.nih.gov/research/umls/rxnorm	250697	0.0.1	erythromycin 0.04 MG/MG Topical Gel
2611	http://www.nlm.nih.gov/research/umls/rxnorm	199168	0.0.1	phenobarbital 64.8 MG Oral Tablet
2612	http://snomed.info/sct	70536003	http://snomed.info/sct/900000000000207008/version/20230430	Transplant of kidney (procedure)
2613	http://www.nlm.nih.gov/research/umls/rxnorm	891135	0.0.1	aspirin 31200 MG
2614	http://snomed.info/sct	32413006	http://snomed.info/sct/900000000000207008/version/20230430	Transplantation of heart (procedure)
2615	http://www.nlm.nih.gov/research/umls/rxnorm	4053	0.0.1	erythromycin
2616	http://snomed.info/sct	183996000	http://snomed.info/sct/900000000000207008/version/20230430	Sterilization requested (situation)
2617	http://www.nlm.nih.gov/research/umls/rxnorm	752899	0.0.1	0.25 ML Leuprolide Acetate 30 MG/ML Prefilled Syringe
2618	http://snomed.info/sct	60234000	http://snomed.info/sct/900000000000207008/version/20230430	Aortic valve regurgitation (disorder)
2619	http://www.nlm.nih.gov/research/umls/rxnorm	1098649	0.0.1	nefazodone hydrochloride 100 MG Oral Tablet
2620	http://www.nlm.nih.gov/research/umls/rxnorm	855672	0.0.1	phenytoin sodium 100 MG [Dilantin]
2621	http://www.nlm.nih.gov/research/umls/rxnorm	1737449	0.0.1	10 ML Pamidronate Disodium 3 MG/ML Injection
2622	http://www.nlm.nih.gov/research/umls/rxnorm	1998	0.0.1	Captopril
2623	http://www.nlm.nih.gov/research/umls/rxnorm	315428	0.0.1	aspirin 650 MG
2624	http://www.nlm.nih.gov/research/umls/rxnorm	860516	0.0.1	24 HR carvedilol phosphate 20 MG Extended Release Oral Capsule
2625	http://www.nlm.nih.gov/research/umls/rxnorm	1046924	0.0.1	atropine sulfate 0.00388 MG/ML / hyoscyamine sulfate 0.0207 MG/ML / phenobarbital 3.24 MG/ML / scopolamine hydrobromide 0.0013 MG/ML Oral Solution [Donnatal]
2626	http://www.nlm.nih.gov/research/umls/rxnorm	310436	0.0.1	Galantamine 4 MG Oral Tablet
2627	http://www.nlm.nih.gov/research/umls/rxnorm	999998	0.0.1	Leronlimab 700 MG Injection
2628	http://www.nlm.nih.gov/research/umls/rxnorm	2639745	0.0.1	hydrocortisone 10 MG/ML / ketoconazole 1.5 MG/ML Otic Solution
2629	http://snomed.info/sct	698354004	http://snomed.info/sct/900000000000207008/version/20230430	Magnetic resonance imaging for measurement of brain volume (procedure)
2630	http://snomed.info/sct	11218009	http://snomed.info/sct/900000000000207008/version/20230430	Infection caused by Pseudomonas aeruginosa
2631	http://www.nlm.nih.gov/research/umls/rxnorm	317300	0.0.1	aspirin 325 MG
2632	http://snomed.info/sct	386510005	http://snomed.info/sct/900000000000207008/version/20230430	Amputation care (regime/therapy)
2633	http://www.nlm.nih.gov/research/umls/rxnorm	1092217	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Medicated Pad
2634	http://snomed.info/sct	398171003	http://snomed.info/sct/900000000000207008/version/20230430	Hearing examination (procedure)
2635	http://www.nlm.nih.gov/research/umls/rxnorm	830794	0.0.1	diltiazem hydrochloride 360 MG
2636	http://www.nlm.nih.gov/research/umls/rxnorm	572203	0.0.1	aspirin 325 MG [Bayer Aspirin]
2637	http://www.nlm.nih.gov/research/umls/rxnorm	2265538	0.0.1	dexamethasone phosphate 1 MG/ML
2638	http://www.nlm.nih.gov/research/umls/rxnorm	897676	0.0.1	verapamil hydrochloride 180 MG Extended Release Oral Tablet [Calan]
2639	http://snomed.info/sct	171231001	http://snomed.info/sct/900000000000207008/version/20230430	Asthma screening
2640	http://snomed.info/sct	271442007	http://snomed.info/sct/900000000000207008/version/20230430	Fetal anatomy study
2641	http://www.nlm.nih.gov/research/umls/rxnorm	198039	0.0.1	nitroglycerin 0.4 MG Sublingual Tablet
2642	http://snomed.info/sct	714812005	http://snomed.info/sct/900000000000207008/version/20230430	Induced termination of pregnancy
2643	http://www.nlm.nih.gov/research/umls/rxnorm	103942	0.0.1	carbamazepine 250 MG Rectal Suppository
2644	http://www.nlm.nih.gov/research/umls/rxnorm	309679	0.0.1	dexamethasone 0.001 MG/MG / neomycin 0.0035 MG/MG / polymyxin B 10 UNT/MG Ophthalmic Ointment
2645	http://www.nlm.nih.gov/research/umls/rxnorm	978950	0.0.1	Natazia 28 Day Pack
2646	http://www.nlm.nih.gov/research/umls/rxnorm	1008930	0.0.1	dexamethasone / phenylephrine
2647	http://snomed.info/sct	132281000119108	http://snomed.info/sct/900000000000207008/version/20230430	Acute deep venous thrombosis (disorder)
2648	http://snomed.info/sct	424393004	http://snomed.info/sct/900000000000207008/version/20230430	Reports of violence in the environment (finding)
2649	http://www.nlm.nih.gov/research/umls/rxnorm	329730	0.0.1	erythromycin 20 MG/ML
2650	http://snomed.info/sct	288959006	http://snomed.info/sct/900000000000207008/version/20230430	Unable to swallow saliva (finding)
2651	http://www.nlm.nih.gov/research/umls/rxnorm	315693	0.0.1	clarithromycin 25 MG/ML
2652	http://www.nlm.nih.gov/research/umls/rxnorm	856481	0.0.1	24 HR propranolol hydrochloride 160 MG Extended Release Oral Capsule
2653	http://www.nlm.nih.gov/research/umls/rxnorm	1359128	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Activella 1/0.5 28 Day]
2654	http://www.nlm.nih.gov/research/umls/rxnorm	308136	0.0.1	amLODIPine 2.5 MG Oral Tablet
2655	http://www.nlm.nih.gov/research/umls/rxnorm	1537189	0.0.1	chlorhexidine gluconate 10 MG/ML / ketoconazole 2.5 MG/ML Medicated Shampoo
2656	http://www.nlm.nih.gov/research/umls/rxnorm	1313883	0.0.1	phenytoin 25 MG/ML [Dilantin]
2657	http://snomed.info/sct	370247008	http://snomed.info/sct/900000000000207008/version/20230430	Facial laceration
2658	http://www.nlm.nih.gov/research/umls/rxnorm	1091265	0.0.1	phenobarbital 10 MG/ML Injectable Solution
2659	http://www.nlm.nih.gov/research/umls/rxnorm	315566	0.0.1	carbamazepine 300 MG
2660	http://snomed.info/sct	233604007	http://snomed.info/sct/900000000000207008/version/20230430	Pneumonia (disorder)
2661	http://www.nlm.nih.gov/research/umls/rxnorm	214542	0.0.1	ephedrine / phenobarbital / theophylline
2662	http://www.nlm.nih.gov/research/umls/rxnorm	905269	0.0.1	Trihexyphenidyl Hydrochloride 2 MG Oral Tablet
2663	http://snomed.info/sct	415300000	http://snomed.info/sct/900000000000207008/version/20230430	Review of systems (procedure)
2664	http://www.nlm.nih.gov/research/umls/rxnorm	336010	0.0.1	aspirin 385 MG
2665	http://www.nlm.nih.gov/research/umls/rxnorm	571752	0.0.1	aspirin 325 MG / butalbital 50 MG / caffeine 40 MG [Fiorinal]
2666	http://snomed.info/sct	735971005	http://snomed.info/sct/900000000000207008/version/20230430	Fish (substance)
2667	http://snomed.info/sct	284551006	http://snomed.info/sct/900000000000207008/version/20230430	Laceration of foot
2668	http://snomed.info/sct	10939881000119105	http://snomed.info/sct/900000000000207008/version/20230430	Unhealthy alcohol drinking behavior (finding)
2669	http://www.nlm.nih.gov/research/umls/rxnorm	212446	0.0.1	Azithromycin 250mg
2670	http://www.nlm.nih.gov/research/umls/rxnorm	1928007	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) } Pack [Aurovela 1.5/30 21 Day]
2671	http://snomed.info/sct	183418007	http://snomed.info/sct/900000000000207008/version/20230430	Social case work (regime/therapy)
2672	http://www.nlm.nih.gov/research/umls/rxnorm	853500	0.0.1	aspirin 228 MG [Aspergum]
2673	http://www.nlm.nih.gov/research/umls/rxnorm	1371360	0.0.1	ketoconazole / lactate / salicylic acid
2674	http://snomed.info/sct	232353008	http://snomed.info/sct/900000000000207008/version/20230430	Perennial allergic rhinitis with seasonal variation
2675	http://www.nlm.nih.gov/research/umls/rxnorm	746804	0.0.1	120 ACTUAT mometasone furoate 0.22 MG/ACTUAT Dry Powder Inhaler [Asmanex]
2676	http://snomed.info/sct	104435004	http://snomed.info/sct/900000000000207008/version/20230430	Screening for occult blood in feces (procedure)
2677	http://snomed.info/sct	5758002	http://snomed.info/sct/900000000000207008/version/20230430	Bacteremia (finding)
2678	http://snomed.info/sct	370143000	http://snomed.info/sct/900000000000207008/version/20230430	Major depressive disorder (disorder)
2679	http://www.nlm.nih.gov/research/umls/rxnorm	317629	0.0.1	dexamethasone 1 MG/ML
2680	http://www.nlm.nih.gov/research/umls/rxnorm	745791	0.0.1	200 ACTUAT levalbuterol 0.045 MG/ACTUAT Metered Dose Inhaler
2681	http://www.nlm.nih.gov/research/umls/rxnorm	847089	0.0.1	aspirin 81 MG [Miniprin]
2682	http://snomed.info/sct	770349000	http://snomed.info/sct/900000000000207008/version/20230430	Sepsis caused by virus (disorder)
2683	http://www.nlm.nih.gov/research/umls/rxnorm	1037184	0.0.1	{24 (ethinyl estradiol 0.01 MG / norethindrone acetate 1 MG Oral Tablet) / 2 (ethinyl estradiol 0.01 MG Oral Tablet) / 2 (ferrous fumarate 75 MG Oral Tablet) } Pack
2684	http://snomed.info/sct	234262008	http://snomed.info/sct/900000000000207008/version/20230430	Excision of axillary lymph node (procedure)
2685	http://www.nlm.nih.gov/research/umls/rxnorm	1052414	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Pamprin Max Formula]
2686	http://www.nlm.nih.gov/research/umls/rxnorm	545186	0.0.1	itraconazole 10 MG/ML [Sporanox]
2687	http://www.nlm.nih.gov/research/umls/rxnorm	1052416	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG Oral Tablet [Pamprin Max Formula]
2688	http://www.nlm.nih.gov/research/umls/rxnorm	827075	0.0.1	nebivolol 20 MG Oral Tablet [Bystolic]
2689	http://www.nlm.nih.gov/research/umls/rxnorm	890955	0.0.1	erythromycin 0.0053 MG/ML [Maracyn]
2690	http://www.nlm.nih.gov/research/umls/rxnorm	686924	0.0.1	carvedilol 3.125 MG Oral Tablet
2691	http://www.nlm.nih.gov/research/umls/rxnorm	357977	0.0.1	sunitinib
2692	http://www.nlm.nih.gov/research/umls/rxnorm	316314	0.0.1	modafinil 200 MG
2693	http://www.nlm.nih.gov/research/umls/rxnorm	197887	0.0.1	hydrochlorothiazide 25 MG / lisinopril 20 MG Oral Tablet
2694	http://www.nlm.nih.gov/research/umls/rxnorm	1092678	0.0.1	chloroxylenol 3 MG/ML / ketoconazole 3 MG/ML Topical Solution [Pharmaseb]
2695	http://www.nlm.nih.gov/research/umls/rxnorm	858804	0.0.1	enalapril maleate 2.5 MG Oral Tablet
2696	http://www.nlm.nih.gov/research/umls/rxnorm	1300272	0.0.1	ketoconazole 20 MG/ML Topical Foam [Ketodan]
2697	http://www.nlm.nih.gov/research/umls/rxnorm	206702	0.0.1	isoniazid 150 MG / rifampin 300 MG Oral Capsule [Rifamate]
2698	http://snomed.info/sct	25675004	http://snomed.info/sct/900000000000207008/version/20230430	Patient transfer to skilled nursing facility (procedure)
2699	http://www.nlm.nih.gov/research/umls/rxnorm	1747691	0.0.1	emtricitabine 200 MG / tenofovir alafenamide 25 MG Oral Table
2700	http://www.nlm.nih.gov/research/umls/rxnorm	1037183	0.0.1	ethinyl estradiol 0.01 MG / norethindrone acetate 1 MG Oral Tablet
2701	http://www.nlm.nih.gov/research/umls/rxnorm	566561	0.0.1	dexamethasone 1 MG/ML [Maxidex]
2702	http://www.nlm.nih.gov/research/umls/rxnorm	135095	0.0.1	aspirin / codeine
2703	http://www.nlm.nih.gov/research/umls/rxnorm	1550965	0.0.1	{28 (estradiol 1 MG / norethindrone acetate 0.5 MG Oral Tablet) } Pack [Lopreeza 1/0.5 28 Day]
2704	http://www.nlm.nih.gov/research/umls/rxnorm	966222	0.0.1	Levothyroxine Sodium 0.075 MG Oral Tablet
2705	http://www.nlm.nih.gov/research/umls/rxnorm	2668107	0.0.1	aspirin 81 MG Oral Powder
2706	http://www.nlm.nih.gov/research/umls/rxnorm	813961	0.0.1	ascorbic acid / aspirin
2707	http://www.nlm.nih.gov/research/umls/rxnorm	685588	0.0.1	aspirin 1.5 MG/ML
2708	http://www.nlm.nih.gov/research/umls/rxnorm	308974	0.0.1	carbamazepine 100 MG Chewable Tablet [Tegretol]
2709	http://www.nlm.nih.gov/research/umls/rxnorm	197884	0.0.1	lisinopril 40 MG Oral Tablet
2710	http://loinc.org	33728-7		Size.maximum dimension in Tumor
2711	http://www.nlm.nih.gov/research/umls/rxnorm	896023	0.0.1	60 ACTUAT fluticasone propionate 0.1 MG/ACTUAT Dry Powder Inhaler [Flovent]
2712	http://www.nlm.nih.gov/research/umls/rxnorm	2604934	0.0.1	chlorhexidine gluconate 2 MG/ML / ketoconazole 2 MG/ML Medicated Pad
2713	http://www.nlm.nih.gov/research/umls/rxnorm	335990	0.0.1	aspirin 742 MG
2714	http://snomed.info/sct	29303009	http://snomed.info/sct/900000000000207008/version/20230430	Electrocardiographic procedure
2715	http://www.nlm.nih.gov/research/umls/rxnorm	685589	0.0.1	aspirin 1.5 MG/ML Oral Solution
2716	http://www.nlm.nih.gov/research/umls/rxnorm	198384	0.0.1	isoniazid 50 MG / pyrazinamide 300 MG / rifampin 120 MG Oral Tablet
2717	http://loinc.org	26515-7		Platelets [#/volume] in Blood
2718	http://www.nlm.nih.gov/research/umls/rxnorm	608844	0.0.1	ketoconazole 10 MG/ML Medicated Shampoo [Nizoral]
2719	http://www.nlm.nih.gov/research/umls/rxnorm	246297	0.0.1	rifampin 20 MG/ML Oral Suspension
2720	http://snomed.info/sct	76571007	http://snomed.info/sct/900000000000207008/version/20230430	Septic shock (disorder)
2721	http://snomed.info/sct	287193009	http://snomed.info/sct/900000000000207008/version/20230430	Suicide - firearms
2722	http://www.nlm.nih.gov/research/umls/rxnorm	814664	0.0.1	aspirin / phenylephrine
2723	http://www.nlm.nih.gov/research/umls/rxnorm	749196	0.0.1	clopidogrel 300 MG Oral Tablet
2724	http://www.nlm.nih.gov/research/umls/rxnorm	831318	0.0.1	diltiazem hydrochloride 300 MG [Diltzac]
2725	http://www.nlm.nih.gov/research/umls/rxnorm	859747	0.0.1	rosuvastatin calcium 10 MG Oral Tablet
2726	http://snomed.info/sct	84114007	http://snomed.info/sct/900000000000207008/version/20230430	Heart failure (disorder)
2727	http://www.nlm.nih.gov/research/umls/rxnorm	359221	0.0.1	acetaminophen 110 MG / aspirin 162 MG / caffeine 32.4 MG / salicylamide 152 MG Oral Tablet
2728	http://www.nlm.nih.gov/research/umls/rxnorm	205866	0.0.1	clarithromycin 500 MG Oral Tablet [Biaxin]
2729	http://www.nlm.nih.gov/research/umls/rxnorm	1007407	0.0.1	ascorbic acid / aspirin / cysteine
2730	http://snomed.info/sct	63332003	http://snomed.info/sct/900000000000207008/version/20230430	History AND physical examination (procedure)
2731	http://www.nlm.nih.gov/research/umls/rxnorm	897693	0.0.1	verapamil hydrochloride 120 MG Extended Release Oral Tablet [Isoptin]
2732	http://snomed.info/sct	442571000124108	http://snomed.info/sct/900000000000207008/version/20230430	Tree nut (substance)
2733	http://www.nlm.nih.gov/research/umls/rxnorm	794229	0.0.1	aspirin 81 MG Delayed Release Oral Tablet [Bayer Aspirin]
2734	http://www.nlm.nih.gov/research/umls/rxnorm	898687	0.0.1	benazepril hydrochloride 10 MG Oral Tablet
2735	http://www.nlm.nih.gov/research/umls/rxnorm	197886	0.0.1	hydrochlorothiazide 12.5 MG / lisinopril 20 MG Oral Tablet
2736	http://snomed.info/sct	698560000	http://snomed.info/sct/900000000000207008/version/20230430	Referral to sleep apnea clinic (procedure)
2737	http://snomed.info/sct	698247007	http://snomed.info/sct/900000000000207008/version/20230430	Cardiac arrhythmia (disorder)
2738	http://snomed.info/sct	33367005	http://snomed.info/sct/900000000000207008/version/20230430	Angiography of coronary artery (procedure)
2739	http://snomed.info/sct	371073003	http://snomed.info/sct/900000000000207008/version/20230430	Postural orthostatic tachycardia syndrome (disorder)
2740	http://www.nlm.nih.gov/research/umls/rxnorm	863184	0.0.1	aspirin 360 MG / caffeine 75 MG / magnesium carbonate 100 MG / magnesium salicylate 60 MG Oral Tablet
2741	http://www.nlm.nih.gov/research/umls/rxnorm	200285	0.0.1	hydrochlorothiazide 12.5 MG / valsartan 160 MG Oral Tablet
2742	http://www.nlm.nih.gov/research/umls/rxnorm	308278	0.0.1	acetaminophen 115 MG / aspirin 210 MG / caffeine 16 MG / salicylamide 65 MG Oral Tablet
2743	http://www.nlm.nih.gov/research/umls/rxnorm	198467	0.0.1	aspirin 325 MG Delayed Release Oral Tablet
2744	http://www.nlm.nih.gov/research/umls/rxnorm	897854	0.0.1	trandolapril 4 MG / verapamil hydrochloride 240 MG [Tarka]
2745	http://snomed.info/sct	308283009	http://snomed.info/sct/900000000000207008/version/20230430	Discharge from hospital (procedure)
2746	http://snomed.info/sct	104173009	http://snomed.info/sct/900000000000207008/version/20230430	Sputum Culture
2747	http://snomed.info/sct	113076002	http://snomed.info/sct/900000000000207008/version/20230430	Oral Glucose Tolerance Test
2748	http://www.nlm.nih.gov/research/umls/rxnorm	1537019	0.0.1	aspirin 500 MG / caffeine 60 MG Effervescent Oral Tablet
2749	http://www.nlm.nih.gov/research/umls/rxnorm	349251	0.0.1	tenofovir disoproxil fumarate 300 MG Oral Tablet
2750	http://www.nlm.nih.gov/research/umls/rxnorm	1998774	0.0.1	Breath-Actuated 120 ACTUAT beclomethasone dipropionate 0.04 MG/ACTUAT Metered Dose Inhaler [Qvar]
2751	http://www.nlm.nih.gov/research/umls/rxnorm	315694	0.0.1	clarithromycin 250 MG
2752	http://www.nlm.nih.gov/research/umls/rxnorm	855673	0.0.1	phenytoin sodium 100 MG Extended Release Oral Capsule [Dilantin]
2753	http://snomed.info/sct	111088007	http://snomed.info/sct/900000000000207008/version/20230430	Latex (substance)
2754	http://www.nlm.nih.gov/research/umls/rxnorm	1986791	0.0.1	{21 (ethinyl estradiol 0.03 MG / norethindrone acetate 1.5 MG Oral Tablet) / 7 (ferrous fumarate 75 MG Oral Tablet) } Pack [Aurovela Fe 1.5/30 28 Day]
2755	http://www.nlm.nih.gov/research/umls/rxnorm	903890	0.0.1	fluvoxamine maleate 50 MG
2756	http://www.nlm.nih.gov/research/umls/rxnorm	890953	0.0.1	erythromycin 0.0053 MG/ML Topical Solution
2757	http://www.nlm.nih.gov/research/umls/rxnorm	2563424	0.0.1	aspirin 325 MG [Vazalore]
2758	http://snomed.info/sct	36923009	http://snomed.info/sct/900000000000207008/version/20230430	Major depression, single episode
2759	http://www.nlm.nih.gov/research/umls/rxnorm	316313	0.0.1	modafinil 100 MG
2760	http://www.nlm.nih.gov/research/umls/rxnorm	864706	0.0.1	methadone hydrochloride 10 MG Oral Tablet
2761	http://www.nlm.nih.gov/research/umls/rxnorm	198479	0.0.1	aspirin 400 MG / caffeine 32 MG Oral Tablet
2762	http://www.nlm.nih.gov/research/umls/rxnorm	1008814	0.0.1	dehydrocholate / homatropine / phenobarbital
2763	http://www.nlm.nih.gov/research/umls/rxnorm	262090	0.0.1	oxcarbazepine 600 MG Oral Tablet [Trileptal]
2764	http://snomed.info/sct	409023009	http://snomed.info/sct/900000000000207008/version/20230430	Professional / ancillary services care (regime/therapy)
2765	http://www.nlm.nih.gov/research/umls/rxnorm	691072	0.0.1	dyphylline / ephedrine / guaifenesin / phenobarbital
2766	http://snomed.info/sct	73438004	http://snomed.info/sct/900000000000207008/version/20230430	Unemployed (finding)
2767	http://www.nlm.nih.gov/research/umls/rxnorm	1098673	0.0.1	nefazodone hydrochloride 250 MG
2768	http://www.nlm.nih.gov/research/umls/rxnorm	564507	0.0.1	ketoconazole 20 MG/ML [Nizoral]
2769	http://loinc.org	14959-1		Microalbumin/Creatinine [Mass Ratio] in Urine
2770	http://www.nlm.nih.gov/research/umls/rxnorm	617320	0.0.1	atorvastatin 40 MG Oral Tablet [Lipitor]
2771	http://www.nlm.nih.gov/research/umls/rxnorm	1925790	0.0.1	aspirin 325 MG / citric acid 1000 MG / sodium bicarbonate 1700 MG Effervescent Oral Tablet [Alka-Seltzer]
2772	http://www.nlm.nih.gov/research/umls/rxnorm	206078	0.0.1	erythromycin 333 MG Delayed Release Oral Tablet [Ery-Tab]
2773	http://snomed.info/sct	1501000119109	http://snomed.info/sct/900000000000207008/version/20230430	Proliferative diabetic retinopathy due to type II diabetes mellitus (disorder)
2774	http://www.nlm.nih.gov/research/umls/rxnorm	691444	0.0.1	niacin / niacinamide / phenobarbital
2775	http://snomed.info/sct	392091000	http://snomed.info/sct/900000000000207008/version/20230430	Care regimes assessment (procedure)
2776	http://www.nlm.nih.gov/research/umls/rxnorm	855945	0.0.1	phenytoin sodium 300 MG Oral Capsule
2777	http://www.nlm.nih.gov/research/umls/rxnorm	541947	0.0.1	clarithromycin 250 MG [Biaxin]
2778	http://www.nlm.nih.gov/research/umls/rxnorm	332984	0.0.1	dexamethasone 0.4 MG
2779	http://www.nlm.nih.gov/research/umls/rxnorm	979471	0.0.1	hydrochlorothiazide 25 MG / losartan potassium 100 MG Oral Tablet
2780	http://www.nlm.nih.gov/research/umls/rxnorm	1116758	0.0.1	chloroquine phosphate 500 MG Oral Tablet
2781	http://www.nlm.nih.gov/research/umls/rxnorm	2608695	0.0.1	{24 (ethinyl estradiol 0.02 MG / norethindrone acetate 1 MG Chewable Tablet) / 4 (ferrous fumarate 75 MG Oral Tablet) } Pack [Finzala 24 Fe Chewable 28 Day]
2782	http://www.nlm.nih.gov/research/umls/rxnorm	901438	0.0.1	verapamil hydrochloride 160 MG Oral Tablet
2783	http://www.nlm.nih.gov/research/umls/rxnorm	209823	0.0.1	aspirin 325 MG / meprobamate 200 MG Oral Tablet [Equagesic]
2784	http://www.nlm.nih.gov/research/umls/rxnorm	312961	0.0.1	Simvastatin 20 MG Oral Tablet
2785	http://www.nlm.nih.gov/research/umls/rxnorm	205324	0.0.1	modafinil 200 MG Oral Tablet
2786	http://snomed.info/sct	271825005	http://snomed.info/sct/900000000000207008/version/20230430	Respiratory distress (finding)
2787	http://www.nlm.nih.gov/research/umls/rxnorm	2189	0.0.1	Cefoxitin
2788	http://www.nlm.nih.gov/research/umls/rxnorm	11170	0.0.1	verapamil
2789	http://www.nlm.nih.gov/research/umls/rxnorm	200345	0.0.1	simvastatin 80 MG Oral Tablet
2790	http://www.nlm.nih.gov/research/umls/rxnorm	308589	0.0.1	belladonna alkaloids 0.13 MG / phenobarbital 16.2 MG Oral Tablet
2791	http://www.nlm.nih.gov/research/umls/rxnorm	570079	0.0.1	acetaminophen 250 MG / aspirin 250 MG / caffeine 65 MG [Excedrin]
2792	http://www.nlm.nih.gov/research/umls/rxnorm	748977	0.0.1	{28 (norethindrone 0.35 MG Oral Tablet) } Pack [Nora-BE 28 Day]
2793	http://www.nlm.nih.gov/research/umls/rxnorm	855873	0.0.1	phenytoin sodium 300 MG Extended Release Oral Capsule
2794	http://www.nlm.nih.gov/research/umls/rxnorm	1300269	0.0.1	ketoconazole 20 MG/ML [Ketodan]
2795	http://snomed.info/sct	306237005	http://snomed.info/sct/900000000000207008/version/20230430	Referral to palliative care service (procedure)
2796	http://snomed.info/sct	254637007	http://snomed.info/sct/900000000000207008/version/20230430	Non-small cell lung cancer (disorder)
2797	http://www.nlm.nih.gov/research/umls/rxnorm	689541	0.0.1	aspirin / propoxyphene
2798	http://www.nlm.nih.gov/research/umls/rxnorm	106307	0.0.1	erythromycin 40 MG/ML / zinc acetate 12 MG/ML Topical Solution
2799	http://www.nlm.nih.gov/research/umls/rxnorm	904481	0.0.1	pravastatin sodium 80 MG Oral Tablet
2800	http://snomed.info/sct	423475008	http://snomed.info/sct/900000000000207008/version/20230430	Heart failure education (procedure)
2801	http://snomed.info/sct	52734007	http://snomed.info/sct/900000000000207008/version/20230430	Total replacement of hip
2802	http://www.nlm.nih.gov/research/umls/rxnorm	848524	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Diltzac]
2803	http://loinc.org	49497-1		Platelets [#/volume] in Blood by Estimate
2804	http://www.nlm.nih.gov/research/umls/rxnorm	1648131	0.0.1	chlorhexidine / hydrocortisone / ketoconazole
2805	http://www.nlm.nih.gov/research/umls/rxnorm	1988323	0.0.1	diltiazem hydrochloride 360 MG [Tiadylt]
2806	http://www.nlm.nih.gov/research/umls/rxnorm	845488	0.0.1	ramipril 1.25 MG Oral Capsule
2807	http://snomed.info/sct	91302008	http://snomed.info/sct/900000000000207008/version/20230430	Sepsis (disorder)
2808	http://www.nlm.nih.gov/research/umls/rxnorm	25033	0.0.1	Cefixime
2809	http://www.nlm.nih.gov/research/umls/rxnorm	904668	0.0.1	{30 (aspirin 81 MG Oral Tablet) / 30 (pravastatin sodium 40 MG Oral Tablet) } Pack
2810	http://snomed.info/sct	56786000	http://snomed.info/sct/900000000000207008/version/20230430	Pulmonic valve stenosis (disorder)
2811	http://www.nlm.nih.gov/research/umls/rxnorm	1536834	0.0.1	aspirin 500 MG / citric acid 1000 MG / sodium bicarbonate 1985 MG [Alka-Seltzer]
2812	http://www.nlm.nih.gov/research/umls/rxnorm	2286261	0.0.1	dexamethasone 20 MG Oral Tablet [Hemady]
2813	http://www.nlm.nih.gov/research/umls/rxnorm	316479	0.0.1	phenobarbital 16.2 MG
2814	http://www.nlm.nih.gov/research/umls/rxnorm	816174	0.0.1	aspirin / chlorpheniramine / phenylpropanolamine
2815	http://www.nlm.nih.gov/research/umls/rxnorm	885219	0.0.1	Benztropine mesylate 0.5 MG Oral Tablet
2816	http://www.nlm.nih.gov/research/umls/rxnorm	197541	0.0.1	Colchicine 0.6 MG Oral Tablet
2817	http://www.nlm.nih.gov/research/umls/rxnorm	1049221	0.0.1	Acetaminophen 325 MG / Oxycodone Hydrochloride 5 MG Oral Tablet
2818	http://www.nlm.nih.gov/research/umls/rxnorm	1365653	0.0.1	24 HR oxcarbazepine 150 MG Extended Release Oral Tablet
2819	http://www.nlm.nih.gov/research/umls/rxnorm	308409	0.0.1	aspirin 500 MG Delayed Release Oral Tablet
2820	http://www.nlm.nih.gov/research/umls/rxnorm	597193	0.0.1	erythromycin 50 MG/ML Oral Suspension
2821	http://www.nlm.nih.gov/research/umls/rxnorm	1007472	0.0.1	aspirin / chlormezanone
2822	http://www.nlm.nih.gov/research/umls/rxnorm	1014678	0.0.1	cetirizine hydrochloride 10 MG Oral Tablet
2823	http://www.nlm.nih.gov/research/umls/rxnorm	198188	0.0.1	ramipril 2.5 MG Oral Capsule
2824	http://www.nlm.nih.gov/research/umls/rxnorm	1734919	0.0.1	Cyclophosphamide 1000 MG Injection
2825	http://www.nlm.nih.gov/research/umls/rxnorm	854252	0.0.1	1 ML Enoxaparin sodium 150 MG/ML Prefilled Syringe
2826	http://www.nlm.nih.gov/research/umls/rxnorm	2588854	0.0.1	levoketoconazole 150 MG Oral Tablet [Recorlev]
2827	http://www.nlm.nih.gov/research/umls/rxnorm	328569	0.0.1	phenobarbital 65 MG/ML
2828	http://www.nlm.nih.gov/research/umls/rxnorm	831226	0.0.1	24 HR diltiazem hydrochloride 120 MG Extended Release Oral Capsule [Cartia]
\.


--
-- Data for Name: ui_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_profile (id, name, ui_profile) FROM stdin;
1	SD_Synthea_AllergyIntolerance	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_AllergyIntolerance",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
2	Diagnose	{\n    "attributeDefinitions": [],\n    "name": "Diagnose",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
3	SD_Synthea_Observation_10480-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_10480-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260385009",\n                "display": "Negative (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "10828004",\n                "display": "Positive (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
4	SD_Synthea_Observation_14804-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_14804-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "U/L",\n                "display": "U/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
5	SD_Synthea_Observation_14959-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_14959-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mg/g",\n                "display": "mg/g",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
6	SD_Synthea_Observation_17856-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_17856-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
7	SD_Synthea_Observation_18752-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_18752-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "439590007",\n                "display": "Cardiovascular stress test abnormal (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
8	SD_Synthea_Observation_19123-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_19123-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mg/dL",\n                "display": "mg/dL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
9	SD_Synthea_Observation_1988-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_1988-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mg/L",\n                "display": "mg/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
10	SD_Synthea_Observation_19926-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_19926-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
11	SD_Synthea_Observation_19994-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_19994-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
12	SD_Synthea_Observation_20447-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_20447-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{copies}/mL",\n                "display": "{copies}/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
13	SD_Synthea_Observation_21377-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21377-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mg/dL",\n                "display": "mg/dL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
14	SD_Synthea_Observation_2157-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2157-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "U/L",\n                "display": "U/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
15	SD_Synthea_Observation_21905-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21905-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "58790005",\n                "display": "T0 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "23351008",\n                "display": "T1 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "67673008",\n                "display": "T2 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "14410001",\n                "display": "T3 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "65565005",\n                "display": "T4 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
16	SD_Synthea_Observation_21906-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21906-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "62455006",\n                "display": "N0 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "53623008",\n                "display": "N1 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "46059003",\n                "display": "N2 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "5856006",\n                "display": "N3 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
17	SD_Synthea_Observation_21907-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21907-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "30893008",\n                "display": "M0 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "55440008",\n                "display": "M1 category (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
18	SD_Synthea_Observation_21908-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21908-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "258215001",\n                "display": "Stage 1 (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261634002",\n                "display": "Stage 1A (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261635001",\n                "display": "Stage 1B (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "258219007",\n                "display": "Stage 2 (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261614003",\n                "display": "Stage 2A (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261615002",\n                "display": "Stage 2B (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "258224005",\n                "display": "Stage 3 (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261638004",\n                "display": "Stage 3A (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261639007",\n                "display": "Stage 3B (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "261640009",\n                "display": "Stage 3C (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "258228008",\n                "display": "Stage 4 (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
19	SD_Synthea_Observation_21924-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_21924-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260385009",\n                "display": "Negative (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
20	SD_Synthea_Observation_22577-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_22577-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "428915008",\n                "display": "Toxoplasma gondii antibody positive (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
21	SD_Synthea_Observation_24467-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_24467-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "/uL",\n                "display": "/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
22	SD_Synthea_Observation_2532-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2532-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "U/L",\n                "display": "U/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
23	SD_Synthea_Observation_26499-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_26499-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "10*3/uL",\n                "display": "10*3/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
24	SD_Synthea_Observation_26515-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_26515-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "K/uL",\n                "display": "K/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
25	SD_Synthea_Observation_2708-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2708-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
26	SD_Synthea_Observation_2713-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2713-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
27	SD_Synthea_Observation_2777-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2777-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mg/dL",\n                "display": "mg/dL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
28	SD_Synthea_Observation_28245-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_28245-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
29	SD_Synthea_Observation_2857-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_2857-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ng/mL",\n                "display": "ng/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
30	SD_Synthea_Observation_29463-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_29463-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kg",\n                "display": "kg",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
31	SD_Synthea_Observation_29554-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_29554-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{#}",\n                "display": "{#}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
32	SD_Synthea_Observation_3016-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_3016-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "m[IU]/L",\n                "display": "m[IU]/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
33	SD_Synthea_Observation_3024-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_3024-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ng/dl",\n                "display": "ng/dl",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
34	SD_Synthea_Observation_3173-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_3173-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "s",\n                "display": "s",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
35	SD_Synthea_Observation_3184-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_3184-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "s",\n                "display": "s",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
36	SD_Synthea_Observation_32465-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_32465-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
37	SD_Synthea_Observation_32693-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_32693-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mmol/L",\n                "display": "mmol/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
38	SD_Synthea_Observation_33728-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_33728-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "cm",\n                "display": "cm",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
39	SD_Synthea_Observation_33756-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_33756-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mm",\n                "display": "mm",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
40	SD_Synthea_Observation_33762-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_33762-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "pg/mL",\n                "display": "pg/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
41	SD_Synthea_Observation_33914-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_33914-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mL/min/{1.73_m2}",\n                "display": "mL/min/{1.73_m2}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
42	SD_Synthea_Observation_33959-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_33959-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ng/mL",\n                "display": "ng/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
43	SD_Synthea_Observation_38208-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_38208-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{score}",\n                "display": "{score}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
44	SD_Synthea_Observation_38265-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_38265-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{T-score}",\n                "display": "{T-score}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
45	SD_Synthea_Observation_39156-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_39156-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kg/m2",\n                "display": "kg/m2",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
46	SD_Synthea_Observation_44667-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_44667-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260413007",\n                "display": "None (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
47	SD_Synthea_Observation_44963-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_44963-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "50427001",\n                "display": "Increased capillary filling time (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
48	SD_Synthea_Observation_4548-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_4548-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
49	SD_Synthea_Observation_4549-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_4549-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
50	SD_Synthea_Observation_46240-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_46240-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{count}",\n                "display": "{count}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
51	SD_Synthea_Observation_46288-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_46288-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
52	SD_Synthea_Observation_48065-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_48065-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ug/mL",\n                "display": "ug/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
53	SD_Synthea_Observation_49497-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_49497-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "K/uL",\n                "display": "K/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
54	SD_Synthea_Observation_55277-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_55277-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
55	SD_Synthea_Observation_57905-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_57905-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ng/mL",\n                "display": "ng/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
56	SD_Synthea_Observation_59408-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_59408-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
57	SD_Synthea_Observation_59557-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_59557-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "445528004",\n                "display": "Treatment changed (situation)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
58	SD_Synthea_Observation_59576-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_59576-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
59	SD_Synthea_Observation_6075-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6075-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
60	SD_Synthea_Observation_6082-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6082-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
61	SD_Synthea_Observation_6085-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6085-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
62	SD_Synthea_Observation_6095-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6095-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
63	SD_Synthea_Observation_6106-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6106-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
64	SD_Synthea_Observation_6158-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6158-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
65	SD_Synthea_Observation_6189-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6189-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
66	SD_Synthea_Observation_6206-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6206-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
67	SD_Synthea_Observation_6246-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6246-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
68	SD_Synthea_Observation_6248-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6248-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
69	SD_Synthea_Observation_6273-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6273-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
70	SD_Synthea_Observation_6276-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6276-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
71	SD_Synthea_Observation_6301-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6301-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{INR}",\n                "display": "{INR}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
72	SD_Synthea_Observation_63513-6_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_63513-6_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
73	SD_Synthea_Observation_65750-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_65750-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "n/a",\n                "display": "n/a",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
74	SD_Synthea_Observation_66519-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_66519-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
75	SD_Synthea_Observation_66524-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_66524-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
76	SD_Synthea_Observation_66529-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_66529-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
77	SD_Synthea_Observation_66534-9_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_66534-9_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
78	SD_Synthea_Observation_6833-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6833-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
79	SD_Synthea_Observation_6844-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_6844-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
80	SD_Synthea_Observation_70006-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_70006-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "702566000",\n                "display": "Suspected non-compliance of drug therapy (situation)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
81	SD_Synthea_Observation_71425-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_71425-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "pg/mL",\n                "display": "pg/mL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
82	SD_Synthea_Observation_718-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_718-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "g/dL",\n                "display": "g/dL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
83	SD_Synthea_Observation_71802-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_71802-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
84	SD_Synthea_Observation_72106-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_72106-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{score}",\n                "display": "{score}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
85	SD_Synthea_Observation_72166-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_72166-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "8517006",\n                "display": "Ex-smoker (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "266919005",\n                "display": "Never smoked tobacco (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "449868002",\n                "display": "Smokes tobacco daily (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
86	SD_Synthea_Observation_72514-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_72514-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{score}",\n                "display": "{score}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
87	SD_Synthea_Observation_7258-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_7258-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kU/L",\n                "display": "kU/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
88	SD_Synthea_Observation_74006-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_74006-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "kg",\n                "display": "kg",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
89	SD_Synthea_Observation_751-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_751-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "10*3/uL",\n                "display": "10*3/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
90	SD_Synthea_Observation_753-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_753-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "10*3/uL",\n                "display": "10*3/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
101	SD_Synthea_Observation_84215-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_84215-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
102	SD_Synthea_Observation_8478-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8478-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "mm[Hg]",\n                "display": "mm[Hg]",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
91	SD_Synthea_Observation_75325-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_75325-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "267036007",\n                "display": "Dyspnea (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "60845006",\n                "display": "Dyspnea on exertion (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "267038008",\n                "display": "Edema (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "62744007",\n                "display": "Orthopnea (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "59265000",\n                "display": "Paroxysmal dyspnea (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "19283009",\n                "display": "Rales (finding)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
92	SD_Synthea_Observation_75443-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_75443-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
93	SD_Synthea_Observation_76690-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_76690-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
94	SD_Synthea_Observation_77606-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_77606-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
95	SD_Synthea_Observation_778-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_778-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "K/uL",\n                "display": "K/uL",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
96	SD_Synthea_Observation_80271-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_80271-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "53566005",\n                "display": "Positive Murphy's Sign",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
97	SD_Synthea_Observation_8289-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8289-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "%",\n                "display": "%",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
98	SD_Synthea_Observation_8302-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8302-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "cm",\n                "display": "cm",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
99	SD_Synthea_Observation_8310-5_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8310-5_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
100	SD_Synthea_Observation_8331-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8331-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "Cel",\n                "display": "Cel",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
103	SD_Synthea_Observation_85318-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85318-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ratio",\n                "display": "ratio",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
104	SD_Synthea_Observation_85319-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85319-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260385009",\n                "display": "Negative (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "10828004",\n                "display": "Positive (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
105	SD_Synthea_Observation_85337-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85337-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260385009",\n                "display": "Negative (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "10828004",\n                "display": "Positive (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
106	SD_Synthea_Observation_85339-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85339-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "260385009",\n                "display": "Negative (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "10828004",\n                "display": "Positive (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
107	SD_Synthea_Observation_85343-2_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85343-2_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{#}",\n                "display": "{#}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
108	SD_Synthea_Observation_85344-0_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85344-0_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{#}",\n                "display": "{#}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
109	SD_Synthea_Observation_85352-3_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_85352-3_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{#}",\n                "display": "{#}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
110	SD_Synthea_Observation_87626-8_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_87626-8_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "{nominal}",\n                "display": "{nominal}",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
111	SD_Synthea_Observation_88040-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_88040-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "385633008",\n                "display": "Improving (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            },\n            {\n                "code": "230993007",\n                "display": "Worsening (qualifier value)",\n                "system": "http://snomed.info/sct",\n                "version": "http://snomed.info/sct/900000000000207008/version/20230430"\n            }\n        ],\n        "type": "concept"\n    }\n}
112	SD_Synthea_Observation_8867-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_8867-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "/min",\n                "display": "/min",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
113	SD_Synthea_Observation_89579-7_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_89579-7_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "ng/L",\n                "display": "ng/L",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
114	SD_Synthea_Observation_9279-1_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_9279-1_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "/min",\n                "display": "/min",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
115	SD_Synthea_Observation_9843-4_[LOINC]	{\n    "attributeDefinitions": [],\n    "name": "SD_Synthea_Observation_9843-4_[LOINC]",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "cm",\n                "display": "cm",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": true,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
116	Medikamentenverabreichung	{\n    "attributeDefinitions": [],\n    "name": "Medikamentenverabreichung",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
117	Person	{\n    "attributeDefinitions": [],\n    "name": "Person",\n    "timeRestrictionAllowed": false,\n    "valueDefinition": {\n        "allowedUnits": [],\n        "max": null,\n        "min": null,\n        "optional": false,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [\n            {\n                "code": "female",\n                "display": "Female",\n                "system": "http://hl7.org/fhir/administrative-gender",\n                "version": "4.0.1"\n            },\n            {\n                "code": "male",\n                "display": "Male",\n                "system": "http://hl7.org/fhir/administrative-gender",\n                "version": "4.0.1"\n            },\n            {\n                "code": "other",\n                "display": "Other",\n                "system": "http://hl7.org/fhir/administrative-gender",\n                "version": "4.0.1"\n            },\n            {\n                "code": "unknown",\n                "display": "Unknown",\n                "system": "http://hl7.org/fhir/administrative-gender",\n                "version": "4.0.1"\n            }\n        ],\n        "type": "concept"\n    }\n}
118	Person1	{\n    "attributeDefinitions": [],\n    "name": "Person1",\n    "timeRestrictionAllowed": false,\n    "valueDefinition": {\n        "allowedUnits": [\n            {\n                "code": "a",\n                "display": "a",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            },\n            {\n                "code": "mo",\n                "display": "mo",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            },\n            {\n                "code": "wk",\n                "display": "wk",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            },\n            {\n                "code": "d",\n                "display": "d",\n                "system": "http://unitsofmeasure.org",\n                "version": null\n            }\n        ],\n        "max": null,\n        "min": null,\n        "optional": false,\n        "precision": 1,\n        "referenceCriteriaSet": null,\n        "selectableConcepts": [],\n        "type": "quantity"\n    }\n}
119	Prozedur	{\n    "attributeDefinitions": [],\n    "name": "Prozedur",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
\.


--
-- Data for Name: contextualized_termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode (context_termcode_hash, context_id, termcode_id, mapping_id, ui_profile_id) FROM stdin;
391f79a7-6784-3a5e-bb29-5af6b82d5280	1	1482	\N	1
bca3577e-b960-39be-b870-ba7c98735005	1	2059	\N	1
e40db0d5-f370-3810-b12c-dc0369b3ff01	1	752	\N	1
ccdbe872-2996-3a9a-b631-8f6da9d88249	1	2197	\N	1
f6329e96-ca19-320e-9079-9352f6c3a61d	1	337	\N	1
f207800f-0d5e-35f1-9e36-1b1a82b7ea48	1	279	\N	1
7aa9b1a5-3c5d-3f17-bf0c-ca1dc811d7fc	1	2622	\N	1
1782b301-de73-3df7-91f5-d24ef37fb020	1	1394	\N	1
d8d56177-f70e-369c-b053-30227b4c28b6	1	619	\N	1
007e92cd-6868-3e26-8cf1-b12c698a5f0b	1	2534	\N	1
7afd1ef4-5536-30a1-a4f0-ebcb2a9a3a2c	1	431	\N	1
0350266b-4d82-3e9b-bf66-56d3c49f1625	1	2808	\N	1
af6559a7-c4ba-3aea-af7c-91978a66b02d	1	2787	\N	1
28150c9c-e189-3f66-b7bb-c955acc8ccd5	1	192	\N	1
9a4fdf11-9a7a-33fd-bbed-9d10be717de2	1	2552	\N	1
1d97a083-12d6-3b5b-85bc-98b65d278eba	1	1319	\N	1
c7e5a3b5-aafc-35e9-8249-18c4062a9e7f	1	1633	\N	1
f84480cf-9a2f-3cc0-bd7d-970ea494320b	1	854	\N	1
7dc2f1c8-4e02-3a36-959e-4a74efd7bf28	1	547	\N	1
b131358b-1d90-3667-8955-32f310d03dc7	1	1252	\N	1
ad55a331-86b7-3f68-bf8f-df577bc58116	1	1882	\N	1
f251be64-567e-365a-a4b9-302807ca171e	1	2295	\N	1
9ec9af20-dcbd-3434-9abe-a85f88ea29f9	1	271	\N	1
2820d431-95b5-3c78-af25-ccc14d2495df	1	2666	\N	1
8fb83018-0ce5-3471-aba7-4d291675006a	1	627	\N	1
2b222972-90dc-377b-86a3-15355007d0a2	1	2027	\N	1
1873b7ea-80f4-32cd-9757-bd72301f7d78	1	2061	\N	1
68f275ec-4646-377b-8ccf-eeeb25fe871f	1	20	\N	1
3c199854-7bd8-3efb-9839-fc805e3c7c03	1	2753	\N	1
a2d75531-4a37-30d7-b61d-58d939776998	1	772	\N	1
43be2469-d570-39f0-971a-e001ce7272e8	1	403	\N	1
9ee91ac6-786e-3e60-adf0-def221eb9c57	1	2388	\N	1
8136cc97-c797-328c-b261-95aed808c7ed	1	1767	\N	1
336ea5d8-16ee-3682-b3cd-cf49db62fe4f	1	1861	\N	1
0e6ee1bd-b164-3350-8b3c-dd58f390f9ad	1	1754	\N	1
01983d4f-9948-35b3-b556-59f76744aec4	1	1789	\N	1
83f58e8d-ec8d-3c47-9fc6-43a3749c98da	1	2077	\N	1
dad0dc89-3ddb-3c87-b372-43f1b1d9d41a	1	1094	\N	1
b3586b82-a8b2-333a-a59c-54fd12b1e978	1	2568	\N	1
254b6fb4-bde1-3e3f-812b-30f107ffc0bc	1	1113	\N	1
77f51810-7391-3cbc-8f7e-dac3f7042a96	1	939	\N	1
02dfd165-48ae-332d-b944-cf21fdf94740	1	1902	\N	1
2ed63f08-9bc8-3740-a19a-e61c57225b68	1	48	\N	1
818f4ca6-fb59-3b68-8dc1-87120276ca35	1	381	\N	1
218f7e67-0abc-3a7c-a40d-c5513bdd061b	1	1498	\N	1
9bc3e622-779d-39c3-bdb5-bec444dbf351	1	2360	\N	1
a38c699d-a21b-3444-9089-a8ef52a59d3b	1	2691	\N	1
f78780d7-6b72-3668-8c31-6ce7641bdef7	1	196	\N	1
a0e6da37-76ec-30fa-8657-575725320f56	1	2732	\N	1
f5e88674-bfb7-3e46-b528-da8ee759d5b7	1	1914	\N	1
b8063995-70a8-37a5-b824-c3f90da40c6c	1	1627	\N	1
2c3b1cd9-125d-3a8c-948a-f78408a7016c	4	2138	\N	2
8c0470c7-a98b-33f0-b7f8-f44a7d11a419	4	266	\N	2
186b17fa-717b-3ade-8ef1-55c8325de968	4	2531	\N	2
d10c175c-cb80-394e-b4e3-f771a5699612	4	1390	\N	2
ef9853ca-2202-39d5-af72-30e54667a631	4	607	\N	2
a7b9b390-55a1-3eaa-a6e8-282ff57d8ad6	4	252	\N	2
04f69ec1-4045-3a9d-991f-a56b4d787991	4	1699	\N	2
831d0662-7e91-3576-9721-e8f7525d55a5	4	1800	\N	2
3d55744a-9953-3831-b6cf-100a5117946c	4	2496	\N	2
8f0cf97f-d6b6-3c9e-8b74-364dd7db9543	4	534	\N	2
cb6b1738-59e5-36db-a8f2-b2805c7d0a26	4	1485	\N	2
71943d04-0a20-311b-8b92-9a0ffb321a13	4	2647	\N	2
ae586253-78ae-3532-b280-a6c5952f017d	4	296	\N	2
35d6d7e5-54d4-3901-99af-63641ccf3c97	4	506	\N	2
789639fb-2955-3631-a2a7-77204921e941	4	1554	\N	2
a465053a-0373-3927-808e-997ae835bf1c	4	2581	\N	2
a9235eae-8ebc-3fcb-b777-51b10e42a6f2	4	2411	\N	2
a7124500-89ab-3b7d-8227-1303286c8d82	4	1536	\N	2
dd4de736-4219-32d6-8eb1-e6319ac36265	4	1865	\N	2
223fe4ad-56fe-3f42-bc3c-b3e0610dcde4	4	385	\N	2
1055a3ae-0738-36dd-b889-3503595ba5a3	4	186	\N	2
260335a9-46d4-3b93-83dd-dfdaeb842b3e	4	666	\N	2
7dd82118-a517-3eb8-b780-1bbee9f91777	4	1613	\N	2
9532cf08-8b6d-3f14-a6e6-748173b3a6df	4	1776	\N	2
37e1d008-29b4-35ab-b985-d0bc3c835336	4	1087	\N	2
d22b27d4-5811-333b-b3a0-936a71252357	4	524	\N	2
e35edcb5-43c7-33f4-8f16-d11413731acc	4	55	\N	2
0b7a0e8c-5ffa-33dd-8b6c-8fd3d861448e	4	198	\N	2
e315b937-c241-3e0e-a3c8-bc4b86c16a46	4	2618	\N	2
4debfdad-0c76-326c-96ca-6dd47f036594	4	532	\N	2
bd8194fb-1e81-3def-8205-e67446cb68ac	4	350	\N	2
84806e3c-d345-36bc-ac5d-a54450b4166a	4	1785	\N	2
8d385d87-ff1c-3c46-abf9-664f8d53713d	4	1332	\N	2
cb2a73de-9df6-3077-914b-340a10d3e9d3	4	1927	\N	2
5a99ec60-b0b0-3ee8-93da-01ea3dc2cf47	4	1727	\N	2
cb430733-90cc-3195-854d-ddb0470dc9df	4	2578	\N	2
8bd70f72-205f-3071-bc8f-70e9238c576e	4	2165	\N	2
971eebc9-cee8-34f9-a0c0-f02590bc2eb2	4	1021	\N	2
f2662b2d-2d6e-3a26-b8b3-7b225945ca44	4	2677	\N	2
ef78c9c3-755e-3dc0-a958-0ce69ee29469	4	1060	\N	2
5fe5e49a-ebad-3352-9828-00e6d996bdb3	4	2084	\N	2
3176092e-d00b-3c3b-af7b-ebe7d79a478c	4	1244	\N	2
f540bee5-64d3-383c-9342-8433d5c72648	4	947	\N	2
41c1f0b0-9c9f-3fb1-8fc9-0358b2fca275	4	1230	\N	2
d506470e-981a-385a-9f6f-ba62860fb870	4	2577	\N	2
e84ba7e9-845f-39bb-a2d0-ba9aad8f3c5f	4	1307	\N	2
8e0c9349-cb72-3e96-b231-8be1f0986945	4	779	\N	2
a95be5ae-582c-352f-a719-a7ff9e5ed684	4	987	\N	2
bc4ebaac-2fb9-3bc9-b82c-9c12b5ce0774	4	1092	\N	2
cd763fe0-7e9b-33a1-945b-b8990f8e04f2	4	2737	\N	2
78c7af5c-676d-3bec-9599-8d8e8d0a0cb9	4	340	\N	2
7c92dfe6-12d9-35f9-90ac-437a39f19445	4	1437	\N	2
921eb11d-afca-31ae-8aa5-0a2c1757e9a3	4	2468	\N	2
966c626c-57ac-3dda-85b6-27415ec38eea	4	2107	\N	2
461d60ed-4397-3727-a0f3-e0a9053416ac	4	1719	\N	2
76696ac8-4064-340a-a993-08ff05208420	4	715	\N	2
ec19b62a-b105-3c70-9ef3-75e657f23982	4	358	\N	2
380da3d0-9448-3b7f-859f-386d44214eb8	4	1548	\N	2
ad8110f3-15fe-3267-bbe4-b4c4b49bf90e	4	457	\N	2
26dfb054-e45f-39cf-b3ee-01518a46053c	4	1391	\N	2
ff0f4863-f506-3371-b2c8-ab8e8652ef1f	4	2556	\N	2
6b8103ec-8024-3bea-9a6e-9762148f7c90	4	1237	\N	2
87e1f565-ae81-3ace-8f6f-473c86d7162e	4	1105	\N	2
21f3e711-eec5-37b3-a844-668c6f0b7769	4	2524	\N	2
62fe940d-6e3d-3376-8944-098b9658e592	4	280	\N	2
6e167934-5c9a-38df-a5de-ad99622cad2b	4	1289	\N	2
ed9e5de5-d2ef-3a1b-a8a6-ba56fd7d91ee	4	1584	\N	2
07b18dff-6f8f-360b-993e-b9657fe6ceef	4	2273	\N	2
d2108e4d-f2d4-3516-83f3-397773b60bf0	4	489	\N	2
6210ef32-c792-3d54-abea-f19bf5c04e8f	4	1140	\N	2
a205edb7-e6b3-359d-a8b1-8a63a3dc2511	4	2269	\N	2
6f819b09-b95d-3cfa-88d8-363447d3ebe3	4	1228	\N	2
5f298b3b-88fe-3ca9-9303-7699fc30a87e	4	1002	\N	2
d789e707-af42-3eb7-bd15-c7ad88612fb6	4	902	\N	2
eb05f76d-e315-350b-825c-9222b07b7ed7	4	585	\N	2
180df9c9-33f3-383a-96f5-6ff76f8872d2	4	581	\N	2
1e6273df-bbba-3678-8efd-f27088d5934d	4	1169	\N	2
14b19510-a10d-3728-9f49-217c288f5452	4	1679	\N	2
9cd13f39-8681-3d11-8e26-e0ea7ccee19c	4	1581	\N	2
089b0ea7-1e27-3d95-be76-01a8b4dbb229	4	1096	\N	2
5980ef07-889c-3624-b151-cba8875d4fbb	4	2268	\N	2
800e5905-b78a-3375-b881-22c940e33e2c	4	2455	\N	2
9d457362-3e40-34ea-b42c-82585deba5e0	4	2004	\N	2
f58c758a-6cf6-3d0f-a2ff-45b7129f8f9f	4	1027	\N	2
462468c0-92cc-37f4-a0e4-556fa4a6e3f0	4	2302	\N	2
30ec5ea7-aa03-30f5-b262-fe7966a0c76f	4	1818	\N	2
05d66030-7378-3d73-bafe-7e76a2b6ea8b	4	1708	\N	2
e03bb524-e392-3b10-8bee-26b5c18ef65d	4	281	\N	2
35ced80d-4b68-370e-be1e-148880648ca1	4	2352	\N	2
48385968-f7b8-3b40-a560-fd9dc0ea152f	4	635	\N	2
7d19d733-1edd-38eb-84bb-e5ef39ab048b	4	2349	\N	2
add8d03a-13d3-3738-abe5-c385d88531df	4	928	\N	2
eadeb627-a4d4-3697-b353-62897acaa904	4	716	\N	2
c0ccab36-5eca-3b70-a4b0-8a8d9a1851ab	4	1395	\N	2
add11cf6-43af-329a-bad7-bf1525b2ed5b	4	1983	\N	2
1445f47e-2ecc-30a1-a91e-40e904e65279	4	691	\N	2
084e9cf1-d487-3203-a1e8-4acf8e117033	4	141	\N	2
1a56aba2-fa2f-35b4-82bf-7c7a02af6fdd	4	1236	\N	2
4dae1ed1-e312-3394-8968-e67dfbb1d796	4	125	\N	2
9e0b7627-6e1c-3f63-b822-d49ad2257b71	4	1736	\N	2
fa92380a-0b9e-32a2-bd34-36ce1e4b7ec8	4	2152	\N	2
4e2d65bd-1595-36c7-ab2a-0ea847226016	4	1774	\N	2
9eaa1d43-d4e3-36f6-89d9-c1765eab4a73	4	2244	\N	2
33da2623-1209-3ab0-bf10-b4b5a09bc92d	4	952	\N	2
7f10a1e7-2039-38f0-8619-41500a6b9d15	4	848	\N	2
2f05e986-b402-3406-a7de-afe754c27a9d	4	1540	\N	2
a4ad4773-3d01-3057-9464-29e8dfa2a705	4	2546	\N	2
8211339c-3b8d-3486-8237-9e4a36322012	4	1931	\N	2
dbdba56c-e494-3f2c-b80b-c130e2017396	4	943	\N	2
0bbee2b9-ee61-3a55-a797-faf14bacdfe6	4	1534	\N	2
799d5efb-473f-34ab-9734-9b5269e6e68d	4	1231	\N	2
69834b84-8ee7-3a66-becd-af8a8eee24c9	4	763	\N	2
fc846e4a-b7d4-3aa6-9daf-de31f07b08d3	4	278	\N	2
0079e930-35ce-3091-a34b-de52bdcaf696	4	2657	\N	2
a7e28eaf-066f-3790-ab26-b2d40c3639cf	4	1829	\N	2
a1941349-2af2-3bcc-aeef-d1d872936c42	4	962	\N	2
2eaec5c3-30e4-3eb7-a5a5-3edbd8ddae41	4	2502	\N	2
db15ff68-04e5-3353-8323-520ae08d851c	4	1433	\N	2
bf75c670-07d3-3f8a-a645-856866583563	4	1960	\N	2
9e44711f-7305-3b70-9e87-7fda9812553e	4	2033	\N	2
4388817f-dfce-3da3-93e8-c4baa96ba331	4	2476	\N	2
37a7f90e-e148-3b1f-9127-f60e3550b11a	4	1843	\N	2
7ef86f90-94d3-312a-92c1-6e5a5877d258	4	611	\N	2
2e8e30e0-27e3-3809-87b9-dac136a0a838	4	138	\N	2
030d7e16-3003-325f-b5f6-477df5f0b58c	4	1517	\N	2
f17e9359-c5c3-3e05-b878-07d58d7465bb	4	1117	\N	2
ba63e0bc-aa72-321a-b9f7-a2074ccfc79c	4	2477	\N	2
f57ff04d-2924-3a8b-83d1-443202a78352	4	315	\N	2
26047954-5811-34e0-a2ad-665aa055cbf3	4	798	\N	2
6e879c5b-730a-3a83-abcd-1a2620c05aaf	4	1162	\N	2
f3747400-ef64-3160-8ee1-d63493113571	4	638	\N	2
3cbfef94-0b88-3a76-96f1-f6c9cb5099da	4	2093	\N	2
575a9cde-0889-35b7-a191-7b0f65ad086b	4	1058	\N	2
a7382e92-f42a-3972-b637-ba1aa1e9fb41	4	2402	\N	2
332523a8-81a0-3769-b30c-d9a43ed93532	4	223	\N	2
b9cd3e00-d152-3a2d-8a82-3e1e7306f38c	4	2726	\N	2
ac51d9c5-9c90-3ec3-90f1-be0fe7b628c0	4	295	\N	2
2668bc1d-19d2-3832-99bc-6cc8f8e5276d	4	2414	\N	2
d769c904-3b06-315d-b76a-0dccbfcd2439	4	1654	\N	2
f35607ab-e782-3749-8d4c-d68d0ec2cb1f	4	35	\N	2
b35e6cda-bcfa-3bb8-b655-49480c475414	4	2549	\N	2
2a2509e5-a758-3a09-b964-aabe10368afe	4	217	\N	2
215c52f9-8f8c-3eb5-9664-3e5015b98523	4	1725	\N	2
6ebf7e3b-0133-3236-aa0f-2dca17cc8c6d	4	2064	\N	2
bfbacadf-d3c7-3f0a-8fef-1db3db605529	4	1019	\N	2
468ba3b1-bc1c-301b-9879-efcfce831123	4	835	\N	2
734e3a42-4651-3fa6-b26b-e484994f46b2	4	2440	\N	2
10a499b4-dfa6-3c79-a33e-7aaa4618bcd5	4	2233	\N	2
88c2e31b-8f85-3ee9-ae78-ee228c0a46ca	4	372	\N	2
d2c3a00e-9829-35ab-8678-a4822a47b49a	4	2123	\N	2
bb785f93-0eaa-31d5-a89c-26e94ed24a54	4	1406	\N	2
0d96ac15-b542-3fb3-a742-baa81ec49b31	4	2239	\N	2
b120ab38-03b5-304c-8659-b52f87595a5f	4	302	\N	2
65193972-7368-3fe9-b42c-d12b58747a13	4	123	\N	2
0f499665-b203-3a39-b6aa-83801d807b7d	4	579	\N	2
b7571cbc-5f21-3f9e-a7e9-cfc0dfa45abc	4	1098	\N	2
e1acbe4c-36e8-31ff-90bd-d7f8f504a767	4	2142	\N	2
432fc503-f6a5-3920-a36e-3c49df07705a	4	114	\N	2
ca7f6eee-dd80-36f6-9718-bb29912d7a50	4	97	\N	2
58d22aa4-d435-3e9c-af19-7858a9c994a0	4	1462	\N	2
66f19a17-0d05-38da-9178-2360ce91fc03	4	470	\N	2
0b0c6dd6-d45a-3a27-a584-6189a4e0c722	4	1480	\N	2
71dd7643-0c2b-3f32-b029-697ff5663fdc	4	1996	\N	2
4dc51ad6-4cbf-3fee-bba0-a8f0f6ef7acf	4	2144	\N	2
8ab82222-75f8-3e20-8c24-d4d7d4d51ac5	4	1817	\N	2
dfd3c060-f988-3334-923a-fcf991a420b5	4	2470	\N	2
f3a71fbe-cf14-3209-8ca9-166b3451772d	4	2630	\N	2
905735b8-bdae-3ae9-9671-9f181dab0f51	4	1403	\N	2
7d33bd7b-d68a-3667-8a03-2e6325d31132	4	1559	\N	2
921e7af5-bfa6-3be5-a800-c72279ac73c0	4	999	\N	2
b14fd578-e399-3009-98ce-43a1fb039fa3	4	985	\N	2
d3434988-0efb-36c9-b074-784351b3bf52	4	1067	\N	2
effa80dd-ffc1-3840-9d2a-d20ca43d1cff	4	1033	\N	2
7c1fe924-bb81-3c8f-aa07-dbd4806a87ff	4	793	\N	2
174b8133-f287-366c-b8fe-a1ee151c2d2f	4	749	\N	2
a418c77f-5510-31cc-aa69-99a9f402a41b	4	2223	\N	2
0f9169f6-00bf-3ce8-9a8c-3dd3ee8434de	4	253	\N	2
02dc716c-815c-3815-9e3b-2ce402d590a0	4	1400	\N	2
588ba484-3f79-3f4a-b39a-5af8c7f0b3f5	4	1229	\N	2
a775267a-036b-30ae-829d-07810ee2b859	4	927	\N	2
6d2321ac-8653-3bab-97d3-928165a46c7d	4	1104	\N	2
4e8222e5-1396-352a-b7b7-63731653ee30	4	617	\N	2
7b947177-9322-3d23-9090-8ba1ff701e02	4	562	\N	2
1bfdcf44-c46e-3761-bd04-5fe75e43d295	4	2667	\N	2
a89aa387-cdbb-30a9-926c-a8dae97011d0	4	1862	\N	2
c79e0ce5-602b-343d-84d9-0220a3a4d2de	4	1799	\N	2
3aaf6ff6-9565-362e-b1fb-7df021735584	4	1913	\N	2
57f2e4cd-6168-3bf4-8309-607641bbe45c	4	1266	\N	2
b2a28187-7264-3e17-a6ac-2bd58b7d95de	4	1546	\N	2
69cab584-47d4-3e36-8116-802c9aee0c52	4	1081	\N	2
081fd8ef-8dd0-3078-a1a2-9694060d131e	4	12	\N	2
21e5820e-6fba-396d-9a7f-81326d56e4be	4	961	\N	2
0a890b4f-be43-3b3e-ae44-aab6a2ddf046	4	1150	\N	2
61d6a5e6-ac7e-3c64-a240-3a5cfe02c900	4	2758	\N	2
aa75c541-0b2e-3bb9-a8a0-f56ae36ed694	4	2678	\N	2
5b14e534-bfbb-3541-82b9-4d0d23f2f6d1	4	1208	\N	2
86a523ec-4fe3-349e-b71e-4225c130b753	4	1427	\N	2
cc233a81-2efa-3e90-a000-1430223ef884	4	559	\N	2
29eb4fba-3017-3269-a886-23b915415272	4	486	\N	2
62096447-d84f-302f-b0ee-e138c291f2eb	4	2256	\N	2
580b64f6-f068-3090-bd3d-1f08cdd986e4	4	964	\N	2
37b4eaf5-1a4e-384e-a962-4096ab0a0aa5	4	780	\N	2
f7b81e23-d0b2-3aa4-b143-7563d856efea	4	601	\N	2
68fc5a21-c139-3c53-b00e-2ffd05eb9889	4	2220	\N	2
b6092644-0305-382c-9d03-21d922058edd	4	832	\N	2
93ee43e8-3693-30a6-8133-a3eccf518a09	4	2334	\N	2
258b9107-d64e-3175-b3cb-29ef89e4c036	4	2175	\N	2
f103e0c6-7038-3c5a-86db-3b6edca92b43	4	390	\N	2
871b7cd0-7121-3f2a-9120-e8830d0c5e88	4	755	\N	2
57635618-4e58-347d-9581-a17a375924ac	4	2523	\N	2
e07f8892-2ef0-34cb-89de-5adcc186d5dd	4	521	\N	2
bc24d4fb-f8d5-324b-b43e-b919da1e072e	4	412	\N	2
15c1f610-ec4e-3779-b429-44f5a1c0fbb2	4	1493	\N	2
73644dbb-4ea6-3ff2-93d1-7fcce3997e0b	4	2270	\N	2
00ff6186-0888-3fbb-8089-d57cf200af5e	4	2458	\N	2
5307ae30-5973-3ad6-a35a-8863de0b8b40	4	2143	\N	2
92dc2f6b-e2cf-3947-b93c-e79906bbe75e	4	758	\N	2
fbd0d57f-8289-3f57-a7f2-bd175b8b16f9	4	2206	\N	2
bc5c5890-01e0-3528-86f9-f4444cd38398	4	122	\N	2
edf76141-f498-36cf-825d-4b1ab9e69fea	4	2475	\N	2
6351cd80-5f8a-3a7c-9aaf-de847885278c	4	1810	\N	2
fb083a81-6a2a-3154-b346-c5f1a08b0200	4	2230	\N	2
2e1548f3-dd72-30bc-95ea-98120a7806bc	4	2525	\N	2
6d4530b0-24d5-3747-a557-15271f9dcc4a	4	1435	\N	2
d462c6f1-2a82-335d-bd97-b2f08bb31210	4	790	\N	2
cfcd4dfe-508a-3570-a27f-cf82febed76c	4	2796	\N	2
f6dde1d9-5375-3b3f-9dc6-bc499ea3a6a4	4	1226	\N	2
005beb98-4359-375e-b688-19225ea8fd94	4	1044	\N	2
1a0dbcfe-787c-3461-b2d8-076a2db50f73	4	2235	\N	2
ec322602-c503-3d03-bbd0-36a6fc90b381	4	2202	\N	2
d44ef9e0-7b7b-36fc-95bf-0a2b2b039f27	4	651	\N	2
e814ebc4-1255-3b59-b3bd-68731a4884de	4	1065	\N	2
b14ca42e-f370-3e13-bb72-bd2d490173c1	4	1369	\N	2
5a1f504c-e98c-36fb-9e76-fff8bd16bb7f	4	137	\N	2
0a3406bb-cfd8-3622-b4cd-a03295b6f671	4	1313	\N	2
2b11975a-21bb-3d0b-8ad5-5948b6ac492f	4	1364	\N	2
147d9e39-f26a-3b75-96f3-0544f22d0a11	4	2586	\N	2
2195e503-8364-3658-a004-132883f42c8d	4	747	\N	2
b01656e4-7f0e-3fad-93f7-3e2487ad387d	4	614	\N	2
faea7e9a-88c6-39eb-8c20-530e09eba4fc	4	1761	\N	2
f7e46257-8359-39eb-b62e-c92ec5214a2f	4	1515	\N	2
ffce4d0d-86d0-3068-be24-374621ae2d59	4	2050	\N	2
66f51aa9-b705-3453-a7c8-4f1e8bea5f05	4	2698	\N	2
7c4d6b6a-c6d3-3ad7-89ae-9bc42942c048	4	1642	\N	2
882c7c55-838c-3421-9895-72df636f319f	4	2674	\N	2
cb7ac9d9-9b35-3f58-93c0-7893e74a8f14	4	2660	\N	2
a7b70312-3618-3593-a840-315deee6b882	4	249	\N	2
dc3f5751-d6cb-3085-b533-cbc01b4eaf0c	4	2299	\N	2
e2cf498b-8942-3631-8a36-11183148ea01	4	784	\N	2
689a04f5-ef36-3d79-826d-19e45c453fe9	4	990	\N	2
aa3a1418-6456-33e1-a506-1d5fda586687	4	2210	\N	2
834ceaa3-69af-3282-a8d3-cd47f5bca661	4	221	\N	2
78bcb449-df73-3113-8cdf-c4962bb60897	4	2464	\N	2
7024b477-7c41-3780-ae33-19b279fbfabc	4	2739	\N	2
d88e0e68-2644-3465-a643-c3d807279a7d	4	2171	\N	2
428d946b-77c3-36b3-8f1d-72091b7c8049	4	683	\N	2
85b230d0-950e-3351-a03b-8504486e984b	4	1945	\N	2
ea946584-10ad-351e-9ff9-7e48eebcea16	4	1491	\N	2
2eb83d8d-fa09-3188-bc52-13f2fc4a8120	4	2555	\N	2
8750567c-beaf-307e-b5a5-14f12a686b44	4	165	\N	2
1e9904e8-468a-3a35-bdd4-cb6228abf109	4	102	\N	2
78c703a4-6a48-3483-9fb9-3d92b8069a5d	4	2250	\N	2
934dfe5d-bccb-37ef-97c4-dc0be42cde70	4	1838	\N	2
2641b21c-cb93-3cae-b936-7fd0405616eb	4	1146	\N	2
9a344b35-a69f-39f1-af0d-9df666bb6aca	4	276	\N	2
a5a795a2-6c88-301a-8aed-a5208c859594	4	2773	\N	2
cfce2dc3-3d28-3f3f-af6b-52bf37e4af28	4	1351	\N	2
3afc5560-d2fe-34fe-b5d6-2caa4dd35f7d	4	1265	\N	2
4b8b61ce-8ed3-30a1-a045-7f301dd22d4d	4	1684	\N	2
a7f24dab-17c1-32d2-ad40-0238bc214ac0	4	1287	\N	2
f2fec908-606f-3701-b1f5-b3437e084154	4	2810	\N	2
5617127f-a279-3bf0-9e76-03eed6f6e730	4	1678	\N	2
f32ed004-e640-3d89-bfb1-e17912bbeb8c	4	72	\N	2
39905a3e-3a76-32fc-a9ee-694929bfe507	4	36	\N	2
e0c0111b-0ae8-35d3-b71d-c63a9b5bc040	4	704	\N	2
d98c4613-4daa-3efc-a17d-44de2d6d2cc9	4	899	\N	2
4ce0ccb2-0051-3700-a3e9-d2bc9f979dff	4	2376	\N	2
8eefafdc-0f00-303d-a263-80d44a9022a1	4	1300	\N	2
7ba9e605-1449-3fa8-843b-2d15bff9a166	4	2648	\N	2
3e3306a9-c906-3ef5-b2b6-de2b96a969b7	4	2786	\N	2
5ce7c5d7-1dfd-3aec-9411-192a5f34e2aa	4	2052	\N	2
10cf7d34-6b1b-3ff7-9346-c92d7a34b19e	4	408	\N	2
b4ba31f2-3fb5-342f-aa16-b24fb036aae4	4	2212	\N	2
67587d98-1127-3e4f-b0ed-f3a0e32f6f6e	4	2281	\N	2
af76104d-d224-3940-b7e8-f19ae1fa6078	4	2069	\N	2
5b540419-2433-3878-bd3a-80f1b06027b6	4	826	\N	2
e59e280b-b223-3a39-890e-d7287245be8a	4	2055	\N	2
a5105032-4fd1-3bd8-ac7c-1a7c0f4cc68b	4	1590	\N	2
b808c13e-f197-30e5-9b30-aa113d8afa57	4	1239	\N	2
33d11113-12a7-3285-94cf-3fc6fc2e7eee	4	1148	\N	2
825ebba0-c292-3d18-aaba-19de444c086a	4	1619	\N	2
5cb79dbc-d27a-3b6a-a696-d4c6a51f6fde	4	2081	\N	2
d6da5eda-6e4a-3591-b0db-c52475ca4d43	4	2807	\N	2
d9920ddb-d6d4-34e2-b63b-c1070dc9f892	4	183	\N	2
ab81b56b-da04-3fec-815a-e206d6868297	4	1254	\N	2
edaca3a9-2f31-3ee2-81f0-95d14e2da14f	4	2682	\N	2
c6799796-c36b-37af-bc57-253a40a6fd5b	4	2720	\N	2
83ca5d10-79a3-3745-8042-246e54944412	4	1864	\N	2
f4cd0747-4d7e-3565-b7c8-f991db44ec97	4	923	\N	2
6d611ed7-0944-3741-8e0e-050f088cebd2	4	2532	\N	2
81d0c25c-0b2c-3220-89e1-1e12bd3bcaac	4	965	\N	2
b0f936de-123e-341f-bc7e-2e992ed528a0	4	503	\N	2
2132cb45-4e19-32ee-a1bf-c907408ba031	4	133	\N	2
4be44869-c52c-355e-9faa-92010fcd39f8	4	476	\N	2
28aa0e59-e55b-3653-8e6f-38e34921f2e7	4	1383	\N	2
a62c31bf-1e56-383a-9289-6aa5d72a0303	4	2132	\N	2
31400302-d696-3c55-8eee-7c9724719c98	4	1965	\N	2
5bcb7757-5b7f-36b4-a8ce-96fe4668f4ae	4	2016	\N	2
20893905-502d-306b-83f0-6863d229413d	4	807	\N	2
c9745a2e-9111-3e6c-a633-5c47b752bb3b	4	115	\N	2
52607e8e-ca3c-3c41-b23a-48bd84b7e11d	4	2497	\N	2
466ae2f8-bfb2-3a3e-921b-38099961c9f4	4	1976	\N	2
30a87140-1f29-3427-82e9-000e054e8bbe	4	2535	\N	2
d4f4dcc5-6e62-3897-afe6-d376ac1861ef	4	2157	\N	2
3205219e-f8c0-3360-b7d2-f1633d4c5570	4	2345	\N	2
49be4a3b-1a4c-3364-8538-da6cfb85b97a	4	2616	\N	2
1034dc53-3db5-37e4-83ac-cffe95d74398	4	1207	\N	2
42074a94-c5a0-3a4f-8049-9ebdc8d19945	4	1053	\N	2
5ecede90-7e80-3a31-a740-c0fff8ce5c4f	4	437	\N	2
32785f56-da38-3297-b0d5-881d0460e9cc	4	1673	\N	2
a38902ef-565c-3c4c-8ee8-90217339f4cd	4	98	\N	2
3a2d1425-63cf-306a-8898-53943fdce915	4	2721	\N	2
78ee033a-6545-3706-b3fa-71a0df411dda	4	210	\N	2
14b76bee-b116-3040-83e7-80d223a55f71	4	846	\N	2
4d4b5e68-4279-3611-83eb-51a30b747d4e	4	2002	\N	2
c2c3fd00-48f8-3822-a22b-0d86df0944fc	4	703	\N	2
9261265a-2d6b-3401-b5f0-096a7878b93c	4	449	\N	2
a67fccbc-c17c-30b6-ad7a-071d0e4f9cbb	4	2102	\N	2
bfcc6362-251e-314a-b639-de87b706e875	4	1966	\N	2
40b4ae20-beb0-39d8-918b-cbaf000262ed	4	2096	\N	2
a1e4fb11-2a3a-3f54-baf5-9b90a29e4362	4	2224	\N	2
9588baa2-9ac5-3b89-9c59-aa18bfe3a192	4	1747	\N	2
1d57841f-a8e5-31ac-9b13-650b37cb5ea0	4	369	\N	2
e5735a2e-3c9b-35b2-a3ed-abf53910baf1	4	1057	\N	2
05123afe-8f8f-3026-81c9-d81d24598ba2	4	269	\N	2
130c8bb4-e0a4-3fe3-ab43-5d0157cf2bf9	4	1899	\N	2
b4064df0-234b-3235-909b-cdc1d63b8188	4	970	\N	2
89ce9991-1a36-3e0d-baa3-81a76aa74946	4	722	\N	2
471673cf-c5de-3ab8-9869-a60372946633	4	1127	\N	2
0bd3bd0e-5d27-3258-a5f5-1908af728d00	4	1982	\N	2
f1da8a0a-320a-337f-bfd2-3cc9e5fd576b	4	8	\N	2
269c4cab-ed89-3b41-8c52-4e30553047b9	4	896	\N	2
b3103f9e-f5f2-3d9b-86a3-53663fa01ca6	4	2560	\N	2
4411c874-c3fb-358b-9b5a-c9d939f70fa4	4	2650	\N	2
4fc5d46c-a29f-30ff-b285-6016ebec1bf4	4	2766	\N	2
2aaad0ea-10be-35b3-bc3b-f0b4e44c2c0f	4	2668	\N	2
7a6c5638-f442-3a8e-9bee-1614e33918c7	4	231	\N	2
b8b57f45-ea35-31df-9e52-153b6c3eb516	4	1938	\N	2
8dff5131-e8b7-39c0-8550-18071364d83f	4	1570	\N	2
4a08e155-1281-3551-b3d0-2ed7563bd9cf	4	2232	\N	2
c08903c4-71a0-3e56-8245-2087af4d6d4d	4	959	\N	2
875138e0-4f62-3b7d-a12b-cba93cd5ab0b	4	216	\N	2
21cf49b2-7c24-3cd3-a217-f00a4a08b599	4	2192	\N	2
a8920ed9-f0c5-3dff-9c55-ba93d635d35b	5	19	\N	3
a7b78af1-d4e1-39ee-8e62-080c0328d58d	5	593	\N	4
b13b1552-ee1d-3463-bbea-e29bfe16dd83	5	2769	\N	5
581d2319-059e-3e44-accf-44875abe1304	5	355	\N	6
6829cab9-3fe1-3630-a0e5-9ed56746acc5	5	1681	\N	7
06e030c8-9c1b-3a74-9cea-b4437b4e2d51	5	1250	\N	8
876af11c-e237-36f7-b3b6-80999a8d98e3	5	2596	\N	9
d5253fc4-3787-3e93-a2f9-aee7ce4875d3	5	2282	\N	10
2eff5dd0-ca22-35b4-a34f-61b2dbb4d3de	5	459	\N	11
9c4d87a1-8bac-3feb-aeb6-f577c0569631	5	2266	\N	12
693e7540-ed73-3045-9759-e4ee5ea5a2a2	5	1426	\N	13
1b89a03f-2cb1-3333-bdbc-1d8c8e366241	5	2140	\N	14
682ed91e-f064-38b9-a6eb-97626e1e7f42	5	2005	\N	15
b0e50d1d-6237-3f46-9467-5c67378980c2	5	2485	\N	16
ee933901-d41c-38af-8e75-dc76e76cca92	5	1192	\N	17
cceddb76-b71a-3783-8c22-22ac2d8fddd4	5	401	\N	18
ea1fdda8-e31c-34a9-a255-fbc2c2ddb171	5	507	\N	19
82c8a19f-cedc-36bc-94df-448bfe69bf07	5	2022	\N	20
27af7a09-a0c0-3bc6-a7db-38c58d0a6af8	5	1808	\N	21
28ef788e-5c32-3261-99a4-749f91d164dc	5	1591	\N	22
5e7add55-a854-3454-af35-20cd198f0af0	5	365	\N	23
39e06f4a-de37-3a22-840b-503f5d12bd9d	5	2717	\N	24
06a33be0-cd39-331a-aafc-b84fc4baf9fa	5	1564	\N	25
bb40bb1a-f822-31b8-9404-ac8cd230a1cc	5	2008	\N	26
83874c8e-3f1d-309a-a757-44eabea0fd16	5	1210	\N	27
064e3612-0857-3285-bedd-0eb2303885a1	5	824	\N	28
3be7fb03-8d09-336f-9be5-afe5b4ca2d6f	5	914	\N	29
53082773-357a-3fc1-acd2-0c8b0597e535	5	267	\N	30
9c7108d2-9a34-3704-acf9-5dcd2f21345c	5	1362	\N	31
428850c8-e541-397f-8a47-f87759d70d8f	5	2397	\N	32
c8a1fbec-3871-3aa0-82cd-c976c44e359e	5	560	\N	33
d3d210c3-7680-3123-a540-11d91faf9c61	5	2134	\N	34
88827007-9671-34c8-b2dc-20e259b23fd6	5	1782	\N	35
67ccf98f-39f2-35f9-9124-cb3ec78036b9	5	290	\N	36
511d35bd-762e-379a-bcf5-c8e886cd92d2	5	2595	\N	37
0a903737-d7b2-3568-a69e-6417329cd711	5	2710	\N	38
fe5055bd-0a8c-3c5b-90fe-35db2310059f	5	1578	\N	39
84c69b17-0343-398c-8483-e999381a9d5b	5	1469	\N	40
5b6187e3-16e4-33df-b3e8-cc071cc9c167	5	867	\N	41
5e260075-62ec-3a76-ac5d-d2d34e969253	5	2607	\N	42
d3fffbfd-67d4-305a-b334-75b52b351d06	5	2029	\N	43
df468e50-b350-3db9-be21-9ee8e2b4d7f5	5	2030	\N	44
5e8a6791-de9c-3860-9a46-3878e11b7679	5	1921	\N	45
490c735c-53b6-3acc-b73b-1d2eebf7820a	5	105	\N	46
171d18bc-aaf1-3759-9f26-5f1bc1b1452a	5	1064	\N	47
daea8df5-c0e1-3a24-a785-b681ca8924c4	5	2481	\N	48
32562afb-5944-32d8-9c08-8ec33f87185d	5	1657	\N	49
cfca6836-97fd-3c8c-aee1-bd5582c8691f	5	620	\N	50
a9ab0172-80b1-371d-9568-a17d645498d5	5	2536	\N	51
360fd4bf-972e-391e-9c73-5f7f5ad251f9	5	1674	\N	52
a643e127-53c5-391f-acb6-7874e2ec41e2	5	2803	\N	53
d8f121b6-125c-364a-9dd1-02882c1b82fa	5	49	\N	54
c01af2fe-0f31-39e0-a9e0-02f6a4b195ec	5	1541	\N	55
8dbc0949-bdd1-32db-9803-89606ae83adc	5	225	\N	56
0872a4a7-2382-37db-923b-fcdf032637ad	5	2460	\N	57
a0f5a6b9-96e3-37f3-b709-b8d542e3bb9a	5	1071	\N	58
22772ddb-4ba8-33be-b8d9-0232c73e151d	5	2515	\N	59
98d6837c-574d-3d8d-bc96-ec32a9249c6d	5	2564	\N	60
ee832a15-8cfa-3a6a-aaae-6a552b70bbb7	5	1022	\N	61
b75d48e5-a85b-3e61-91a7-e1d0036016b0	5	2504	\N	62
220d4e27-6af5-3142-9ea0-1ff679be7cf6	5	1501	\N	63
b8222861-5b43-3375-afdb-1deeff277905	5	1262	\N	64
52c2717b-1f35-389e-ae2a-f4f339565b9c	5	819	\N	65
a690c822-bced-3f21-b69d-b2dbdc48cd5d	5	112	\N	66
d7cb37cf-2861-300a-b965-b950c040f6c2	5	563	\N	67
038689d1-8958-3c74-bb2b-f70eb92c0cc9	5	1698	\N	68
78862a8e-1337-3602-892d-71065a897af0	5	2	\N	69
7c3644b0-4ba3-34f6-998c-29d25f2fc1c0	5	1293	\N	70
8d2c11d1-dbce-317c-a525-ac67fb3871fd	5	1108	\N	71
30ab14e1-4b62-3c49-9a6a-9decd1d2b660	5	1551	\N	72
3f4492c0-3530-31cb-b873-bf3b1d202f8d	5	1107	\N	73
235664d1-369c-3f13-8181-8942c39f4210	5	2219	\N	74
f70d7531-e36f-39e2-9c23-524f35247329	5	427	\N	75
55abf8f3-d714-3e2b-9e87-083deeef3f82	5	2594	\N	76
fe45df37-8e3a-3379-a10d-7b91a4de899f	5	2347	\N	77
d2ddea72-0003-397f-8a28-2ff8bdc56cc1	5	500	\N	78
6793de12-d2dd-36ef-8137-312fb5e28a81	5	1086	\N	79
bc2af084-54bb-3a02-bb23-66fd018e0ea9	5	2316	\N	80
4be6827c-c060-3b5f-8058-a31815439102	5	2375	\N	81
908374fb-1429-36d6-b2c3-180cc18f349d	5	1745	\N	82
56562c81-d998-39e6-b620-d2207f4c7668	5	2551	\N	83
c5ababb7-8d7a-316e-8007-64d6811af057	5	580	\N	84
3557ce57-3699-3c67-9f20-e730cc4512ba	5	1016	\N	85
c8abab55-b0d1-3d4f-a5b5-2093cbba4c96	5	81	\N	86
f1c133fe-2c51-3c6b-81e9-65903ef41517	5	189	\N	87
300b109a-d704-35cc-a295-8e1544ba9e17	5	1256	\N	88
49610313-23b4-369c-b5c0-0035c777a05f	5	2049	\N	89
21d449ed-e983-3cd3-9f4d-fc718c2caa40	5	1361	\N	90
41fd6bcc-5596-30ab-8e6f-7a8d80fee762	5	2547	\N	91
784c1b34-18f4-346b-9918-2efdd7f3513f	5	626	\N	92
b5ff0197-f12a-392e-af66-f7682a55dece	5	2147	\N	93
d2b9af8a-1352-38db-b8ab-d6cd84e64fb8	5	1837	\N	94
7766b62f-5818-3ed0-a266-bac8aeacb540	5	690	\N	95
82a8d74f-dcd0-3b0f-96f9-e9e99d804d5b	5	1275	\N	96
b0f76d53-b4ba-3bad-a3e5-e14cc32d82fc	5	1271	\N	97
a88ac481-aac7-36d0-9a43-711a11479d0d	5	2204	\N	98
dbd71fa2-9c82-34bc-95ff-7ca8e4d69412	5	1179	\N	99
dc94205a-0c09-3112-9360-e83909a9eb38	5	1041	\N	100
6e6e42bd-6497-3273-be14-dcb420ef2390	5	43	\N	101
68a10eed-98e9-36a1-93f5-fa834653f010	5	2082	\N	102
734bc366-9654-3a32-9841-9cd3346eee68	5	692	\N	103
92a1c877-3a4d-3c64-a58c-8bca7cc2412f	5	1903	\N	104
ed4bbe18-d5d2-318c-aa01-a3e52f405804	5	172	\N	105
f52d2b74-dc9c-312e-b825-ea50608e23cc	5	920	\N	106
e0d8524a-35e1-3a5a-92ff-6f1ae3abab05	5	1115	\N	107
f319897f-6d12-3194-a1df-88ccad27a977	5	659	\N	108
76bca2e4-5058-3f00-8af6-bbe97b2e5641	5	421	\N	109
8f9634e3-ce4d-3b17-9242-b003a6b8e72e	5	1297	\N	110
e93f4294-4bbc-3b97-83c8-e7201a2e16e9	5	1824	\N	111
fb6c8f4f-2cdc-3386-8491-e8a1d53862f3	5	1078	\N	112
b9659ce6-4c47-347a-9109-6ae59a313821	5	2174	\N	113
b0188207-b1a5-3027-957a-b89f18840a90	5	693	\N	114
af23dd98-2d45-3771-a83d-cfe9cce1f1ac	5	1059	\N	115
60db57e5-6e82-341e-bba4-2df21e6543cc	7	2040	\N	116
016fea43-941e-35a2-a4b8-12e06286c8a1	7	2398	\N	116
9028ef03-4429-35e2-abfc-e8075951018e	7	2617	\N	116
db2b0944-9875-34bb-9132-d7436ca18925	7	384	\N	116
26dc4686-a054-3144-afd9-190506bb4b9e	7	2283	\N	116
c5da382f-c412-3bea-b017-5b4f28b636ec	7	973	\N	116
31015f4d-fdf2-3faf-b0e3-1cd970a328e6	7	101	\N	116
5c72ec79-8dc5-341f-a03e-4b4ee66ecb8b	7	347	\N	116
23be5caa-72ea-30a4-8191-592e2273e7af	7	1891	\N	116
017a299c-3a7a-302f-98d4-f85e9e67ec9f	7	1701	\N	116
74ba85c4-a2cc-35b5-b7a1-8f5c4a9243b6	7	2429	\N	116
bda5eddd-02d3-319d-9548-f96c3a77b214	7	1977	\N	116
de5f4e05-e181-3a68-a007-e52e403f01df	7	2533	\N	116
a1c63df0-45e8-3cf2-ba5d-3ac71d1ac950	7	2825	\N	116
e34386ab-2fb9-3458-b4b9-be3e8baefd9f	7	781	\N	116
662ee8da-c5f1-3b22-92a6-5fb73d11cae9	7	1582	\N	116
e8f54088-dd39-362c-9481-e30a56ce15df	7	921	\N	116
5ebfc6cf-1728-306b-b609-3ffc4768f7a3	7	2441	\N	116
e4d55aeb-c854-3132-b0f9-2aaa7bcc04dc	7	2153	\N	116
0d2c3f67-4831-3a59-93eb-db33f9c94ffe	7	1711	\N	116
46c16dc1-c420-30ca-acdb-d693599107af	7	744	\N	116
8db92114-4662-3bd5-81a8-a0aec6e25249	7	213	\N	116
13da1b28-7636-3d36-b7c6-cb562a529a02	7	827	\N	116
2fa8eaa9-e968-37a0-9732-4cca5003ee8c	7	1585	\N	116
86bcc75b-200f-39ef-9138-b0c7b7bf5ceb	7	214	\N	116
7580fccf-9906-3eb5-8814-4be813f52e8e	7	333	\N	116
c814a577-7a81-3a39-8c3c-16d206ade8d8	7	1333	\N	116
b51991b5-8cff-33ef-92bb-bb2e8d09d4b4	7	14	\N	116
96184e55-a102-3cb9-88e1-2c043bcc3786	7	817	\N	116
441b4c0b-37f8-3ab7-8b4d-44285a4dd167	7	2621	\N	116
792264d5-c55f-3463-8a83-96692d8fd2c0	7	1387	\N	116
95c03265-e007-331a-acb7-6d5a2431aa55	7	405	\N	116
3a68bc1c-e7d7-3406-a44e-6bf90c336019	7	113	\N	116
28c7ee96-b966-3dfe-9bbc-b77251ee79ed	7	242	\N	116
f550de23-16d9-3a6b-9d7f-00be77f5e57b	7	1831	\N	116
60762e60-6791-3254-a0da-4b55c42aa79d	7	2471	\N	116
064b6c68-a249-39ce-bda5-9e79e5056e3a	7	2328	\N	116
2ae64969-d365-3dd1-959c-8cfaeb277338	7	2264	\N	116
405a8756-3a1d-3870-8ca5-2f487e56710d	7	2129	\N	116
f92b23aa-d27b-39be-b47b-41d014073e8c	7	1414	\N	116
e5e4b283-4cfa-3026-8a71-e2d6de94a519	7	851	\N	116
f4519b53-2567-3afe-adf4-b7662a7d7f74	7	2603	\N	116
0b0a6ce5-c3e6-351a-988a-0c49360e2b22	7	2356	\N	116
5bbfc291-85d2-3f33-aca3-f1f731040e3d	7	1354	\N	116
7a290d02-d677-3dbb-baa3-d5259ca4919e	7	687	\N	116
0357e103-b46c-3cde-b954-bb7bdf0258f9	7	2486	\N	116
170749b8-8a75-3026-a475-b621064ebfcd	7	511	\N	116
e5fd5d7b-491b-3ea6-afd0-93542e4b56e1	7	1897	\N	116
9b15a970-86ce-338b-a9b2-13f9c3fd7883	7	688	\N	116
40f83827-e581-39ac-936c-2b6e13a72226	7	1514	\N	116
a5add682-88aa-3618-88fc-5b7ae2f8d4e4	7	2225	\N	116
c0fe86a0-1759-3dbf-b361-333259b69c4e	7	244	\N	116
2c553a0d-5eb9-3213-956e-9f1f82e814ef	7	1461	\N	116
79582e16-43e6-37cb-ab37-08bc5c0e4f0b	7	1122	\N	116
3f59d639-24c8-3708-bfc0-d60e7b6e43fd	7	1704	\N	116
a8732ad1-9584-3bc5-b488-6be3018cecc4	7	1811	\N	116
d0f674ea-3ed1-3bfa-9d77-0e628210c1f6	7	404	\N	116
e3a04349-ce94-3551-a9e7-b766c6c3bc13	7	1405	\N	116
2911d864-3cc5-3fa3-8abd-82c72538b5bb	7	1227	\N	116
490e5094-8d26-3d90-9d65-e52436c8a092	7	1386	\N	116
647689c5-d6b7-3a5d-a82a-c5189cd6ee05	7	1421	\N	116
f3be89fe-b840-302c-90a5-bde7ebfac19b	7	1136	\N	116
86edddb2-8be4-372a-975a-b2a259fa1bf7	7	2404	\N	116
147fe207-9be1-367b-bb76-adea88d6736e	7	61	\N	116
bc80b8bc-a60e-32bc-934e-90138b2b9695	7	2675	\N	116
ee984f24-0b98-3830-96b3-3a709ee2be0b	7	1460	\N	116
54742161-2837-3dcc-805d-dbe89e461a21	7	1500	\N	116
d0ee710f-4358-3dfc-b590-780dc08c65a1	7	2466	\N	116
dbfd606d-e1f1-3b9f-ad74-6f9a5cafb74c	7	215	\N	116
db669915-0edb-3658-89a9-809f279b171c	7	2529	\N	116
df299462-0f37-338a-8925-a7b9e68e98c7	7	2386	\N	116
d3235bc0-4762-36c5-85fe-4dff34e29e7a	7	1953	\N	116
7e563fd4-af9b-30c9-b64d-5094b4e67649	7	1617	\N	116
3fdc09aa-9a4b-3ee7-9146-9be2c4f4642f	7	199	\N	116
85085c88-c93c-324e-bc7a-c37e17070be8	7	1247	\N	116
ad06cd1d-59f6-3653-8f7e-69b608fb2a08	7	1675	\N	116
5c076dd5-7bec-3359-89a3-3f24f7154fa8	7	265	\N	116
78cece93-28d9-3955-a1af-24aa01bc9f04	7	731	\N	116
e620c060-3fe6-39ef-9e2f-36d6367fd0eb	7	2680	\N	116
a52d39a5-033c-3781-83f3-311b108eb00d	7	650	\N	116
cb816bb2-89fb-3673-b04c-3ed0eda8f6b8	7	2407	\N	116
b46233d0-5268-387f-82b9-0468d41de6a9	7	1496	\N	116
6818c649-a3d1-3dfb-b131-cef745d62ceb	7	2426	\N	116
1d78eacb-996f-35b5-8116-1ebfae21a8d0	7	2624	\N	116
4f07be9e-f4af-33ac-98f5-44e70016222c	7	1204	\N	116
0417b51f-6839-320a-b4f2-342594f34449	7	2567	\N	116
b65f0726-ef34-39d1-8c73-006d76329cd5	7	382	\N	116
62f9c44b-ed69-317c-a296-546ee31bc5d9	7	622	\N	116
a99aceca-671c-3a00-929e-38cdd8daf047	7	409	\N	116
ed0513ac-bad1-3a76-92e9-957fd0030b84	7	2828	\N	116
b02bcb0a-f398-3d78-8c37-558debebbdcd	7	332	\N	116
a7921f98-87c4-32d9-856b-aef0121c6e20	7	2802	\N	116
329b8c5b-ca7a-3c1e-b6af-bdfdc3752d8d	7	1560	\N	116
7e2a8a0f-ba6f-3e55-85ff-9dda83ca2117	7	1760	\N	116
04108b3c-e156-3a69-a7e4-25169a756bff	7	289	\N	116
687827ce-60cd-375f-8486-b7a8b3ff8c49	7	1202	\N	116
6a9c5415-687f-3563-9427-fcd3a1f9028f	7	292	\N	116
b6685fa0-067a-3c40-b6bb-db192971ca37	7	878	\N	116
71505972-1b28-365d-8b15-0a1d86312a3b	7	6	\N	116
23f9b919-fb13-3b24-b85f-09d5aa6a8fd5	7	1539	\N	116
6c347019-70e9-3a7b-925e-3146210af62f	7	1981	\N	116
f2e37cf8-03c4-3e28-b65a-6a8dccedd71c	7	831	\N	116
2bf3a41d-e4a0-3fc6-b1cc-8482ecdfcfbc	7	2046	\N	116
f6fa4994-ad5d-3abe-b6c3-c8b7b4e6aa75	7	732	\N	116
29e263a9-427e-3780-976b-f57195f2510f	7	721	\N	116
2b904b20-ceb7-3355-98ce-3a7981f1a3d7	7	922	\N	116
2c88c144-4f83-3a96-8dc5-c167a6f97dcc	7	92	\N	116
3f09b445-0f9e-3edf-b462-ce507c2c5169	7	2473	\N	116
3cfa7cb9-016f-33d3-8450-6f7f358acbc5	7	2303	\N	116
e69df8f9-1800-31cb-a878-f0062548d5d7	7	325	\N	116
e90b9c19-9c28-3046-b612-8441fabe9aaf	7	67	\N	116
d9e2a05d-186b-357a-965b-ec9b5c1c75a6	7	2296	\N	116
f3a96ae3-f3bb-3def-a414-42f0109cf1c1	7	847	\N	116
cf8f96fd-7550-3f68-b506-7fc2b23361f8	7	422	\N	116
3e3258ad-ffa5-3196-a40e-6f537b5efb07	7	15	\N	116
25748359-a34c-325c-bf5f-34fd486d4c2b	7	2538	\N	116
779ad1e7-fbd7-3bec-aae4-33902ad36684	7	972	\N	116
21b694d5-f003-3415-88e7-eac33f2f02f7	7	1906	\N	116
5d64be29-76d3-3d83-8f95-029ea43fc546	7	510	\N	116
e5cb5919-ce78-3101-8c3b-adc6b4ac8e85	7	516	\N	116
764ac552-17e0-3a7a-aab9-4e1762356658	7	1640	\N	116
24e177b9-1ebf-3d37-b4bd-741188a93bb4	7	1949	\N	116
754d1e05-80f9-3753-8844-b0e43a658a32	7	566	\N	116
e09eeee0-02c2-3340-b9f6-04dcb54c6f0e	7	1167	\N	116
497dacd6-782a-30ca-a69c-1eba86ae123d	7	1355	\N	116
1e061538-c825-3ce9-b4a2-d0d4d3323dea	7	56	\N	116
10c4e851-b27a-397d-98c7-c9873aae26d5	7	363	\N	116
9211e0d4-6851-310d-9587-47733cc9ee76	7	816	\N	116
b14261d4-64c8-39de-8d79-52bcd91cf7d9	7	929	\N	116
ad6524ad-ef7f-30cb-85f4-077c523eee7d	7	2286	\N	116
866a8f9f-505d-313c-86ee-ebb837777f86	7	2042	\N	116
2439aaa5-f632-3d59-bb33-0ed5e12fcc8a	7	875	\N	116
c4908c0c-587e-35fb-b037-3e763e47813e	7	1205	\N	116
ca3a635a-7913-313d-a30c-25b767ccbe0c	7	2416	\N	116
5bc944dd-762a-3f76-8568-ae4c55f5ea32	7	1614	\N	116
fa3c1954-f3cd-3dc3-8f10-cd5b16c1ddf1	7	545	\N	116
62c9cfd6-bcf3-3cf2-a2db-d9347eaf9f24	7	2527	\N	116
64cced36-5c16-3cfc-9104-9fffd7e2e801	7	1680	\N	116
bc345be5-0740-3fae-8e3c-6e100f3620ac	7	1249	\N	116
2fda66c7-f7ab-369b-89ef-680a18be3ade	7	1308	\N	116
b7aa4807-6fe0-3dc0-bd5c-681c674722ae	7	957	\N	116
30e4272b-ee84-3d7b-9284-9628993dddae	7	1821	\N	116
1adcc34c-222c-3eec-9353-11553890c6e0	7	1638	\N	116
9ef13b91-84f7-3fd5-aaa9-918faa33a146	7	652	\N	116
5d18377c-5306-3389-82a2-55589b7c1748	7	2263	\N	116
d3ccab32-b6c1-33d3-96ef-6a00c4c1b164	7	1901	\N	116
4b34781a-3fc7-39d9-be3d-2ad8bd16f11a	7	940	\N	116
63685429-8fd4-39a6-ad98-4073b25f9150	7	344	\N	116
7bf243b5-653f-340f-ac15-9d85afd62f5c	7	1467	\N	116
6da49b2b-9428-394b-a252-c2215a449136	7	1325	\N	116
773d077c-a0b9-3c8a-9a3d-0ebdceff2606	7	1126	\N	116
0418ae46-fe81-3a5e-b754-e3cdfb9265f9	7	356	\N	116
64975599-73bf-313f-92aa-2b1ea853eb49	7	2818	\N	116
0e21255e-2b3d-3889-a3bd-968f3b31fc67	7	4	\N	116
fbbd5876-440d-3528-8858-c3e58797d1b7	7	502	\N	116
a38253a1-5cbc-3614-979a-14eb6358c73a	7	1537	\N	116
18e67948-c5f6-383a-b98b-b775dfffc53a	7	160	\N	116
817434e4-8c06-39aa-87ef-771da657819d	7	1368	\N	116
5d94fdd0-c5e1-3d94-a39b-fef87b30bd8b	7	277	\N	116
e3ca5517-a591-32b7-a36a-053cc4a122a0	7	2652	\N	116
70eb3cd9-2970-3c8e-82fa-342189b09ef5	7	1750	\N	116
8c2d723a-b733-38f8-b346-c08154f8a9c4	7	1278	\N	116
635f2ce9-9d17-346c-93ec-d82ef1b35406	7	1766	\N	116
87a957a5-d6e7-3084-a793-f43a22bdcd5f	7	544	\N	116
51fbdbb8-1ec9-3fd7-9a1e-c6c1f3b24ed1	7	233	\N	116
25bbf040-36fe-3715-b07c-ef57d9ad503d	7	1993	\N	116
939a8b9a-0ba2-3875-beeb-0d77c5e26476	7	224	\N	116
e9eb5f7c-52ab-347c-9050-ed000502666e	7	1151	\N	116
6f91f1b2-72db-320e-9ec7-a63c5ac90988	7	326	\N	116
4877c239-30b1-351b-8b0f-4c4b14d6b726	7	1794	\N	116
20b17c3d-e691-3714-9390-78b5f36a8ab0	7	2469	\N	116
cfd1383e-0169-3b60-bfef-a98d23e694d5	7	2003	\N	116
e867b05d-7d0a-32d2-a8a1-3ba4695b0e75	7	916	\N	116
3b8c4371-831a-3923-8e63-79cc4d854222	7	2185	\N	116
a31abe6d-5fe3-3265-8172-005c1e6d0d50	7	2207	\N	116
f814ed8b-291d-3749-9ec1-7e020c1e91ae	7	1741	\N	116
d3af1afa-e159-3a48-97ca-6b2ad68f79e5	7	2358	\N	116
a3e560a4-c77f-3fd0-bb9b-6ef6529e41e6	7	933	\N	116
3bd3a7e6-a085-3379-80c2-9dd9b6eb8313	7	1744	\N	116
e465c646-9385-3dac-b9c9-f2ff22aa71bb	7	1385	\N	116
c60a7f40-d237-315e-a4f5-5fd2c89fad55	7	2394	\N	116
85a37e60-0dc1-3854-8c7f-0e0426a87016	7	413	\N	116
e24f6a5f-868e-3ba1-a821-e4647ae66fe7	7	1430	\N	116
c014afeb-472a-31e5-9383-25867a1d3f39	7	2513	\N	116
c637b913-0d5b-3b6a-806f-cfdb76b94805	7	291	\N	116
1fadb7c3-fcf4-3604-88d3-958ad5aa4864	7	1281	\N	116
678441a7-e9ec-3959-8453-b05daa7c53e8	7	616	\N	116
e536f5d9-8b6b-3374-a304-beb5ba5d2195	7	1823	\N	116
2b4f483e-5d3d-3d43-99ea-2a10ca9dee3a	7	1623	\N	116
812a2aa6-0057-370b-a688-ee7c2afb1d8d	7	979	\N	116
d13b9356-6189-3b2f-8536-5c26b6b6b7ad	7	2604	\N	116
4f41d271-ac66-3b59-8cee-753efbc58582	7	1958	\N	116
453c11db-c579-35b6-b5ea-a4bed1197459	7	1084	\N	116
87ff0e76-a75f-38dd-85e2-f163a7418601	7	1509	\N	116
6471c5d8-5d9e-38d1-90fc-b290005b14a0	7	1241	\N	116
b26e1cdc-cbe5-339f-a5e2-f180b15e49f4	7	1294	\N	116
13c810f9-83d5-3c4d-8451-6afa4026d935	7	834	\N	116
84ccd7dd-f081-3b22-835f-e8a0be0255f6	7	34	\N	116
94a0e522-f4bc-32cf-8a6f-afdb173b1bc4	7	1100	\N	116
0d9e0be3-4e4d-3e95-991e-b74c9e501f4d	7	89	\N	116
1898e61a-d94c-3897-a628-02b3fffb3038	7	7	\N	116
3c5b32b7-1af6-37ca-8fef-8b019a232c1a	7	1915	\N	116
630cd7ce-899d-3001-9d05-1e33c5ba5fee	7	2307	\N	116
0959f873-6ec7-31b1-ac38-6f7d04878fee	7	2072	\N	116
39c476df-2e7a-34b9-b053-87d3e95b5fb4	7	2711	\N	116
20718f1f-3bb0-3bb4-b4fb-309087efd521	7	682	\N	116
ddf95ec0-0604-3569-8cc6-b2c139f2cd5b	7	569	\N	116
432f095e-ec22-3467-85f2-07560dffe002	7	2602	\N	116
f6899697-e99a-3993-b027-5ed37b84b318	7	288	\N	116
3fffc08b-4d65-3d33-a72c-bfeb4a42cab2	7	699	\N	116
766e9c5e-b299-3003-ab39-853e3dcdea81	7	1076	\N	116
17007bb3-6189-3131-a458-55562fb4b6dc	7	2344	\N	116
3dca5e07-d63c-3bde-b510-34ccc73da094	7	2076	\N	116
ba624e3b-7928-3e7a-861f-7ad4dc160f9a	7	441	\N	116
49591b0a-48fd-3092-882e-f49d2469f26c	7	782	\N	116
c327bb1e-1345-348d-8683-a075a6071129	7	2301	\N	116
943eadc3-dc7c-3c10-9bd6-bf754a8d7e17	7	2505	\N	116
be3b28f3-1f25-3e98-84dd-c014cc41cbfb	7	2198	\N	116
2bd69bf2-f07d-36de-b201-a07faed6af91	7	2215	\N	116
35850e7e-1263-3b6a-a14c-d95d97d739db	7	1006	\N	116
f90fa758-5d05-3f25-a4ca-fd4bbd9abadc	7	2060	\N	116
3ae383a2-e31f-3f2a-bc30-0ac5d7549586	7	1665	\N	116
47979857-c5b9-3c66-8887-a1c0f2e91bed	7	1431	\N	116
9c729e57-fe06-38e2-a3e3-f624e7bbd152	7	1061	\N	116
b71c76d2-1924-3c39-84e3-44b621d8cd43	7	1085	\N	116
b3924af6-4859-320a-886d-efc7b3c3e9c3	7	2119	\N	116
2564cfb5-e6b7-36ed-943d-15ef9d2ab4c5	7	1131	\N	116
4cd8122d-9d75-3ac5-a2a6-1b1d3d81dcd8	7	2387	\N	116
ec2c525e-f597-3e9e-9b89-5878bc83fa6a	7	2727	\N	116
fca25131-5b71-3b0b-b3da-99021141e4ad	7	1631	\N	116
f28b9ca8-315f-31c1-9b3f-89a36668f6ab	7	1697	\N	116
835681ce-8458-3b5e-9d97-ca30a89f61d1	7	2742	\N	116
90728f2d-02b7-360e-821a-4a22ddb00b7c	7	170	\N	116
d066389d-e810-364f-af0e-f9a397c75dd5	7	2366	\N	116
3ecaaedd-1f4f-3b93-94b4-e40274a8cc30	7	2447	\N	116
98eb8efb-ca87-3d0e-ab84-15d82df3760d	7	1571	\N	116
23babb63-a6b0-35e4-b1fc-023ded72406d	7	2097	\N	116
6216f6f3-5e8e-3684-8749-5b5bbae659c5	7	1156	\N	116
2b17dd8d-cd25-34e6-a885-8407143b0318	7	595	\N	116
a612d60e-15ab-3ab7-977a-435be0748986	7	2342	\N	116
61d7d8e0-b686-3466-8498-8262c773eefa	7	1459	\N	116
9a325c99-cff0-3836-9511-746bc9162c84	7	1337	\N	116
83776aaa-ba85-30e2-8b90-f810b24f29cb	7	1689	\N	116
e856817a-adea-3213-87bf-3e60389bae15	7	2791	\N	116
133b73fc-168f-351d-a088-6ac95e4b3683	7	2685	\N	116
9357645a-ebc0-3869-a8b4-700cc8a9111e	7	1894	\N	116
2cadda31-ef90-3fc1-9ef5-6e999ec1231c	7	1504	\N	116
0ace21fa-09cf-3aab-91dd-265a4091fd93	7	2073	\N	116
cd9c6eef-fb1c-3f9d-96c0-8af77918a3fd	7	1157	\N	116
de6ec552-aee4-3c00-88d8-6c52b8b88423	7	2425	\N	116
706d2d20-6965-33e1-8930-bc5c92cd7c8a	7	11	\N	116
ef7a9333-c71f-3295-aacc-bbb4ec3ca90f	7	958	\N	116
7b973fc4-aa7c-3624-b79c-fef38d4bd05d	7	2687	\N	116
fb99d89a-bb80-301b-b152-7ac45d6cf6cd	7	1279	\N	116
46dbb0e9-26a6-3566-b959-afba52bbc117	7	1047	\N	116
19c953b8-413e-35e8-8b72-3014c84b4692	7	1232	\N	116
f7b13206-1265-33a5-bce5-9013e2faf79d	7	1479	\N	116
bc6e5ed3-287f-3f64-af61-f9a20daf8792	7	57	\N	116
32b27c38-1534-3a7e-98eb-18eee9ae91be	7	442	\N	116
78390b0d-1a82-3a3d-8a30-7bfc952ee19e	7	1048	\N	116
918e527b-b65b-332a-9759-5eb730f1eeb4	7	254	\N	116
4e3ed319-4850-3ce8-b45b-44a323e64a5e	7	1666	\N	116
ce971046-4c72-3416-ba82-57a162c91dc0	7	1004	\N	116
9e3a96ce-2030-3ab4-b48a-1d36bda4e25f	7	1705	\N	116
1b67419a-fcfb-3645-bdd3-bd6030eee66a	7	220	\N	116
a312c039-00be-3a5c-b3c4-235bd85e6abc	7	1984	\N	116
63a80df5-07b3-31e3-be58-66edf674f074	7	1378	\N	116
25c21032-f14f-354e-9815-893bd4cf8553	7	2817	\N	116
5e652c09-1328-36d7-b929-aa63e74ef1a7	7	1804	\N	116
4d7f94f8-359b-378d-b0dc-3794aa3b27e0	7	1187	\N	116
a29e9f06-3ae7-35ae-b99f-a24616d1ae26	7	1222	\N	116
483278cc-30e7-3e64-8aba-22b79013b4cf	7	1726	\N	116
ccc2009d-d433-31c6-bb4e-cafca66c11bc	7	2275	\N	116
5973bde0-9683-3550-9afa-358936fbdeff	7	1895	\N	116
cdca9627-94d7-3576-b009-81240e572ac0	7	177	\N	116
0e6e2121-3595-35ef-b284-7d9d131603b2	7	945	\N	116
80137d14-69ba-30aa-a306-27434c635ba0	7	2201	\N	116
3a48819e-a6ff-3c00-8b14-d2f9d86c8a19	7	1184	\N	116
e35817b7-bdf9-3226-9570-666f7897f88e	7	805	\N	116
73d41305-7de7-38bb-8847-43ef1c7cb26f	7	1819	\N	116
90360cf2-f7d7-3272-9674-82402b662b2e	7	2135	\N	116
c0b87d00-84a4-36c4-bec6-ba36ff217042	7	451	\N	116
885a6583-f3dc-39bc-9d2e-890f4481b74b	7	1195	\N	116
409ca5ee-63a1-31ff-99f8-eac56d18da36	7	2155	\N	116
7af225a0-a057-3877-8ee5-4e21ba71e9e1	7	1912	\N	116
1b8ee78e-7753-32c0-982b-c8e32d01c43c	7	1918	\N	116
10e934db-2199-356e-883f-82ecb517b18a	7	485	\N	116
477bb50d-6ab7-3ab9-a727-3c1e07c7c6ae	7	464	\N	116
2daed538-a89c-3638-bbd7-fd3acedf9312	7	1997	\N	116
804fbd01-b0f5-3af5-af63-2fcbc85affd7	7	658	\N	116
92aef7fa-264e-3dc7-941a-32fc25abc5c0	7	2554	\N	116
1a9444db-f554-343a-8972-dddc0d5a2788	7	1969	\N	116
664abfcf-81db-3c15-a6f2-8f78f4631c1a	7	774	\N	116
13b4f162-3ec3-33ce-849d-fbdd947ae856	7	794	\N	116
800a6b38-efdf-32dc-a147-99b1d9f0aaab	7	1600	\N	116
675b4a22-a0e6-3ce9-8122-a5056b236904	7	38	\N	116
8174c4e2-7017-330b-9bd4-b717472d9d0f	7	1442	\N	116
5fb85107-c671-3573-8fa8-2b5cd83e46b9	7	672	\N	116
edfa6d45-9646-3e31-8dd1-33e7cb9bdd2e	7	1046	\N	116
61257972-ca82-35b0-b309-da91b9526acc	7	87	\N	116
74cdf2d2-f229-3e50-b498-290f674278bb	7	709	\N	116
f86099e1-fc02-318d-b08f-40e7072e5f6d	7	2654	\N	116
8d047ad0-1e13-3c6c-bc86-0480434c7115	7	1160	\N	116
cc5bb9fa-9209-3b65-af60-cdfb6e88945a	7	530	\N	116
57171f73-7abe-3269-9326-8161dee195bd	7	411	\N	116
8061eb7e-e751-31c7-b344-7c029893aadd	7	2522	\N	116
c5f7c5b0-71f2-308a-81e2-1550ac85c7bf	7	368	\N	116
145e77ce-9522-3d17-a076-05134babf27c	7	448	\N	116
a6b6c2df-ea8a-3324-b390-fe344cfd98d5	7	392	\N	116
bb3d34fb-211d-3e8b-8c0f-56425d6a9c9e	7	1066	\N	116
70cc01af-de70-3e6b-bd00-7467a14e1690	7	130	\N	116
6b8ef672-c7a1-30d3-9d61-717931e48344	7	669	\N	116
19dfe8d8-23bb-365e-a49c-9c8a6dd5f885	7	1128	\N	116
bc6656dd-07e2-3b31-a0f5-d73f5fdd9c0d	7	2499	\N	116
400457fe-fa99-3859-a3ae-f4285578bb55	7	2463	\N	116
d8797b4d-1e95-3249-ba4e-a42c38901d8d	7	2176	\N	116
7fd48616-b811-309e-878a-854e7ae734e6	7	1358	\N	116
6752bfe0-8078-31a7-9bd8-cc601fd674d4	7	2706	\N	116
5217c950-6e89-3ef7-96b5-7714dbe70561	7	1592	\N	116
83c84aa6-0a26-32ca-a885-d2eea27594c3	7	2729	\N	116
931053fd-b346-366d-9855-5ac0ade4dcaf	7	2216	\N	116
b84be170-7265-3579-b675-0a85cdba7f4c	7	752	\N	116
afab435f-a63f-33ba-bae8-da0fcf5a77a1	7	2584	\N	116
f92af0f7-4b7e-3cd9-bb0c-c55b62a929ba	7	2179	\N	116
19a7f805-62ea-3225-acf9-4e936e020eff	7	377	\N	116
3e878ad4-dbc9-3d9b-ba23-42d4837a359c	7	2159	\N	116
b85ed56b-05bd-3c9f-acd8-e3aa1b85e497	7	694	\N	116
82682384-4b2c-3d5b-bc76-84937d137458	7	2186	\N	116
e99fbec3-1c79-3c99-89ac-a1334b7c1aaf	7	995	\N	116
d3b7a83f-5cc4-34b4-8648-34ff36a77383	7	1616	\N	116
c5cba0b8-f928-3078-83b2-ae714cde02b3	7	2456	\N	116
33fb6e7b-579f-38c9-9e15-0958ed55b5c9	7	148	\N	116
bf889425-93c8-330a-a8fe-7945edfb61c0	7	2287	\N	116
dc8452d9-5f57-3677-ac66-b0ce11dabb7d	7	1377	\N	116
e4f7e649-d18b-365e-bd46-fa87814aab66	7	937	\N	116
dc2e48d0-e021-385c-bb53-e6ceafc6c439	7	1742	\N	116
57cedfcb-3401-39f3-ae68-3964437eac02	7	2160	\N	116
0d38786c-02b8-3380-ae1b-235868938e94	7	1359	\N	116
363aef21-179e-3f09-b6e4-bbe9642044de	7	697	\N	116
9d9b6ea0-9c1e-32b5-962b-aab1a45e336f	7	797	\N	116
f164875a-8159-3b94-a89e-b04387db9c72	7	1668	\N	116
40e5832a-e85c-33c4-b037-d3654317eb5e	7	1908	\N	116
19f25d95-8feb-350d-99b7-88b26ab18733	7	1356	\N	116
5cc86d29-75d1-3cfc-9d26-e8280b749a09	7	167	\N	116
4c6a47bb-7f36-3423-b2ae-352d2f45f6d8	7	1863	\N	116
be208824-536c-3c5b-aeab-598b7ce0aded	7	2821	\N	116
56ac8acb-b5db-344e-8f2c-fad857086069	7	1926	\N	116
01cc300c-a7a7-36e0-bc1e-8ff1bde930fb	7	1661	\N	116
012c1343-8228-3d7c-81bb-338d9205b8dc	7	490	\N	116
5f95ec57-d46a-32ce-9309-bd86a2ebc93c	7	1825	\N	116
baae0d26-41aa-3f1d-88c9-eb3040155e75	7	1363	\N	116
afc6df9c-44df-3324-bf6c-8864f6d87958	7	2814	\N	116
f83273c0-a9cb-3832-ae79-6d6f0af0b495	7	268	\N	116
b44b29e6-a44d-3935-9d4c-821ea14e43d3	7	1660	\N	116
d6900888-e8d0-30aa-8360-be038ae843e7	7	2702	\N	116
f13cffac-7885-37a5-964a-9f1b88efd67b	7	861	\N	116
e97a922d-a031-3c4e-a8fa-345628cc3c8a	7	1153	\N	116
a3344816-2d7b-33bb-aaac-107480c235cf	7	1401	\N	116
7ef10121-cdd7-3a83-b52c-a7b58c083570	7	21	\N	116
95834444-ace1-3b6b-811b-ffe845ab74fa	7	1650	\N	116
65646eae-c710-359a-917d-535196f16fb3	7	1429	\N	116
db97c09d-249a-359d-8fb1-b798f3f2a397	7	259	\N	116
fe26b051-5f09-355e-bf00-770dc04e6e99	7	1125	\N	116
71ff1e18-3587-3389-969b-46c63c0d269b	7	1052	\N	116
fc3313a1-901b-3cd7-937f-f3338c762499	7	1011	\N	116
211bcaee-6fcd-3578-a78c-8357b71e032c	7	756	\N	116
f83eb844-150d-3c5b-965b-0c1492d25c0f	7	1322	\N	116
714c3e67-0e9c-3f34-b616-9eacdd6f2502	7	85	\N	116
8f48fa33-7098-3a83-8b07-ca4078b5a9a9	7	2079	\N	116
410f4bf2-501f-356c-a02a-a3812cab2f3d	7	1820	\N	116
84bf943d-015b-362e-a0e4-897757478e21	7	788	\N	116
0aa72829-ac45-3f04-91c2-12268f385805	7	461	\N	116
c5552c4c-3491-3f2e-870e-bc67fb194b01	7	1196	\N	116
b809fab9-9002-3c8b-bafe-aa9aecb30611	7	1645	\N	116
32bf64ba-d408-3f2b-a446-0b1abba4bf06	7	188	\N	116
d02bf621-c310-37ea-8dd0-4fc441b1efa4	7	1481	\N	116
3694aa6d-4b48-3b68-bb39-336ee2ac2858	7	2321	\N	116
1caea135-5d76-3449-856a-4a33eec0f6f3	7	1580	\N	116
f1312ea6-f7c9-3671-af15-bd723d654ce4	7	2722	\N	116
02c394a6-4937-3b41-90cd-10d73bad147d	7	783	\N	116
614721a1-b741-32f7-89e4-1e7e2372b1a5	7	452	\N	116
ef6618b6-9bb0-36df-aa17-5834184c8268	7	2310	\N	116
66d6d45f-7d04-379c-a055-8a457eb306ac	7	2797	\N	116
93a33136-a9a3-3df4-bac5-d5bdace60c5a	7	282	\N	116
2ff3f156-fdfb-3a5d-954f-a531f420fbe1	7	1396	\N	116
1001eab5-d76c-30cb-9e2f-61b2cb08292f	7	1440	\N	116
bdab13ec-11c0-32f0-a143-4d49d5510ae6	7	865	\N	116
c219097e-e015-36c1-80ff-1a180570b0f5	7	1663	\N	116
28efb21a-9a52-3ea2-8be5-b7721d9f8836	7	376	\N	116
cf1a0211-39dd-31c9-99f3-cdebe40dd4f0	7	2707	\N	116
f2be5e9e-15da-32e0-aad2-4dc8b774b293	7	2715	\N	116
645773ce-4121-37d3-b8d1-ef66cb98ef94	7	1871	\N	116
b7cadc92-b9c0-35f5-84b4-3967267be787	7	1904	\N	116
7319aa4b-b985-3db7-b6d5-a559da80b799	7	1889	\N	116
62f47072-a0eb-38e8-81f1-ba3b5e1b0079	7	1037	\N	116
1c6cd192-54f9-3729-8140-8e436a89bbc7	7	2314	\N	116
7c03fe28-0092-37d5-82e8-09dd7dccf30f	7	2410	\N	116
873e7c2d-15bf-38dd-ac83-767fb9020131	7	297	\N	116
7bef2527-2f14-306b-a01a-a4b35248a988	7	1848	\N	116
4f98ce8f-4af9-36f7-8b28-97f1199ff84d	7	655	\N	116
0a15f45f-41e3-3e4e-8559-887f10df2f1e	7	1709	\N	116
eb441ce2-9f8f-3e0d-a2b7-1af4f98c8e6c	7	2336	\N	116
4f726144-4ab2-3db9-982e-6e1ff2b469c4	7	948	\N	116
1144b981-c783-39f1-936d-850b752626d2	7	1489	\N	116
41c53e49-442e-31e7-9962-d704175c4c36	7	106	\N	116
8c7ca785-bc8f-3939-8b33-f30d882b5f6c	7	320	\N	116
c2b8be17-8df4-3dac-b756-5cf85101c3da	7	1497	\N	116
2a00c591-2373-3c85-8c4e-30fe9b3927e7	7	407	\N	116
3d661334-a871-3044-8df4-1ff4e7536192	7	1505	\N	116
10c13f3c-26fa-3d00-ad85-3b043bfacf82	7	1856	\N	116
728818c8-271d-3648-8268-05aa119984e5	7	924	\N	116
9a4a103a-d06f-38d1-b09b-1fdf4b826c61	7	1392	\N	116
1c854c4e-b6eb-3d4c-b392-35153ef003e1	7	634	\N	116
c6379f8a-d71b-3e7b-ad62-0a5ad573e12c	7	498	\N	116
5ab9ff32-22b9-3a4f-a8e8-8f8490ec10d0	7	1381	\N	116
088fb667-a7dc-3b15-8eb0-38c34f4b13a3	7	136	\N	116
afd1f635-2d8e-3afc-8c80-22cc470af8a7	7	1836	\N	116
bccaeb14-c6c0-38b3-a567-db400c8b83e6	7	83	\N	116
9bc39797-6024-3bb5-b0df-77f97cacaf13	7	2672	\N	116
b13c80af-aee7-3d69-ab67-374389888736	7	1979	\N	116
0c74c1aa-4988-33c6-94fa-f255ef012bed	7	1432	\N	116
779eaacc-9f79-3fa2-a0d2-eb24f2820227	7	1676	\N	116
68085e6d-3458-3c42-bc37-207611f51c79	7	1923	\N	116
417cc9ed-ddad-3254-b09e-ef22b6fcce8c	7	905	\N	116
84f5ae48-19dc-3f5e-bdb5-a305ee1696d7	7	1443	\N	116
8ea0b637-43c4-393d-965e-07e6d489c3cd	7	519	\N	116
5c29f01b-9be2-332a-b972-9806ac2b7b79	7	1950	\N	116
a36ccd88-2d04-357d-afa6-fb4c2a97407f	7	792	\N	116
5c29cb8f-58dc-3dbe-a9f7-4b1451a5c7be	7	1878	\N	116
e2a48ed6-9843-3546-8597-d6efea50b7fc	7	1753	\N	116
a27a8639-e191-392b-bd03-74b3c99b306f	7	1091	\N	116
5a5610d8-4fc6-37f0-afbf-7fa5e3b43644	7	2613	\N	116
b73746e1-e160-32b7-a9e0-c62bf091a8a0	7	1398	\N	116
0387e62a-2b9b-36fc-a170-1c6cf4b79d30	7	2631	\N	116
7a9c13e4-1cc4-3c74-9729-2d1f261c244d	7	1526	\N	116
1083420b-759e-3644-9859-51fda9682e8b	7	642	\N	116
2ab6387b-5ecb-3abc-afee-c78fae1fe460	7	576	\N	116
f226276a-ed2b-3f1b-97e8-3e4f6817e8f4	7	1735	\N	116
5b71845e-0a8a-3a62-a6d4-3beda16222a1	7	1533	\N	116
fd26fc85-5e58-3c5d-bb98-d83436c9ceec	7	2665	\N	116
06f2cff0-c83c-3bee-bbca-2e63bd999a87	7	2566	\N	116
fe1d3f93-3f09-36ad-b195-d8335c6665ce	7	248	\N	116
90fcddbe-d51a-3aaf-8aac-9ae8fa47c65a	7	897	\N	116
a1399426-9894-3f17-8709-bee7699eb0e8	7	910	\N	116
9fef7ad4-6730-31e8-b1fe-6c4c3bbe1920	7	40	\N	116
3e97f867-fc99-3349-bc61-f5ea57b91cfb	7	1830	\N	116
a1609f58-aa3e-3152-ad36-dfe334894ab1	7	572	\N	116
7e440a58-96f4-364c-9477-a4cdfa5470a4	7	2247	\N	116
8c6f3791-4cfe-3e5b-a690-f7656763171d	7	2507	\N	116
65582471-d525-3a67-a28c-7faa740c431f	7	608	\N	116
8c5aaa6e-6a92-3c70-995b-87c7d8836531	7	2771	\N	116
5f945437-8dfe-3f79-97d4-80146d20e53f	7	432	\N	116
4561bd84-fba0-3b5d-9242-0e396d787878	7	378	\N	116
d0126352-b6bc-3558-a792-9ad324b9ebda	7	1892	\N	116
9dce025f-7ac3-397a-a464-603c84bdf235	7	146	\N	116
666a8ad1-2221-39e2-8df6-91d3ae0dcbd5	7	1529	\N	116
ecb567b5-b6e3-3199-ab81-815089ef0ade	7	2063	\N	116
e73d90e0-f7b2-3f67-9f01-101899a4b105	7	2011	\N	116
292930ed-fe6a-341d-b0b1-0270d098ac8a	7	1123	\N	116
71bd4ecc-6bab-3057-ae49-c6377ecd85b2	7	2323	\N	116
eb1cd853-d1ff-39ce-9941-b159117beefe	7	157	\N	116
8523ff7b-6ab1-3ef4-9387-bb5adc9a6b9b	7	2044	\N	116
3c196df8-cb1b-3fac-a460-c88b5ce7b08b	7	1677	\N	116
fb860063-3275-375b-92d8-38e99de168b3	7	2783	\N	116
c558d606-f075-3b6b-9be8-af12b771811b	7	1473	\N	116
2b5d8815-b3d0-383e-b835-c332472c2b19	7	349	\N	116
b839dc74-2aa3-33f1-b858-2211c04b299a	7	1593	\N	116
083f81f6-9138-37b2-b961-c544aefbc739	7	201	\N	116
06f42b21-2439-3989-a4af-d9ec61add42b	7	2234	\N	116
59412e41-972b-38d1-941e-2934765f1fb7	7	2565	\N	116
96ceab46-61ed-3b97-87a1-94d31a5583fb	7	1001	\N	116
7a96efe9-74c0-36a0-859e-46f8bce77d64	7	1301	\N	116
55f7f12e-d2f6-3cc3-a8ec-3012cbb34a4a	7	2106	\N	116
c2933709-cc2a-362a-a15d-e5cb15f3c859	7	2636	\N	116
08bf226f-99c2-3640-914e-990d1a8a49fe	7	132	\N	116
895ffb8c-7ef6-35e0-ad9d-d2357e2626ea	7	1268	\N	116
83171d45-41bc-3d56-9d79-4a40f9b5b886	7	1670	\N	116
c8e084ae-4f30-35b1-9375-0e51665824bf	7	197	\N	116
c0e666c9-a7e2-38ef-9ad5-110be1fc479b	7	2757	\N	116
786cf52e-0d6e-3e4f-b62b-b2c53fe015c7	7	2743	\N	116
3dfa9914-2438-35a2-a238-b0eb23d7ea34	7	600	\N	116
3f191507-2d15-3ac9-81db-bdc7c4bc8be2	7	1778	\N	116
6f85370d-76c6-3969-843d-92bcbc2259c6	7	74	\N	116
0ed62d4e-6c49-3e5a-9e24-d6cc3ff0bb4c	7	908	\N	116
c7ba9f3a-9a78-3538-b532-e3ed3e8d4c20	7	228	\N	116
307d02ed-d051-31d1-9b70-1e2c4d6c5d27	7	426	\N	116
f7cf9c96-b8ba-3e53-bcc4-7b4ad061cb6d	7	438	\N	116
636e56c8-d026-39f7-bc14-ca636e633b21	7	1566	\N	116
bf353a16-d5ca-37a8-8b64-4c2ad88c29d1	7	1928	\N	116
ee5bf5db-cec5-316d-aa84-44818f67d003	7	1964	\N	116
dcb2d9a7-fc00-36f5-bcb6-3a01f47dabcb	7	1556	\N	116
d4f3c1e7-2754-3248-a5ae-644c8d37e200	7	1220	\N	116
cb675c3b-a845-3776-9367-dc157e69c9ec	7	2585	\N	116
0ee4c97b-5edd-3f23-bd87-a383caf05317	7	2740	\N	116
093715f3-7f4e-376b-af90-6d5c240e1f4c	7	2664	\N	116
6e04cf06-47c5-3d02-b251-f1e60db6cc66	7	535	\N	116
6512126a-dccb-34a1-a7bd-932a5382d818	7	2378	\N	116
05b5a333-a670-3c64-b9fe-59fe9b0ce56e	7	1518	\N	116
97790143-264a-36a3-b609-5b00f474da6d	7	1292	\N	116
5df79fec-bd61-3268-829e-034cc62c7655	7	986	\N	116
a8af689c-c475-3bf1-ba67-49ffcaa2c4d1	7	1756	\N	116
5a061440-a677-3235-96ee-9bdccdbde07c	7	80	\N	116
c1c01b28-14ea-3038-a9bc-863fe7f44a77	7	1968	\N	116
4d27ee10-ff7a-3e37-a1f6-f3acd5382d9c	7	1043	\N	116
6b2fe5e3-c933-3d7b-8efc-f724f927bfca	7	2379	\N	116
7ec01fd5-f025-3b89-90ba-652314c8e44d	7	1374	\N	116
1d1925a9-21e6-3394-871d-8ed14a70ff89	7	2761	\N	116
37e6ef0a-6094-382c-a2a0-0208cd646cdf	7	1694	\N	116
15151451-8bcf-36c5-bd1b-683652c6ca15	7	2172	\N	116
cafade5c-0503-3a76-960b-069f34acb15c	7	956	\N	116
f63ea3aa-b100-336e-ada0-022c4ac87c90	7	2103	\N	116
9b8077dc-0655-39f6-9851-057b9a274050	7	1943	\N	116
8f0d91e4-7a9c-3a11-ac6d-5bbcec6e138b	7	2340	\N	116
bb918de6-e896-3c29-a4be-2f95e3a98a2b	7	1884	\N	116
d7cd1157-536a-31b3-a23a-1aaba1d8d133	7	2056	\N	116
99debe8a-3898-3b7c-889b-c6d8fbfa468d	7	1474	\N	116
0052b73b-5e01-33a1-87cb-6f8222c35107	7	842	\N	116
eec00a34-f97a-3a13-8d47-7a4df56f26f2	7	1456	\N	116
969987b0-aaf1-3c44-a8c7-dff4cb147433	7	63	\N	116
3cbb7dd3-9500-3bbb-8071-e03c1152ebe9	7	1520	\N	116
89819703-da07-3a4f-8e66-7f73fae037d5	7	324	\N	116
89b999ea-10cc-346c-bd86-1ae4ecec5f5f	7	644	\N	116
305de396-41c0-301e-ac78-02a20cb9c491	7	673	\N	116
9e87b907-37fc-3808-b710-cdfe7cea4dba	7	2118	\N	116
5b0813e2-9f2e-3d08-9242-5d40c87d97a4	7	1324	\N	116
b4da2ee4-009d-30d9-82de-4b75288040f4	7	2748	\N	116
3215b420-0c1d-3d7a-94f9-29533a5fe3ea	7	2090	\N	116
69743ef8-c2ef-34a4-bc10-d23b2f898237	7	1688	\N	116
61d39e4e-e1a5-3573-8de6-2d9b4bc3d4f3	7	2222	\N	116
e09c32db-01ba-3b06-a2b7-78ba38ff6c72	7	2811	\N	116
63eaf8cc-ef0a-3571-af88-6dffa11ccfbb	7	898	\N	116
9130a103-cd79-323b-adb6-8232fe225550	7	293	\N	116
149a4743-80ee-3a81-a69b-33c89b5930f5	7	13	\N	116
ecfff1ba-9078-359f-ae5d-cbd6e5397feb	7	653	\N	116
69a77f01-a41d-3d9a-82c1-0d14c1d00179	7	463	\N	116
f71ac8e7-f7da-3245-9369-63fb0f1140a0	7	1768	\N	116
1b68c532-da20-3ff5-9c49-a856f1787b11	7	679	\N	116
5df4b63f-435b-3616-8a11-5433c76429d2	7	227	\N	116
af49b78d-b469-3872-8c2c-84ccbb5e8fda	7	250	\N	116
91b1b5db-9ce4-34aa-82c7-1b8ebb9e871d	7	397	\N	116
2bfbcdf1-9f55-3c9a-b82f-b0598f34a66c	7	144	\N	116
03987ab1-29fd-31bd-8e2a-87e3c008427a	7	389	\N	116
0b197fd9-6190-321d-a8d2-9bd677aa300f	7	1035	\N	116
c25bd79c-4b41-3406-98e7-ccf7fc2cf4cb	7	1604	\N	116
9d95dc6f-80c3-333d-bf89-af0b8607b534	7	2819	\N	116
ecfcdb6b-2ee7-32e3-9da2-2fa87e1bb66b	7	1543	\N	116
079f63b9-fd80-3cc3-bd41-72d83bd483e6	7	1743	\N	116
8a9dbefb-6d10-3f4e-8f6d-4cc3c66517c0	7	1375	\N	116
7257b5a1-873e-3514-9f0c-96b15bfff8ab	7	84	\N	116
d50c2739-cddf-32c5-9455-ffd094fa819b	7	2101	\N	116
dac22eb6-4b8c-3a0a-a2fc-60bb52bddebc	7	1599	\N	116
a1003aae-703b-366a-96a1-8d1f57eb1aaf	7	1779	\N	116
02baea12-6bd8-3ecf-bcf9-1dd3a2e6cb18	7	2285	\N	116
9faf5713-f109-3e3d-a412-39fb8f5ec769	7	1049	\N	116
30c5719d-c1ea-393b-86b5-56eca3a39e18	7	399	\N	116
918da25c-7f54-37dd-a087-487fb6d35adc	7	728	\N	116
91dff172-834d-3a75-b544-67419fdbe272	7	1499	\N	116
4ae0cc60-0609-31c2-b28c-8f2ac2333fd8	7	2437	\N	116
780734db-e813-3616-a7c1-5a8f1cf60ef1	7	2623	\N	116
e512d919-279c-325f-bacf-2311051558bb	7	1379	\N	116
0e63c675-62e9-332a-b21b-442e21507086	7	1372	\N	116
cf07eafa-a3c4-3140-ac01-a9d119a8d605	7	2053	\N	116
554bb51b-e7ba-3ce4-9596-c962446d0d10	7	745	\N	116
0df785c4-cbbb-3163-a980-c218d6e1d5ed	7	1428	\N	116
1ec02f9e-9fe1-30a2-ac96-d0b778f480b7	7	1549	\N	116
3f719f8f-ad13-31ae-93cb-2277dce836bd	7	2713	\N	116
ab87f9b6-31ad-3cf0-b77e-edf50859ed13	7	2438	\N	116
8d7a2674-bcf6-3b0e-ae38-bc6c9b1a23a5	7	1152	\N	116
c5cfecc8-c41b-37e1-bd54-e33f59d4f13c	7	1350	\N	116
b647fce5-fc7c-3def-ba2c-4b97f453912d	7	894	\N	116
36f907bc-4e0c-3b3b-a71e-083525e18b03	7	1185	\N	116
caf79494-9851-3f4a-8421-b9534e21ca8c	7	2406	\N	116
d8a2dcc7-54b0-3830-8735-9db83377e933	7	2184	\N	116
ced754ee-d22c-385e-8e2e-b16ce1f47fd6	7	775	\N	116
9130444e-5550-38f3-9254-cad8e4d87162	7	1036	\N	116
f3a60fb7-996c-3544-8ecd-062a286039f4	7	73	\N	116
c861e573-6755-3ae6-bb31-29966e4a229a	7	1183	\N	116
99e073f6-eede-3ba3-b45a-dc33fcff4c32	7	1088	\N	116
d659e5a5-3425-348c-9a54-7bcbcf5325a9	7	643	\N	116
0da8dcdb-6218-31f7-917f-ee0ddc630993	7	2163	\N	116
c61cb13d-b041-36a3-a1e0-8adc89c20f81	7	863	\N	116
fbc453d7-6bb3-3734-8f57-109cb9503332	7	1648	\N	116
6da4fcdf-88a8-3066-b01f-8ceaec8be3e8	7	1129	\N	116
87e27fb2-6a4e-3674-ae6d-2a3cb88c8ff3	7	1652	\N	116
af36ec48-61c4-34c5-a0bb-125ab50b5894	7	200	\N	116
000f0901-67e7-35a5-8fb4-98c45da40bec	7	1890	\N	116
6272b3cb-4f2b-3c12-a5c2-19bfcd3a5702	7	274	\N	116
06b03698-699c-352c-bf50-edcc5fa0dbe9	7	1807	\N	116
70616778-df27-342a-ae42-db5f086dd1c3	7	283	\N	116
d3bf279e-860c-3277-9d24-88950ed2c598	7	419	\N	116
f416d933-bb5f-3802-a6af-affcc8eb8ea5	7	75	\N	116
13074d24-5d41-3203-9e1a-9e52db871388	7	2681	\N	116
30c7ebb4-91e9-3ce6-ad99-fd2d75db255e	7	273	\N	116
e2164bfe-da56-3aa6-9eb5-323876f36d2a	7	251	\N	116
82eb2d70-9f02-3a46-b379-22bc045c5b1f	7	239	\N	116
6e7b2e35-b2e6-371f-95c3-9d20cf2baec6	7	2188	\N	116
2a53d11b-7d95-38a0-ac46-63dfb1936da4	7	551	\N	116
02e700d8-7a9f-3ac4-ba80-ecc3b65ea941	7	1849	\N	116
7ccfb90d-928b-3462-8c0d-e61607c11eef	7	903	\N	116
8cc69dbf-11fd-3a9a-b065-c5f176ce0d21	7	386	\N	116
c5198683-b94f-35cc-911e-c5b02db9f5b9	7	2733	\N	116
aa666860-88aa-37a6-b518-009090c184aa	7	1746	\N	116
7d003255-ae56-3671-ba4b-c283f1f6cd67	7	2368	\N	116
9a067dfa-a6ad-38e0-8af8-279b4b14a8c8	7	59	\N	116
4d022c96-9b9e-381a-9e36-8665338383d5	7	480	\N	116
88d2de8f-ec81-3a82-9b19-de96441ba86c	7	2543	\N	116
1b048c72-fc2d-3db0-9049-f21e6bdd60a7	7	2705	\N	116
e269e803-0824-3c00-9f6e-1ca274419051	7	1468	\N	116
2979dc08-57b9-32d1-a09c-d265f67fe8aa	7	765	\N	116
fb2b27ed-e5a3-3f17-98d4-5c8cf6affaf0	7	1758	\N	116
504faca8-4dc7-3726-b5db-91d37aa52560	7	1809	\N	116
121b9276-6a38-398a-9b17-ac337480b4e7	7	1323	\N	116
a0c508f1-1528-3e7a-ab15-0af446c8db3c	7	2150	\N	116
6a557742-30b5-30e1-a0c2-6401a457484a	7	976	\N	116
a3561926-ba2b-3a9b-9456-9ed44ceb57cd	7	967	\N	116
c2c31a5d-eaeb-3d8f-acdd-6148ceb1ac36	7	1147	\N	116
fc724fcd-afba-3e6d-8a6f-1836abce4173	7	517	\N	116
ece34e2f-76b5-3640-92ca-3586036dfbbf	7	1547	\N	116
2ef3aa4c-34c3-30af-9e79-4a7c77f42ab7	7	1583	\N	116
64a7bac5-9bea-3dd5-9ebb-a7b462bc89de	7	205	\N	116
6d218760-3550-367b-b31f-d94ee8040749	7	173	\N	116
7a0d558e-5a0c-330e-b9a7-40e53df0c9c5	7	1780	\N	116
5140a9ae-3929-3b80-9dc5-07f04a51d9ef	7	2482	\N	116
f670cd5f-cd77-3316-9d76-b0b0f3d6d297	7	341	\N	116
8b6e3bdb-e45f-354d-89d4-8aff47805fa6	7	2133	\N	116
6cc506f4-45da-3097-85cb-32064e44558b	7	2253	\N	116
d542816f-0a4e-3525-ae29-f352a1bca385	7	2346	\N	116
c0616f58-3348-3ac4-b9dd-7190f939b192	7	364	\N	116
ab20ee6c-52ed-3e3e-9c61-bf4639b5398a	7	919	\N	116
9e222203-c865-3807-a122-55db496ed139	7	256	\N	116
594be739-ea9c-3e7d-9f15-af92a8462fe6	7	353	\N	116
1771e3bf-82cb-35de-aecf-d30fbad70f84	7	2020	\N	116
20473fa5-8385-361a-b90f-a4a7261459c5	7	982	\N	116
12f19770-de2b-362a-9f67-66e61373c1be	7	2770	\N	116
ff6e4086-3f2d-3dab-a4f1-cb764c8bd174	7	1598	\N	116
05ffdc89-43eb-388b-b04c-88d52d91b416	7	2419	\N	116
11d6d82d-9068-3cd5-bbf6-44829254ce46	7	1803	\N	116
c4d14314-0ef5-3ee9-9994-a98daa0b3b4d	7	518	\N	116
74aa8294-8477-3779-9a4a-1cc40cd90bb8	7	700	\N	116
1cac28c0-feff-3850-beb1-9bf135ec9774	7	166	\N	116
894ca42b-43f5-3d0c-bb5c-ede553c4f118	7	2203	\N	116
47966707-5fea-3ad2-b6bd-4472acfa7960	7	1478	\N	116
7616ac43-f6c2-3ec7-a919-38edf1fd0e4b	7	2625	\N	116
7c69c3b5-a972-39b3-87de-01e8a144a0b6	7	2521	\N	116
9690ac7f-4d3f-3863-984c-6c38d26622bb	7	1772	\N	116
27cedabc-3376-372f-8bb9-9d57625ccf22	7	305	\N	116
e69c379a-7f13-3c9b-9d0b-5e3a9b4fab14	7	190	\N	116
4ac48563-3d68-3cdb-a552-116f91a04ff7	7	1282	\N	116
f312ec95-4ae1-3371-9371-c490504c0051	7	1562	\N	116
d7ed2804-2eff-3d0f-928b-981c6c83b029	7	1118	\N	116
f3483d7d-2eda-3e40-85c0-d865014a8801	7	1154	\N	116
4bc856fa-eb71-318d-b501-af983ccbd17e	7	539	\N	116
8a32d345-ff61-3ee5-98a9-74f44a51c3c5	7	2048	\N	116
727c5e28-b6f8-3e7c-a470-b0d1c41f04a9	7	2421	\N	116
3e14e8c3-ed13-32e5-ac49-b76e938f53d1	7	2001	\N	116
c0ba2865-f5e8-3e9a-b456-50d35c7902cc	7	2669	\N	116
821cb22f-5ca8-3ace-8b72-129fcfa24543	7	571	\N	116
05491045-ac80-3678-a5d7-0503854c9759	7	520	\N	116
d31c3230-ed48-36f5-a2a3-9a1a082c7e71	7	1039	\N	116
9d34040b-cc6b-330b-868e-3bd40ec69566	7	1243	\N	116
4c0eb345-f4ab-3522-af0c-8645e2871b1d	7	740	\N	116
2ced0d2f-4bc1-31aa-bb9b-a198f34d0e8d	7	1759	\N	116
7ae6184e-3586-363a-a394-c0f35f40ecde	7	1587	\N	116
690867a5-2ac0-33de-9ea5-65efc59553c8	7	830	\N	116
cf127bb4-df55-33e9-b27f-1c44790ce778	7	2790	\N	116
0e623867-e604-3f56-b8e8-64d5b500df68	7	953	\N	116
96e9abea-2635-38e4-9919-ddc94aae491b	7	1703	\N	116
ed200175-76ed-3e1e-ab60-7e090419c188	7	1190	\N	116
d1d36ca7-7214-30b6-a526-7ac1ebd224da	7	2734	\N	116
2d6dde13-756b-3388-8fd1-d6568c454185	7	119	\N	116
5909872d-02f6-3414-a130-4c415ff32320	7	877	\N	116
ac725a3c-bdd8-3343-9aa4-13e1aa02abac	7	969	\N	116
e037c012-8e6a-3519-96fc-5d8a3c72bb0c	7	2322	\N	116
973638d8-4942-3d28-bb95-f9b18495a78f	7	222	\N	116
65731c78-aefd-31b7-a6f8-ae66fc505b42	7	1860	\N	116
29495a27-bec6-3c80-8b71-d78a968d6736	7	2608	\N	116
e77b2174-7637-344a-91d5-f9da480b306a	7	240	\N	116
859ef61a-c226-3b91-83ee-bd3d18f5989d	7	418	\N	116
5694e358-8473-3b21-9ec1-96d253027554	7	1276	\N	116
763e79c3-54ff-3646-8b10-eb699abe8d7e	7	2815	\N	116
0a92669b-0cdb-3d91-b4ab-ed6579398100	7	662	\N	116
bfff2ad2-14e3-3e21-9e3b-9c26279c5c7d	7	1191	\N	116
b7837d0d-8996-35be-b7c1-b0605696efd0	7	1770	\N	116
d97d5889-5d3a-36ff-91ea-1c583ab80133	7	1258	\N	116
aa338605-f717-37d9-b270-100eb0669bce	7	1850	\N	116
e8513344-9989-3c59-968a-ee1440628347	7	1944	\N	116
92bc5443-16bc-3c0a-9161-6375e4847734	7	1896	\N	116
8985f25f-3dd3-3ac8-a39d-302aff8aebe3	7	849	\N	116
813527ed-6804-39ff-bcdf-fc15e4a5be4c	7	2750	\N	116
24a46059-7f63-3fd6-9ff9-fb0fdb83971e	7	639	\N	116
3dd39824-a2fe-3da7-89ad-86f9ae01ecf2	7	799	\N	116
bbb6a9ed-b681-31d0-87df-92dc66d7904f	7	2588	\N	116
01f49b2f-7383-3bc8-bc16-43e8a2349aa5	7	2290	\N	116
690e4734-c426-31de-aa1f-ff8b935af79c	7	586	\N	116
9ebda5c9-77e6-35fc-943c-9a63db726dbc	7	2520	\N	116
297a75e4-d63b-3622-89be-167f450da98b	7	1868	\N	116
190b48c2-4ca4-3f93-a328-6bf62380119a	7	1702	\N	116
63bf116a-fb54-307d-a243-f206fe17d1b0	7	436	\N	116
98130e59-9bc9-312a-b6a7-e06c874d6509	7	1992	\N	116
4efbfb28-5fab-3f06-a376-d2bd2bf2bffa	7	1970	\N	116
98571151-9001-355c-bb69-865ee0908843	7	140	\N	116
2945c813-0b0b-3bc0-baf1-43b0ecbe7ad9	7	3	\N	116
195eaee5-e78a-3a8c-93d6-13fdb2d449e8	7	806	\N	116
d6740f44-1dc6-3d48-8116-9217af4933e7	7	695	\N	116
0176a0ca-151f-3958-b7f8-a4e589960aa5	7	932	\N	116
8493c10f-5001-3359-be1f-80d4be29b00c	7	858	\N	116
0ada3df0-61a6-3a6a-80bc-0067656ec9e2	7	1007	\N	116
202811a4-3b6e-3e1f-8a57-645891d5c319	7	1635	\N	116
a563e73d-7ef7-36f6-9b36-e6aa624572a8	7	2506	\N	116
e3fc7941-8a48-36de-97db-0cc71135fe2f	7	1445	\N	116
f6c91068-49a3-337f-a5d3-0cbec80671ee	7	2255	\N	116
e5788066-abda-3ad7-a9ce-7b0d38f387e5	7	2708	\N	116
2ddeed64-cf6e-3025-bcc6-d4074f0c244c	7	886	\N	116
f91868f4-1025-34db-b260-39a132d1e3b5	7	2043	\N	116
f09e07fb-e34a-3e13-83f0-8c00123330ce	7	870	\N	116
e6cb21ef-1a49-305c-86a4-71cd2e60be57	7	1457	\N	116
4d45c0d9-d10e-3234-9df7-36e894275a2f	7	2114	\N	116
09331710-0ebd-3be2-a5a5-6b7a90782f87	7	2293	\N	116
39642c61-d799-3ebb-9ffb-3d1cc632d696	7	2113	\N	116
308acdbc-05de-33d5-851e-d96e677c008d	7	686	\N	116
2340b440-7725-32aa-84da-294817ff5419	7	936	\N	116
166500a9-3651-3096-aeb4-73a4fcf81880	7	843	\N	116
f9a275d6-c4e0-304a-9b07-13671d8cd95d	7	275	\N	116
b18543fc-d71a-35ff-939f-8b08b4583b0a	7	1141	\N	116
d93617dd-b50a-34d2-aed5-787d0748af83	7	1655	\N	116
67d99586-2a88-31d7-a57e-b47db6402698	7	561	\N	116
4b20b689-9997-3df4-bb02-5aac93a23701	7	211	\N	116
c6fc4f8b-9139-345e-aaae-f7cd92edf061	7	379	\N	116
bc63c255-ce6b-395b-b8c2-fca0b1758c24	7	1172	\N	116
92f1ad27-68a3-3196-aef1-882caef898b7	7	2643	\N	116
b1398a12-32eb-3ea6-8746-1bda7a361cbe	7	2659	\N	116
1e7b66c1-ded6-38db-ba05-7ba6d923d9f3	7	1116	\N	116
048a739e-2055-39e8-a0ee-11c9e0e1d452	7	1805	\N	116
de956266-7349-3012-8d25-30a44478228c	7	351	\N	116
e98394fa-9877-3f18-840e-0582b689fd6e	7	2274	\N	116
71df99f6-e184-3f8d-b69f-88fecfdec416	7	1366	\N	116
cc26104c-6e1a-36ac-b89a-dd5ef2400d53	7	1257	\N	116
a9d25493-b088-3708-a2d4-e65faf54f090	7	1956	\N	116
d01eb56d-d1ff-3b08-a5b7-fd8e7f35f7a7	7	2367	\N	116
26cc574b-212f-398f-99c6-15646510669e	7	1238	\N	116
8f48fdb9-861a-3265-b769-91b376e92054	7	2124	\N	116
6d4a2bd9-3bd7-3b50-a034-8ffa5b4a818b	7	1164	\N	116
4eb930f6-329d-3758-afba-2f7e1776428f	7	1867	\N	116
8d0f1849-129a-3d80-b98e-a9b6677b405e	7	2690	\N	116
399e337f-f63d-3ecc-a493-6010d337ed54	7	2453	\N	116
6e21eaae-3e53-3c84-8626-67343348cee8	7	2288	\N	116
77139cb3-b06e-3fc5-abd9-37bd7e1d2355	7	777	\N	116
9edd03ea-ab9a-398f-af55-c0f393129553	7	195	\N	116
4086bb87-3c26-3874-bbd8-69708267f820	7	2587	\N	116
d6e5cddd-c3cd-3402-a5f0-1dac5b9d9475	7	813	\N	116
ab09abe8-d7df-3112-acf1-ca4f077ff931	7	1506	\N	116
78456cad-4e73-30fe-946c-7acca7d5d5a8	7	2822	\N	116
8fd3bbe5-841d-3e7a-bad0-9c1a24f61a8a	7	1312	\N	116
0f29f003-ef6b-3785-a18a-85bae67bee99	7	1513	\N	116
54ff0dd9-56fc-3944-870e-4cb7bbbc8936	7	2804	\N	116
d9b93f50-ccad-3257-b235-191d4c1ab7c9	7	828	\N	116
7cd37a43-0269-3cb2-9d07-376d61c0c4f2	7	481	\N	116
b9ea0c00-cb92-3a00-9c51-a4f1b658ea1e	7	996	\N	116
f1e1f033-490c-3fb0-a0f1-5e86d5d43065	7	2173	\N	116
35af9edc-3d92-348d-94ea-aa7509cf5373	7	1165	\N	116
212b9741-85a2-3a8c-aac8-8259dba598bc	7	2655	\N	116
0c9f7805-2d78-376f-9b24-1fd7cce4e585	7	154	\N	116
c5e64c0f-ed98-3641-9a1e-b48b0fc5afbf	7	1233	\N	116
6470ab52-3eaa-38dd-b464-ca9742ee76b9	7	1618	\N	116
56ae8b71-ed14-3146-8924-c7d5722647e6	7	2712	\N	116
acda6e2c-ecf4-32aa-8803-4b742c1e0a26	7	434	\N	116
a784e147-d32a-3d8a-a409-f43e413adf85	7	2009	\N	116
1dd09dc6-ef33-3a54-8100-06168c9d6e9c	7	785	\N	116
d246e23e-e4cd-3ad3-8ee5-edf1e62ff099	7	2427	\N	116
e16382e7-9b1f-3dc8-93c2-a6fa325c100d	7	285	\N	116
8ab5aa64-adfe-30e6-82d0-01e3b3f82415	7	482	\N	116
6327bc66-2406-37a4-a49b-dcd2dad0aa41	7	1930	\N	116
c300761a-5854-34ec-8dde-efd1266aee48	7	741	\N	116
d31f7a57-818d-3cc5-a2c0-f8455bbde260	7	1211	\N	116
b2d9db0e-d65f-309c-b70f-315383d6a791	7	2338	\N	116
0aba9c25-3d73-3bcf-8d53-4b29ee729de2	7	2483	\N	116
cf349a85-e327-3f49-89e9-af71228cacbf	7	1947	\N	116
005d60ab-c45c-3f0d-8797-267c8bc9ab6b	7	1291	\N	116
d0bfb10f-3654-369d-999b-a802ed36ad21	7	339	\N	116
72fbfe49-a491-3dbb-a7a6-ced47fb50dc6	7	1790	\N	116
d48e11d8-572c-3e1f-a4aa-cb1287946b8e	7	1737	\N	116
9fc91ef1-2f4f-380b-b959-f050ddfd334d	7	127	\N	116
ea7fdf20-7938-383e-a099-20a2919b43ef	7	416	\N	116
d1c8ed88-0ab3-3bde-bd4b-8f3dcbc651c7	7	1020	\N	116
853b358e-90cf-313f-a11d-8882d41d9e93	7	1465	\N	116
b3d14023-4ff2-3fe8-ba9f-235bb59d8daf	7	588	\N	116
30df4868-9698-3859-8a3e-009c11691766	7	1762	\N	116
d5ac4e16-9271-3ba3-857f-5012d52b8930	7	723	\N	116
ffc5a561-4dd1-3f02-93f8-11b413f7817c	7	705	\N	116
e98c7107-1e9c-37ef-8b3b-aea02ae5dce7	7	590	\N	116
8a550789-1ccf-3109-92a0-4fe7cf04fdaf	7	2780	\N	116
f45e58d3-c552-3274-8761-ef7423feb252	7	1922	\N	116
534b9cd0-0746-31e6-9e72-9983e6c92cc8	7	1525	\N	116
ed727684-e7e3-35a0-92a7-bdabd54b36b3	7	605	\N	116
6ceabff8-047a-38f1-b1a5-46df82fcdc47	7	143	\N	116
e6544da7-c886-3e92-adaf-4faf884df7b8	7	1777	\N	116
f552ffe0-6827-379e-8c11-f08f3bd3ae43	7	2633	\N	116
dd1b0fb6-b1f2-3e10-912b-371a8c61887d	7	1409	\N	116
8f24e62d-bafb-3a95-9973-626a0db7f83d	7	2433	\N	116
901dc238-351d-3933-8332-1163537d1aa2	7	2694	\N	116
4307274c-0ec4-3000-80cf-d1c7cbe2b6d2	7	391	\N	116
81390910-f31e-319d-9ada-e3ad5ea43b07	7	1624	\N	116
47344b16-8655-3e5c-86e5-827169c86a92	7	1615	\N	116
a5ef44e4-df9f-3272-9d04-ca48d099b37b	7	156	\N	116
b7aca413-12e6-3269-a530-09e4f06a36f6	7	1299	\N	116
62f4df5b-28cb-34c1-bed8-f4c4ecaef0ad	7	935	\N	116
1d5949fa-2016-35d7-9f9c-8787651cb856	7	1791	\N	116
396001b6-6218-317f-af11-7bd25be202ae	7	615	\N	116
88e43f34-fad3-3917-a0bb-1f2c69c0dd77	7	2364	\N	116
c792aad5-2856-3cf4-beef-3f47ccfb749e	7	1696	\N	116
f1ed99e0-bbef-376c-a2c0-19da6b56b413	7	1334	\N	116
5b51e4ec-865c-306e-96c9-1e0aa8fd1db1	7	168	\N	116
185221a9-185f-384b-91fe-1e088b0681a4	7	2651	\N	116
be7733d7-5501-37c3-950a-b085f1435b83	7	796	\N	116
8ca083d7-de3c-3ada-8a43-bbc07a3864cb	7	2751	\N	116
b9039ed3-92f5-3492-ac7f-bd859ae2ff6c	7	2777	\N	116
5ccd0aeb-6d0d-37a3-b53e-eb630ec4607e	7	868	\N	116
2654e5c4-7376-3dac-8035-67fb7d2e7f92	7	443	\N	116
40c661af-a0d5-3c4f-93b6-976afce963fa	7	567	\N	116
0631f491-4f71-3945-b835-204b404cf1b9	7	1246	\N	116
6660ce2a-b63f-3a3e-9741-bf97d8126e3f	7	1029	\N	116
0b072f62-6dc2-39e8-a994-3274ddcc49c9	7	661	\N	116
1e6a9e7f-1367-3e5f-99b3-cfde0f42d55a	7	766	\N	116
f0ca4652-2f6b-39b2-ab64-bfa0741d457b	7	2413	\N	116
2356e865-c78f-3a3a-a79a-4a4268b69a26	7	757	\N	116
bf87031d-7540-3e81-a583-eed505a38ae6	7	1919	\N	116
212265d3-25f6-3cec-9d65-913805bfdc2d	7	2728	\N	116
0e407c0d-0dae-3cac-b845-1846460794f8	7	1586	\N	116
2375e891-d9eb-3ede-a719-02b71307c0a7	7	1712	\N	116
2ecdb33e-e20c-3837-b900-d52fef1bd6f7	7	1886	\N	116
a06a975d-a47f-3db4-98e8-a28539a84a1f	7	46	\N	116
2bb6edd8-6cf7-3ef1-ba5d-9832f79dcbe6	7	2723	\N	116
e90e5fdc-6619-3862-829e-38de0a235907	7	1740	\N	116
41039583-7210-3548-8272-9b991bc608d5	7	1193	\N	116
c9a7db59-8506-3a07-82e7-d2f019b7caf8	7	2305	\N	116
04c688cc-7fc0-38ac-95a8-e3e8d5150323	7	1062	\N	116
10bd5fa3-7835-3656-bbb4-b8b0401070d0	7	2816	\N	116
0c8a26a4-d548-3ec6-9e5a-c65ef3bf3c05	7	2824	\N	116
55529396-3a4a-3fff-a66b-bebcaa289405	7	2243	\N	116
7938548e-5b6c-33ab-8e3d-3a1b1eb0e710	7	479	\N	116
69bd5f17-f57f-3248-8424-706e65fbe684	7	298	\N	116
35dd033b-88b8-35f2-9820-cca380578188	7	2320	\N	116
eb3763c4-d37d-313f-a558-2482c70cd205	7	2762	\N	116
32761391-bd40-3c51-ba26-31e5d4d038f9	7	528	\N	116
aff55eb0-d979-3eee-8a0b-f832a0e64cf3	7	318	\N	116
652fa0f1-bc3a-342f-a34b-297eb4c0e9aa	7	522	\N	116
bdd13c21-b3cf-35eb-9a43-303ec73cfd80	7	241	\N	116
ef95993e-29e1-319f-bd3a-e09ea6a630e5	7	1303	\N	116
d58d974c-0960-3f77-9098-4dfab38b442a	7	513	\N	116
d68e3535-486c-3366-8ae3-11800f4f0305	7	1219	\N	116
d1eb07d3-5ec7-3c7e-8743-f2df3a9cef29	7	135	\N	116
95837c97-f5c8-386c-bdb4-ac8773d604c4	7	2494	\N	116
5d24ca5c-4734-3141-a847-88405bfae94d	7	1870	\N	116
4673e849-40f9-3f36-bfe3-7f99d16d71cc	7	2646	\N	116
69392d7b-a19c-3feb-bff5-7568a642faf3	7	147	\N	116
725d7d02-f92b-3f2e-8e47-0e479b8107b2	7	888	\N	116
cde09077-85ca-318b-a3f8-bba990e6088d	7	1558	\N	116
d705d9fd-4b9c-3160-86e8-49690e888b9a	7	1826	\N	116
159921aa-b61f-3ff0-a4e0-dab098b40ebb	7	2191	\N	116
4d4c7bb6-f96e-3810-abf3-fc1b11266850	7	1112	\N	116
27103844-adce-3211-bf28-55de117e0de2	7	1531	\N	116
44a0ebba-e7d4-3683-9b0e-f55c9e454dc6	7	2430	\N	116
6cb82273-9ff5-3e26-844b-f1ca240b3b4b	7	2644	\N	116
a952689f-fc46-3bcb-91cc-6c4e0a563c8d	7	1370	\N	116
4f773f20-8ab8-3ea2-9ff8-614228d183e8	7	656	\N	116
9c57b9b8-0739-311b-a76e-e961cc878be4	7	724	\N	116
a8c559a5-92ed-349c-b294-517425586bfd	7	42	\N	116
d91f715b-8680-31e3-8411-c8fa158bc794	7	246	\N	116
a318033a-8465-3fb0-a7da-d81ce0bc0bc3	7	1569	\N	116
2029856c-03ae-3fab-8b4f-beb46727db61	7	1089	\N	116
15eba71b-ee43-31af-b9fc-2dbebed7f73b	7	1137	\N	116
bdf7fad9-1512-3569-bd0e-c19c8e58c3cf	7	2599	\N	116
7f1727b2-a77f-3b20-8307-0d74c6598499	7	1834	\N	116
8f0ffe9e-f5e9-3d47-be5e-b219fcb534a6	7	2068	\N	116
1b3bba98-88d8-3134-8f5f-67d4178eb154	7	2778	\N	116
d3a37a59-f3a6-3443-8c8f-262c85ac437b	7	1990	\N	116
62138e3f-8fa4-35e2-b400-2ab3caf1b679	7	1144	\N	116
f6afdec1-f573-3a60-83f6-be2a9646c6bd	7	1605	\N	116
1641c469-082c-3c78-adc8-f9658c5a77d5	7	2431	\N	116
56f4e3b2-2ae2-32c3-9505-e9c52d526c8f	7	1240	\N	116
2cb3fba8-7fca-3ea7-b87d-855c1c0f5168	7	88	\N	116
2126cee6-7621-3c85-81a2-2038768f5067	7	1408	\N	116
384b3e39-2361-3de4-bf16-7c38bff55911	7	2218	\N	116
4b459b60-0731-32d9-836e-08a4cc4b87ad	7	2540	\N	116
02e923c7-2795-3f7a-a390-192a6af39cd7	7	360	\N	116
b1920b15-8da8-30e2-ad82-57587b1c7732	7	1784	\N	116
25220115-a516-34dc-9d93-1dc90dd42e88	7	717	\N	116
0709f83f-4250-3534-9113-ba3ca6278e98	7	971	\N	116
d55b8d73-7503-3b11-9aa5-b7070133a53f	7	876	\N	116
c6c6822c-8dda-31b7-b297-3fc6796513b2	7	856	\N	116
f4ca8703-12e3-3951-88cb-c38d3906a290	7	730	\N	116
1b3f60ee-95c2-3cbf-ada2-22ad15c98e11	7	453	\N	116
227d925e-6905-3310-9a15-93ef0e3f5ed1	7	1905	\N	116
c6030f1a-96c0-3853-bb74-66e32c8b7144	7	2032	\N	116
a52c13cb-6574-3426-baf2-c65d24c69745	7	768	\N	116
218dccc6-5167-3d8a-b398-7a8213e78798	7	161	\N	116
2e22101c-cb0a-327c-bff9-a2e143a975e8	7	2679	\N	116
516cf3b6-ecf4-3e04-a67b-6119825408de	7	1974	\N	116
1219da88-9fdb-3d3d-a2d9-b5d807a5a3d2	7	1933	\N	116
7b18b970-3121-3891-9876-640d82ceebc3	7	226	\N	116
df4b2c93-5dc3-392a-b97a-3c5588bcf24a	7	1264	\N	116
6f213284-2b3e-3e05-8796-479e84b5c0e9	7	727	\N	116
ff13165c-2f0c-35e9-b1c9-82609805ae10	7	725	\N	116
76b65dec-abcf-3a70-929d-69c39b8e5ba4	7	2127	\N	116
2bf1d464-bc92-344b-8d0d-d89decef9863	7	245	\N	116
9fd9cda1-b8fe-3ec2-80d4-591afca47fd2	7	487	\N	116
cb3d9276-64ea-30e5-b8a1-7ca6a46588fc	7	997	\N	116
caed25d2-f60a-3661-b71b-86f38ca22a99	7	2701	\N	116
0fabd3df-7cc8-3a5d-9589-83f08bad0a3b	7	149	\N	116
b842c496-052f-3de5-aba4-578b31fce015	7	469	\N	116
222983b8-8532-3cb2-a231-465f3e8da388	7	1329	\N	116
1d39074d-c059-3fd7-b8ee-ac7ecf992232	7	915	\N	116
4bc6f07b-b39f-3e4f-8920-4c02167df096	7	494	\N	116
7e8836c1-aedc-3bc1-aed8-ab45262e2cf9	7	596	\N	116
ee32e5c3-f7b9-39b4-b1eb-81d244d0f1f3	7	2403	\N	116
77e49e88-bc62-3944-b90b-472d8fccd4f9	7	767	\N	116
4db879b6-8173-36b5-8a85-f77de8081c88	7	2357	\N	116
2389d22c-ff87-3e71-a208-2414025852d2	7	352	\N	116
05ea068a-85cd-3e49-95b6-119b70d6376a	7	2489	\N	116
bdb5e707-1523-3b06-bda4-5834dec49f46	7	182	\N	116
a7005f26-9e8b-3c03-b5d0-778d0e3c6274	7	1450	\N	116
a4e1fa1d-039f-310c-adf4-f6ddebc87e07	7	1717	\N	116
b2cc395b-fbdf-39c7-a6f6-56b96af385af	7	497	\N	116
c9bb7934-a8b4-3cc9-8982-b3e4327372f7	7	1336	\N	116
bea3001b-577d-3f45-a1f8-1d2c06a3058a	7	1306	\N	116
2ba656e8-4ce2-3cf4-ae57-2c495417e5a8	7	22	\N	116
73474ee8-be3b-345d-a270-782b55a8f3d7	7	445	\N	116
68d1c477-4232-37d1-b09a-b80821caaa83	7	2812	\N	116
a140102f-2d10-388d-abf2-fa0bc0d44583	7	1330	\N	116
dc6e47eb-0565-3216-80fa-9ee861ceb315	7	609	\N	116
f85c0cf6-c91a-3463-a331-e96fed843948	7	2451	\N	116
ae4d9db9-7621-3b32-917b-8baf1d69a79b	7	1302	\N	116
2a01b727-f646-3e3d-8e85-aa21751d90fb	7	1550	\N	116
c1bd4b26-b9d5-3c53-9d90-0ee28a9cb208	7	881	\N	116
b8885490-6d7d-3b12-98c2-8481174934e4	7	864	\N	116
26373945-0c63-377a-89f2-a62d5952018c	7	2563	\N	116
d15f4e49-ef77-36a7-9dc7-a162572ce1f9	7	1907	\N	116
e9111b6e-28d8-3da9-9617-1fc75dcd7d86	7	2405	\N	116
7c6d721b-ce95-3e56-8ccb-46f7be505835	7	810	\N	116
eab30854-28dd-331b-8ae4-836acc8d752e	7	1713	\N	116
c88bc6b1-a8bf-3190-bc1a-69f118cd4b82	7	2300	\N	116
f8c365fb-5413-325c-96b5-b7ffc2d0b8cd	7	668	\N	116
ff9c19a5-6491-35a0-9705-2c864c976395	7	2637	\N	116
29551128-7727-3012-9631-7366bf6796ca	7	689	\N	116
59f31828-e6c8-3018-8c89-ace65e44b1be	7	734	\N	116
0dbe5745-5f87-30fd-9a62-0904565a707d	7	1632	\N	116
c16b9b4e-98b0-3c0c-b998-1b1068c7f08a	7	1413	\N	116
8456575f-053f-300c-a0b9-49ce0d37f16c	7	1957	\N	116
665bc5f6-2aa6-320e-b126-8e9f6ad9f8c8	7	2369	\N	116
73a28220-6fd9-324b-aa32-7884da8ed1e1	7	2363	\N	116
05fa72d2-d4cf-39e9-a112-2e98317141da	7	1384	\N	116
dcbfdc32-ef19-3e60-bf38-fb512dc86ffb	7	1734	\N	116
db240a00-db6d-3d18-999d-1cc5e3f8d1b6	7	514	\N	116
94fc9d6d-f3ca-35cc-8455-deddf09e4df9	7	1841	\N	116
8e7e69ae-13a3-31cb-92db-5f91c6058bb4	7	2408	\N	116
37a96f24-c45f-374d-9e02-d33299d0b20b	7	1575	\N	116
c98c6d85-56a0-3969-82e8-2028bc1241a4	7	171	\N	116
31768f92-bc85-368e-a5e7-8471722e6c5b	7	2609	\N	116
3042c08b-0ab4-381c-b259-4075bc71850f	7	121	\N	116
37e2dae3-9e1b-3322-831c-f857973c8a00	7	317	\N	116
74b3809f-5909-379a-aca9-04a31baafe6b	7	2591	\N	116
0319a9fd-d7f5-3f95-9576-d5e059758268	7	2136	\N	116
d8a6022e-0e92-390e-bab2-b562893f3100	7	243	\N	116
5a0de02a-9b7e-37d4-84d8-91a7a86954f0	7	53	\N	116
9d84a178-073c-3493-aed3-03fc4b24a410	7	400	\N	116
2291e9b0-26c2-30fd-87a7-fc90e405670a	7	1888	\N	116
3ef7a2f3-cc9f-3aea-b276-4050636ed245	7	1954	\N	116
fb028c37-891f-317f-bc23-5c84d3c4140d	7	430	\N	116
59afc396-ec5f-3ee1-986e-77a5ee195750	7	1464	\N	116
bfcfdffd-afdc-392a-a375-4b613b5d67a5	7	2315	\N	116
766c1877-00c2-3b76-b27e-11d0e05bd1dc	7	1881	\N	116
0f39a85a-d083-3412-b0d0-97c4ce2d27cd	7	751	\N	116
8255214d-f39b-3771-90da-1e5b921c568d	7	1416	\N	116
231c4278-3378-388e-9480-9487df51ddf0	7	1470	\N	116
ce7e07c1-6527-358d-826f-9f4ba2a265a8	7	1073	\N	116
afd7f8b3-7a0f-3634-a11f-ee52579f9640	7	483	\N	116
aac7a5b2-5922-3a6a-8737-6ebbfcc2266b	7	1010	\N	116
8da4d527-4a94-36bc-8ab5-c1d5b55cc480	7	304	\N	116
f7e5bec7-6e95-303b-8b0e-3f60c052718c	7	2087	\N	116
3cfc79cb-dec6-3620-b169-0e0eaab02897	7	739	\N	116
e9b062cc-b674-3395-9b6d-22c0e48e7a47	7	2178	\N	116
ef5dcfb0-f4a1-3c7a-8947-a55929a5356f	7	2374	\N	116
14f8fb54-e30b-3cd5-a213-66025ce1b1ee	7	1314	\N	116
4d0b420e-8f42-3a39-aafc-3350cbdea5b1	7	2501	\N	116
1574e22f-0009-33c1-b406-2d3353250b35	7	2278	\N	116
52003da7-e666-35d8-9bfb-df9d14c88f68	7	1201	\N	116
77772d83-32a9-3558-89b8-98c4f3cf8550	7	2169	\N	116
a9ceb1ea-f4e1-3728-956d-c3b66721936a	7	584	\N	116
991983d5-2fa5-334c-94a5-68951ac55ef5	7	667	\N	116
f501ac95-2ff8-3c2b-9728-c9e329b1a721	7	712	\N	116
da38ee31-68af-366e-a0ad-3cfefe2de457	7	2149	\N	116
c25f0fc9-7aeb-3894-8b8d-c4f8d8651c23	7	1253	\N	116
a4a6aa37-b622-3617-b067-78f3856c50f1	7	1828	\N	116
d0ac49d2-a418-3a6f-90db-a4ded1b90925	7	1488	\N	116
d99f03f2-58b8-3413-86b7-dbf539ba9b14	7	1017	\N	116
4f23f054-5859-3973-afbb-a32829c5f4f6	7	2236	\N	116
4ae105a5-1d08-3d96-9c9e-29cd0c25826c	7	1620	\N	116
5c9662ec-41cd-37f6-a171-c5433fc63648	7	1277	\N	116
875ce133-5687-3e3e-b926-695d2d0dea56	7	1030	\N	116
1e247119-0505-35f2-90fb-5571d639b374	7	433	\N	116
1a86a9dd-5c6f-345f-8f4e-59d66735f656	7	2724	\N	116
a90a0383-c645-3cb1-be9d-053f43c5b923	7	2168	\N	116
a477e890-4072-3f35-852c-669b660aaac2	7	359	\N	116
1fd9718a-882f-3924-afa9-99f293a89572	7	2395	\N	116
4c2f7409-8d65-36d8-81cd-b52ef60a0f6f	7	51	\N	116
509350c8-ea4d-394f-b8e6-fb9c53594f2e	7	2635	\N	116
a3a8e47a-69b2-3d9e-9a3f-6a92aa8d8500	7	151	\N	116
6c96465e-7b9a-3320-8fe2-c285f9438897	7	357	\N	116
fa552fa8-c42b-3d5e-9168-5e63ea0b63e2	7	2057	\N	116
9800853e-a93b-3ce9-ac7e-11b32fb71363	7	2805	\N	116
9b690693-7543-33f6-bf3d-6f3f47eb5b01	7	1203	\N	116
86d14315-7f0f-3849-a993-be1b617a6320	7	2000	\N	116
9bbfdb1e-402f-3049-84f9-7b4d7554623f	7	632	\N	116
97f2344c-1989-3a22-b2c1-25194e40c875	7	591	\N	116
4f1fcf7c-ebb5-3daa-843a-3938c98635aa	7	32	\N	116
e179b8cc-b866-34e8-83e1-8f815a9389ba	7	1552	\N	116
110cb7d0-91a9-3b6b-9e99-4bea9cca2702	7	234	\N	116
8b67701b-2dd1-3947-9757-74fad0ceade7	7	2325	\N	116
2564d100-f861-311f-91c1-e7cde98e2bee	7	893	\N	116
a483aa00-a37b-3999-87de-c8be8637a729	7	1090	\N	116
7feb425d-5494-3da0-b78a-2b07bc35f639	7	1565	\N	116
0f9852e6-5b9c-39f4-b649-bc476e60e008	7	2574	\N	116
9be7e1cf-e50e-3b7f-9983-a1950778573d	7	477	\N	116
8b963a1c-676b-30d0-8640-28e80e0041a5	7	1962	\N	116
ef5ce6ca-c618-3799-834b-479fb7edb292	7	110	\N	116
1ef6f983-3567-359c-9e5b-b2c1daa7a472	7	1206	\N	116
70901e97-4423-3842-959f-8f6a0eb3b1af	7	2457	\N	116
07b1675f-5cc9-3ecf-be04-a1bf774367c3	7	2331	\N	116
55bb4f0c-e646-3bfe-bb47-4a234adc3328	7	737	\N	116
b8020e0f-e041-3fb3-9ded-53a2e90f4559	7	1942	\N	116
b0347abd-2b43-3a57-a947-87b88dff7001	7	475	\N	116
2715a265-7c84-3462-b29c-87bf011e5f68	7	1815	\N	116
880023e5-f32f-3118-b96d-af8e6d98f8da	7	2514	\N	116
b521537a-7134-38e6-94ae-f09d81f4c4c2	7	187	\N	116
39ac2660-2bf9-3352-b0c2-82c1a7203ffa	7	1050	\N	116
c0554cb4-f7c2-34a7-a6bf-6562882d187d	7	2765	\N	116
2c42fd46-f1f8-3d4a-afde-975679a36fb0	7	467	\N	116
9dd3d621-7f26-304f-b12a-be065f4b0062	7	1316	\N	116
6c608ec2-dc37-3188-b9b9-d484d28dcdfd	7	1159	\N	116
0d00cd8a-ee1c-30a0-8459-9632f27278f3	7	260	\N	116
5302ea89-54ef-3ac3-af81-7138199f2d94	7	889	\N	116
78f92ced-3a0a-3ecd-a1e5-4d3e86e31b3a	7	791	\N	116
3e80bb23-deb7-3bc1-99f9-dff4f2581a93	7	2699	\N	116
dfd30c63-1262-3cc2-8db5-dc9cbccc46b4	7	218	\N	116
b99f4611-8372-3f35-ba14-f6548c81fea8	7	1975	\N	116
8e35b574-f683-3e58-ba67-4c5d68a7ee0d	7	998	\N	116
948782df-c3ef-3682-9111-7aca6dfc4651	7	439	\N	116
5db72b7a-a2e2-3200-afa1-f3174b74f440	7	2695	\N	116
e6e1cdde-2a9a-3271-accb-214c346b878e	7	2267	\N	116
7b0d8176-e408-37b7-9428-7343afb527c9	7	1224	\N	116
9dcaa224-038e-3664-845e-83392400ceda	7	729	\N	116
3b28a4b9-69dd-37dd-a623-c2ebe42597dc	7	2445	\N	116
0ecd067d-ebc2-31cd-936b-55db6e48face	7	855	\N	116
decb184b-eb79-31ed-8e1e-4d87df0517e6	7	1321	\N	116
34d3cf09-1103-314e-80c4-e83a52469de2	7	2661	\N	116
29e9d758-8e2b-3627-ac6d-b07bd89371ac	7	1180	\N	116
de72e496-af33-3f2a-8b0b-cbb461cb28c9	7	951	\N	116
1eb025e3-c8ae-3fa9-a92e-c6a688b0addb	7	2615	\N	116
f33a9b04-dd59-3636-94e8-84b00815178c	7	1658	\N	116
29763614-1151-3e4c-ba4a-8be469e1be28	7	1621	\N	116
55f08ea6-b1a3-3c61-bccf-08d030d68063	7	578	\N	116
8d4d4d9e-c611-3395-88b6-bd7048f540cf	7	330	\N	116
46da97bd-6123-364b-9d62-5977ee912602	7	1438	\N	116
0142dc4e-3b91-34b9-ad67-79fd36dccfc7	7	925	\N	116
3c8cd9bf-848b-3f2d-b495-9b1183db398b	7	1728	\N	116
c70d7280-891a-37da-a717-f23c4eb22411	7	1959	\N	116
f4f82766-0cea-3803-b15a-8c1eba326d8a	7	1197	\N	116
39d1cbe3-878f-3384-aeb9-926421728b37	7	2031	\N	116
a9cef588-dada-36bf-8725-c9f1950f2958	7	2689	\N	116
60b906a5-7889-381f-815e-622970116e5b	7	2756	\N	116
bad4343d-de50-3354-af05-c932424394dc	7	93	\N	116
6f52ecdd-967f-30e5-8f0b-35bd9ffc6028	7	1134	\N	116
81941bb9-c304-328d-8eac-bd0d45ba2bbc	7	1833	\N	116
b7b16ed3-3d9b-334f-b755-3f0a0ee0c7b9	7	454	\N	116
0d35f131-325f-3d5c-a284-1b46da8686a6	7	47	\N	116
3c5ad50b-bae7-3572-8894-606a4f6d7d2a	7	1143	\N	116
f5b8055a-da6c-3c2a-a7ce-04de68ce5f2f	7	462	\N	116
0fd8beae-0e05-3c2a-ae94-a394ac8b7bcb	7	327	\N	116
089607ac-932f-3332-b7df-cbc591872cf8	7	447	\N	116
0061d991-9770-3cde-b030-6f9880142da5	7	587	\N	116
6afb5b28-606e-34a4-a62a-bdf8c451d323	7	2610	\N	116
53ed5efb-128d-330f-b5b0-77c5168d1969	7	1138	\N	116
5001631a-57e5-3c98-b443-f3fbfcac698d	7	1109	\N	116
f6c089d5-85df-3755-81ae-a566065cf6bb	7	203	\N	116
0569f9cf-4cae-3a1b-838f-4da044b1f090	7	1373	\N	116
d869bcc9-3010-397c-af2d-743bc4beff6c	7	2649	\N	116
bfd4f358-2a7d-34c4-8a65-559932e5bfe4	7	1876	\N	116
1a7fdcc7-d015-3034-b505-bce3ac799a08	7	1315	\N	116
c05e3705-5bf1-33e8-9ae5-615c000c8a5a	7	2245	\N	116
22674617-a5bb-32f1-8af8-d2a6298388e3	7	1596	\N	116
8eea48cf-74b2-37a1-83cc-306cf21a9ab8	7	2510	\N	116
ce1baa09-299f-3dcc-8c29-c38e827dc711	7	1511	\N	116
88c432ad-266e-36e7-b680-f0a3ec888bcc	7	1487	\N	116
4a2241e4-9a03-3483-965a-646d7e9c4513	7	1407	\N	116
83aa5177-0e70-3b03-a0f0-92e964e43e03	7	1751	\N	116
23449603-7a2f-338a-a971-77ad55edd634	7	334	\N	116
0c9bce82-e18a-3036-b039-f13a66376574	7	1801	\N	116
08706757-ae96-3d34-8bf9-955ee1b7c98d	7	465	\N	116
596e5d24-2f07-3644-a4da-ff6b315de203	7	2439	\N	116
d4b2c110-1c60-353d-b186-2cd8dc515e02	7	548	\N	116
49085f67-80c7-3858-9fee-8c4df6f54e45	7	2248	\N	116
55063ca9-3542-3dab-92e9-89d9705b7d39	7	2399	\N	116
d0c18135-305f-3e44-aad3-b4cac44dba4c	7	30	\N	116
4aa70bc2-c8ad-3283-ac72-a9921d5f5277	7	2385	\N	116
768ed8e0-1447-3cdb-a724-ed31397b0c3c	7	1484	\N	116
56fd9136-4414-3118-b857-5ce0be412537	7	120	\N	116
620ceed6-7d4b-3a15-b981-16cb38f89420	7	989	\N	116
d1002d3f-5060-35bf-a1af-039d5953737f	7	2772	\N	116
1b5f072b-bf8c-3a43-9e0f-db9ec252d5d7	7	1097	\N	116
7792f431-63c2-3c3c-aeaa-9c2a529464d3	7	850	\N	116
0fe5f8e0-b198-3c92-bb8c-f6a663a4d3d2	7	2798	\N	116
62bfe984-d361-3aad-ae13-1d3edc09e0bc	7	1318	\N	116
e997abcb-f0fa-339f-b78d-898fc0f7b37e	7	2820	\N	116
61466b4b-ac98-3ddc-bb01-24747d0443bf	7	825	\N	116
bee2ed54-d3e6-3666-b9b7-c734b2f89db9	7	66	\N	116
f2d2793e-2a09-34b8-b234-7cbd7eec4da0	7	2021	\N	116
7f5bbfd3-77b0-3f35-9511-cf3c719e5ae0	7	2158	\N	116
9d44011a-45a1-3d4b-bcda-118f345c0316	7	331	\N	116
a32275fd-8ec6-3f08-9bc9-a3a133659110	7	387	\N	116
73e9da83-05e3-3782-9574-eb0a95dd77d6	7	2252	\N	116
4c20fa61-cb1f-3863-b4d5-8b0e9511ae94	7	1643	\N	116
05a508a9-16cd-3a1a-8a9e-4b735c2882b8	7	2443	\N	116
947dbc58-d609-3ea8-a5c0-16a00459636e	7	942	\N	116
2746375c-dd6b-3df5-bb2f-aef85ad9aa39	7	2039	\N	116
fe99d585-3ca5-33b5-9891-805541835fc4	7	549	\N	116
4a279147-873c-349b-85a0-f7bcb6100c78	7	466	\N	116
d7758d92-4771-37bf-b38e-1d9a6587a66c	7	2444	\N	116
f6b59eb1-dd46-3719-8fe4-e9763ee5e990	7	2276	\N	116
b93b2bdd-84f0-3a50-967d-e4485d904d54	7	1764	\N	116
4f86b28e-5729-3260-a271-846d111100b4	7	718	\N	116
3e21493a-1f5d-3e40-83cb-f97d3266940d	7	2335	\N	116
ee2bc573-f7e7-3a28-a542-cee68647eb8d	7	1752	\N	116
c3bd98f7-eb78-3670-bbce-7cd7079599c6	7	2480	\N	116
c55b6fb2-8874-3cd4-9ab6-f25b57271fbf	7	24	\N	116
e14f5ad4-0339-3789-895e-9e10db4e9226	7	1352	\N	116
e5715ff5-1051-3def-a822-a95dbf542c0c	7	362	\N	116
9d599eb5-d369-3f74-a902-2298c0365654	7	396	\N	116
7b3b620d-385b-3785-962d-84f4afdb7251	7	247	\N	116
e2261555-55b8-34da-a95e-e5ec7b93e687	7	641	\N	116
bfc09615-b056-3948-a239-2d982b243251	7	18	\N	116
238fa3b0-5dc7-3d93-9044-232de9dba507	7	621	\N	116
c534a3b0-a975-3378-974f-baf7556a1b26	7	1099	\N	116
1517a7e4-7116-34da-a73e-d61cc1e31178	7	2590	\N	116
57c4c8b6-617c-3d35-8216-76ddcfae2d56	7	64	\N	116
3c5246d3-55b4-315d-961b-1ce77ca85c15	7	1471	\N	116
11f250e2-dded-37d4-99d3-f17b6bc6cdd3	7	866	\N	116
2ed9af68-0a05-3e82-b813-7c86e6698a0b	7	491	\N	116
8bf2757f-f1fc-33e8-8b3e-595b8cda948d	7	2309	\N	116
6b6021db-0484-3e4f-b396-f4fca811b37e	7	2156	\N	116
6c02ce57-ba16-3425-a6e5-e1eea6288be7	7	1963	\N	116
5121aa7c-7cdb-3f86-acc8-b0d5d8030969	7	525	\N	116
fc7b5ef8-ad39-3c7d-a3ef-475c7585b982	7	1771	\N	116
804c2e58-4812-3c6b-8d89-aa14d0c62e78	7	2317	\N	116
0e731837-6a0c-32c6-b133-d60e222f38df	7	1609	\N	116
68376d82-4290-34df-b1e1-a6dd7decf7bc	7	1133	\N	116
058aebb7-b096-37b0-a60a-400d429d7ab1	7	230	\N	116
06b7cb88-dd6b-3342-8fbf-3ee7a83513ba	7	981	\N	116
8824940a-db91-3c0d-bda4-38b8a892c707	7	1715	\N	116
0153fcb1-17ee-3533-83d9-a4fe9ff1f15b	7	1028	\N	116
ae15068a-8755-3745-8023-370879856114	7	1447	\N	116
bfb7fb51-1e1d-39ca-954c-4d7c3282417d	7	2104	\N	116
8fa5f5f4-7d60-3da6-bcb3-8807d47437dc	7	94	\N	116
2955d1a7-3762-32e4-ac0f-bfade04fc573	7	1669	\N	116
ace1feaa-0198-3e10-b9c6-c77d1faca09d	7	504	\N	116
a9bab25a-3a53-327f-81ff-1701caf0e8d8	7	310	\N	116
bf09373f-ae69-3a65-830b-01c666cce966	7	1553	\N	116
8316a701-6017-3716-9b1a-d2a16ff30eab	7	1495	\N	116
07e96056-501e-35f6-bc73-fce169d5f7c7	7	1786	\N	116
bc2a7857-6fc5-3d5e-870c-bf8269cd54a9	7	2479	\N	116
7ddc9f77-ef82-35cc-9d74-767c17f8fe24	7	261	\N	116
00b9b7d7-f813-32b8-83e8-8b3854a916a0	7	1844	\N	116
80fc601a-5305-373d-842d-f452d68eea31	7	680	\N	116
9c46ca18-f571-3906-b457-f75479faa090	7	1535	\N	116
2015d705-b43a-3a1e-991a-c5d2b9a2114c	7	938	\N	116
65097297-a943-3595-8f46-4a2618681a5c	7	1519	\N	116
72c269e6-ed83-3889-999b-174d2d1fa645	7	2544	\N	116
c5d8bd0d-ecbf-39ee-9bac-ecbaebc3d4c6	7	69	\N	116
3eeb11cc-2202-3446-a19f-4e2e7da03921	7	2592	\N	116
a4c4463c-90ea-379d-8176-9d6a9b16194b	7	815	\N	116
40e9ec13-aa15-35ec-8f81-b44928760142	7	2306	\N	116
b4c191a9-afc6-34d1-a3af-e11d7b12f4e5	7	1346	\N	116
0eb6cfa4-b8ef-37f5-aba9-acada872c9bb	7	1054	\N	116
cc2e8e25-bb0a-3e11-9a30-152e2238ad9a	7	2019	\N	116
bfdc670d-abf3-3a6a-bd12-d67869df285b	7	2700	\N	116
c554afd4-755b-39f1-9f95-9e715b97f350	7	2542	\N	116
d7e0af85-7677-3ed8-a0b2-401988fa9392	7	1685	\N	116
0a4aeef9-2368-3532-9386-25c1a9a1f6c0	7	1434	\N	116
68368899-9f70-3336-b9bf-a95408a7c3ac	7	1026	\N	116
732966aa-cb84-3023-8a78-02f430e6365f	7	153	\N	116
8ea0582e-bc6c-3fe6-ac2c-36a44306f2db	7	1280	\N	116
7e9f3ad0-3182-306b-9e7e-d825c53be9df	7	345	\N	116
f3ed5be8-225f-35ed-88d6-857e62bc2cc1	7	1212	\N	116
589ab6b7-a503-3b23-b52b-efe5ddf121ec	7	1544	\N	116
3169f25a-d0b6-365b-a975-5a637a4b74f3	7	1045	\N	116
557a7bde-c619-3b95-910f-bedc3513997e	7	2109	\N	116
fa79e2f0-3123-3491-b682-9d58e3de02df	7	577	\N	116
692cf696-f00d-330b-a31a-69b7149a4231	7	735	\N	116
8aa52c99-f274-3f8a-bbe9-91b5610ad04b	7	1952	\N	116
48fd9a70-f62f-3117-80a4-702bc87b0c42	7	2161	\N	116
a88c8dde-d3e5-3cbb-a4c1-562b208acd55	7	1664	\N	116
30c07897-cd9a-3640-ac5c-6c9ab9b7da18	7	542	\N	116
eecdc0c3-4d37-3f9f-83e7-30ba521cd47f	7	1775	\N	116
6876efba-7910-3713-b261-6712edc023cb	7	1339	\N	116
2807d19f-368a-3f14-b809-efb0d04be768	7	435	\N	116
90f5bf2f-ed06-3f6b-9d3e-7c5894974c08	7	1859	\N	116
e15302e7-d7ac-3a40-88d4-a054f2a4e5f2	7	904	\N	116
ec6cbb49-a66e-3d64-885d-66d5c5db583b	7	1507	\N	116
418eccdd-5281-3638-a645-630d4699fa64	7	623	\N	116
47defb78-7a88-3c8d-a449-1b1aeba5e880	7	1690	\N	116
8282dbc0-eab0-3152-b2a9-b30077ae9fd0	7	1082	\N	116
43ef6237-6873-3d0b-9c2b-df88e778f381	7	328	\N	116
553ee3f6-3cf2-3c63-adb2-55e6b33f7fac	7	2557	\N	116
1516493c-1152-3e17-94fb-077f53c6354d	7	808	\N	116
6be55700-5a40-3282-84c6-21c00cd42cc5	7	1636	\N	116
cc3f7b51-e22c-3b44-9f2b-e905b0761b0c	7	2755	\N	116
f2c3c333-bb93-3403-9a13-6723eacfb6b6	7	538	\N	116
b0d63edb-a398-3d5e-bed1-4c0babccd0ea	7	2091	\N	116
54c6bc89-687c-3cef-b384-d7dee17df214	7	1305	\N	116
e6297294-ee02-3f51-bf9f-bdcff7e558ed	7	2626	\N	116
ec764d71-63f5-356c-a616-6fd4b8d539bd	7	2145	\N	116
7ec3ad1f-92bf-3403-a3b1-271ab3b68fdc	7	444	\N	116
8f343b1c-7c4a-30f6-b5e1-cfd896093f2d	7	1769	\N	116
2936f234-7628-35db-9431-92e6929eaf8a	7	2558	\N	116
fe2d2084-cba4-32d3-9f74-777eb222ad90	7	1937	\N	116
27b3151b-5511-33d6-9ae8-36ba3501a5f8	7	1961	\N	116
8ec3faee-e775-3bc5-84fc-ac021329302b	7	235	\N	116
f0fb0c50-dbdb-376b-a3ba-ae6eea131b43	7	949	\N	116
e188f2d9-9a99-374b-b638-f3bf228b68f7	7	714	\N	116
2d0a5e8c-0970-348f-a8c9-1a43bf7ec0c5	7	2054	\N	116
c2bf963d-173b-3bfc-b378-e815936af5a8	7	836	\N	116
b8c1c9dc-a80f-3890-a6c0-7f79c5558df1	7	1528	\N	116
7a9f52da-75f0-351f-951e-f43468d597ad	7	2735	\N	116
69657ce2-a272-323e-b170-137bdd482ebb	7	1038	\N	116
cad23a5c-28e6-3f31-9a6b-a10d65ff5e8c	7	1706	\N	116
a2a7c668-4fa8-3ebc-8179-75711d350103	7	2312	\N	116
373276f9-48c2-3af9-9cae-cb0361fd5c36	7	2086	\N	116
06bd33b2-eed4-3ed9-a52a-5783527d5317	7	2741	\N	116
44eac828-e6d5-3172-b39d-499aa1612f9e	7	1031	\N	116
2f034ddf-75f2-3971-ad56-62f55d1e55cd	7	2381	\N	116
f1537cfd-bbd5-384e-b9bb-6fdde67a5eac	7	2693	\N	116
a8f39bbd-e7bc-3c24-867a-66fa983e5f2e	7	2779	\N	116
e15dcf77-e780-36ef-94d8-69f77e56082b	7	992	\N	116
a2e647ec-a580-3678-9b91-c5909d812d08	7	1304	\N	116
ac966e0c-0271-3238-add1-f857e1a24068	7	946	\N	116
9d7ecbdb-8c68-3add-bc50-b7893f0fac2e	7	23	\N	116
83286650-a3c8-340e-8ed6-48ca84e2ef6c	7	2085	\N	116
ee5260a6-0856-3eeb-9fd3-bba73e84564c	7	2209	\N	116
9d3145ed-14e3-3fec-90d9-4806b4a877d9	7	2182	\N	116
df4e09da-37fc-3150-95b8-e4674b5bf361	7	2628	\N	116
834561f7-2adf-3931-ba9a-f563eaaf128a	7	37	\N	116
217810c3-ace1-34e8-957a-b8bf82b26556	7	2254	\N	116
c1cd340d-90e7-361a-aafb-fc201ad128a8	7	1597	\N	116
a1b9bf8c-e336-3060-bb75-edd07b34b19d	7	811	\N	116
2a806c71-9662-3b66-aebd-386d0c83c331	7	844	\N	116
0132dddc-2d57-38c4-b73b-5770434933f8	7	895	\N	116
1bbcf02f-b76b-3b3f-9f3f-0c8c7eab87b5	7	2442	\N	116
dc4d6b9d-6f34-388c-9312-55b323aaab8d	7	2559	\N	116
5f58f13c-28e1-36a5-af9c-7034765d3eaa	7	583	\N	116
06965656-8ed7-3de8-a772-a15f54b0d1a0	7	1476	\N	116
e5d73c89-0321-3298-afc5-393b014f77bc	7	2487	\N	116
15fc72dd-1a60-3254-8004-39df1c35f4ac	7	1215	\N	116
dab01ad1-0ad4-3f23-9485-47882606614c	7	2006	\N	116
1a9854e4-54c4-3a62-a260-8b53f2f65b43	7	891	\N	116
ef89e1f8-773c-3bd9-ad8c-fd15f00fc0a6	7	526	\N	116
8bc1edaf-b067-3f52-a822-3ccee3e0c374	7	2459	\N	116
492a08a6-41d1-358d-bdce-6be6aa9b330b	7	31	\N	116
7fd92668-d8d3-3c95-ab75-c3648302d9ac	7	1056	\N	116
29ba5464-cc9c-3703-8dfc-befd926ba21f	7	2164	\N	116
cdd7530d-6b6b-37ca-ba7e-af101c845488	7	907	\N	116
00fed410-cd6d-3100-9902-a4def14f1cb5	7	2697	\N	116
f53f1cb7-864e-370e-84f1-77c511665aab	7	1216	\N	116
b0533462-fe7a-3d0e-9fe8-ecac7be23296	7	62	\N	116
0e67b451-6e1a-3ac9-879e-6c417d8f95c1	7	2716	\N	116
815d839e-4ada-3139-a92f-0815bd7c8c95	7	2518	\N	116
cb2f567d-9459-3695-9e91-af50132fccaa	7	2213	\N	116
3a207b36-87ca-3711-a9da-3dfb5a92844c	7	838	\N	116
831a0600-0992-3220-8a00-5420343ee177	7	366	\N	116
555ec800-3eff-3c8f-868d-5e5fa4132e7f	7	1812	\N	116
63ffa56a-3797-3e7f-a87a-d38fb47a2797	7	2686	\N	116
665d39f7-9d61-325e-a901-d089c871cc4c	7	645	\N	116
cbb25564-b890-3b41-892a-0cb741667fba	7	309	\N	116
dd85b113-4e58-3020-a885-45d7f437a9ed	7	2593	\N	116
8f9a2533-857e-33f1-af81-b2ea3448c131	7	1475	\N	116
8b0dc4eb-9270-3cbe-8c59-fe840bcf28fd	7	1911	\N	116
b8b54800-cd80-309e-8661-02b614caac4e	7	1424	\N	116
de2e155c-aa43-3082-a649-13c2e61b18a7	7	164	\N	116
cb6148c8-d635-31a6-bf21-c7a27a3ad4ee	7	2194	\N	116
bbada38f-3d95-38e4-a732-ed1f6f1c8a04	7	2193	\N	116
95ae2d09-979a-3230-913a-150feca69a6f	7	1367	\N	116
4f4bd876-4e8b-3230-8cd7-cadaf759fc18	7	99	\N	116
460fb48f-e262-3490-9b90-388bd1a3c725	7	2329	\N	116
aa2ab4c4-2e8f-3ee4-8b2f-8098803a336b	7	191	\N	116
71fba7c2-934c-376e-98cd-73bdfb2c9482	7	764	\N	116
29db7fa6-0e98-3ba4-a1c9-26100b70bdd0	7	2066	\N	116
63fb5d19-6a62-33d3-bab9-952398f96650	7	1898	\N	116
cc430412-1b40-3340-86ba-1a0359aa08d7	7	2260	\N	116
570f7c2d-518b-3540-b8cd-cdc021d1e86a	7	2673	\N	116
6a34e7b8-9d3f-37c2-afda-f07e84138410	7	707	\N	116
c0c0b769-1878-306b-bec7-02c528dfcb78	7	818	\N	116
33f370cc-fc9a-3250-9b67-a89a6eb3a441	7	874	\N	116
f5a9863d-c841-3ed5-b8f6-5e498bcd3707	7	633	\N	116
da273a83-64bd-399e-81ae-5c525cd200d5	7	2327	\N	116
e722615e-8c66-37ea-88ff-c4041ff9a422	7	993	\N	116
364d95c4-5164-39e3-81a2-91631b645a53	7	1783	\N	116
fe877bbb-cf8a-3878-b4ae-e6a47e12d3c9	7	1852	\N	116
b01f34d5-8584-3184-9b59-9bac264cd91f	7	1069	\N	116
a28364dd-b729-32e5-9a0c-5f1a119dfb5e	7	2012	\N	116
692e3158-bc21-38b4-85a2-931801a50ce2	7	394	\N	116
3c77a7e3-636a-3a9e-a0d7-e54dbb0c0c4b	7	2221	\N	116
22dcc169-3dcb-361f-85f6-4e020c808ea2	7	286	\N	116
651ab74c-e873-3433-b795-f1abb642865a	7	2116	\N	116
1837e0cd-c607-34ff-a469-a7333b06d4d9	7	527	\N	116
033da90d-22e9-327f-9599-d9b9713e50ba	7	892	\N	116
7ed5a323-6856-3151-b6ac-d6123eb3e28a	7	2509	\N	116
5a975330-f81d-308c-9a16-c9a34be63d42	7	1326	\N	116
e13d72d2-4b08-3483-8dad-eb6bbb6b4450	7	1093	\N	116
ec0cee9c-a586-3b8f-b78f-178529c2b8dd	7	2718	\N	116
aa9ef014-cf94-320f-9e21-1f3487b8632f	7	1135	\N	116
7a5fa384-d3f8-339a-bbb0-56b7c40b768b	7	484	\N	116
e4de5930-59a8-38bb-ace4-a76abda2b0be	7	1999	\N	116
1b546a95-1f76-33f6-8e4b-cbbba7913750	7	1439	\N	116
22b9c20b-81b0-3f04-acd1-676cbf5655b5	7	1003	\N	116
de5dfd1d-99c4-3758-95c5-7b53532b415e	7	2794	\N	116
510b548e-e081-3596-9b98-0e55179646e7	7	840	\N	116
aa0ee8d0-3fa5-3e2a-83f2-dac8d2033f08	7	2768	\N	116
e80869bf-26de-3a5a-ba76-b900158d42c0	7	2262	\N	116
a36661aa-3b9d-3c16-a3ed-f195e96a6f97	7	2028	\N	116
1af32c38-e871-30fb-b2dc-ad66274ebb70	7	930	\N	116
614c0aa8-d000-3439-bfbc-3ceb0951eef2	7	2423	\N	116
c495454e-7562-35f6-9400-5202636445bb	7	219	\N	116
ad468ba1-cd0c-31de-a35f-9efb3824a774	7	380	\N	116
f95eebb5-960a-3300-aee0-b70b9e56c809	7	2696	\N	116
8326e13a-90aa-3bc5-b271-7b79a955ac43	7	1503	\N	116
203d2044-6137-37ea-8d82-8c0853bba7ae	7	2575	\N	116
5503b0b0-b286-3610-a34e-d9c373eccd3a	7	308	\N	116
4f7802cb-a4e3-3a6a-8335-8e049a2ef09c	7	1223	\N	116
8573bc8c-d305-3ce0-ab38-f671e5aa9d15	7	1295	\N	116
d3185de0-b40c-34fc-9593-720910ab9aff	7	1353	\N	116
e0eba088-9752-378f-9264-44cfaddaab22	7	1376	\N	116
58d5f9cf-c99b-30f3-b86e-42e2b1303c25	7	1453	\N	116
84c4dfd7-df62-3b48-91f2-f63d884c3a6c	7	316	\N	116
c380673a-7b93-3a02-a91f-032388f6e1a2	7	2284	\N	116
1f5a83ce-c726-3bbc-a255-38b318c0546e	7	2041	\N	116
0bb2362b-27d5-3ea1-b4d1-992872749d0d	7	107	\N	116
1fe6d5f2-71a4-3206-b1f9-3c3839eaa295	7	2627	\N	116
dbefafc5-ea32-3f56-9082-d296237fbcf3	7	2492	\N	116
a79b5c93-a38c-3933-8566-b98f2c1ef8c1	7	2389	\N	116
ab633de1-d33f-3595-b9c3-c4ed1934246d	7	2015	\N	116
64e1836d-71be-3774-b30d-73855468aecf	7	2461	\N	116
6a276631-b92f-392c-bd58-6d73ecfe5034	7	678	\N	116
357e3cee-c48a-3c2d-a600-60112ca12549	7	1851	\N	116
fee98c12-b8a7-3b50-b621-3ecbb3ec38f9	7	1477	\N	116
db35be7a-e7d5-3290-aea2-cb44241215e6	7	109	\N	116
625a275b-c4fb-3146-a1f5-9dc0d1f9f777	7	2826	\N	116
cf339489-64d2-3f5e-8a40-ccef7e45fa77	7	1574	\N	116
48fa04b6-d753-3234-8cec-b2aa05d5dc2b	7	70	\N	116
8dfc8c38-35af-3657-96d3-58b8237d7292	7	2704	\N	116
881cd438-c0da-3bc4-8852-5c9f0ca8825c	7	1667	\N	116
a0823660-5982-3d2a-b657-84691bfb336c	7	1320	\N	116
4001058f-30cd-38a0-a90d-ed1a2ebfc5d7	7	1792	\N	116
9f894a91-7106-3123-a6c4-3a553b80788f	7	1524	\N	116
c54e1879-a7b0-3877-94a5-d001ddeaa3c1	7	2237	\N	116
bebe598d-144b-3725-840a-ab46944ad1c0	7	713	\N	116
2f62f4c2-fd64-3cb7-914e-28f54dcc34ef	7	2709	\N	116
3a44db0e-3b61-3112-81cc-83c3c9741d7f	7	1516	\N	116
18df324b-bfe6-34f8-80f7-6d54526b6147	7	1454	\N	116
25bcf5e8-a623-3d9f-b215-26fc5726a882	7	370	\N	116
0f55eb64-eb02-3bcd-9042-a95cd67bf588	7	606	\N	116
77723673-94b4-3cd1-83db-d3c0c8f001c3	7	871	\N	116
852d247d-b121-3f7d-aa6d-1a7c11eba320	7	100	\N	116
4f50158e-0736-380d-bfd1-e0e744b6fe6d	7	1879	\N	116
6fc276c3-7ee4-3e1a-b195-54feffb31fd9	7	599	\N	116
5eabacc3-290c-33a5-a687-e0a2ba4d60cd	7	1885	\N	116
9efd9066-b582-365f-b983-00c938bd69d8	7	629	\N	116
1ec327e5-29b7-3e32-9c4b-5fb26f0797b4	7	460	\N	116
ba254c3d-bc65-3291-ae40-e20ddb13931f	7	1814	\N	116
d67864d6-f39d-3082-bfd6-1fa977c7e031	7	1530	\N	116
3fa1bbc3-c229-38ad-9255-81d6ec796f13	7	710	\N	116
3792a519-4b29-36ba-82fb-ab90111216d0	7	2036	\N	116
84172a86-56d8-34d8-8d81-7d8329a8ac21	7	9	\N	116
1a84752c-a7d0-3f5a-a7f8-3222f6bf7c3a	7	1883	\N	116
f0ab4896-53de-332b-bef8-5b8744c30ff3	7	2037	\N	116
47201160-d030-3254-8b16-9f3c03b60277	7	2355	\N	116
f85b1964-464e-3ed2-9719-3475a33ca97c	7	1634	\N	116
e570113f-4ae2-30ba-a465-223afae78c7e	7	2280	\N	116
9de4cf23-95f7-32f9-ae5b-8f5c664132ee	7	1787	\N	116
f36dc2f4-1973-3b4f-89a3-507e026b4fda	7	2760	\N	116
1f77eb19-4db8-3539-bb48-92e7fae78068	7	1853	\N	116
7a044678-3167-31e9-abed-24c38ac0a852	7	493	\N	116
2cc3d03c-2413-30cd-b23b-17b64e2c96ed	7	2117	\N	116
9e323785-6ee9-3603-a700-cad1850709fc	7	556	\N	116
6eb4f3b6-755f-325c-bff0-827220a35c36	7	804	\N	116
f728c678-3dd1-3384-8cca-eae8ef26b4a1	7	1671	\N	116
45b0e0aa-40eb-32d7-9b66-3fea735e6621	7	2217	\N	116
2bc53f4a-4694-3ecb-b80c-3565d8fb6269	7	2200	\N	116
ca9c24e4-614e-3be9-9e47-2ecad9606b2e	7	2396	\N	116
d9a2dd2d-bc93-3d3a-9037-ed36b4c89bc6	7	602	\N	116
32cdd26c-e7e5-3d66-b97e-0b3b357fefc1	7	597	\N	116
f43fe278-d017-3395-9d88-3bef9735e2e8	7	2759	\N	116
2cda6907-a866-3699-9068-c3375166d783	7	206	\N	116
a6cd7387-aa49-3a8e-853a-127db9b5ce71	7	1198	\N	116
0521cad6-dde4-3815-a2f8-95d5b05fb60a	7	2115	\N	116
e9cb82d1-946e-31e4-8bae-c3f833ef6532	7	2692	\N	116
578653ff-0381-3e29-830d-3199ef7c3886	7	2424	\N	116
082c021c-4985-3661-b6f1-7564adb8caa1	7	2785	\N	116
dc7e7672-9eee-3b2c-a928-02a53ddd1125	7	2099	\N	116
210efba3-1211-3a4e-ba1f-c7cc831cc84d	7	2420	\N	116
343a8943-630a-32af-9a47-ff08a8c7843f	7	573	\N	116
80d4b2b0-bb03-37e6-9d93-f22a3cfb6dff	7	155	\N	116
76e558ab-03db-3422-a00b-f928511e8c41	7	1579	\N	116
64187952-f82c-3ff4-929a-e81902365c8a	7	2645	\N	116
115c75ed-d722-320a-b700-a7c3fed828ac	7	746	\N	116
5f67729c-1bfb-33e1-a8e9-8a2c2d10fd48	7	671	\N	116
984a4960-d092-3d4b-8aa8-d3731683de23	7	82	\N	116
419d7e81-96bf-36ca-998c-28a2e50db37b	7	178	\N	116
5ec04612-9af9-3f68-a456-35a45aedcdac	7	2080	\N	116
76d8ea1b-a6fe-3223-b7ca-a9ae14bfa3b5	7	1854	\N	116
f2cc82de-61b9-3543-99c6-f0bfc421a90d	7	264	\N	116
8d4c99c1-3ada-35a6-a6f0-f3344ec68b08	7	1286	\N	116
f0157b31-f76e-332b-b7bd-2367cf453b1a	7	2688	\N	116
78a4bf2a-4362-31e3-a879-c31fc2f08f1e	7	1806	\N	116
6032404d-0e67-3dba-82ba-8aed2d7d4362	7	108	\N	116
26d8d2f6-8450-3221-8b2d-b7eb2177cb99	7	2390	\N	116
d74e7aee-cc65-3c4e-9392-def59137cbbb	7	2619	\N	116
1e84e3ab-7f75-3af5-b513-375d4eea065d	7	1077	\N	116
cf164c25-d56e-3d86-9f6d-df308c4d60f2	7	887	\N	116
0c7ecb09-7112-3e4c-9e6d-aa628004c435	7	158	\N	116
29340f2d-9381-3d44-8872-d91582a22d1e	7	1538	\N	116
929b9eb3-0092-3598-aa2f-ebb833503ad5	7	2767	\N	116
17a329b9-8c22-3adc-9adc-df1ac9ab7b95	7	983	\N	116
a0800a2f-beeb-3090-a42e-167281d10751	7	975	\N	116
f074e9e4-b919-3318-a83c-36116d78343f	7	1998	\N	116
c01e5fa3-156d-3ada-abec-378f49b7b9a5	7	1827	\N	116
b4d41ecb-ae06-3bce-9c59-cd2db8c9f0a0	7	1872	\N	116
a48394f5-bc41-3472-9470-847d6b60acfa	7	833	\N	116
1c3111fc-2bf9-3248-a9d3-43fd88319e9f	7	1492	\N	116
79c7eb4d-dd59-316b-bff0-b179cc9d870c	7	2774	\N	116
4068b92f-28bf-34bd-ae40-86107e0a6217	7	1451	\N	116
db45eeb2-6c9e-3d6d-914e-d0143475ba6b	7	1563	\N	116
232294ca-def5-38dd-b293-bd8cce0b3850	7	2167	\N	116
6cabc808-6c22-360b-b78e-56f36eea7fc2	7	2641	\N	116
3f1667f0-185f-3c78-9519-bcbf4af604d9	7	2350	\N	116
3ef9ed7d-9ce2-32f7-bb3b-2dd465d55ef4	7	931	\N	116
f5eb2a8a-3c03-3e3b-9231-7608416f225b	7	116	\N	116
3232c4be-19fd-3f0e-b8de-c35c8c67fac1	7	1716	\N	116
c134fa6f-b6cf-3310-9703-36e65ac094db	7	890	\N	116
069af9d5-977a-30bb-bf3c-81b53836690f	7	1102	\N	116
d5433e81-f756-3ef4-bc23-2bd570101112	7	753	\N	116
44a2d27a-1bca-3f2a-a8f0-e919fe15eb60	7	1415	\N	116
4f5e39c3-6a67-3582-bbeb-b8c81c16183e	7	900	\N	116
871bbf48-843e-3668-8af6-ca4220755c0e	7	1213	\N	116
b12faf23-bf81-38e7-a7d3-ba20f6631634	7	1649	\N	116
34d0dbe3-033c-3a0c-b855-a681d8c8afa0	7	733	\N	116
826b1898-f221-3f8f-8d38-2a1cc4d4f05b	7	1639	\N	116
0c9ee15d-95b5-3e99-b2cd-93fcbc253dad	7	1234	\N	116
a882cc81-ec40-30d5-8676-1561a9e0c640	7	1200	\N	116
d49f62de-aa51-3fb7-bc48-965c88cfc269	7	1625	\N	116
bce9aa21-0aba-34cd-bb27-599033132301	7	603	\N	116
67445393-5d49-3056-91d3-0242bb2e68ce	7	301	\N	116
46caabfd-728c-3500-b6e3-9b1116cd09f3	7	2074	\N	116
959168a3-6f1e-375a-8ed3-4b03b814d541	7	311	\N	116
affc99fa-012b-3096-b48a-829f9d47e314	7	1155	\N	116
3cc90b68-3e59-3150-99e6-e9679cb3fc89	7	2257	\N	116
d3865307-dbe4-3910-87ae-bf3920142580	7	2351	\N	116
b55c27d1-4ac1-3fdc-b615-0798700e4c2d	7	2545	\N	116
60fe4c0b-3dbd-3425-87a5-b1f63718cae9	7	624	\N	116
a2473786-5f89-36f3-89a1-b72956fd93e0	7	124	\N	116
aa5aaf1b-1d2c-3e52-b596-12fb44d81120	7	471	\N	116
01433e48-2500-3219-a19c-0b9d21f31505	7	2450	\N	116
96a1e731-b7f9-3b3b-8c7d-f3fa421ee3ff	7	1024	\N	116
32be389a-9650-3fc8-b8f9-eb93087ad8b5	7	664	\N	116
8d754da1-2d65-31c6-99a2-9fb5daf1b48d	7	1682	\N	116
8e3c447d-1a85-3e36-ac36-4d01a7f8f213	7	1626	\N	116
6941f89d-1594-3f94-a062-057bbd18ba28	7	429	\N	116
446c2497-5a7d-3209-a399-d8928db1479e	7	139	\N	116
3b7b33c1-d09d-3cf9-8e59-a0feee62f968	7	1441	\N	116
0423d8d3-9bba-3069-ab31-ea5d7128b754	7	2070	\N	116
1aa771a3-2048-364f-be4a-b06467cf533d	7	2412	\N	116
6896e96b-0bf1-3a76-b388-45902b6ed586	7	1327	\N	116
83b16341-d218-3310-a927-a288f54c363e	7	853	\N	116
e756ba84-ff7b-3db8-9296-470807922700	7	742	\N	116
edc00314-0334-3aa9-bf36-117f80be88c1	7	1523	\N	116
b80a9312-363c-3469-a6c4-ab1483cd0b33	7	1419	\N	116
cc8895ed-beca-38de-bf77-94471809cba2	7	169	\N	116
45c4cd39-cf56-33aa-a7fb-fddf0d6a0b78	7	2600	\N	116
332417f8-2312-32b7-8c3d-13bb86c8f6b4	7	1940	\N	116
fdecfcff-79db-3753-a352-26a2160474f1	7	2583	\N	116
654cad14-4eaf-386c-a157-bd42c425deb9	7	2763	\N	116
a3560a24-d802-3f7f-ba79-19b46a89529f	7	2246	\N	116
f3365b95-bdc9-31c4-b355-90066caf90aa	7	1389	\N	116
60645e7b-2507-3cbd-abce-7cf2ea3290f0	7	1672	\N	116
725f805a-534d-32e1-962b-f39b6277cda8	7	1177	\N	116
5c9849ac-f3fe-3dd1-9fb1-141f0c292ddd	7	1070	\N	116
ea06475c-f7b5-3432-a48c-54cb2eb6041a	7	2038	\N	116
a31151c7-e7a2-3b01-a986-18876fbc4d7e	7	1909	\N	116
2a3a441a-043f-310d-b618-778549d52537	7	1686	\N	116
daca33ee-c328-3e8c-a41d-179596ce20a6	7	515	\N	116
5707dff6-c77e-3005-82ae-c59fa162a7b0	7	918	\N	116
49b38744-4ebc-3803-b3d9-15a1158f1fd0	7	2251	\N	116
1b5b33b0-526e-358e-b17a-89474e8d49b9	7	306	\N	116
f50a6a05-c249-31c4-aa53-b8a8009d2ec3	7	1290	\N	116
94bf5da2-a144-36bc-9dd2-e4645c6b5cea	7	76	\N	116
6da2337a-199c-3144-816d-bc57d6aa6659	7	613	\N	116
08a139ee-3b29-3a11-bc7d-9951aabae98f	7	1173	\N	116
2fda4548-3180-3fbf-ada0-240ea1083f50	7	2078	\N	116
a65c4f91-5553-3030-bd03-587ef4e963db	7	1411	\N	116
c2259bff-efe4-3cee-ac34-be585e24848d	7	1874	\N	116
fb23fcdb-a09c-3d9a-b682-5010b24018f1	7	1486	\N	116
99085b63-c5d1-3608-8032-1dee1477e16b	7	1397	\N	116
50bc557d-a4d2-35bf-9417-90533f6c72ee	7	1284	\N	116
a50ff7d2-90c6-36b6-b3a4-e6de4c2094d3	7	984	\N	116
6a24ff24-426a-3310-93fd-00f840b0f1f8	7	2658	\N	116
c486f91a-afd2-337f-af67-6fe30094292d	7	1449	\N	116
36894ea9-aeb6-37d0-a21e-14bfff9ddf9b	7	2231	\N	116
f236e297-8f3f-357d-a3ea-e9874a9a9736	7	950	\N	116
b9651987-f221-32d0-92b7-09ffbc63b2e4	7	564	\N	116
210010bb-8831-3ab7-b56e-5e07e2d92007	7	1738	\N	116
2f0ef59d-676f-3e3d-973c-bebba5b9a469	7	1763	\N	116
d0b039aa-128b-3d86-aa8e-ec8a9ebfc9d6	7	1267	\N	116
a4945951-642f-36a4-87d1-46aea9036534	7	1466	\N	116
d7718e19-cbb8-3530-9bc6-28da7cd98c82	7	2530	\N	116
53269987-4e9e-3d18-b90a-0ba501159a42	7	1588	\N	116
e352d17b-e160-3126-b558-c6478273eaf2	7	2187	\N	116
40b3638b-b404-30ea-a51f-d4446b3f23bd	7	2813	\N	116
d0414ddf-ee72-3ad3-a6e5-18f7cb0c2069	7	2249	\N	116
12d54172-bad5-3a4b-a833-8df93298a16c	7	1781	\N	116
f39dc63c-60dd-3824-ac2a-062ed05528e4	7	711	\N	116
33f30282-51b4-3eef-9aea-4457fd1e6830	7	944	\N	116
e92e7dff-30be-3cf8-b033-7def4eae498e	7	2548	\N	116
4f7d5858-a0c1-3d04-9eef-b04de735f582	7	1985	\N	116
21e1f911-b7ea-3eab-9d55-58382ff0c25e	7	1695	\N	116
d9b40de1-831d-327b-a5a4-46535f423cc2	7	428	\N	116
8b57cc43-be5e-38fd-86ff-b044d4de0d2d	7	313	\N	116
746b9b77-81d9-3f50-8b4c-d108a0c384c5	7	879	\N	116
722aa92d-c808-3849-88ef-85b41f449779	7	2259	\N	116
34f65afe-1cd4-35b2-89d5-c9eafa2586fc	7	675	\N	116
6df117a7-07a3-3bfb-9557-da91177ef553	7	159	\N	116
7e41e236-0a75-3091-ab10-6f73c184a5c0	7	77	\N	116
44e57dc0-bf76-3a46-9132-7f5c03ab8dbb	7	738	\N	116
cb65df2c-ba60-3062-9c7d-9206b5b8ed82	7	1490	\N	116
a2b1d714-28bc-3a6f-87f4-d69c3bcf4664	7	2474	\N	116
12ddd817-71c2-3209-9bbf-1ca0895273ee	7	812	\N	116
9e535ab5-cd5a-3448-86c8-25c3b7d746af	7	184	\N	116
899fe2a8-c77e-3fc6-b02d-b90822338bf1	7	820	\N	116
cf4c9774-581b-3e58-a5eb-40e83fff1a38	7	323	\N	116
2423ecf1-482d-32b7-81a7-83f6b9fa9081	7	1527	\N	116
6569fbaf-d277-3a4e-9537-f6731dbf9026	7	44	\N	116
f733aa11-13ec-3980-bfcd-1e81c3790321	7	1371	\N	116
2f2ec956-ce61-386b-b837-74feb1ed1c6d	7	2380	\N	116
7842fbfb-e6e9-3f42-8341-e092f5ddc121	7	2500	\N	116
ddd4c460-e56e-3643-8847-016a47b92a98	7	2010	\N	116
e98971bf-f70a-3823-9eec-caf52ae88ae0	7	2611	\N	116
80dc14d5-48c7-32b6-949d-3af3de26dc81	7	2827	\N	116
c23efdc3-e18f-3dd8-911c-6e9fb63bfa9e	7	1720	\N	116
fe6ba6d1-db80-39d9-a605-727c89c18b6c	7	2541	\N	116
f9a1ed35-893d-358c-8469-3b1688c081ca	7	786	\N	116
eaa4b31c-1b91-3c24-a240-5dbe09fa1975	7	565	\N	116
1f33e673-2fb5-3ef7-991a-6e1ace24acf9	7	300	\N	116
cbef3750-1dc0-340c-a876-42853e88bd53	7	1845	\N	116
8bf2ece3-e328-3d9b-8fa9-91607b682d6a	7	1555	\N	116
94decaff-8d81-306b-9f1f-d0f3ab29120f	7	2354	\N	116
241543a5-9fa3-3916-8fc7-3795abeda440	7	2448	\N	116
a20d1ec0-65da-33c2-b300-0f54207d10d5	7	2372	\N	116
c9494673-9aa9-3a61-93f6-296aef22568e	7	800	\N	116
31400c05-bdb3-3f67-af03-c307f9e02f80	7	2508	\N	116
1f84a25c-8a82-3f36-8105-7c552f50c9c9	7	417	\N	116
c1ae3dc5-1509-3b99-a8eb-abf8b304fde6	7	492	\N	116
c0294315-915e-3e05-b6f2-f9ed58285f11	7	2035	\N	116
5cf5f83c-ebac-36fc-96a9-bac15f611e68	7	2656	\N	116
edec22ec-fc5e-37d4-89c0-5b9d40181f04	7	1522	\N	116
06388ca0-b7aa-3877-903d-7f53b05625bf	7	2112	\N	116
8af5cdef-14e3-3583-a802-d4149bfeaff0	7	2183	\N	116
5b96ec3b-996d-3403-a217-a384a0d2b91b	7	229	\N	116
b4617d15-fdae-389e-89ae-7795ccece1af	7	505	\N	116
b9037120-5bcb-32f2-9462-a55089497f28	7	2304	\N	116
86c574ce-b842-3511-bb81-b61501a1f433	7	646	\N	116
52132094-4f51-3bca-8b28-3f48eb37853c	7	2291	\N	116
db35de60-50b0-39ff-97de-4de44caed558	7	179	\N	116
f9f4ab29-0121-3156-9071-9679bf91b055	7	2620	\N	116
8df47cd0-92e4-3a0e-9aed-8896de62bdc5	7	803	\N	116
699bb7ba-e4d6-375a-8e0f-9ea04912f803	7	2752	\N	116
357adad5-0c8e-36d0-9736-131e36844d4c	7	2365	\N	116
b0b8d8e5-55f8-37ac-bd82-f5db732db20a	7	1341	\N	116
4c2f3158-8eb2-336b-8866-3cb91d33c0c8	7	2007	\N	116
c7f06ab9-91e6-3791-ab2d-6a857fb04dfe	7	1880	\N	116
438876ac-6c40-36f2-873d-bb047e8051c6	7	2377	\N	116
7939d920-d078-3ccd-9fe7-3f067a50dfda	7	1472	\N	116
a0def446-91fd-3b6f-b715-b53436396c33	7	2014	\N	116
2fe3bf65-19fe-3ea1-90f5-9278bb2456ed	7	54	\N	116
6e487ea2-60f7-3bfa-a164-26ffc3b25bd0	7	1095	\N	116
0d625090-d750-3787-b658-f37bbc490b0c	7	1724	\N	116
d508604e-2e52-3894-8966-d22e47877873	7	1857	\N	116
4a224706-901b-32f7-a257-57b690cddee9	7	142	\N	116
b28c93a9-86ff-3436-b9c5-274ee9644df6	7	2553	\N	116
b2190e56-4bcf-394d-b65c-c83e415c9d33	7	1132	\N	116
8772d2b4-77a2-31a7-98e0-e0ddb8ed2f8c	7	2793	\N	116
9482f7d2-f3db-34bb-9bb8-5df3f6acbb18	7	880	\N	116
b4908ca3-3f47-35e3-8b02-2593dd3e111a	7	2776	\N	116
86912889-a01c-3e73-8365-0adaf165a109	7	1910	\N	116
dfdbe512-738c-320b-877c-86e00d3d926e	7	1422	\N	116
ac52e4e0-c53e-3415-be54-35c22abed059	7	410	\N	116
0ecfe8e3-dd9a-3a98-9e97-deaf21b8211d	7	2228	\N	116
712172e7-34b8-3f35-92a9-30f30dd2722a	7	1795	\N	116
da2e64f1-1703-3563-8891-ec2fc3b26a16	7	1404	\N	116
660dc748-28f9-384a-8bbd-686ff6a1c242	7	478	\N	116
ce09e791-10da-3eed-8c0b-73f34b545cfd	7	2332	\N	116
9ef79374-cbc8-3a09-bf14-d337c902a9a4	7	1269	\N	116
460ca964-d413-3d2d-9b27-8b435cf376f7	7	194	\N	116
ea8ed515-5323-3b20-acb5-8e737242a368	7	555	\N	116
eef1aa63-82e5-33b9-b641-8ac5f9cb3891	7	1340	\N	116
2c7a48bb-bc57-3360-a856-2cd5b90ef0bd	7	2516	\N	116
d01ea4da-be4a-3b76-a186-9159e49b9e39	7	2799	\N	116
f414a8ba-01fa-34c9-9c65-491bfad41136	7	2472	\N	116
2fa08ba6-90bb-30bd-922a-b773c93286c9	7	2348	\N	116
62c876b9-f905-3127-b732-fedcbfe61833	7	176	\N	116
f8b023fd-6d2f-38ca-b6b3-b7ce0caf6f4c	7	1955	\N	116
c12c0389-fd14-39d5-915c-f59e79fce838	7	2446	\N	116
2821158a-adc7-3228-b247-2ed468c2bd0d	7	2561	\N	116
7b0ab995-144b-302b-a8b6-ec1a340e36c1	7	1285	\N	116
32ed99b7-51be-37be-bbfe-69aad293fec6	7	1217	\N	116
53259a97-6990-3faf-935f-587e027bfd78	7	117	\N	116
aeb3a57f-5971-32b3-9af9-5ea112dd48f9	7	1255	\N	116
97f07ae5-3a39-3fbf-aea7-0f342eb3143e	7	665	\N	116
b655cbca-4152-3468-acb7-187b0e703912	7	1283	\N	116
fe10686d-286b-3824-8a68-a84b8eefc5a9	7	2297	\N	116
edc5f5a2-b800-3661-8170-bcb116cf977f	7	1946	\N	116
c92c0a25-e313-3c8f-b816-3b8d1b57fdbc	7	841	\N	116
201f87f4-c061-32b0-b289-e7fdeb73f727	7	508	\N	116
7cfdc4c3-6d91-307c-9c13-6b931493d024	7	2806	\N	116
f2f4ec7a-9cdf-3a79-bcc3-514e985ee2b4	7	663	\N	116
f6ba6d5c-70a7-30e1-bf2c-3226af19a4e7	7	2823	\N	116
185f3153-5cf4-3549-a2ba-9dd186a06a4f	7	906	\N	116
1724e025-da33-351e-aa0c-14cf42e0f291	7	2512	\N	116
caaffed2-35f9-367f-9566-d15a690dbc17	7	1822	\N	116
7583987a-3435-3eed-9d77-5cb97e0f81d5	7	660	\N	116
e3a9ee8b-cdf6-33e1-958d-a774b16a6fc8	7	509	\N	116
9cbf46d5-5ffb-35f4-b005-dfa151b5f570	7	2177	\N	116
8e3a83c4-6392-3f89-a7fa-f578810676d6	7	1015	\N	116
4cdf240e-4f30-3d52-a71b-9efc2a53b089	7	2128	\N	116
843d3afe-f90f-3c92-81f8-45c14a2e03c3	7	966	\N	116
981d01f6-7844-3c23-b16a-cc33e5899461	7	1025	\N	116
e56da9f2-c7a1-33f7-a81a-a1b15fac9ad1	7	1512	\N	116
80415878-c39f-355d-8c24-f8398ed1a560	7	29	\N	116
a82b5512-a905-3961-a201-dec798204e4f	7	1079	\N	116
3a4e08a7-bd48-3a47-8b35-d2bd058c7612	7	821	\N	116
08ca4b5c-2825-3aea-8cfa-bce38bc42546	7	2452	\N	116
c23cd11c-559d-321f-b9ba-eda2f0c49e5e	7	1130	\N	116
2271eb47-b1fb-34e7-915a-49db5bbb259a	7	2598	\N	116
24b7b2bb-3ce5-3f35-835a-757c3876ed7a	7	954	\N	116
f95f5ffc-6015-3f7d-99cf-a4b386ef009a	7	2528	\N	116
00762e02-db56-35e0-be1e-9188b9e3f156	7	2719	\N	116
df5bb866-ff3a-3214-8039-591e190d1fcc	7	496	\N	116
ba95d8f5-9599-37d0-b281-fe1b51fdc80e	7	676	\N	116
5399934a-c680-31a3-b3f6-4adbaade9890	7	2214	\N	116
f98bd2df-d538-36b8-a6da-1a0ddc8ca1a2	7	1693	\N	116
fba418a2-38be-3a0d-928b-3d251dcef2e4	7	25	\N	116
b2cd2de8-2045-3e4e-9854-03497fb09b0e	7	1338	\N	116
eb3701e6-9544-3924-9071-272ed99f90c2	7	837	\N	116
065d6d8a-376b-3bd5-8de6-0d499e74b937	7	96	\N	116
1ea600de-87ea-3b84-a90d-b2d6cfb0a843	7	415	\N	116
125c6f49-c08a-31ed-b6d7-23c4e6bf03f4	7	2573	\N	116
40a407f7-217d-3675-bbd9-344d79e8321d	7	968	\N	116
1a06fde0-ef04-3487-889f-9af995ade6f0	7	872	\N	116
5311b00b-9d17-3628-94a8-8ebecc953df9	7	1399	\N	116
be33cff5-ad34-37e5-b3db-05f55c7c794b	7	16	\N	116
11b39e01-acfd-300d-ad26-cd82e4a1fc6e	7	17	\N	116
022858df-75e1-301d-824d-857631ad4af7	7	1858	\N	116
961ec3a7-5690-3180-b981-76f2dff06398	7	2725	\N	116
7bd95af3-74ff-3703-a26b-7e0d873f4050	7	754	\N	116
deeee9a5-6970-3634-ba1a-92477088af99	7	2151	\N	116
d8c66c00-4a31-3008-aa97-ac9e9db893e1	7	594	\N	116
fca5b96d-0e89-34cb-84ea-fafcbccf2ebb	7	1188	\N	116
c8d600e8-3cea-3e8c-a2bd-3e4fff75af34	7	1388	\N	116
dcc8e5a2-41f1-3b6a-a57b-f3f7021196f6	7	531	\N	116
8c96f709-d53c-3b3b-bc09-e47d58aaafdd	7	1948	\N	116
8b216cc5-f023-3011-b582-f6b0baf9a617	7	1448	\N	116
6a8959b8-9a64-306b-81b8-228f0c550adf	7	2261	\N	116
2f834980-5acf-38a6-8322-f6640d81b635	7	1846	\N	116
e07374cd-9f15-357b-9da9-31d7b3ff7c9a	7	523	\N	116
665a8e67-68ba-3f2a-a440-00c4dfa7632b	7	1603	\N	116
809ea43d-becb-39a2-9094-e6c7caea0efd	7	814	\N	116
1bd76e19-f949-3726-8380-b47e04f00729	7	2013	\N	116
d1e4d709-7b2e-3870-a4d6-eebfba7deaf8	7	2517	\N	116
1c17f547-525d-396c-8465-cd312af3341d	7	2784	\N	116
7a2f30ff-8361-33b8-9cc3-2d2f17547eb2	7	1410	\N	116
963bcd1d-0ecf-3876-a4ca-c0f7bc04b930	7	27	\N	116
37b69f4b-cc39-3ef0-a5fc-797bd0e034a8	7	2789	\N	116
c6c0dc4c-72aa-3341-ad93-e6b205b74966	7	2045	\N	116
e004e477-13be-3fdf-aba5-88a1ac3b459c	7	789	\N	116
fc39e5f5-2325-3cc6-a04b-b0db4a5acb97	7	670	\N	116
c1534361-7598-3e1b-93d1-05a52a71d5dc	7	1971	\N	116
1464873e-8fb6-3265-ab41-fe0486a31cd0	7	1707	\N	116
0b20d4c9-3214-3b47-b8e2-0f7bc72ad752	7	1595	\N	116
8def1ccf-563b-3a1d-aef2-eed270f89533	7	1656	\N	116
852c2f53-8ea1-36b7-9c0f-db3cd7e95606	7	2088	\N	116
44b21999-cb8a-3442-ae78-939af07f9ea3	7	2058	\N	116
f70cff75-0b49-31e3-9253-8003cd58e77d	7	649	\N	116
afbab740-df2c-3f34-8146-253d4bd1eff3	7	1005	\N	116
b721e572-bc0d-379d-9bf2-a611fb10af47	7	885	\N	116
21a2ca2e-e5b6-3647-8cac-bb43efdc0866	7	468	\N	116
4858b568-7e10-3f2c-9a6b-54ce2815c2f9	7	270	\N	116
583e2170-6247-3aa8-b7bc-343797621b3b	7	2749	\N	116
416860ec-03b0-3190-865b-199417d67ea5	7	550	\N	116
d83b83dc-31df-3827-b9cb-a335beada15d	7	414	\N	116
db87795d-ceb5-32c0-88d6-7062e3a0ef15	7	425	\N	116
4680d732-0cb7-3549-a016-480ba485ddd1	7	2166	\N	116
d4aebcef-bef0-312d-8c6b-9f9ab6997504	7	1145	\N	116
95db44f9-65a3-3106-899f-421a968f9efe	7	1251	\N	116
bb2bf0fc-99de-3982-b7d9-8ebf13c3150b	7	2744	\N	116
3f06874b-9719-3ce3-ad6d-0cea9a219da9	7	647	\N	116
bf4c19ef-315f-3bb1-956c-aa733d5a089c	7	2662	\N	116
29b35fb6-2cda-3347-8930-181186f2d6d4	7	701	\N	116
8ca379cd-dcd7-3cf5-a8c2-5b06a9a4d2a7	7	759	\N	116
0834aee0-63d5-333c-83aa-57a4ab8713a9	7	977	\N	116
10fa116f-5bcb-3df4-830b-3c491d71f9c1	7	1420	\N	116
696cfa74-80ea-3eff-9d7b-76a1d154237b	7	787	\N	116
e85eb242-a700-309b-a892-7a8779313073	7	884	\N	116
96cb78a3-2ef4-3653-8b28-d1552b6eaab2	7	677	\N	116
9438bcc6-397f-321b-824d-5610139e27f5	7	1311	\N	116
dcba8e38-6ddc-3c5c-8417-18e3247dd213	7	1749	\N	116
f80392d3-2d3d-3c92-b2c2-057ecd89cff4	7	1916	\N	116
1766c357-41f7-3401-9772-fd527563073d	7	1700	\N	116
78710c2a-f0b2-36ca-95a5-a2a074b02779	7	2788	\N	116
8f26888a-4e5d-330a-b496-45fcb63a1e52	7	913	\N	116
c928b96e-2f7a-3076-ba56-c2d2168cbc53	7	255	\N	116
0beba8c5-2cec-3615-8c0f-6be8ced8cd63	7	860	\N	116
46aa6722-8fc7-3fdc-aa35-2d406f1f6212	7	1869	\N	116
ed545042-7142-3c51-aabd-38f185e8a0f3	7	1721	\N	116
46c8b1af-38b6-34ce-a5b4-eccd4520a1ea	7	1168	\N	116
34febf4e-ba0b-3b31-a228-8c22c6b6f588	7	625	\N	116
57960386-14d5-3d93-aa7e-ae209f0389b2	7	1951	\N	116
cec1afa8-809a-3805-b881-9f771c51b621	7	2731	\N	116
167e4196-faff-31ac-aa5e-4d105b42d7d8	7	2024	\N	116
86230c2e-466f-3137-92f8-34901ce94b48	7	321	\N	116
868b1d5f-20f6-3a54-97a4-e5280ee35377	7	2782	\N	116
770fbc21-1cbe-3adb-9e15-6592ae2deb06	7	150	\N	116
cd0565d5-4c12-38c7-a072-2914e1bb584d	7	1436	\N	116
29302a97-ed33-3e00-a75f-cce275234547	7	582	\N	116
0b7576bb-c5a6-3bd2-bf19-9907bed89c9c	7	423	\N	116
a9a7dd3e-fb67-37d8-aa67-67e30accdb8e	7	1802	\N	116
eb177fb7-31eb-3b67-a9ae-a486fd6ed94b	7	2638	\N	116
082dab2a-ad77-36ef-8b50-b4d45b59345c	7	1124	\N	116
a96606fe-7ed8-35e5-a2d0-c1e29f98474b	7	104	\N	116
86108787-5922-3ff3-acd1-d62fb96d0071	7	209	\N	116
0ef24058-b7e1-368b-983c-2dd67c8edd8b	7	795	\N	116
afdab264-cd88-319b-a7f9-d4d37d0c24d2	7	1298	\N	116
646521bf-5933-3241-8087-2a5f3188452d	7	1644	\N	116
f9f7df9b-b8a1-36fe-9843-4db8c16be7b1	7	1572	\N	116
164e987e-172f-3de9-908b-aae823d4a079	7	1662	\N	116
819cbcbe-e39b-3749-b3bd-adf23e916bed	7	28	\N	116
b09d61b5-8cb9-33bc-aefa-a81c49d81973	7	1731	\N	116
7dbb6a08-f6d8-3b21-8588-c7ab83a713b5	7	2490	\N	116
ba1f5900-6f14-3612-ace6-00232ab322d4	7	1967	\N	116
541d652b-a2dc-35dd-88a3-21c6f73977b9	7	440	\N	116
a2b7203f-535e-342b-9265-3c91014f1a74	7	2141	\N	116
6d67ebf8-499b-373a-9cf4-3511795cf679	7	1080	\N	116
9b2a3039-a0ba-324b-b4dc-5543b585144f	7	706	\N	116
95ecb439-8907-3c5b-9577-541536256e62	7	1357	\N	116
3a8ad1e0-839a-3d20-b4d2-de9dd7cc4436	7	1924	\N	116
c2c9bb7f-fc7a-3949-92b7-5b742f208e84	7	319	\N	116
3758d692-1ab2-35af-8b95-1929f1abe3bd	7	2341	\N	116
974a33c5-8207-3d35-bce5-f5016503c227	7	2337	\N	116
863ed0dd-e74d-358f-93b4-533535753462	7	648	\N	116
aa910957-4ab7-320f-9089-49c3be9940f0	7	2435	\N	116
ffe7a118-db7c-349e-8be7-d04d15c51689	7	371	\N	116
ebe17ef7-0127-3131-b3b9-7bd9a2cf1c1e	7	1589	\N	116
6da7e4cf-5c7b-3436-b28e-af461dce5ed2	7	1444	\N	116
b7e5a21e-985c-3129-b243-06eb2727b082	7	175	\N	116
96140d44-b876-3cca-a5d9-9da2dd849c24	7	2417	\N	116
6fe368da-a54b-3aa3-ab12-f1b9c95d83ae	7	1235	\N	116
2b633105-e1c6-368e-be44-679d076c02cb	7	1331	\N	116
44670e22-64ac-3acb-83f7-ca3d7932a2d0	7	1576	\N	116
9ff929fb-b050-31eb-a158-fdff669df54d	7	1793	\N	116
df3051e4-9a17-3a34-a8cd-0b1fe1e890cc	7	1508	\N	116
5ff66a13-9185-311a-b29c-13d5cef2be88	7	592	\N	116
ce04a9fc-ea99-324d-b60c-9f6b723bab05	7	1335	\N	116
2a112065-2aaf-374c-8ae0-a6cb8b1bd95d	7	1723	\N	116
b475b6e8-5887-3ffa-83c0-e37e5dabe742	7	809	\N	116
bd72b9fe-2808-336c-aee9-3c3c5c3ecec7	7	2391	\N	116
ce95e135-e7c5-3b7d-bd71-5948970491bd	7	822	\N	116
2d374988-9bc6-33e8-949f-05e811d2c1dc	7	2146	\N	116
ea86f265-4921-3c31-afc3-eefecc5ed901	7	2436	\N	116
6d199a47-f073-303e-a26f-ac7881a31533	7	1813	\N	116
55013c4e-420d-3033-a18c-d6ca7f36ef5f	7	1847	\N	116
eb479e62-67c8-3140-b6d7-4def5726b7ad	7	2065	\N	116
307e9ef4-593c-3996-9fa0-5a21e98f52ba	7	1714	\N	116
a28c72d8-76b9-372f-ad35-bed37dceb925	7	2126	\N	116
d862ccae-83a8-3d14-bced-96980e13790e	7	934	\N	116
be38cd21-29c4-31c5-bb3e-f89dacdfa00a	7	1182	\N	116
6d81bd79-0c23-35ff-93ec-85f6ff9c4b2e	7	873	\N	116
84f985a9-fa22-31fa-84b0-836fee649ebc	7	612	\N	116
e40e4c1d-5bf0-3c2f-9aec-f01a962c2643	7	1181	\N	116
fdc63cad-9e77-3c10-bf8f-a1de1808fe7f	7	2025	\N	116
7201e6fe-68e6-3d31-9e83-aa7fb6c0be04	7	1260	\N	116
28012fc2-1418-3b93-bcba-34fd593d349c	7	2105	\N	116
5e7b5541-8146-37f4-bc3a-e7bfc55590c5	7	2519	\N	116
36f0c169-8c53-391f-9b99-e11bd6041cc0	7	743	\N	116
0a55f31d-4d4b-38d3-8f45-d395c7bf5d16	7	2384	\N	116
4e047675-e38d-3ab1-a2f1-f483895ea14d	7	540	\N	116
68471e47-6659-38fd-95ef-003e09d7cc17	7	395	\N	116
3a03d1d1-e001-3e1b-9a55-401c04a38c61	7	2189	\N	116
ac01053a-5aac-384e-923a-437c3da05e02	7	2289	\N	116
dfa7a941-51a8-3d60-936c-716ef54913a5	7	1567	\N	116
86039437-bddb-3192-9052-097d25132766	7	568	\N	116
904962f0-cd28-3ecd-b5c6-70bf450eae36	7	2240	\N	116
5c8d18d8-4a3a-33a3-9151-a3a3e3b96282	7	1653	\N	116
b0e8560d-b998-3ca6-a863-7cb74bff2ac1	7	126	\N	116
63db46e1-e161-36a5-b9d3-2ee98922d938	7	1199	\N	116
15c8d639-203b-3c0b-95f0-22269128fd42	7	2324	\N	116
651a9621-1718-3211-bfa8-550c43031176	7	1755	\N	116
c40fb334-f653-3480-b555-9dcb81cadefc	7	473	\N	116
d90dff1c-7278-3eb0-9566-f9c507b1b217	7	1068	\N	116
17ecf289-c0ca-391d-bf04-81488739f14c	7	1008	\N	116
506df6a0-ab1b-36c8-b86c-285c882438f2	7	129	\N	116
9230ce19-7991-3b42-b8b3-18372febe93b	7	78	\N	116
8abb4db6-8094-39ed-b833-4300c48b2a18	7	1347	\N	116
f0f69663-40b4-3689-8bea-8e8e47d0f9a7	7	2139	\N	116
6d6ae084-65b7-3e80-af29-09b4b94050eb	7	2488	\N	116
1d2a73a8-84c9-3c13-aa3f-863a66a3cd4b	7	2205	\N	116
1391ced7-ae40-3429-a897-ad20f5b5a8b8	7	367	\N	116
22cf2173-fffd-3769-b482-0142c3c3a787	7	536	\N	116
96a9a350-8137-3050-9173-20257fc73fa5	7	2754	\N	116
00c32ebe-ab15-3970-96e3-7493740b5f3c	7	202	\N	116
3d1cbc95-c274-3030-8b49-81c371362cc2	7	1455	\N	116
7abf6ed2-26c0-330d-ad39-e3fc6c5ece33	7	2582	\N	116
7bc188e5-6f80-381a-b5bc-dce67ef37895	7	2503	\N	116
e9fa8f25-8bbc-3100-ba2f-85f227582501	7	1659	\N	116
6198d87c-999f-3ce4-a137-06562b5d785c	7	458	\N	116
9f046d20-e80f-34ba-9cce-85eeafee7094	7	1568	\N	116
1a585468-e7c2-35e6-8f7a-f2333923110b	7	2670	\N	116
d108e4f4-2cc1-3eca-963a-e841b03e97c1	7	1936	\N	116
8ac67f6b-d464-34b9-a8bd-7d6937a28f59	7	628	\N	116
e7038d95-fe53-32fc-8880-d0c0cead4e83	7	2120	\N	116
0a97c6d7-f510-3138-9589-26294e994f98	7	2062	\N	116
9175185a-5116-32a3-a3f9-1fcc9610d07c	7	2154	\N	116
a779ba0a-8c63-3dd6-9796-daa5e0e34b93	7	65	\N	116
cec2195d-ca28-3b18-8811-dfef3523de20	7	2562	\N	116
27882304-2c95-31a5-a28c-dcc81e08de53	7	2292	\N	116
09139d60-3f85-3d45-b4f5-d9302893f702	7	41	\N	116
3c32a1d4-91b6-3c5f-909b-4ba20c001b33	7	1939	\N	116
19cf3e68-3372-30fa-8138-bb992a250855	7	2026	\N	116
2066f9fb-ba0a-3931-9a83-5d5c2146a48a	7	750	\N	116
5896580d-4dc6-3779-bcd4-6ec32db5f287	7	771	\N	116
8e8797c2-36c6-3daa-8871-80997785e146	7	773	\N	116
ffc0f0a6-97ba-3346-900c-58cc3a4b0433	7	1425	\N	116
0409b854-8d28-3fc4-af58-60837243a4a9	7	1245	\N	116
8d494879-9270-3b18-98a1-0b9114609906	7	1032	\N	116
004b9fb0-cbcd-386c-9fd3-0c8b592cacbf	7	2308	\N	116
cf786f0a-6bfb-394f-a31d-a2b95b4a7ba1	7	1360	\N	116
feee7b5d-5b11-3ba4-9287-02a69a886bdc	7	2162	\N	116
6fa65d3b-6eb3-3815-8798-a13b252e7830	7	2478	\N	116
3b1a8adb-79e1-3c5b-9395-58dd0deba66b	7	2034	\N	116
c34a72f1-f1b3-3414-a8d0-0b3a9c54de9b	7	236	\N	116
071b9baf-79dc-300b-8f84-d3bbe7b6d6e2	7	978	\N	116
ba1738b5-9331-3e44-81b3-b4e3ed4f8487	7	1083	\N	116
f489832a-59ae-3c47-87ba-886838f59540	7	2071	\N	116
0ae221bf-ee2a-348b-b587-ce55c9b1ec93	7	574	\N	116
6e83d310-225d-38f6-b4ac-8c0a27f70b3f	7	1577	\N	116
45c0da85-7d57-3ce7-9304-323b90ae281b	7	2393	\N	116
68d17e1d-29ba-3d17-96b8-8f43baa4cd14	7	2422	\N	116
268a3562-46fe-30e4-bdf5-9e9610af7e8d	7	575	\N	116
d456d23a-9cdd-3276-934b-b64ccb150356	7	1149	\N	116
2c07373c-830c-3963-b1f5-ddc5e787ae3a	7	336	\N	116
6302a323-3b32-35b0-8ccb-e3ae512ad0f1	7	1458	\N	116
eb022dd8-52c2-3e2e-b9ec-f8ae464c9263	7	720	\N	116
348c08c0-6df2-385b-93c9-9fde2f49d42c	7	1270	\N	116
3789e5a8-dc8d-32a4-aad4-8e357fea65c1	7	2683	\N	116
477a9837-ff37-302f-a14c-e89d8e7a448d	7	1840	\N	116
847403f9-2d2a-3a43-bab2-b91eccf7da9d	7	845	\N	116
c5e6033e-e181-3d0b-b437-366fa8534c0f	7	911	\N	116
075a7434-eaa1-3e5b-b6f2-627c4391babc	7	2781	\N	116
e5c2c9ae-bb98-317f-bef9-2fbf8250a9a6	7	778	\N	116
810888cc-ba9b-395e-b90d-83a682aaa736	7	2051	\N	116
15c1c2ad-89d0-3d72-9418-913f81950c6f	7	2023	\N	116
9bd0f497-f57c-3339-ad2e-fbb7e099d141	7	1816	\N	116
325ce7a7-90ad-3e1b-b747-a4eb5095dd89	7	912	\N	116
f4c63818-85cf-3293-b727-50a0c097a78b	7	1101	\N	116
e3d96319-ca71-39d9-a324-235ccf75442a	7	1972	\N	116
363abdb2-b71e-3522-bd9c-0769d57c4cdf	7	552	\N	116
a5261bba-376c-3ad0-b9bf-542f43f29223	7	1796	\N	116
24961f31-ff7b-31df-80f7-910505ade398	7	2498	\N	116
472106a4-eb58-33ad-9814-b3ee28b6b2dd	7	71	\N	116
9c9a9e91-589c-3937-bc8a-b9aae0841d82	7	2569	\N	116
48a4d0c9-8974-3e5c-bf73-429805cb12f2	7	450	\N	116
93e0e4cb-75c0-3d20-bb5e-b74c40739f4d	7	1573	\N	116
1c8bc9da-68b8-3ef0-ae73-8e05216dc8b9	7	2392	\N	116
0b8943b4-1a3b-3d7e-91a7-2e3fc5a7b2d6	7	1055	\N	116
b50d8c9b-b02b-3a19-901d-f09eb9ff91e4	7	2343	\N	116
c03950f3-1a44-3390-aad4-cfa4a0a3df26	7	2465	\N	116
4217be9b-7baf-3512-95d0-51f89d94b27c	7	2238	\N	116
01390087-09d5-3da2-afef-1799b9067abb	7	1272	\N	116
4459c343-ff33-3c1e-b89d-140d8ff7512d	7	1798	\N	116
cf9d7241-8766-3f3b-9a2b-130c33cfab54	7	610	\N	116
7ef6ef7a-a528-33a4-a628-e60ec1fc9f67	7	1273	\N	116
db6b70bf-9a3c-34b7-88ed-cf401d864920	7	1973	\N	116
c7ae3cf5-3004-3b01-9951-c9887fe1bc59	7	342	\N	116
58598ed7-8dea-3aef-9ec9-7a3eab9b5038	7	1110	\N	116
cfeb6355-cdc8-359d-ad78-edf964842ce9	7	2370	\N	116
2007fff0-add2-3c69-9fd9-02c797ec92fc	7	111	\N	116
b59cb902-c78c-36cb-8608-cece2ef9af7c	7	1839	\N	116
7e1b6be3-651d-3d21-8106-0236b68b529c	7	1710	\N	116
cceba197-0b23-3f14-9c12-380063927496	7	2137	\N	116
b469d955-56b6-31b7-a0f1-822aa3502fb7	7	2195	\N	116
56f0a69a-8656-34c9-a3b3-06d9008c1357	7	839	\N	116
ef299acd-0d8f-37b5-84ce-34c3be527775	7	1532	\N	116
aea10983-2feb-3ee1-80dd-ec7b54d8dfea	7	2449	\N	116
119d95b7-037e-3d9e-9f12-8b6b13567dea	7	2653	\N	116
bee07529-31f3-34a3-83cc-41218b6d22a8	7	1932	\N	116
f048a08b-d09d-3d1e-8b49-135356070908	7	237	\N	116
f46182fb-f808-32c5-ba29-ad9392f4e2cf	7	2703	\N	116
e0a09aa0-b12e-3caf-b826-343103b1ca9e	7	1418	\N	116
b39605dd-46b6-3a73-9035-7352dd04c2da	7	1835	\N	116
f755865c-9034-3912-b4db-58f5d05efad1	7	1875	\N	116
392bec79-26b1-31d2-ae35-86669919fd84	7	802	\N	116
d7c428dc-2f39-3157-8afb-ef3e494abb4c	7	529	\N	116
5b4ecbf6-7a7d-334b-a99a-66af112f0bf9	7	361	\N	116
28cf574c-4c0f-3710-9f4b-41525c21eba0	7	636	\N	116
f04ef510-95a8-3c1d-97a3-0b81cbaf00dd	7	2597	\N	116
4c7707bc-3803-31dc-8545-1afc83ce966c	7	2580	\N	116
ec8282a8-4c59-3f61-a32b-4e8e27f35ca3	7	307	\N	116
72aa80c1-0fd4-3f87-857f-8e0664f09718	7	499	\N	116
07cfdca2-2506-321b-bf93-d1c9a936dcea	7	134	\N	116
2ab5c1c1-c283-398b-bbfc-b17ee2453c2d	7	2294	\N	116
d9ab69cc-38e2-3184-80b7-314c00143b10	7	1622	\N	116
d73d1532-01b3-3755-961c-0a1b69cabd1d	7	2792	\N	116
0168fb5c-3201-35a7-af41-14d9a86fcaa9	7	2095	\N	116
5d24d797-48bf-35f6-b679-bf419198eb20	7	1452	\N	116
b5d5f148-3a10-33ff-bdfc-d820e9c03e13	7	2271	\N	116
6558f76e-144e-333e-ba16-b360626faa1f	7	630	\N	116
2d01ec49-49d3-309e-bbcf-1aab7af66a7a	7	553	\N	116
9dbe472a-9059-3637-ad2c-b00b6066829c	7	52	\N	116
4bd10b9e-c41e-3724-9b15-0707a0f9767c	7	2809	\N	116
32bf85d0-02e0-33a4-ad0b-18faab31e16b	7	883	\N	116
8115b9c3-2aad-34f9-bc50-e5757a93dc72	7	2371	\N	116
608321a1-743e-38f5-b9e5-9d4ca7caf6bb	7	1991	\N	116
0cf40a62-7502-35e0-b0d0-5d91c405e074	7	2383	\N	116
37e0c599-cd68-3877-b481-1b2fd2a53e95	7	1788	\N	116
315dc95f-2e80-3db9-9cdd-fcc2af610d39	7	1877	\N	116
fc4e120c-d714-3a7d-97eb-8ef8c65ac730	7	1722	\N	116
49cd6bb3-3c14-36ed-9d28-100f50fe141e	7	1641	\N	116
0bbd2c58-711e-33e2-bb60-331d2470b856	7	1186	\N	116
88cf2ff9-d5d2-3d61-b477-5e9733c9ec37	7	163	\N	116
eeba9702-32e9-3056-8dea-0731b09e7ac9	7	1310	\N	116
2a4684ad-77d2-34f7-999d-dfdcff0a2727	7	1349	\N	116
4391cb2d-5793-3cb8-8d17-8e2fadfeda33	7	1683	\N	116
ba0d6637-e888-39e0-aff8-7a1efc5f0257	7	1980	\N	116
d32ee145-8d87-387e-a107-0180ca6349a4	7	2409	\N	116
6c5bb9f2-f0e3-399f-a3f4-8a4ece48ae1f	7	674	\N	116
be5c4136-b4e5-366f-ac7b-1803d761e2c9	7	2526	\N	116
ae470bab-da90-3bef-a205-301676905106	7	1601	\N	116
339c2683-c56b-3b68-bd24-cde5777c7fa3	7	348	\N	116
a985a451-ddc5-33b2-bdd9-d2a940cd6d3e	7	512	\N	116
bd024f36-f478-31b1-91b5-56cd14b08c7c	7	2018	\N	116
d3713366-1ef6-323c-8293-4ff872ee8b0f	7	2067	\N	116
3dd384a2-8266-3234-badb-d66b91d2cce0	7	1988	\N	116
23b22461-a475-30f3-be93-2c8bdea9de13	7	2196	\N	116
16aa0292-5615-3e7d-94fb-3bc588e19c1a	7	373	\N	116
a21bec31-801d-3784-84b3-dd2fed8985a3	7	1023	\N	116
6079a9d7-295e-37cd-92e3-e645c6e23ce2	7	1893	\N	116
7aba8061-ab6e-32aa-ae00-cb2740079713	3	1630	\N	117
c4c47cd1-1707-3e93-bc98-0f28430aa06e	6	1121	\N	118
de442646-1c6e-3954-952e-f53f4cbe2b3f	2	657	\N	119
69ee75dc-5274-3cfc-b203-3ddca83cc5b5	2	238	\N	119
9327df0b-91d8-3d33-82f3-ab66ae4b6077	2	1166	\N	119
9bdede24-2965-3acd-84dd-ffe7e85a3ab3	2	60	\N	119
0e0e717e-f0bd-3bab-af2d-148346baa228	2	974	\N	119
6c1bb558-fa9b-3075-88f8-953ae7b46ffb	2	2353	\N	119
0e893e7a-676d-34ee-89f7-3ee755f8a587	2	312	\N	119
d1ad071e-90a0-31c2-9c9b-c34ab8ec93e2	2	79	\N	119
8b3cf6fc-61f0-3c03-b63d-f02626198505	2	2319	\N	119
8a213eed-05bd-3af8-a47c-3831149f28d6	2	2130	\N	119
a52eb76e-8e5f-3c80-9517-a5cf4bdfbb0b	2	1009	\N	119
b3da1441-22a5-3c46-84ce-166d4deb1d3a	2	2313	\N	119
78e4412b-b521-3057-9440-8829e37861ec	2	726	\N	119
dc59aec9-d4c7-372d-adc1-4d5210517b8e	2	338	\N	119
54e0a848-2072-340f-a34e-c9f141f69aeb	2	258	\N	119
54da2f5d-cebe-3c8a-bd34-51839380173d	2	2632	\N	119
25d0df7f-db45-3493-90dc-df655c5bdec6	2	90	\N	119
cae1beaa-d6a2-3dd4-80a6-9012aba0ae54	2	696	\N	119
19325b01-21a9-34b6-b00e-f3caf48ef488	2	1161	\N	119
7ee69b50-ee88-3cae-977e-2c9f537afb34	2	901	\N	119
24f0d14d-00a2-3ec6-936d-4dd82684fdeb	2	2738	\N	119
4f888e73-7776-3b00-8aa3-27f54d0a9815	2	2511	\N	119
d15d8f8b-5451-3f28-8f43-ccb1f3efcc77	2	1542	\N	119
f0d62de1-931e-30fd-a20b-7b66f043d641	2	1920	\N	119
9d7d8375-9227-3ca5-9bcb-e6098ad2263d	2	472	\N	119
f7da8f35-0578-38e8-94fa-6482d431753d	2	1174	\N	119
27aabfda-a68c-370e-a787-435aae38b82c	2	1242	\N	119
8ff41393-7d0f-3d70-b51a-95e03ab65a52	2	501	\N	119
67bdbbf4-3306-3b12-8a55-281f5539ab6e	2	618	\N	119
2aec744a-844d-3526-94ae-e3371cbe4bfd	2	762	\N	119
7168440e-5b9d-3385-bf07-deb549610aab	2	2467	\N	119
087c5a92-43b9-3e01-a7bc-338d22c8c070	2	1263	\N	119
9b79fe42-c314-33c0-9781-b30477f24378	2	681	\N	119
44e818a4-d3bd-3770-9157-6007fab47097	2	917	\N	119
2591201b-6b54-3a48-b56c-e32459ecc781	2	180	\N	119
14ae4949-b436-3e01-879a-27139283a918	2	1051	\N	119
cea24dfb-5dcf-39c7-9c53-0cae7339dd9b	2	2434	\N	119
e8a07555-1468-3f45-974f-c83eb04e795d	2	1986	\N	119
6ad48bd3-00f8-3917-b462-491b1b5e38f5	2	857	\N	119
91319772-812c-38d5-913c-20a70728f87f	2	10	\N	119
3a5c31ad-b84f-3c0e-9361-7b7e36085e2f	2	2639	\N	119
7f8880c1-7de7-30e1-9b74-d677f165f5e7	2	2122	\N	119
24dff44d-926c-36b7-b286-4a95b15fd315	2	402	\N	119
ac2fca35-027f-3572-a708-8b48df765f4a	2	346	\N	119
3148b052-540d-30dc-aacd-97c449dcd8ea	2	598	\N	119
6fd2d8ff-27b5-3541-b288-7455c67842a0	2	2258	\N	119
4b696b1e-2a86-3d02-a958-9a8a23bc788c	2	1178	\N	119
9f9069bd-c1f0-3111-b1e0-a3320ac63060	2	2170	\N	119
64eefb9b-cb95-3d2a-bfd5-056d74a72af5	2	2298	\N	119
06c1c440-bc84-31b8-b612-05df209534ee	2	1557	\N	119
2ff105e0-61fa-38f5-9d8e-5974f867f27b	2	1175	\N	119
3c99b98c-f7f8-328d-8479-7488ff42f13a	2	761	\N	119
c8bdb17f-2a0a-337b-a52c-efa9a27947d8	2	1510	\N	119
412dc773-3829-3518-929a-0e0dfeb33d17	2	631	\N	119
14a1115f-e5e6-348a-90f6-f558c4aa2155	2	955	\N	119
c81dd282-a907-399b-825d-4b5cdf03551c	2	2208	\N	119
1514e9d4-636a-392f-b148-3acba6061ce2	2	1261	\N	119
0bfc6e46-5ee7-3f93-a642-19179e9b6cfe	2	2401	\N	119
cf5df743-b4b6-3f84-b9d0-56819503b5c2	2	86	\N	119
22a492a7-0452-3e38-abea-2615f966000a	2	2775	\N	119
d68e9207-aa6f-365a-86d0-0f3697957beb	2	2576	\N	119
a51290d4-4f4a-31c7-bba6-0a8d22f3a205	2	1612	\N	119
9106eea2-8108-3c0c-a691-8d6ea4353cc3	2	546	\N	119
72276343-74db-37e5-a245-fe8b0bd879fa	2	2571	\N	119
e53de623-e7aa-33c1-957f-1e0f57f32880	2	2131	\N	119
9c0fa814-5ebe-35fd-b270-93c9ac2c65cc	2	1842	\N	119
5b028b6e-c974-3c02-abb9-b4bc164ab1e8	2	1925	\N	119
2a26f746-c553-34a9-9784-9ad62c31abaf	2	398	\N	119
2ea9685e-a2e1-396b-b7ae-c66e4005e583	2	2373	\N	119
3f3e993d-4c77-3e51-93b3-d3ac3b880ea9	2	869	\N	119
4f627715-c753-32d5-abea-f29bc5252c1d	2	2181	\N	119
262a1004-7c34-3a5e-9947-669aad5c3cf8	2	1380	\N	119
77b2feeb-7117-3c20-a75d-3ec458dd67a3	2	1342	\N	119
00be3c9d-fe7b-3b81-96eb-1a3b56724076	2	859	\N	119
2bb5fe80-68b2-3daa-8b7f-dd612dc49523	2	58	\N	119
6b4c845d-825d-3244-a316-0cac86416675	2	294	\N	119
3f752511-ee9e-3f90-982f-2685ce999f74	2	2362	\N	119
9c9a5cde-ffa5-3499-8baa-0fdbe2e32a61	2	1225	\N	119
24b6ca0e-d106-3e7d-9ccb-8162a1f76e1a	2	829	\N	119
37779217-44de-331b-8750-6450ee3891db	2	1900	\N	119
b3100b68-cde4-3879-a359-77312e662cc1	2	2605	\N	119
b11d2baf-117d-32fd-9e95-9701d0d8bec6	2	1259	\N	119
eed8cffb-1d45-3a6c-a873-b5d5c70f5882	2	162	\N	119
0e32d976-c4c8-328f-97ae-7ad796dc9d62	2	45	\N	119
42070d0d-eab9-3ba2-b8d4-806de3412e05	2	152	\N	119
151a7200-9410-30b6-abf3-2059013953e7	2	702	\N	119
b974dadd-60d1-3c2c-be25-fb0a679eb05a	2	145	\N	119
114347cd-d38b-3770-ac6a-65dc4971044c	2	329	\N	119
32b971c6-c79f-3599-a529-c5e9567e3e9f	2	1106	\N	119
c4f1c53d-48d3-3a63-8fc3-8326c6a704c6	2	708	\N	119
dc02ea4c-7706-3d20-8c92-f0f0b20de9d6	2	909	\N	119
2868fc52-fceb-3d95-a9a5-90bc67a33c94	2	1929	\N	119
2bf6ce86-2c6b-36e7-9d1e-531ec8ecf0fa	2	2110	\N	119
bc87f631-50b4-3c45-9dc3-beb56c994804	2	589	\N	119
7e1a0620-555d-36a7-8da5-2a0d8227e63b	2	1797	\N	119
8a460946-a413-375f-ad01-60c160d5ff69	2	1189	\N	119
cbae2fea-50fc-372a-9073-4453c91bc0a4	2	2745	\N	119
739f2d9d-5928-32f1-8ae7-3ee364c4b151	2	1343	\N	119
b4584926-2ec5-34f7-a30a-e2f5e104ccf9	2	748	\N	119
1a208aa8-0327-3732-8dd5-11843697ecb8	2	776	\N	119
849823cb-303f-3370-89b7-44a627eb10bd	2	2493	\N	119
13037ab6-8893-30a6-84a9-11fe66b3e51a	2	1730	\N	119
5c2ff173-e2b3-32f4-b881-4c295ea018ac	2	2180	\N	119
7af2846c-bc09-3a59-9b39-e8691bc669bd	2	2714	\N	119
fd0a483d-a5ec-3fed-8600-292ade476d2b	2	1610	\N	119
d6e3d581-bf02-3c4d-aa8d-0a12b9b68e1d	2	2400	\N	119
0327c6ec-1371-3aa4-85d7-f044fdd02a78	2	533	\N	119
63f98392-9b5a-3a6e-a4b5-ce25b63e7679	2	1732	\N	119
1f89fb5b-cc44-38b4-b36e-3073a74ac8d1	2	1606	\N	119
66e0600f-c5af-3e11-a227-82c975a0f62b	2	760	\N	119
b8f7ddb9-5e0e-328c-99b9-6c869a35d4bb	2	204	\N	119
40db8c5d-853d-3225-a5d1-266c30c7a105	2	257	\N	119
30cf41fa-f765-3618-b6f9-68b04a43d753	2	2684	\N	119
26aed27a-f981-367a-b72c-2b6ef8d7c9f6	2	1417	\N	119
071c171c-e550-39ea-9bac-2041280260ea	2	801	\N	119
f9694abe-a1eb-30f4-8be0-99deb50269bc	2	2579	\N	119
034653cc-bd82-358a-9744-323f2bc063c1	2	393	\N	119
89b1f167-c94d-300e-bced-ecf1c81b8715	2	769	\N	119
10372624-8eee-319f-9ace-3f0c0b8aa41c	2	1718	\N	119
d6affd6a-27cc-33f1-bca7-b1cf1672b12f	2	2601	\N	119
55f19b0b-2cf8-3a5b-82f6-edc820c0022d	2	2640	\N	119
1e1ae033-0c8a-3ab1-9a2d-3372a1254db4	2	2454	\N	119
449b6270-11f4-3185-9066-941bd71a6b51	2	2484	\N	119
b1671fb3-d3f7-3be1-9d33-561a549e1ec7	2	299	\N	119
7ef9d866-6170-3baa-a891-14ee4914a302	2	1691	\N	119
3a3cdaf1-d072-3b24-b84f-384e8fa3dd56	2	2634	\N	119
0ff17205-4589-3996-bd6b-10fead8cd1c3	2	2800	\N	119
bc0a56fa-dfaa-3d07-8162-4e0b71f4a68f	2	2462	\N	119
7fb75962-4850-319e-a219-e7d678517564	2	2495	\N	119
f2522b07-a712-3418-8f82-7bb8c97f8b81	2	1608	\N	119
71b1b51c-72fb-3bce-b02c-1d24728ce755	2	684	\N	119
0335e4c4-51ce-3361-bf39-1a1ed1aa05e5	2	2318	\N	119
e6b31394-5fce-3536-8489-620afea7aeab	2	2359	\N	119
687aa175-aafc-3d51-96ef-6c6ef9c345b8	2	1063	\N	119
dbb26b4e-a918-3c73-bb6d-ae415538a9a1	2	988	\N	119
54b2ad59-8646-3059-b2e1-6f5b893090ee	2	2730	\N	119
06fc6b9b-2322-3157-a26b-db248c84cb9c	2	131	\N	119
24ce6a4a-5747-3476-b019-51ee2642bad4	2	685	\N	119
a16bf48c-c670-3578-9bf8-e305bddb59f4	2	1773	\N	119
918d02c1-7c59-32f4-956f-b0091ab2bf41	2	1317	\N	119
a2dcccef-1ffb-3167-ac21-af587d89bc3a	2	2415	\N	119
7490ee38-1558-3ae5-88a6-b1d3138f87c4	2	2148	\N	119
90280734-8584-34f1-aeb4-033e14cf9759	2	262	\N	119
66bfbe79-a242-3f79-b1be-30dd56b74ab9	2	2326	\N	119
946dfb33-68ea-3d45-9c3d-0a2d9e235029	2	420	\N	119
86134942-bce9-3ff5-b5a3-0feccb4eca56	2	1463	\N	119
8e958465-27e8-3674-9263-b82f7bcd6707	2	1218	\N	119
7d4730a3-7db1-3ab1-8073-a9dd8e6cfdb6	2	374	\N	119
f71c2fca-18ab-3ed9-934e-ee8943f42a97	2	2083	\N	119
897f9b6f-eec8-3524-961e-3f2920ba9b1e	2	1502	\N	119
b208b399-4148-3673-9c31-6d05f5dfe059	2	2642	\N	119
781714b6-fea5-36b6-9f05-a47581d09153	2	2229	\N	119
ed324983-6ad9-3640-92fb-6918ecb76a73	2	1646	\N	119
b29ee330-29bc-363b-a5ab-848626546768	2	303	\N	119
c703f47d-7bcb-3e9a-a0e4-580eea33882d	2	1887	\N	119
72baa961-0626-3fd0-98f1-46877fa11649	2	1111	\N	119
206360b5-420b-3b16-ac6b-2c84cd00641b	2	2199	\N	119
cbfb2e0e-6fc6-343a-920f-9e506ec1d9e8	2	128	\N	119
09aa1aba-aa17-39b6-8134-b1e8a4ab0a81	2	2491	\N	119
71a100a6-b252-39c8-9ff6-4f9328c57628	2	2100	\N	119
2f8216cb-f7e7-3420-bf4c-c45a9f26d944	2	963	\N	119
ff217e82-ece9-3b62-871e-37ba39562d13	2	68	\N	119
00d29387-d921-3d44-9dda-6ea35c446f7f	2	193	\N	119
46987444-fc68-34aa-be15-fa74e6a398e9	2	2098	\N	119
b9793179-7ff3-3c4a-8d8e-7b556d138e3b	2	1629	\N	119
41196274-55e3-3199-8742-448e92c4e5c0	2	1139	\N	119
3db462b2-0afe-380b-b5de-6d585c6e8732	2	1873	\N	119
ad1fce16-48a0-37b5-bdd3-25505343c4b8	2	994	\N	119
6756c091-f9f5-3393-bbca-e5df7da15f42	2	446	\N	119
a7617e5f-3339-3793-80e8-1d161646ccc4	2	2572	\N	119
0ff7553e-c779-3d4c-88a7-973d98a986b9	2	1917	\N	119
a8d93757-7cd8-3b4e-b967-575393bf7274	2	1014	\N	119
d2dba12d-9702-3c8d-be57-7aa2bf100822	2	1994	\N	119
af63d206-1185-3cf0-9eca-aad73a124467	2	1987	\N	119
5c03771a-dda9-31b5-868c-2dbf595a75be	2	1176	\N	119
29bd8c21-7843-3be1-903f-e974a0b9b340	2	558	\N	119
ec49d342-4484-3ad1-8a21-76c171744bc6	2	2361	\N	119
8390f4b9-7530-301c-8b7f-04fd5c4e6c0e	2	2589	\N	119
e18580ec-1e6b-379f-b5a8-16d23a443ed7	2	1142	\N	119
583abf5e-dbdb-35a2-8e00-08b2415e8655	2	1119	\N	119
3b4b6b2c-94ba-324b-b380-8205b7ce5136	2	2226	\N	119
59a79e5d-2fba-3ac8-823d-bf7866010712	2	2629	\N	119
7b3dc8fb-8d3f-3cde-95e0-0b22d72cee4a	2	1651	\N	119
541e6110-e173-36e9-a982-16073c27ae17	2	640	\N	119
f925f145-34ea-3f42-8757-a7e3fad34cf1	2	1989	\N	119
0fc35fd5-76e4-3c35-9e94-3d6cc17168b1	2	637	\N	119
3cd274ea-2bb6-3c42-bfda-f1bb676714e3	2	2242	\N	119
8c006b38-3f04-359a-9f3f-9d9c59221fa9	2	1328	\N	119
e7483629-b1c0-322b-86bc-954d8533534d	2	2330	\N	119
e8bd16ea-bf45-3a2d-953d-9ca9951107d8	2	2094	\N	119
0fbd49e4-f2ea-3e3e-9d34-ef59e5984e42	2	1	\N	119
9ce8531b-d334-3bd9-9fb9-a5260032095d	2	1209	\N	119
9a63f5b3-d6b1-3556-b6a2-921b32d69d1f	2	1733	\N	119
cd3f61dc-ad39-30c0-a9f8-7f305b7d4ed8	2	537	\N	119
9292e8fc-9881-3d35-8c39-da48aab79611	2	2125	\N	119
f68137fc-cccc-3ff0-a9aa-e9e254b69415	2	543	\N	119
545c4d3b-a101-3181-8249-a8cd3602e68d	2	2111	\N	119
3e4a540c-46a2-3541-967f-85bde2c368d8	2	1978	\N	119
55affa9d-24af-341d-ab34-67560fe7e7d5	2	2265	\N	119
b8e915c7-eeac-3684-a16c-daf63022dfda	2	212	\N	119
3e6fbb7e-c28c-394a-a365-2f102fc1a920	2	1114	\N	119
bd2edc56-041a-37b4-aa23-e6d9d1977067	2	1855	\N	119
21bcb696-9fc1-3705-94cf-3ece7e42a04a	2	2227	\N	119
5726628b-a2f9-324d-9119-2f6d4edd4ac3	2	1748	\N	119
9d256443-313c-3324-ab71-dead6b806732	2	1040	\N	119
b1dd6d80-232e-356b-b809-8f073dfa2704	2	2333	\N	119
145923c4-cef7-3413-b2a5-79bb836a6979	2	1103	\N	119
a69c3d15-cc91-3065-9ce1-1c4d8606dc77	2	2382	\N	119
e549bedc-6462-3e7b-a1ff-0874bbc0a2b1	2	263	\N	119
f437a343-895b-3a33-b76e-a2ad0e560c9e	2	1483	\N	119
934c9d7e-c760-3083-a5b8-b605afa324cd	2	50	\N	119
67639e35-bebe-3f4e-81ae-edfa56551163	2	2017	\N	119
5daeb089-3ec7-3670-be27-3ea889366616	2	181	\N	119
9f7d9065-fd0d-3809-a4ad-96dd5fe90429	2	1000	\N	119
1180f485-ea42-3735-8217-3c2f7e3f08dd	2	2747	\N	119
5820b73e-8041-3745-a753-06d6ac30de72	2	1628	\N	119
a688880f-42be-3365-b80d-c4eadb6d9a11	2	1042	\N	119
dbcde4a9-6cd1-3ec3-af0f-0b6b49be1f9f	2	1536	\N	119
41f7e74a-8982-3658-a9ce-cdb8d7d74332	2	570	\N	119
22703a8c-01dc-36dd-91a1-947a1ebd8808	2	960	\N	119
f17484ee-dafe-3e4e-85ba-3eeadb2cf86f	2	1545	\N	119
615de138-514e-3633-986a-8b507c982796	2	1194	\N	119
8af34c94-d34e-37af-88ed-3d9886ee3e50	2	1602	\N	119
500dcb8d-27e0-3ba9-892e-c6bc2ec7bc7b	2	1214	\N	119
9904e7b0-b32c-3a70-8bcc-68b00fce9de4	2	770	\N	119
4d830caa-71a8-3e33-a71e-4f09f326c662	2	1158	\N	119
6de783e6-94e3-3fcb-9269-8081bfebf5e6	2	103	\N	119
63248b24-0f68-3176-8efd-f0d81445014b	2	1221	\N	119
b8988303-92f8-31b7-a289-72319ba77d84	2	557	\N	119
60d6ec63-0c35-391d-a0fe-bea7903a3534	2	95	\N	119
38575dce-26c9-3013-8a11-ec60905e6214	2	232	\N	119
a5a8141c-d7c1-3ec4-b716-97a60aae9354	2	287	\N	119
27ef3903-0699-31fb-b0d6-377fac6ed7ac	2	118	\N	119
f09c3aa1-00bd-36e1-b7f0-6c9458b15668	2	1075	\N	119
240b58af-a005-3d56-b3ea-33c127b78391	2	2075	\N	119
02a5521a-c05a-3a98-9071-48882a6a5d11	2	1412	\N	119
8d2dc437-0fc0-3cde-b29e-4ecbf6aaf72c	2	474	\N	119
6d9c9f95-783f-37cb-95d7-792c0963df84	2	1120	\N	119
734769e0-e0c3-3cd6-ba5e-cd987fea0150	2	322	\N	119
e27f430d-509a-354d-aae6-8ccb802ce210	2	1765	\N	119
a5df3b7e-1c8e-3b05-80f8-2b91baa75175	2	1013	\N	119
d7105196-f84c-3a05-867f-74a6bc586e4f	2	335	\N	119
8c4cdee9-8be3-318e-adb1-94c9064e6898	2	207	\N	119
0b704d90-f113-319d-af10-55bb5f57c7e4	2	1832	\N	119
1b7291bc-ff05-3b3f-b73e-7e0743a064cc	2	354	\N	119
5fd178f7-3be5-357f-aa0d-615112d2525d	2	2764	\N	119
6edba7d3-703c-30a9-be09-773a4673e8b3	2	1692	\N	119
f841f74a-fed0-3856-ae74-1fd3c1925cd5	2	862	\N	119
790a27a3-8f70-370a-a83f-feb8ec3d3f27	2	2311	\N	119
b0345520-1307-3a35-b61d-572462ccbdff	2	2537	\N	119
92cc3c6c-51e4-39eb-a14a-36cfe90fe7bb	2	495	\N	119
d0b1adbc-5ff3-3917-a4e2-c1f8d428545d	2	980	\N	119
a40f41f1-cce8-3f92-88bf-619edd6839c4	2	5	\N	119
7f0e2e01-efa5-35f7-b4a0-841b140b10ce	2	2277	\N	119
a3aa668d-e9b7-3e96-bdaa-f35b3873da17	2	1170	\N	119
6a51e0fe-10dc-3e59-9f57-59d81c562d5d	2	1012	\N	119
e24e1fd4-3392-3c48-b5c5-fa01fad5772d	2	2241	\N	119
3eeae942-e490-3ca0-9761-234f3642d0ce	2	26	\N	119
753499de-3211-3959-a866-c5ac111ba3b8	2	174	\N	119
0b9a0db2-3645-38d8-9d4c-6058a047e413	2	2418	\N	119
c6f943d3-ad90-3479-a7b2-2f3b1fb4c20c	2	1607	\N	119
d1a753c6-0829-32d2-b798-a1e076403b93	2	2428	\N	119
2d417d48-bd5c-36b6-a1c5-c3ddc2cbe0e4	2	2795	\N	119
bf61203a-e232-3413-9d70-495884d7e97d	2	719	\N	119
a5c23e45-297a-383b-b191-38c9ef303a82	2	2736	\N	119
0e90d905-cfb5-30bf-9814-029a39110762	2	1345	\N	119
66330e9f-942f-3667-8969-f486ebf71f28	2	1296	\N	119
167d792c-6f6f-3ef6-97c4-b5c92a817f20	2	1402	\N	119
46f8d940-0099-383d-95d0-fb852dde9080	2	406	\N	119
815a1126-b4c0-3532-b0ed-c97be30b8f48	2	698	\N	119
26d99d87-2604-3346-9524-433db9a13acb	2	2550	\N	119
c352b252-208c-31da-b2a4-d4be8ce88d8c	2	1034	\N	119
293f5609-d7f9-3909-afa1-1e755623bcbf	2	1594	\N	119
62c9f7f3-aba3-348a-a6b5-1aecf509ca86	2	1074	\N	119
a9cccc8a-9fff-3fbe-9849-a0f166f2f280	2	1757	\N	119
b0f0399a-de35-3ad3-927b-62278302593e	2	1018	\N	119
f30c8d37-c420-3a48-a5c9-ca773aa1c1c1	2	1248	\N	119
826921f4-4b23-3f42-a99e-36e49c909992	2	2211	\N	119
debe8078-7421-3cea-b525-a55216b626bd	2	736	\N	119
966a00f0-f642-300d-aacc-010a826be3f9	2	654	\N	119
29240d5f-9cff-3427-be6e-710149abb6e0	2	2663	\N	119
ee4381a9-3d6b-3504-ac89-cf9c3da33d28	2	1687	\N	119
af1e7bb4-328d-3030-b8bb-dcbd199d61b9	2	2121	\N	119
9fc63103-b537-3cd6-b0f8-de156fa78c53	2	1423	\N	119
fc33a19d-305e-31e5-b296-00125b9e6dbb	2	1393	\N	119
acfc4393-5a5a-3095-a5ef-3e7fd9926e87	2	2539	\N	119
8f146771-0ab4-3fac-b7a9-27d7b32fabef	2	2676	\N	119
ee836b5e-78b5-3ff6-bb04-4bd0a6aea24b	2	541	\N	119
a0dc024c-95ea-3a99-88e3-2fd404fcba34	2	2092	\N	119
cc11adaf-fb80-3626-827d-658542a1f040	2	1739	\N	119
e8ae7f01-1409-3b55-b16b-c41e40cfc137	2	1171	\N	119
9035f72d-28aa-3193-af96-21e6eda7a702	2	2047	\N	119
5867f830-25d9-3835-92f0-a22a832f650d	2	1365	\N	119
88596e72-10bc-3c26-b297-da79556a2991	2	1561	\N	119
4bd84d0b-e173-3141-9d17-7339e2e377e5	2	882	\N	119
a4ca7a53-7ab2-394b-8135-2a4d0ec7ca2e	2	2671	\N	119
c0fb1f57-441c-321c-adb8-abaa2f1b7671	2	1637	\N	119
85cf4bf0-cc57-3bf4-b790-4a3ca2799875	2	852	\N	119
24711fb9-732c-3018-9ca6-2dd05987854f	2	941	\N	119
f15a378b-767e-3652-bb90-af10c09503a7	2	2746	\N	119
3e4f8ceb-b0f0-3109-8062-53d2ee031611	2	2606	\N	119
bd7452cb-4229-36b2-8997-655584d56f61	2	1729	\N	119
fd28e900-42e3-370e-85fe-838eced7775e	2	39	\N	119
91fdfdce-12c9-33e8-aee3-4b7bba6ff44a	2	208	\N	119
7c372b4d-2334-3886-8cb3-8ade42467bba	2	456	\N	119
022e6848-35dd-3f2b-b89d-5c49aba7a18a	2	343	\N	119
4edb66e7-e24a-3e63-a7ad-a27f938f2580	2	2089	\N	119
a780b931-feb6-3817-aa55-eb1d6a524dc6	2	2339	\N	119
74b97760-da8d-3019-952a-564d9af6bffe	2	2272	\N	119
8d74f96b-fef0-32e6-92d6-a0cf65e94276	2	272	\N	119
b0b6367d-2806-3e84-962c-1c4226976e53	2	1611	\N	119
be358333-d43e-3c53-879d-2a9dff8235da	2	185	\N	119
590683bb-0c8d-3c7c-b6e1-d55bb934c180	2	1309	\N	119
3037d03a-b177-376f-b2b7-764d867fcdb4	2	1995	\N	119
3f1f9d60-ad75-353a-aa2f-8d7becabd4ce	2	33	\N	119
86a07ab0-a601-3e90-8794-6e5fc7464264	2	1344	\N	119
167af97b-9825-3934-93d5-9a657639b2f1	2	1866	\N	119
6858ebd0-8293-3269-86f6-c5878590d605	2	2432	\N	119
b47ed9e4-5749-3606-87e5-178bf2313bd7	2	1934	\N	119
b5a517ee-9026-3e8a-a807-f3064fe3174d	2	2190	\N	119
186ad00e-ad8c-34b0-b856-cbcdaadbe54b	2	2801	\N	119
7c702ed4-0c89-3b5e-974a-6bc58c98790c	2	1446	\N	119
006c6486-41b6-37cb-8694-c8ef4140048b	2	455	\N	119
1f7fe5a1-23c3-3e0b-879e-d73f411b0624	2	1935	\N	119
463a8731-c0bf-39c6-a695-f72f3746cb99	2	314	\N	119
2f3e4700-8267-301b-beed-2e25f414e8fc	2	1163	\N	119
fda4a471-c14e-3a04-96ed-8993f913bebd	2	2108	\N	119
8dbd258c-75f4-314a-9da3-69f79648effa	2	2612	\N	119
ab05e8b0-89c7-3f67-9296-4781a538248c	2	375	\N	119
5734f6f8-8572-3681-a2eb-c429f9cc9c0c	2	2614	\N	119
d4b8c32f-5276-31fb-8100-1911f6db490d	2	2279	\N	119
e442da75-a64e-3e6b-8b4b-f35afe149b67	2	388	\N	119
9db306d5-c337-33a4-8536-895092526ad6	2	1647	\N	119
898abd42-3338-3cec-95c4-a5c3b6ded017	2	722	\N	119
302ddaf5-449a-37b2-897d-923ef8f41175	2	91	\N	119
4cc1ee00-77fe-3e95-a284-6f0ee57c2128	2	383	\N	119
b8ef78cd-eca2-374a-bf00-764e110b8b25	2	823	\N	119
91138413-1f2d-3e0a-8bff-36b75512dd2a	2	1288	\N	119
570d7dba-570f-3790-bef7-81530c85d32f	2	1382	\N	119
a27f5273-c4bd-3840-af86-ffa0084c86da	2	554	\N	119
11f88b4e-53c3-30d4-a95e-8a3319dd6f58	2	1941	\N	119
fbe1be7b-82c1-3887-9e93-03f3e50513f0	2	991	\N	119
fecc8721-3f2f-3589-bb5b-6ec7616d4c5f	2	604	\N	119
8a447b0f-ac59-3744-9f47-95ed976ff2fa	2	284	\N	119
7d45a0eb-2de6-3e2d-be73-062c86cfb55a	2	1274	\N	119
ee6def46-16e0-37fb-8496-24f5785d0e1b	2	488	\N	119
3a7b5eda-9f64-3100-847a-2386d3cf8e96	2	926	\N	119
a498c75e-a2a3-3e02-94b0-01b50e5c2e4f	2	1072	\N	119
d84fa8aa-57ce-3571-be81-3758a3cd2ba2	2	424	\N	119
5cbe453c-cfac-3f2f-9463-3fadd86e4179	2	1348	\N	119
1eb3e2b1-d184-30af-97fc-a131727cea40	2	1521	\N	119
\.


--
-- Data for Name: criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.criteria_set (id, url) FROM stdin;
\.


--
-- Data for Name: contextualized_termcode_to_criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode_to_criteria_set (context_termcode_hash, criteria_set_id) FROM stdin;
\.


--
-- Name: context_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.context_id_seq', 7, true);


--
-- Name: criteria_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.criteria_set_id_seq', 1, false);


--
-- Name: mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mapping_id_seq', 1, false);


--
-- Name: termcode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.termcode_id_seq', 2828, true);


--
-- Name: ui_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ui_profile_id_seq', 119, true);


--
-- PostgreSQL database dump complete
--

