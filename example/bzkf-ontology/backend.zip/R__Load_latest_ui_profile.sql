--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;
DELETE FROM public.criteria_set;
DELETE FROM public.contextualized_termcode;
DELETE FROM public.contextualized_termcode_to_criteria_set;
DELETE FROM public.ui_profile;
DELETE FROM public.mapping;
DELETE FROM public.context;
DELETE FROM public.termcode;
ALTER SEQUENCE public.criteria_set_id_seq RESTART WITH 1;
ALTER SEQUENCE public.ui_profile_id_seq RESTART WITH 1;
ALTER SEQUENCE public.mapping_id_seq RESTART WITH 1;
ALTER SEQUENCE public.context_id_seq RESTART WITH 1;
ALTER SEQUENCE public.termcode_id_seq RESTART WITH 1;

DELETE FROM public.criteria_set;
DELETE FROM public.contextualized_termcode;
DELETE FROM public.contextualized_termcode_to_criteria_set;
DELETE FROM public.ui_profile;
DELETE FROM public.mapping;
DELETE FROM public.context;
DELETE FROM public.termcode;
ALTER SEQUENCE public.criteria_set_id_seq RESTART WITH 1;
ALTER SEQUENCE public.ui_profile_id_seq RESTART WITH 1;
ALTER SEQUENCE public.mapping_id_seq RESTART WITH 1;
ALTER SEQUENCE public.context_id_seq RESTART WITH 1;
ALTER SEQUENCE public.termcode_id_seq RESTART WITH 1;


--
-- Data for Name: context; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.context (id, system, code, version, display) FROM stdin;
1	bzkf.dktk.oncology	TNMc	1.0.0	TNMc
2	bzkf.dktk.oncology	TNMp	1.0.0	TNMp
\.


--
-- Data for Name: mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapping (id, name, type, content) FROM stdin;
\.


--
-- Data for Name: termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.termcode (id, system, code, version, display) FROM stdin;
1	http://loinc.org	21908-9		Stage group.clinical Cancer
2	http://loinc.org	21902-2		Stage group.pathology Cancer
\.


--
-- Data for Name: ui_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_profile (id, name, ui_profile) FROM stdin;
1	TNMc	{\n    "attributeDefinitions": [\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "value[x]",\n                "display": "value[x]",\n                "system": "http://hl7.org/fhir/StructureDefinition",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/UiccstadiumVS",\n            "type": "concept"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21905-5",\n                "display": "Primary tumor.clinical [Class] Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMTVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21906-3",\n                "display": "Regional lymph nodes.clinical [Class] Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMNVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21907-1",\n                "display": "Distant metastases.clinical [Class] Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMMVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "59479-6",\n                "display": "Collaborative staging post treatment extension Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMySymbolVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21983-2",\n                "display": "Recurrence type first episode Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMrSymbolVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "42030-7",\n                "display": "Multiple tumors reported as single primary Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMmSymbolVS",\n            "type": "composite"\n        }\n    ],\n    "name": "TNMc",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
2	TNMp	{\n    "attributeDefinitions": [\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "value[x]",\n                "display": "value[x]",\n                "system": "http://hl7.org/fhir/StructureDefinition",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/UiccstadiumVS",\n            "type": "concept"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21899-0",\n                "display": "Primary tumor.pathology Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMTVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21900-6",\n                "display": "Regional lymph nodes.pathology [Class] Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMNVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21901-4",\n                "display": "Distant metastases.pathology [Class] Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMMVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "59479-6",\n                "display": "Collaborative staging post treatment extension Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMySymbolVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "21983-2",\n                "display": "Recurrence type first episode Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMrSymbolVS",\n            "type": "composite"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "42030-7",\n                "display": "Multiple tumors reported as single primary Cancer",\n                "system": "http://loinc.org",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referencedCriteriaSet": null,\n            "referencedValueSet": "http://dktk.dkfz.de/fhir/onco/core/ValueSet/TNMmSymbolVS",\n            "type": "composite"\n        }\n    ],\n    "name": "TNMp",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
\.


--
-- Data for Name: contextualized_termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode (context_termcode_hash, context_id, termcode_id, mapping_id, ui_profile_id) FROM stdin;
00ff2423-1967-33d8-9cdc-86840cd85492	1	1	\N	1
8ffbe92d-dd80-3107-9e4c-336508fb7761	2	2	\N	2
\.


--
-- Data for Name: criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.criteria_set (id, url) FROM stdin;
\.


--
-- Data for Name: contextualized_termcode_to_criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode_to_criteria_set (context_termcode_hash, criteria_set_id) FROM stdin;
\.


--
-- Name: context_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.context_id_seq', 2, true);


--
-- Name: criteria_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.criteria_set_id_seq', 1, false);


--
-- Name: mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mapping_id_seq', 1, false);


--
-- Name: termcode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.termcode_id_seq', 2, true);


--
-- Name: ui_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ui_profile_id_seq', 2, true);


--
-- PostgreSQL database dump complete
--

