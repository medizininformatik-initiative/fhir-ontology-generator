DELETE FROM dse_profile;
ALTER SEQUENCE public.dse_profile_id_seq RESTART WITH 1;
INSERT INTO dse_profile(id, url, entry) VALUES 
